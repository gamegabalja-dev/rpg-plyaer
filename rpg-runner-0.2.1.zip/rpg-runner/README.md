# RPG Runner

안드로이드 폰에서 **RPG Maker 게임**을 실행하는 앱(APK)입니다. 게임 파일은 들어 있지 않으며, 정식으로 구매·보유한 게임 폴더를 폰에 넣고 앱에서 지정해서 씁니다.

| 게임 | 엔진 | 실행 방식 |
|---|---|---|
| The Witch's House MV | RPG Maker MV (NW.js) | 앱 안의 웹뷰 + NW.js 호환 레이어 |
| OMORI | RPG Maker MV (NW.js) | 〃 |
| Fear & Hunger (후속작 Termina도 같은 방식, 미검증) | RPG Maker MV (NW.js) | 〃 |
| The Coffin of Andy and Leyley | RPG Maker MV (NW.js) | 〃 |
| Yume Nikki (유메닛키) | RPG Maker 2003 | 앱에 포함되는 EasyRPG 웹 플레이어 |

> **현재 상태 (v0.2.1)**
> 첫 빌드(v0.1.0)를 실제 폰에서 돌려 본 결과: **Yume Nikki와 The Witch's House MV는 쾌적하게 실행**되었고, **IB는 끊김(랙)**, **The Coffin of Andy and Leyley(TCOAAL)는 한글패치를 넣었을 때 `default language missing or broken : English reinstalling`** 메시지가 나왔습니다. 그 뒤 **OMORI는 실행이 안 되었고**, **마녀의 집 MV와 IB 모두 처음 실행할 때와 장소를 옮길 때 랙**이 있다는 보고를 받았습니다.
> v0.2.0은 스위치 홈 화면 느낌의 새 런처·표지 이미지, TCOAAL 오류 추적용 호환 기능(zlib·crypto·스트림·파일 핸들)과 게임 폴더 구조 로그, 게임별 로그 복사 버튼을 넣은 버전입니다. **v0.2.1**은 그 위에 다음을 더했습니다.
> 1. **OMORI 로그 분석 반영** — 올려 주신 폴더는 설치된 게임이 아니라 **복호화된 소스 프로젝트(OmoriSource)** 였습니다 (`Game.rpgproject`, `editor.json`, 평문 `data/*.json`). 이런 폴더는 제작자 쪽 설명에 따르면 PC에서도 메뉴 이후 진행이 안 됩니다. 앱이 이런 폴더를 알아보고 로그와 화면에 안내를 띄웁니다. 정식 설치본이 쓰는 **AES 암호화(aes-128/192/256, cbc·ecb·ctr)** 도 앱 안에 구현했습니다 (3장).
> 2. **랙 진단 로그** — 어떤 파일이 느리게 읽혔는지, 화면이 몇 ms 멈췄는지, 장면(맵) 전환에 얼마나 걸렸는지, 게임 폴더가 SD 카드인지 내장 저장소인지가 로그에 남습니다 (5장).
> 3. **GitHub 빌드 수정** — `Failed to find package 'tools'` 오류가 나던 SDK 설치 단계를 고쳤고, 프로젝트 zip 하나만 올려도 빌드되게 했습니다 (1장 방법 A-1).
>
> 랙과 TCOAAL 문제는 아직 **원인 확인 전**이라서 새 로그가 필요합니다 (아래 3·5장). 이 코드는 PC에서 최대한 검증했습니다 (순수 자바 코어 단위 테스트 378개, 실제 Chromium에서 호환 레이어·가상 패드·서버 305개, 런처 화면 169개, 랙 진단 스크립트 23개, zlib·crypto를 Node 자체 구현과 대조하는 4,200여 항목, AES를 Node의 OpenSSL과 대조하는 2,000여 항목, 스트림·파일 핸들을 진짜 Node와 같은 시나리오로 대조하는 50개, GitHub 빌드 스크립트 33개, 안드로이드 클래스는 API 스텁 대상 타입 검사). 다만 안드로이드 SDK 빌드와 실제 폰 실행은 사용자 환경에서만 확인할 수 있어서, **문제가 생기면 로그를 그대로 보내 주세요** (아래 “문제가 생기면” 참고).

---

## 1. APK 만들기

개발 환경에는 안드로이드 SDK가 없어서 APK를 미리 만들어 드리지 못했습니다. 아래 세 가지 중 편한 방법으로 직접 빌드합니다. **A가 가장 쉽습니다.** (PC 브라우저 + 무료 GitHub 계정만 있으면 됩니다.)

### 방법 A — GitHub Actions (설치 필요 없음, 권장)

1. [github.com](https://github.com)에 로그인 → 오른쪽 위 **+ → New repository** → 이름 `rpg-runner`, **Private** 선택 → **Create repository**.
2. 프로젝트를 올립니다. **둘 중 하나**를 고르세요. GitHub 웹 업로드는 폴더가 조용히 빠지는 경우가 있어서(압축 프로그램 창에서 바로 끌어다 놓기, 폰 브라우저, 한 번에 100개 초과) **A-1을 권합니다.**
   - **A-1. zip 파일 하나만 올리기 (압축을 풀 필요 없음, 폰에서도 됨)**
     1. 저장소에서 **Add file → Create new file** → 파일 이름 칸에 `.github/workflows/build-apk.yml` 을 적고(슬래시 `/`를 치면 폴더가 만들어집니다) 이 프로젝트의 `build-apk.yml` 내용을 통째로 붙여 넣은 뒤 **Commit changes**. 이미 그 파일이 있으면 열어서 연필(✏) 버튼 → 내용을 전부 지우고 붙여 넣기 → **Commit changes**.
     2. **Add file → Upload files** → 받은 `rpg-runner-….zip`을 **풀지 않은 그대로** 고르거나 끌어다 놓기 → **Commit changes**.
     - 저장소 맨 위에 `rpg-runner`로 시작하는 zip이 있으면 빌드가 **그 zip 안의 내용만** 쓰고, 따로 올라가 있던 낱개 파일·옛 폴더는 무시합니다 (섞이지 않음). 새 버전이 나오면 새 zip을 올리기만 하면 되고, 옛 zip이 같이 있으면 버전 숫자가 큰 쪽을 씁니다. Actions 실행 화면 요약에 어느 zip으로 빌드했는지 적힙니다.
   - **A-2. 폴더째 올리기**: 이 프로젝트 zip을 PC에서 **먼저 풀고**(압축 프로그램 창 안에서 바로 끌어다 놓으면 폴더가 빠집니다), 저장소 화면의 **uploading an existing file** 링크로 들어가서 **`dev` 폴더를 뺀 나머지 전부**(`.github` 폴더, `app`, `gradle`, `tools`, `gradlew`, `build.gradle` 등)를 끌어다 놓고 **Commit changes**.
     - `dev` 폴더는 테스트용이라 빌드에 필요 없습니다. (웹 업로드는 한 번에 100개 파일까지라서 `dev`는 꼭 빼세요. `dev`만 해도 80여 개입니다.)
     - 올린 뒤 저장소 첫 화면에 `app`, `gradle`, `tools` 폴더가 보이는지 확인하세요. 하나라도 없으면 A-1로 하세요.
     - 맥은 `.github` 같은 점(.)으로 시작하는 폴더가 숨김이라 안 보일 수 있습니다 (Finder에서 `⌘⇧.`). 업로드 후 저장소에 `.github/workflows/build-apk.yml`이 없다면 **Add file → Create new file**에서 파일 이름을 `.github/workflows/build-apk.yml`로 적고 내용을 붙여 넣으세요.
3. 저장소의 **Actions** 탭 → (처음이면 “I understand my workflows, go ahead and enable them”) → 왼쪽 **Build APK** → **Run workflow** → 초록 버튼. 업로드만 해도 자동으로 시작될 수 있습니다. 첫 빌드는 5~10분쯤 걸립니다.
4. 실행이 끝나면(초록 ✓) 그 실행을 눌러서 맨 아래 **Artifacts → `RPGRunner-debug-apk`** 를 내려받고 압축을 풀면 **`RPGRunner-debug.apk`** 가 나옵니다.
   - 빨간 ✗로 실패하면 실패한 단계(빨간 표시)를 열어 로그의 **마지막 40줄쯤을 복사해서 보내 주세요.**
   - “Fetch the EasyRPG web player” 단계가 노란 경고라면 유메닛키용 웹 플레이어를 내려받지 못한 것입니다 (나머지 게임은 영향 없음). **Re-run jobs**로 다시 돌려 보세요.
5. (선택) 폰에서 바로 받고 싶다면 저장소의 **Releases → Draft a new release**에서 태그를 `v0.2.1`처럼 `v`로 시작하게 만들어 publish하세요. 빌드가 끝나면 릴리스 페이지에 APK가 붙습니다.

### 방법 B — Android Studio

1. Android Studio(최신)에서 **Open**으로 이 폴더를 엽니다. 처음 동기화할 때 **Android SDK 35** 설치를 허용합니다 (JDK는 Studio에 들어 있는 것으로 충분합니다).
2. (유메닛키를 쓸 때만) 터미널에서 `sh tools/fetch-easyrpg-web.sh` 를 한 번 실행합니다 (Windows는 Git Bash 또는 WSL). 인터넷에서 EasyRPG 웹 플레이어를 받아 `app/src/main/assets/easyrpg/`에 넣습니다.
3. **Build → Build APK(s)**. 결과: `app/build/outputs/apk/debug/app-debug.apk`

### 방법 C — 명령줄

```sh
export ANDROID_HOME=$HOME/Android/Sdk        # SDK 위치 (platforms;android-35, build-tools;34.0.0 설치돼 있어야 함)
sh tools/fetch-easyrpg-web.sh                # 선택: 유메닛키용 (실패해도 빌드는 계속 가능)
./gradlew assembleDebug                      # JDK 17 필요
# → app/build/outputs/apk/debug/app-debug.apk
```

> APK는 저장소에 들어 있는 **공개 디버그 키(`app/debug.keystore`)** 로 서명됩니다. 모든 빌드가 같은 키라서 새 APK를 지우지 않고 **덮어 설치**할 수 있습니다 (유메닛키 저장 데이터도 유지). 이 키는 비밀이 아니므로 다른 사람에게 배포할 앱에는 쓰지 마세요.

---

## 2. 설치와 첫 실행

1. APK를 폰으로 옮겨 열면 “출처를 알 수 없는 앱 설치”를 허용하라고 나옵니다. 허용하고 설치합니다. (Play Protect 경고가 뜨면 **그래도 설치**.) 이전 버전 위에 그대로 덮어 설치해도 됩니다 (게임 목록·설정·유메닛키 저장 유지).
2. **RPG Runner**를 엽니다. 화면 위쪽에 **“파일 접근 권한이 필요합니다”** 안내가 보이면 **권한 설정 열기** → **모든 파일에 대한 접근 허용**을 켭니다 (안드로이드 11 이상). 게임 폴더를 읽고 저장 파일을 쓰려면 필요합니다.
3. 줄 맨 끝의 **＋ 게임 추가** 타일을 고르고 **폴더 선택**으로 게임이 들어 있는 폴더(또는 여러 게임이 들어 있는 상위 폴더)를 지정합니다. 폴더 선택이 잘 안 되면 **경로 입력**에 전체 경로를 적습니다. 예: `/storage/emulated/0/Games/OMORI`, SD 카드는 `/storage/XXXX-XXXX/Games`.
4. 게임 타일을 좌우로 넘겨 고르고 **▶ 실행**을 누릅니다 (이미 선택된 타일을 한 번 더 눌러도 실행됩니다).

게임 폴더를 둘 위치는 `내장 저장소/Games/...` 처럼 아무 곳이나 되지만, `Android/data/...` 아래는 안드로이드가 막고 있어서 쓸 수 없습니다.

### 홈 화면과 표지(커버) 이미지

- 닌텐도 스위치 홈 화면처럼 **가운데에 정사각형 게임 타일**이 한 줄로 놓입니다. 가운데에 온 타일이 선택되고(조금 커지고 노란 테두리), 배경에는 그 게임의 표지가 흐리게 깔립니다.
- 타일 아래의 둥근 버튼: **표지 추가/변경 · 설정 · ▶ 실행 · 로그 · 삭제** (삭제는 목록에서만 지우며 게임 파일은 그대로입니다).
- **표지 추가**: 폰의 이미지를 고르면 그 게임 타일의 표지가 됩니다. 타일이 정사각형이라 이미지의 **가운데 부분**이 보이니, 정사각형에 가까운 이미지가 가장 예쁩니다. 앱 안에 최대 1280px로 줄여 따로 보관하므로 원본 이미지를 지워도 표지는 남습니다. **표지 변경**에서 다른 이미지를 고르거나 표지를 삭제할 수 있습니다.
- **키보드·게임패드**: 좌우 = 게임 고르기, 아래 = 아래 버튼 줄로 이동(위 = 타일로 복귀), A / Enter = 실행·선택, B / Esc = 뒤로. 블루투스 게임패드나 Odin 같은 핸드헬드의 내장 패드로도 조작되게 만들었지만, 실제 기기에서는 아직 확인하지 못했습니다.

### 인식되는 폴더 모양

- **RPG Maker MV/MZ**: `www/index.html`이 있는 폴더 (또는 `package.json`의 `main`이 가리키는 곳, 또는 바로 `index.html`).
- **RPG Maker 2000/2003**: `RPG_RT.ldb`(또는 `RPG_RT.lmt`)가 있는 폴더. RTP가 필요한 게임은 RTP 파일을 게임 폴더 안에 합쳐 두세요.

---

## 3. 게임별 안내

- **The Witch's House MV / OMORI / Fear & Hunger / The Coffin of Andy and Leyley**: 앱 안의 웹뷰에서 PC판과 같은 방식으로 실행됩니다. 저장 파일은 PC판처럼 **게임 폴더의 `www/save`**(게임 구조에 따라 `save`) 안에 생깁니다.
  - **OMORI는 정식으로 설치된 게임 폴더**여야 합니다 (Steam: 라이브러리에서 OMORI 우클릭 → 관리 → 로컬 파일 보기, 그 폴더를 폰으로 복사). 폴더 안에 `Game.rpgproject`, `editor.json`, 평문 `data/*.json`이 보이면 설치본이 아니라 **복호화된 소스 프로젝트(OmoriSource 등)** 입니다. 이 폴더는 게임 플러그인이 암호화된 `data/MapNNN.KEL` 파일을 찾다가 멈추므로 실행할 수 없고, 앱은 로그에 `WARNING: this OMORI folder has plain data ...` 줄을 남기고 화면에 안내를 띄웁니다. 정식 설치본의 데이터는 AES-256-CTR로 암호화되어 있는데(`*.KEL`, `*.HERO`, `*.OMORI` 등), v0.2.1부터 앱이 그 암호를 직접 풀 수 있습니다. 다만 **정식 설치본으로는 아직 실행해 보지 못했으니**, 안 되면 로그를 보내 주세요.
  - OMORI는 메모리를 많이 쓰는 편입니다. 다른 앱을 닫고 실행해 보고, 튕기면 로그를 보내 주세요. 발열이 심하면 게임 설정에서 **프레임 제한 30 FPS**를 써 보세요.
  - 화면이 깨지거나 검게 나오면 게임 설정의 **렌더러를 Canvas**로 바꿔 보세요.
- **The Coffin of Andy and Leyley 한글패치**: 이 게임은 게임 안의 **Language 메뉴**에서 언어를 고르는 구조이고, 언어 파일(`.cld`)이나 언어 폴더는 `www/languages` 안에 들어갑니다. `default language missing or broken : English reinstalling` 이 나온다면 아래 순서로 확인해 주세요.
  1. **패치를 넣기 전의 원본 게임**이 이 앱에서 뜨는지 먼저 확인합니다 (뜬다면 앱 문제가 아니라 패치 설치 쪽입니다).
  2. 예전에 넣은 한글패치 파일을 **지우고**(또는 원본 파일로 되돌리고), 현재 게임 버전에 맞는 **최신 한글패치**를 다시 받아 패치 설명서대로 설치합니다. 옛 패치와 새 게임 버전은 서로 맞지 않는 경우가 있습니다.
  3. 그래도 같은 메시지가 나오면 게임을 한 번 실행한 뒤 **로그 버튼으로 로그를 복사해서 보내 주세요.** v0.2.0부터 로그에는 게임 폴더 구조(`layout:` 줄: `www`, `languages` 폴더 안 파일, 켜져 있는 플러그인 목록, 최근 바뀐 파일)와 게임이 찾다가 못 찾은 파일 경로(`fs ... ENOENT:` 줄)가 남아서 원인을 바로 볼 수 있습니다. 사용하신 한글패치의 **이름·버전·받은 곳과 설치한 방법**도 함께 알려 주세요.
- **Yume Nikki (유메닛키) · IB**: RPG Maker 2000/2003 게임이라 앱에 포함되는 **EasyRPG 웹 플레이어**로 실행합니다. 저장은 앱 내부(브라우저 저장소)에 보관되므로 **앱 데이터를 지우거나 앱을 삭제하면 사라집니다** (덮어 설치는 괜찮습니다).
  - 한글패치를 쓰는 경우 글자가 깨지면 게임 설정의 **텍스트 인코딩을 한국어(949)** 로 바꾸세요.
  - 유메닛키는 키패드 숫자 키를 씁니다: **9 = 볼 꼬집기(깨어나기)**, 1 = 이펙트 사용, 3 = 해제, 5 = 내려놓기. 가상 패드 왼쪽 위에 **1·3·5·9 버튼**이 있습니다.
  - **IB(와 마녀의 집 MV)가 처음 실행할 때·장소를 옮길 때 끊길 때**: 원인은 아직 확인되지 않았습니다 (같은 플레이어에서 유메닛키는 쾌적하므로 게임별 사정일 수 있습니다). v0.2.1은 이것을 찾기 위한 **진단 로그**를 넣었습니다 (5장). 먼저 **게임 폴더를 SD 카드가 아닌 내장 저장소로 복사해서** 같은 장면에서 비교해 보세요 — SD 카드는 작은 파일을 많이 읽을 때 느려서, 장소를 옮길 때 이미지·소리를 읽는 동안 멈추는 경우가 있습니다. 그다음 게임을 처음 실행해서 **장소를 대여섯 번 옮겨 본 뒤 종료**하고, 로그(`로그` 버튼)와 **폰 기종**, 끊기는 장면(예: 갤러리 전시실, 특정 방, 화면 전환)을 알려 주세요. 게임 설정에서 **프레임 제한**을 바꿔 보고 결과가 달라지는지도 알려 주시면 좋습니다.
  - 빌드 때 웹 플레이어를 못 받았다면 카드에 “EasyRPG 웹 플레이어 없음”으로 표시됩니다. 그때는 APK를 다시 빌드하거나, [EasyRPG Player 앱](https://easyrpg.org)을 따로 설치하면 “앱으로 열기”를 쓸 수 있습니다.

---

## 4. 조작

- **가상 패드**: 왼쪽 방향 패드(8방향), 오른쪽 **확인**(Z) / **취소**(X) / **달리기**(Shift), 위쪽 Q·W(MV 메뉴의 페이지 넘김). 여러 손가락 동시 입력이 됩니다. 유메닛키·IB에서는 Q·W 대신 숫자 1·3·5·9 버튼이 나옵니다.
- **☰ 버튼**(오른쪽 위) 또는 **뒤로 가기**: 메뉴 — 계속하기 / 가상 패드 켜기·끄기 / 로그 복사 / 게임 종료.
- **블루투스 키보드·게임패드**: PC와 같은 키로 동작할 것으로 예상합니다. 게임패드가 연결되면 가상 패드는 자동으로 숨겨집니다.
- 게임 타일의 **설정**에서 이름, 렌더러, 프레임 제한(MV), 텍스트 인코딩(유메닛키·IB), 패드 표시·투명도·크기를 바꿀 수 있습니다.

---

## 5. 문제가 생기면 (로그 보내기)

앱은 게임을 실행할 때마다 로그 파일을 남깁니다. 로그에는 기기·앱·게임 정보, 게임 폴더 구조(`layout:` 줄)와 그 폴더가 있는 저장소(`game folder is on:` 줄), 게임이 찾지 못한 파일 경로(`fs ... ENOENT` 줄), 쓸 수 없는 Node 모듈을 게임이 부른 기록(`not available` 줄), 오류, 404 난 파일, 느리게 읽힌 파일(`slow request` 줄)과 화면 끊김(`perf:` 줄) 등이 들어갑니다.

1. 런처에서 **게임 타일을 고르고 → 아래 둥근 버튼 중 `로그`** 를 누르면 **그 게임의 가장 최근 로그가 복사**됩니다. 대화창에 붙여 넣어 보내 주세요. (게임을 한 번도 실행하지 않았다면 로그가 없다고 나옵니다.)
2. 다른 로그 파일이 필요하면 **＋ 게임 추가 타일 → 도움말 → 로그 파일**에서 보기·복사·공유를 쓸 수 있습니다.
3. 게임 도중에는 **☰ → 로그 복사**도 됩니다.
4. 로그 파일 위치: `내장 저장소/RPGRunner/logs/` (권한이 없으면 앱 전용 폴더). 파일 이름은 `게임이름-게임ID-날짜-시간.log`.
5. 게임 화면에 JS 오류가 나면 위쪽에 빨간 오류 배너가 약 9초 표시됩니다 (탭하면 닫힘, 같은 내용이 로그에도 남습니다). 스크린샷을 같이 보내 주시면 도움이 됩니다.

### 랙(끊김) 로그 읽는 법

랙이 있는 게임은 **실행 → 랙이 생기는 동작(처음 로딩, 장소 이동)을 대여섯 번 → 종료** 순서로 한 뒤 로그를 보내 주세요. 로그에 이런 줄이 남습니다 (게임 속도에는 거의 영향이 없고, 줄 수에 상한이 있어 로그가 폭주하지 않습니다).

- `game folder is on: removable volume 399D-D78B (SD card / USB)` — 게임 폴더가 SD 카드(또는 USB)에 있는지, `internal storage`(내장)인지.
- `slow request: GET img/tilesets/Outside_A2.png 2.4 MB took 420 ms (read 395, write 22, other 3)` — 파일 하나를 내주는 데 걸린 시간. `read`가 크면 저장소(SD 카드)가 느린 것, `write`가 크면 게임 화면이 데이터를 받아 가지 않는 것(화면이 바쁜 것), `other`가 크면 폴더 조회·목록 만들기 같은 다른 일입니다. 150ms 이상 걸린 요청만, 앞쪽 60개까지 한 줄씩 나옵니다.
- `requests in the last 30 s: 312, 41.2 MB, busy 2803 ms (read 1900, write 600) ... | png 120 (...) | ogg 4 (...)` — 30초마다 파일 종류별 합계. 종료할 때 `requests in this session` 줄로 전체 합계도 나옵니다.
- `perf: stall: frame took 640 ms at +12.3 s | script task 610 ms | 2 file(s) arrived: img/tilesets/A.png 410 ms, ... | Scene_Map (going to map 13)` — 화면이 640ms 멈췄고, 그동안 스크립트가 610ms 막았고, 어떤 파일들이 도착했고, 어느 장면이었는지.
- `perf: scene Scene_Map (going to map 13) needed 1250 ms until it was ready` — (RPG Maker MV/MZ) 새 맵·장면이 준비되기까지 걸린 시간, 즉 장소 이동 때의 로딩 시간.
- `perf: slow file: ... took 640 ms (first byte after 12, download 620)` — 브라우저가 느리게 받은 파일.
- `perf: 15.0 s: 58.9 fps (worst frame 412 ms; frames >= 100 ms: 3, ...) | script tasks ... | files ... | heap 84/512 MB` — 15초마다 프레임 요약.

| 증상 | 해 볼 것 |
|---|---|
| GitHub에 `app`·`gradle`·`tools` 폴더가 안 올라감 | 위 1장 “방법 A-1”: zip을 풀지 말고 그대로 올리기 |
| 게임이 목록에 안 뜸 | 폴더 모양 확인(위 “인식되는 폴더 모양”), 상위 폴더를 고르면 안의 게임을 모두 찾습니다 |
| “파일 접근 권한 필요” | 상단 안내 → 모든 파일 접근 허용 |
| 검은 화면 / 화면 깨짐 | 설정 → 렌더러 Canvas, 그래도 안 되면 로그 |
| 글자 깨짐 (유메닛키·IB) | 설정 → 텍스트 인코딩 |
| 느림 / 발열 / 끊김 | 설정 → 프레임 제한 30 FPS, 다른 앱 종료, 게임 폴더를 내장 저장소로 복사해서 비교, 그래도 심하면 로그와 끊기는 장면 |
| OMORI가 시작이 안 되거나 메뉴 이후 멈춤 | 정식 설치 폴더인지 확인 (위 3장), 로그의 `WARNING` 줄 확인 |
| TCOAAL `default language missing...` | 위 3장 “한글패치” 순서 확인 후 로그 |
| 앱이 튕김 | 로그 복사해서 전달 |

---

## 6. 알려진 제한

- **IB와 마녀의 집 MV의 랙(처음 실행·장소 이동) / TCOAAL 한글패치 오류는 아직 원인 확인 전입니다.** 로그가 있어야 정확히 고칠 수 있습니다 (위 3·5장). **OMORI 정식 설치본은 아직 실제로 실행해 보지 못했습니다.**
- 웹뷰 기반이라 PC/네이티브 앱보다 느릴 수 있습니다. **Android System WebView / Chrome을 최신으로** 업데이트해 두세요. 안드로이드 8.0(API 26) 이상 필요.
- NW.js 게임이 쓰는 Node 기능 중 **zlib(압축), crypto의 해시·HMAC·PBKDF2·난수, `stream`(Readable/Writable/Transform/pipeline 등), 파일 핸들(`fs.openSync`·`readSync`·`writeSync`·`fs.promises.open`), `fs.createReadStream`/`createWriteStream`**은 앱 안에서 직접 구현해 두었습니다. **AES 암호화(`createCipheriv`/`createDecipheriv`, aes-128/192/256의 cbc·ecb·ctr)** 도 앱 안에서 직접 구현했습니다 (OMORI 정식 설치본이 씁니다). 하지만 그 밖의 암호(gcm·cfb·des 등)·서명, 네트워크(`http`, `net`), 자식 프로세스 같은 기능은 폰에서 쓸 수 없어서, 게임이 부르면 오류가 나고 그 사실이 로그에 남습니다.
- 파일 핸들은 **열린 파일 전체를 메모리에 올려서** 다루고, 닫을 때(또는 잠시 후·앱이 가려질 때) 한꺼번에 저장합니다. 수백 MB짜리 파일을 핸들로 여는 용도에는 맞지 않습니다. 폴더를 읽기 모드로 열면 Node와 달리 열 때 바로 오류가 납니다.
- **유메닛키·IB 저장**은 앱 내부에만 있고 PC판 `Save01.lsd`를 가져오는 기능은 아직 없습니다. 게임별 로컬 포트(20000~39999)가 이미 다른 앱에 쓰이고 있으면 다른 포트로 열려 저장이 안 보일 수 있습니다 (드문 경우).
- EasyRPG 웹 플레이어는 빌드 때 공식 사이트에서 내려받는 파일 구성(`index.html`, `index.js`, `index.wasm`)을 전제로 합니다. 구성이 바뀌면 스크립트(`tools/fetch-easyrpg-web.sh`)를 고쳐야 할 수 있습니다.
- 디버그 서명 APK라 스토어 배포용이 아닙니다.

---

## 7. 라이선스·법적 안내

- 이 앱에는 **어떤 게임 파일도 포함되어 있지 않습니다.** 게임은 직접 구매·보유한 것을 쓰세요.
- Yume Nikki용 **EasyRPG Player**(웹 빌드)는 [GNU GPL v3](https://github.com/EasyRPG/Player) 소프트웨어입니다. 이 저장소에는 들어 있지 않고 빌드할 때 공식 사이트에서 내려받아 APK에 포함됩니다. 그 APK를 **다른 사람에게 배포**한다면 GPL v3 조건(소스 제공 등)을 지켜야 합니다. 개인 사용은 해당 없습니다.
- 이 프로젝트의 코드에는 아직 별도의 라이선스 파일이 없습니다. 공개·배포할 계획이 있으면 `LICENSE`를 추가하세요.

---

## 8. 개발자용

### 구조

```
app/src/main/java/app/rpgrunner/
  App, AppDirs, LauncherActivity, GameActivity      안드로이드 셸 (런처, 게임 화면, JS 브리지)
  GameServer, RequestStats                           127.0.0.1 HTTP 서버: 게임 폴더를 실제 경로 그대로 서빙, Range, 대소문자 무시 / 요청별 읽기·전송 시간 기록
  NativeFs, PathUtil, Base64Lite                     샌드박스 파일 시스템 (게임 폴더 + 앱 데이터 폴더만)
  GameDetector, GameEntry, GameStore, PageUrl        게임 인식·저장·URL
  CoverStore                                         표지 이미지 파일 관리 (파일명·교체·EXIF 회전 계산)
  LayoutProbe                                        게임 폴더 구조를 로그에 남기는 진단 (language 폴더, 플러그인 목록 등) + 설치본이 아닌 소스 폴더 알아보기
  ConfigJs, EasyRpgIndex, LogStore, MiniJson, StorageAccess   설정/인덱스/로그/JSON/저장소 경로
app/src/main/assets/
  shim/shim.js       NW.js/Node 호환 레이어 (require('fs'), nw.*, process, zlib, crypto 등) — dev/shim-parts 를 합쳐 만든 파일
  shim/overlay.js    가상 패드 + ☰ 버튼
  shim/perf.js       랙 진단 (프레임 멈춤·느린 파일·장면 로딩 시간을 로그로)
  launcher/index.html  런처 화면 (한국어, 스위치식 타일 홈)
  easyrpg/           EasyRPG 웹 플레이어 (빌드 때 tools/fetch-easyrpg-web.sh 가 채움)
tools/fetch-easyrpg-web.sh   웹 플레이어 다운로드
.github/workflows/build-apk.yml   GitHub Actions 빌드 (저장소 맨 위에 rpg-runner*.zip 이 있으면 그 안의 프로젝트로 빌드)
dev/                 테스트와 도구 (APK에는 들어가지 않음)
```

게임은 별도 프로세스(`:game`)의 웹뷰에서 돌아가고, 게임 폴더는 로컬 서버가 실제 경로 그대로 내주기 때문에 `location.pathname`이 파일 시스템 경로와 같아 MV의 저장 코드(`process.mainModule.filename` 기준)가 그대로 동작합니다.

### 테스트

```sh
sh dev/run-tests.sh      # JDK 17 + Node 필요. Chromium 테스트는 playwright 패키지가 있을 때만 실행
```

- 코어 단위 테스트(`CoreTest`), 안드로이드 클래스 타입 검사(`dev/android-stubs`의 손으로 만든 스텁), 자바 ↔ JS 브리지 계약 검사, 실제 Chromium에서의 호환 레이어/오버레이/런처 테스트.
- `dev/test/aes.test.js`: 호환 레이어의 AES(aes-128/192/256의 cbc·ecb·ctr, 패딩, `update()`/`final()`의 조각별 결과, 오류 메시지, 스트림, 옛 `createCipher`)를 **Node의 OpenSSL과 같은 입력으로 비교**합니다 (표준 시험 벡터 포함).
- `dev/test/perf.test.js`: 랙 진단 스크립트(`perf.js`)를 실제 Chromium에서 돌려, 일부러 멈춘 프레임·느린 파일·느린 장면이 로그에 제대로 나오는지, 줄 수 상한이 지켜지는지 확인합니다.
- `dev/test/workflow-zip.test.sh`: GitHub 빌드 스크립트(zip 하나만 올리는 방식, SDK 설치 단계)를 가짜 환경에서 돌려 확인합니다.
- `dev/test/zlib-crypto.test.js`: 호환 레이어의 순수 JS zlib(inflate/deflate, gzip·zlib·raw, 사전, 오류 코드)과 crypto(md5·sha1·sha224/256/384/512, HMAC, PBKDF2, 난수)를 Node 자체 구현과 같은 입력으로 비교합니다. 깨진 스트림·잘린 스트림이 Node와 **같은 오류**를 내는지도 2만 건 넘게 확인합니다.
- `dev/test/streams.test.js`: `dev/test/stream-scenarios.js`·`fs-scenarios.js`의 시나리오(스트림 pipe·역압·오류·`finished`·`pipeline`, 파일 핸들, 파일 스트림, 해시·암호 스트림, 열린 파일을 지우거나 옮기는 경우 등 50개)를 **진짜 Node와 호환 레이어에서 각각 돌려 로그가 한 줄도 다르지 않은지** 비교합니다. 같은 시나리오를 `shim.test.js`가 실제 Chromium 안(자바 파일 브리지 포함)에서도 한 번 더 돌립니다. 호환 레이어를 Node 안에 올리는 도구는 `dev/test/shim-node-harness.js`, 공통 보조 함수는 `scenario-env.js`입니다.
- `shim.js`를 고칠 때는 `dev/shim-parts/*.js`(이름 순서대로 하나로 합쳐짐: 10-core, 20-modules, 21-stream-core, 22-stream-write, 23-fsfd, 24-fsfd-async, 25-zlib, 26-crypto, 27-crypto-aes, 30-require-nw, 40-platform)를 수정한 뒤 `sh dev/build-shim.sh`로 다시 만듭니다 (계약 테스트가 둘이 같은지 확인합니다).
- 자바 ↔ JS 브리지 시그니처는 `dev/test/bridge-spec.js`가 기준입니다.

### 참고 자료

- EasyRPG 웹 플레이어 사용법: <https://easyrpg.org/player/guide/webplayer/>
