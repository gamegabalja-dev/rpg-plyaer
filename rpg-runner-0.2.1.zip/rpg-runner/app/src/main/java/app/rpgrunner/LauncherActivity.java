package app.rpgrunner;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Matrix;
import android.media.ExifInterface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The game list. The screen itself is a local HTML page (assets/launcher/index.html) so it can be built and tested like a web page;
 * this class is the native side of it ("Launcher" JavaScript interface): game list storage, the folder picker, permissions,
 * starting a game and handing out logs.
 */
public final class LauncherActivity extends Activity {
    private static final int REQ_TREE = 41;
    private static final int REQ_PERMS = 42;
    private static final int REQ_COVER = 43;
    private static final String EASYRPG_PACKAGE = "org.easyrpg.player";
    private static final int LOG_SHARE_BYTES = 100 * 1024;
    /** Cover pictures reach the page as https://rrcover.local/<gameId>?v=<version>; shouldInterceptRequest answers them from CoverStore. */
    private static final String COVER_HOST = "rrcover.local";
    private static final int COVER_MAX_BYTES = 32 * 1024 * 1024;
    private static final String STATE_COVER_ID = "pendingCoverId";

    private WebView web;
    private GameStore store;
    private CoverStore covers;
    /** The game the picture picker was opened for (kept across a possible recreation of the activity while the picker is on screen). */
    private String pendingCoverId = "";

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new GameStore(AppDirs.gamesFile(this));
        covers = new CoverStore(AppDirs.coverDir(this));
        if (savedInstanceState != null) pendingCoverId = savedInstanceState.getString(STATE_COVER_ID, "");
        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(12, 13, 20)); // same as the page background: no flash while it loads
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false); // file:///android_asset/ stays reachable, the rest of the file system does not
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setTextZoom(100);
        web.addJavascriptInterface(new LauncherBridge(), "Launcher");
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (u != null && "file".equals(u.getScheme()) && String.valueOf(u.getPath()).startsWith("/android_asset/")) return false;
                return true; // the launcher never navigates anywhere else
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (u == null || !COVER_HOST.equals(u.getHost())) return null; // everything else loads normally
                return coverResponse(u.getPath());
            }
        });
        setContentView(web, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        web.requestFocus(); // D-pad / gamepad keys go to the page from the start
        web.loadUrl("file:///android_asset/launcher/index.html");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        emit("refresh", null);
    }

    @Override
    protected void onPause() {
        if (web != null) web.onPause();
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(STATE_COVER_ID, pendingCoverId);
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.removeJavascriptInterface("Launcher");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        // the page closes its own dialogs first; ask it, and leave only if nothing was open
        if (web == null) {
            super.onBackPressed();
            return;
        }
        web.evaluateJavascript("(window.RRL&&RRL.back)?RRL.back():false", new android.webkit.ValueCallback<String>() {
            @Override
            public void onReceiveValue(String value) {
                if (!"true".equals(value)) finish();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_COVER) {
            String id = pendingCoverId;
            pendingCoverId = "";
            if (resultCode == RESULT_OK && data != null && data.getData() != null && CoverStore.validId(id) && store.find(id) != null) {
                importCover(id, data.getData());
            }
            return;
        }
        if (requestCode != REQ_TREE || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        String path;
        try {
            path = StorageAccess.pathFromTreeDocId(uri.getAuthority(), DocumentsContract.getTreeDocumentId(uri),
                    Environment.getExternalStorageDirectory().getPath());
        } catch (RuntimeException e) {
            path = null;
        }
        if (path == null) {
            Map<String, Object> m = new LinkedHashMap<String, Object>();
            m.put("ok", Boolean.FALSE);
            m.put("message", "이 위치는 지원하지 않습니다. 내장 저장소나 SD 카드 안의 폴더를 선택해 주세요.");
            emit("added", m);
            return;
        }
        emit("added", addFromPath(path));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PERMS) emit("refresh", null);
    }

    // ------------------------------------------------------------------ helpers

    /** Sends an event to the page: RRL.onEvent(name, data). Must be called on the UI thread. */
    private void emit(String name, Object data) {
        if (web == null) return;
        web.evaluateJavascript("window.RRL&&RRL.onEvent(" + MiniJson.stringify(name) + "," + MiniJson.stringify(data) + ")", null);
    }

    private Map<String, Object> addFromPath(String path) {
        Map<String, Object> res = new LinkedHashMap<String, Object>();
        res.put("ok", Boolean.FALSE);
        File dir = new File(path);
        if (!dir.isDirectory()) {
            res.put("message", "폴더를 찾을 수 없습니다: " + path);
            return res;
        }
        if (dir.listFiles() == null) {
            res.put("message", "폴더를 읽을 수 없습니다. 위쪽의 '모든 파일 접근' 권한을 허용했는지 확인해 주세요.\n" + path);
            return res;
        }
        List<GameEntry> found = GameDetector.scan(dir, 2);
        if (found.isEmpty()) {
            res.put("message", "지원하는 게임을 찾지 못했습니다.\nRPG Maker MV/MZ: package.json 또는 www/index.html, RPG Maker 2000/2003: RPG_RT.ldb 가 있는 폴더(또는 그 상위 폴더)를 선택하세요.\n" + path);
            return res;
        }
        List<Object> names = new ArrayList<Object>();
        int added = 0;
        for (GameEntry g : found) {
            GameEntry old = store.find(g.id);
            if (old == null) {
                store.upsert(g);
                added++;
            } else { // already known: keep the user's settings, refresh what detection found
                old.engine = g.engine;
                old.mainHtml = g.mainHtml;
                old.mainQuery = g.mainQuery;
                store.upsert(old);
            }
            names.add(g.name);
        }
        res.put("ok", Boolean.TRUE);
        res.put("added", Integer.valueOf(added));
        res.put("found", Integer.valueOf(found.size()));
        res.put("names", names);
        return res;
    }

    // ------------------------------------------------------------------ cover pictures

    /** "https://rrcover.local/<id>?v=<version>" when the game has a cover, otherwise "". */
    private String coverUrl(String id) {
        return covers.find(id) == null ? "" : "https://" + COVER_HOST + "/" + id + "?v=" + covers.version(id);
    }

    /** Answer for a request to rrcover.local (WebView IO thread): the stored picture, or an empty 404. */
    private WebResourceResponse coverResponse(String urlPath) {
        String id = urlPath == null ? "" : (urlPath.startsWith("/") ? urlPath.substring(1) : urlPath);
        File f = CoverStore.validId(id) ? covers.find(id) : null;
        Map<String, String> headers = new HashMap<String, String>();
        headers.put("Access-Control-Allow-Origin", "*"); // only this page can reach the virtual host; lets the page read the pixels if it wants to
        if (f != null) {
            try {
                return new WebResourceResponse(CoverStore.mimeOf(f), null, 200, "OK", headers, new FileInputStream(f));
            } catch (IOException e) {
                // fall through to 404
            }
        }
        return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", headers, new ByteArrayInputStream(new byte[0]));
    }

    /** Decodes and stores the picked picture on a worker thread, then tells the page ("coverChanged"). */
    private void importCover(final String id, final Uri uri) {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                final Map<String, Object> res = new LinkedHashMap<String, Object>();
                res.put("id", id);
                String error = null;
                try {
                    covers.write(id, encodeCover(uri));
                } catch (IOException e) {
                    error = "이 이미지를 불러올 수 없습니다. (" + e.getMessage() + ")";
                } catch (OutOfMemoryError e) {
                    error = "이미지가 너무 커서 불러올 수 없습니다.";
                } catch (RuntimeException e) {
                    error = "이 이미지를 불러올 수 없습니다. (" + e + ")";
                }
                res.put("ok", Boolean.valueOf(error == null));
                if (error != null) res.put("message", error);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        emit("coverChanged", res);
                    }
                });
            }
        }, "rr-cover-import");
        t.start();
    }

    /** Reads the picture behind a content:// uri, turns it upright (EXIF), scales it to CoverStore.MAX_EDGE and encodes it as PNG (transparent) or JPEG. */
    private byte[] encodeCover(Uri uri) throws IOException {
        ContentResolver cr = getContentResolver();
        InputStream in = cr.openInputStream(uri);
        if (in == null) throw new IOException("열 수 없는 파일");
        ByteArrayOutputStream buf = new ByteArrayOutputStream(512 * 1024);
        try {
            byte[] chunk = new byte[64 * 1024];
            int n;
            while ((n = in.read(chunk)) > 0) {
                if (buf.size() + n > COVER_MAX_BYTES) throw new IOException("파일이 너무 큽니다 (최대 32MB)");
                buf.write(chunk, 0, n);
            }
        } finally {
            in.close();
        }
        byte[] raw = buf.toByteArray();

        int orientation = ExifInterface.ORIENTATION_NORMAL;
        try {
            orientation = new ExifInterface(new ByteArrayInputStream(raw)).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL);
        } catch (IOException e) {
            // PNG or no EXIF data: keep the picture as stored
        } catch (RuntimeException e) {
            // damaged EXIF data: same
        }

        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        BitmapFactory.decodeByteArray(raw, 0, raw.length, bounds);
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) throw new IOException("이미지 파일이 아닙니다");
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = CoverStore.sampleSize(bounds.outWidth, bounds.outHeight, CoverStore.MAX_EDGE);
        Bitmap bmp = BitmapFactory.decodeByteArray(raw, 0, raw.length, opts);
        if (bmp == null) throw new IOException("이미지를 해석할 수 없습니다");

        int[] size = CoverStore.fit(bmp.getWidth(), bmp.getHeight(), CoverStore.MAX_EDGE);
        if (size[0] != bmp.getWidth() || size[1] != bmp.getHeight()) {
            Bitmap scaled = Bitmap.createScaledBitmap(bmp, size[0], size[1], true);
            if (scaled != bmp) bmp.recycle();
            bmp = scaled;
        }
        int[] ops = CoverStore.exifOps(orientation);
        if (ops[0] != 0 || ops[1] != 0) {
            Matrix m = new Matrix();
            if (ops[0] != 0) m.postRotate(ops[0]);
            if (ops[1] != 0) m.postScale(-1, 1);
            Bitmap turned = Bitmap.createBitmap(bmp, 0, 0, bmp.getWidth(), bmp.getHeight(), m, true);
            if (turned != bmp) bmp.recycle();
            bmp = turned;
        }
        boolean png = bmp.hasAlpha();
        ByteArrayOutputStream out = new ByteArrayOutputStream(256 * 1024);
        boolean ok = bmp.compress(png ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, png ? 100 : 88, out);
        bmp.recycle();
        if (!ok) throw new IOException("이미지를 저장할 수 없습니다");
        return out.toByteArray();
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "?";
        }
    }

    private boolean webPlayerAvailable() {
        try {
            String[] names = getAssets().list("easyrpg");
            return names != null && Arrays.asList(names).contains("rr-player.html");
        } catch (IOException e) {
            return false;
        }
    }

    private File logFile(String name) {
        if (name == null || name.indexOf('/') >= 0 || name.indexOf('\\') >= 0 || !name.endsWith(".log")) return null;
        File f = new File(AppDirs.logDir(this), name);
        return f.isFile() ? f : null;
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(LauncherActivity.this, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    // ------------------------------------------------------------------ JavaScript interface ("Launcher")

    /** Everything the page may ask of the app. Methods run on a WebView background thread. */
    private final class LauncherBridge {
        @JavascriptInterface
        public String getState() {
            Map<String, Object> st = new LinkedHashMap<String, Object>();
            st.put("version", versionName());
            st.put("sdk", Integer.valueOf(Build.VERSION.SDK_INT));
            st.put("device", Build.MANUFACTURER + " " + Build.MODEL);
            boolean access = AppDirs.hasStorageAccess(LauncherActivity.this);
            st.put("storageOk", Boolean.valueOf(access));
            File logDir = AppDirs.logDir(LauncherActivity.this);
            st.put("logDir", logDir.getPath());
            st.put("easyrpgWeb", Boolean.valueOf(webPlayerAvailable()));
            st.put("easyrpgApp", Boolean.valueOf(getPackageManager().getLaunchIntentForPackage(EASYRPG_PACKAGE) != null));
            List<File> all = LogStore.list(logDir);
            List<Object> games = new ArrayList<Object>();
            for (GameEntry g : store.list()) {
                Map<String, Object> m = g.toMap();
                m.put("exists", Boolean.valueOf(new File(g.path).isDirectory()));
                m.put("shared", Boolean.valueOf(StorageAccess.isSharedStorage(g.path, getPackageName())));
                m.put("cover", coverUrl(g.id));
                File lastLog = LogStore.latestFor(all, g.id);
                m.put("log", lastLog == null ? "" : lastLog.getName());
                games.add(m);
            }
            st.put("games", games);
            List<Object> logs = new ArrayList<Object>();
            for (int i = 0; i < all.size() && i < 12; i++) {
                File f = all.get(i);
                Map<String, Object> m = new LinkedHashMap<String, Object>();
                m.put("name", f.getName());
                m.put("size", Long.valueOf(f.length()));
                m.put("time", Long.valueOf(f.lastModified()));
                logs.add(m);
            }
            st.put("logs", logs);
            return MiniJson.stringify(st);
        }

        @JavascriptInterface
        public void addGameFolder() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE), REQ_TREE);
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(LauncherActivity.this, "폴더 선택기를 열 수 없습니다. '경로 직접 입력'을 사용해 주세요.", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public String addGamePath(String path) {
            String p = path == null ? "" : path.trim();
            while (p.length() > 1 && p.endsWith("/")) p = p.substring(0, p.length() - 1);
            Map<String, Object> res;
            if (!p.startsWith("/")) {
                res = new LinkedHashMap<String, Object>();
                res.put("ok", Boolean.FALSE);
                res.put("message", "'/storage/emulated/0/Games/OMORI' 처럼 / 로 시작하는 전체 경로를 입력해 주세요.");
            } else {
                res = addFromPath(p);
            }
            return MiniJson.stringify(res);
        }

        @JavascriptInterface
        public void removeGame(String id) {
            store.remove(id);
            covers.delete(id);
        }

        /** Opens the system picture picker; the chosen picture becomes the cover of the game ("coverChanged" event when done). */
        @JavascriptInterface
        public void pickCover(final String id) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (!CoverStore.validId(id) || store.find(id) == null) return;
                    pendingCoverId = id;
                    Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    pick.addCategory(Intent.CATEGORY_OPENABLE);
                    pick.setType("image/*");
                    try {
                        startActivityForResult(pick, REQ_COVER);
                    } catch (ActivityNotFoundException e) {
                        pendingCoverId = "";
                        Toast.makeText(LauncherActivity.this, "이미지를 고를 수 있는 앱이 없습니다.", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void removeCover(String id) {
            covers.delete(id);
        }

        @JavascriptInterface
        public void saveSettings(String id, String json) {
            GameEntry g = store.find(id);
            Map<String, Object> m = MiniJson.asMap(MiniJson.tryParse(json));
            if (g == null || m == null) return;
            g.applySettings(m);
            store.upsert(g);
        }

        @JavascriptInterface
        public void play(final String id) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    GameEntry g = store.find(id);
                    if (g == null) return;
                    if (!new File(g.path).isDirectory()) {
                        Toast.makeText(LauncherActivity.this, "게임 폴더를 찾을 수 없습니다: " + g.path, Toast.LENGTH_LONG).show();
                        return;
                    }
                    if (StorageAccess.isSharedStorage(g.path, getPackageName()) && !AppDirs.hasStorageAccess(LauncherActivity.this)) {
                        Toast.makeText(LauncherActivity.this, "먼저 위쪽의 '모든 파일 접근' 권한을 허용해 주세요.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    g.lastPlayed = System.currentTimeMillis();
                    store.upsert(g);
                    Intent i = new Intent(LauncherActivity.this, GameActivity.class);
                    i.putExtra(GameActivity.EXTRA_GAME_ID, g.id);
                    startActivity(i);
                }
            });
        }

        @JavascriptInterface
        public void openPermissionSettings() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (Build.VERSION.SDK_INT >= 30) {
                        try {
                            startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + getPackageName())));
                        } catch (RuntimeException e) {
                            try {
                                startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                            } catch (RuntimeException e2) {
                                Toast.makeText(LauncherActivity.this, "설정 > 앱 > RPG Runner > 권한 에서 '모든 파일 접근'을 허용해 주세요.", Toast.LENGTH_LONG).show();
                            }
                        }
                    } else {
                        requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_PERMS);
                    }
                }
            });
        }

        @JavascriptInterface
        public String readLog(String name) {
            File f = logFile(name);
            return f == null ? "" : LogStore.tail(f, 48 * 1024);
        }

        @JavascriptInterface
        public void copyLog(final String name) {
            final File f = logFile(name);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (f == null) {
                        Toast.makeText(LauncherActivity.this, "로그 파일을 찾을 수 없습니다.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("RPG Runner log", LogStore.tail(f, LOG_SHARE_BYTES)));
                    Toast.makeText(LauncherActivity.this, "로그를 복사했습니다: " + f.getName(), Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void shareLog(final String name) {
            final File f = logFile(name);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (f == null) {
                        Toast.makeText(LauncherActivity.this, "로그 파일을 찾을 수 없습니다.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("text/plain");
                    send.putExtra(Intent.EXTRA_SUBJECT, "RPG Runner log " + f.getName());
                    send.putExtra(Intent.EXTRA_TEXT, LogStore.tail(f, LOG_SHARE_BYTES));
                    try {
                        startActivity(Intent.createChooser(send, "로그 공유"));
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(LauncherActivity.this, "공유할 수 있는 앱이 없습니다.", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void copyText(final String text) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("RPG Runner", text));
                    Toast.makeText(LauncherActivity.this, "복사했습니다.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public void openEasyRpgApp() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent launch = getPackageManager().getLaunchIntentForPackage(EASYRPG_PACKAGE);
                    if (launch == null) {
                        Toast.makeText(LauncherActivity.this, "EasyRPG Player 앱이 설치되어 있지 않습니다.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    startActivity(launch);
                }
            });
        }

        @JavascriptInterface
        public void toast(String message) {
            LauncherActivity.this.toast(message);
        }
    }
}
