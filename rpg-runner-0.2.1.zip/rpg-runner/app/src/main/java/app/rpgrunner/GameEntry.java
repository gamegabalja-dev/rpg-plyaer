package app.rpgrunner;

import java.util.LinkedHashMap;
import java.util.Map;

/** One game in the launcher: where it lives, what engine it uses and the per-game settings. */
public final class GameEntry {
    public static final String ENGINE_MV = "mv";
    public static final String ENGINE_MZ = "mz";
    public static final String ENGINE_NWJS = "nwjs"; // some other NW.js / HTML5 game
    public static final String ENGINE_RM2K = "rm2k"; // RPG Maker 2000/2003 -> handed to EasyRPG

    public String id = "";
    public String name = "";
    public String path = "";
    public String engine = ENGINE_NWJS;
    /** Absolute path of the HTML page to load (NW.js games only). */
    public String mainHtml = "";
    /** Query string of package.json "main" (e.g. "canvas"), without '?'. */
    public String mainQuery = "";

    // user settings
    public String renderer = "auto"; // auto | canvas | webgl
    public boolean pad = true;
    public int padOpacity = 60; // percent
    public int padScale = 100; // percent
    public int fpsLimit = 0; // 0 = unlimited
    public String encoding = ""; // RM2k only, passed to EasyRPG (e.g. 949)

    public long addedAt;
    public long lastPlayed;

    public Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        m.put("id", id);
        m.put("name", name);
        m.put("path", path);
        m.put("engine", engine);
        m.put("mainHtml", mainHtml);
        m.put("mainQuery", mainQuery);
        m.put("renderer", renderer);
        m.put("pad", Boolean.valueOf(pad));
        m.put("padOpacity", Integer.valueOf(padOpacity));
        m.put("padScale", Integer.valueOf(padScale));
        m.put("fpsLimit", Integer.valueOf(fpsLimit));
        m.put("encoding", encoding);
        m.put("addedAt", Long.valueOf(addedAt));
        m.put("lastPlayed", Long.valueOf(lastPlayed));
        return m;
    }

    public static GameEntry fromMap(Map<String, Object> m) {
        GameEntry g = new GameEntry();
        if (m == null) return g;
        g.id = MiniJson.str(m.get("id"), "");
        g.name = MiniJson.str(m.get("name"), "");
        g.path = MiniJson.str(m.get("path"), "");
        g.engine = MiniJson.str(m.get("engine"), ENGINE_NWJS);
        g.mainHtml = MiniJson.str(m.get("mainHtml"), "");
        g.mainQuery = MiniJson.str(m.get("mainQuery"), "");
        g.applySettings(m);
        g.addedAt = MiniJson.num(m.get("addedAt"), 0);
        g.lastPlayed = MiniJson.num(m.get("lastPlayed"), 0);
        return g;
    }

    /** Copies only the user-editable settings (renderer, pad, ...) from m, with range checks. */
    public void applySettings(Map<String, Object> m) {
        if (m.containsKey("name")) {
            String n = MiniJson.str(m.get("name"), name).trim();
            if (n.length() > 0) name = n.length() > 80 ? n.substring(0, 80) : n;
        }
        String r = MiniJson.str(m.get("renderer"), renderer);
        renderer = (r.equals("canvas") || r.equals("webgl")) ? r : "auto";
        pad = MiniJson.bool(m.get("pad"), pad);
        padOpacity = clamp((int) MiniJson.num(m.get("padOpacity"), padOpacity), 10, 100);
        padScale = clamp((int) MiniJson.num(m.get("padScale"), padScale), 50, 160);
        int f = (int) MiniJson.num(m.get("fpsLimit"), fpsLimit);
        fpsLimit = (f == 30 || f == 45 || f == 60) ? f : 0;
        encoding = MiniJson.str(m.get("encoding"), encoding).trim();
    }

    private static int clamp(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    public boolean isRm2k() {
        return ENGINE_RM2K.equals(engine);
    }
}
