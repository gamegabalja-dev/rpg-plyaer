package app.rpgrunner;

import android.app.Application;
import android.os.Build;
import android.webkit.WebView;

/**
 * The game runs in its own process (":game", see AndroidManifest) so that quitting a game frees all of its memory and a crash of a
 * heavy game never takes the launcher down. Android only allows one process per WebView data directory, hence the suffix.
 */
public final class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 28) {
            try {
                String proc = Application.getProcessName();
                if (proc != null && proc.endsWith(":game")) WebView.setDataDirectorySuffix("game");
            } catch (Throwable ignored) {
                // already initialised or not supported: the WebView then simply uses the default directory
            }
        }
    }
}
