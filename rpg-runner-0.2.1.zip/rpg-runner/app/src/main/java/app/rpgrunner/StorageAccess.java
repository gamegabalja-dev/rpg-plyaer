package app.rpgrunner;

/** Storage path helpers that need no Android classes (unit-tested on the desktop). */
public final class StorageAccess {
    static final String EXTERNAL_STORAGE_AUTHORITY = "com.android.externalstorage.documents";
    static final String DOWNLOADS_AUTHORITY = "com.android.providers.downloads.documents";

    private StorageAccess() {}

    /**
     * Converts the document id of a folder picked with ACTION_OPEN_DOCUMENT_TREE into a real path.
     * "primary:Games/OMORI" -> "/storage/emulated/0/Games/OMORI", "1A2B-3C4D:RPG" -> "/storage/1A2B-3C4D/RPG".
     *
     * @param primaryRoot the path of the internal "primary" volume (Environment.getExternalStorageDirectory())
     * @return null when the folder is not on a real file system volume (cloud providers, MTP, ...) or the id is malformed
     */
    public static String pathFromTreeDocId(String authority, String docId, String primaryRoot) {
        if (docId == null || docId.length() == 0) return null;
        String base;
        String rel;
        if (EXTERNAL_STORAGE_AUTHORITY.equals(authority)) {
            int colon = docId.indexOf(':');
            if (colon <= 0) return null;
            String volume = docId.substring(0, colon);
            rel = docId.substring(colon + 1);
            if (volume.equalsIgnoreCase("primary")) {
                base = primaryRoot;
            } else if (volume.equalsIgnoreCase("home")) {
                base = primaryRoot + "/Documents";
            } else if (volume.matches("[A-Za-z0-9._-]+")) {
                base = "/storage/" + volume;
            } else {
                return null;
            }
        } else if (DOWNLOADS_AUTHORITY.equals(authority)) {
            if (docId.startsWith("raw:")) {
                base = docId.substring(4);
                rel = "";
            } else if (docId.equals("downloads")) {
                base = primaryRoot + "/Download";
                rel = "";
            } else {
                return null;
            }
        } else {
            return null;
        }
        if (base == null || !base.startsWith("/")) return null;
        String path = rel.length() == 0 ? base : base + "/" + rel;
        for (String part : path.split("/")) {
            if (part.equals("..")) return null;
        }
        while (path.length() > 1 && path.endsWith("/")) path = path.substring(0, path.length() - 1);
        return path.replaceAll("/{2,}", "/");
    }

    /** True when the path is in shared storage (needs the storage permission), false for the app's own folders. */
    public static boolean isSharedStorage(String path, String packageName) {
        if (path == null) return false;
        boolean shared = path.startsWith("/storage/") || path.startsWith("/sdcard") || path.startsWith("/mnt/");
        if (!shared) return false;
        // /storage/emulated/0/Android/data/<our package>/... is ours and needs no permission
        return !(path.contains("/Android/data/" + packageName + "/") || path.endsWith("/Android/data/" + packageName)
                || path.contains("/Android/media/" + packageName + "/"));
    }
}
