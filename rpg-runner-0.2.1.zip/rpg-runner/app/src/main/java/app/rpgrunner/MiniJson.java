package app.rpgrunner;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Minimal JSON reader/writer. The core classes have to run on a plain desktop JDK (they are unit-tested there),
 * where org.json does not exist, so the app carries its own tiny implementation.
 *
 * Reader: Map (insertion ordered) / List / String / Long / Double / Boolean / null. Integers that fit into a long
 * come back as Long, everything else numeric as Double. Invalid input yields null, never an exception.
 * Writer: output is safe to embed in an inline script or HTML ('<', '>', '&', U+2028/9 are escaped).
 */
public final class MiniJson {
    private static final int MAX_DEPTH = 100;
    private static final char[] HEX = "0123456789abcdef".toCharArray();

    private final String s;
    private int i = 0;

    private MiniJson(String s) {
        this.s = s;
    }

    /** Same as {@link #tryParse(String)}. */
    public static Object parse(String text) {
        return tryParse(text);
    }

    /** Parses JSON text; returns null if it is not valid JSON (or is the literal null). */
    public static Object tryParse(String text) {
        if (text == null) return null;
        if (text.length() > 0 && text.charAt(0) == '﻿') text = text.substring(1);
        try {
            MiniJson p = new MiniJson(text);
            p.ws();
            Object v = p.value(0);
            p.ws();
            if (p.i != text.length()) return null; // trailing garbage
            return v;
        } catch (RuntimeException e) {
            return null;
        }
    }

    private void ws() {
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c == ' ' || c == '\t' || c == '\n' || c == '\r') i++;
            else break;
        }
    }

    private Object value(int depth) {
        if (depth > MAX_DEPTH) throw new IllegalStateException("too deep");
        char c = s.charAt(i);
        switch (c) {
            case '{':
                return object(depth);
            case '[':
                return array(depth);
            case '"':
                return string();
            case 't':
                expect("true");
                return Boolean.TRUE;
            case 'f':
                expect("false");
                return Boolean.FALSE;
            case 'n':
                expect("null");
                return null;
            default:
                return number();
        }
    }

    private void expect(String lit) {
        if (!s.startsWith(lit, i)) throw new IllegalStateException("bad literal");
        i += lit.length();
    }

    private Map<String, Object> object(int depth) {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        i++; // {
        ws();
        if (s.charAt(i) == '}') {
            i++;
            return m;
        }
        while (true) {
            ws();
            String k = string();
            ws();
            if (s.charAt(i++) != ':') throw new IllegalStateException("expected colon");
            ws();
            m.put(k, value(depth + 1));
            ws();
            char c = s.charAt(i++);
            if (c == ',') continue;
            if (c == '}') return m;
            throw new IllegalStateException("bad object");
        }
    }

    private List<Object> array(int depth) {
        List<Object> l = new ArrayList<Object>();
        i++; // [
        ws();
        if (s.charAt(i) == ']') {
            i++;
            return l;
        }
        while (true) {
            ws();
            l.add(value(depth + 1));
            ws();
            char c = s.charAt(i++);
            if (c == ',') continue;
            if (c == ']') return l;
            throw new IllegalStateException("bad array");
        }
    }

    private String string() {
        if (s.charAt(i) != '"') throw new IllegalStateException("expected string");
        i++;
        StringBuilder b = new StringBuilder();
        while (true) {
            char c = s.charAt(i++);
            if (c == '"') return b.toString();
            if (c != '\\') {
                b.append(c);
                continue;
            }
            char e = s.charAt(i++);
            switch (e) {
                case 'n':
                    b.append('\n');
                    break;
                case 'r':
                    b.append('\r');
                    break;
                case 't':
                    b.append('\t');
                    break;
                case 'b':
                    b.append('\b');
                    break;
                case 'f':
                    b.append('\f');
                    break;
                case 'u':
                    b.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                    i += 4;
                    break;
                default:
                    b.append(e); // \" \\ \/
            }
        }
    }

    private Object number() {
        int st = i;
        boolean integral = true;
        while (i < s.length()) {
            char c = s.charAt(i);
            if (c >= '0' && c <= '9' || c == '-' || c == '+') {
                i++;
            } else if (c == '.' || c == 'e' || c == 'E') {
                integral = false;
                i++;
            } else {
                break;
            }
        }
        if (st == i) throw new IllegalStateException("bad number");
        String t = s.substring(st, i);
        if (integral) {
            try {
                return Long.valueOf(Long.parseLong(t));
            } catch (NumberFormatException tooBig) {
                // fall through: out of long range
            }
        }
        return Double.valueOf(Double.parseDouble(t));
    }

    // ---------------------------------------------------------------- writer

    public static String stringify(Object v) {
        StringBuilder b = new StringBuilder();
        write(b, v);
        return b.toString();
    }

    private static void write(StringBuilder b, Object v) {
        if (v == null) {
            b.append("null");
        } else if (v instanceof String) {
            writeString(b, (String) v);
        } else if (v instanceof Boolean) {
            b.append(v.toString());
        } else if (v instanceof Long || v instanceof Integer || v instanceof Short || v instanceof Byte) {
            b.append(((Number) v).longValue());
        } else if (v instanceof Number) {
            double d = ((Number) v).doubleValue();
            if (Double.isNaN(d) || Double.isInfinite(d)) b.append("null");
            else if (d == Math.rint(d) && Math.abs(d) < 1e15) b.append((long) d);
            else b.append(d);
        } else if (v instanceof Map) {
            b.append('{');
            boolean first = true;
            for (Map.Entry<?, ?> e : ((Map<?, ?>) v).entrySet()) {
                if (!first) b.append(',');
                first = false;
                writeString(b, String.valueOf(e.getKey()));
                b.append(':');
                write(b, e.getValue());
            }
            b.append('}');
        } else if (v instanceof Object[]) {
            write(b, Arrays.asList((Object[]) v));
        } else if (v instanceof Iterable) {
            b.append('[');
            boolean first = true;
            for (Object o : (Iterable<?>) v) {
                if (!first) b.append(',');
                first = false;
                write(b, o);
            }
            b.append(']');
        } else {
            writeString(b, v.toString());
        }
    }

    /** Appends s as a JSON string literal. Escapes '<', '>' and '&' too, so the result can sit inside an inline script. */
    public static void writeString(StringBuilder b, String s) {
        b.append('"');
        for (int k = 0; k < s.length(); k++) {
            char c = s.charAt(k);
            switch (c) {
                case '"':
                    b.append("\\\"");
                    break;
                case '\\':
                    b.append("\\\\");
                    break;
                case '\n':
                    b.append("\\n");
                    break;
                case '\r':
                    b.append("\\r");
                    break;
                case '\t':
                    b.append("\\t");
                    break;
                case '\b':
                    b.append("\\b");
                    break;
                case '\f':
                    b.append("\\f");
                    break;
                case '<':
                case '>':
                case '&':
                case ' ':
                case ' ':
                    unicodeEscape(b, c);
                    break;
                default:
                    if (c < 0x20) unicodeEscape(b, c);
                    else b.append(c);
            }
        }
        b.append('"');
    }

    private static void unicodeEscape(StringBuilder b, char c) {
        b.append("\\u").append(HEX[(c >> 12) & 15]).append(HEX[(c >> 8) & 15]).append(HEX[(c >> 4) & 15]).append(HEX[c & 15]);
    }

    // ---------------------------------------------------------------- typed access (all tolerant: wrong type -> default)

    @SuppressWarnings("unchecked")
    public static Map<String, Object> asMap(Object o) {
        return o instanceof Map ? (Map<String, Object>) o : null;
    }

    @SuppressWarnings("unchecked")
    public static List<Object> asList(Object o) {
        return o instanceof List ? (List<Object>) o : null;
    }

    public static String str(Object o, String def) {
        return o instanceof String ? (String) o : def;
    }

    public static long num(Object o, long def) {
        return o instanceof Number ? ((Number) o).longValue() : def;
    }

    public static boolean bool(Object o, boolean def) {
        return o instanceof Boolean ? ((Boolean) o).booleanValue() : def;
    }
}
