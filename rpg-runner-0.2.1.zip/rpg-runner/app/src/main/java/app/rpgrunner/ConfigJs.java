package app.rpgrunner;

import java.util.LinkedHashMap;
import java.util.Map;

/** Builds /__rr/config.js: the per-game settings the injected JavaScript (shim.js, overlay.js) reads. */
public final class ConfigJs {
    private ConfigJs() {}

    /**
     * @param dataDir writable folder for this game inside the app (nw.App.dataPath, HOME, APPDATA ...)
     * @param tmpDir  writable scratch folder (os.tmpdir())
     */
    public static String build(GameEntry g, String dataDir, String tmpDir, boolean debug) {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        m.put("gameId", g.id);
        m.put("name", g.name);
        m.put("engine", g.engine);
        m.put("root", g.path);
        m.put("mainHtml", g.mainHtml);
        m.put("dataDir", dataDir);
        m.put("tmpDir", tmpDir);
        m.put("renderer", g.renderer);
        m.put("pad", Boolean.valueOf(g.pad));
        m.put("padOpacity", Integer.valueOf(g.padOpacity));
        m.put("padScale", Integer.valueOf(g.padScale));
        m.put("fpsLimit", Integer.valueOf(g.fpsLimit));
        m.put("platform", "linux");
        m.put("nwVersion", "0.78.1");
        m.put("debug", Boolean.valueOf(debug));
        return "window.__RR_CONFIG=" + MiniJson.stringify(m) + ";\n";
    }
}
