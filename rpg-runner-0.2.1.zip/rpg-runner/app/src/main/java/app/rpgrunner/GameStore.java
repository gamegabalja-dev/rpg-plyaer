package app.rpgrunner;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The launcher's game list, persisted as one small JSON file. Pure Java (unit-tested on the desktop).
 *
 * The launcher and the game run in different processes, so nothing is cached: every call re-reads the file, and every
 * write replaces it atomically (temp file + rename), so a reader never sees half a file.
 */
public final class GameStore {
    private static final int VERSION = 1;
    private final File file;

    public GameStore(File file) {
        this.file = file;
    }

    public synchronized List<GameEntry> list() {
        List<GameEntry> res = new ArrayList<GameEntry>();
        if (!file.isFile()) return res;
        Object parsed;
        try {
            parsed = MiniJson.tryParse(new String(NativeFs.readAll(file), "UTF-8"));
        } catch (IOException e) {
            return res;
        }
        Map<String, Object> root = MiniJson.asMap(parsed);
        List<Object> games = root == null ? null : MiniJson.asList(root.get("games"));
        if (games == null) {
            if (parsed == null && file.length() > 0) {
                // unreadable file: keep a copy for diagnosis and start over instead of failing forever
                File bak = new File(file.getPath() + ".bad");
                bak.delete();
                file.renameTo(bak);
            }
            return res;
        }
        for (Object o : games) {
            Map<String, Object> m = MiniJson.asMap(o);
            if (m == null) continue;
            GameEntry g = GameEntry.fromMap(m);
            if (g.id.length() > 0 && g.path.length() > 0) res.add(g);
        }
        return res;
    }

    public synchronized GameEntry find(String id) {
        if (id == null) return null;
        for (GameEntry g : list()) {
            if (g.id.equals(id)) return g;
        }
        return null;
    }

    /** Adds the game, or replaces the stored entry with the same id (keeping its original addedAt). @return true if it was new. */
    public synchronized boolean upsert(GameEntry g) {
        List<GameEntry> all = list();
        boolean isNew = true;
        for (int i = 0; i < all.size(); i++) {
            if (all.get(i).id.equals(g.id)) {
                if (all.get(i).addedAt > 0) g.addedAt = all.get(i).addedAt;
                all.set(i, g);
                isNew = false;
                break;
            }
        }
        if (isNew) all.add(g);
        write(all);
        return isNew;
    }

    public synchronized boolean remove(String id) {
        List<GameEntry> all = list();
        boolean removed = false;
        for (int i = all.size() - 1; i >= 0; i--) {
            if (all.get(i).id.equals(id)) {
                all.remove(i);
                removed = true;
            }
        }
        if (removed) write(all);
        return removed;
    }

    private void write(List<GameEntry> all) {
        List<Object> arr = new ArrayList<Object>();
        for (GameEntry g : all) arr.add(g.toMap());
        Map<String, Object> root = new LinkedHashMap<String, Object>();
        root.put("version", Integer.valueOf(VERSION));
        root.put("games", arr);
        File parent = file.getAbsoluteFile().getParentFile();
        if (parent != null) parent.mkdirs();
        File tmp = new File(file.getPath() + ".tmp");
        try {
            OutputStream out = new FileOutputStream(tmp);
            try {
                out.write(MiniJson.stringify(root).getBytes("UTF-8"));
                out.flush();
            } finally {
                out.close();
            }
            if (!tmp.renameTo(file)) {
                file.delete();
                if (!tmp.renameTo(file)) throw new IOException("cannot replace " + file);
            }
        } catch (IOException e) {
            tmp.delete();
            throw new IllegalStateException("could not save the game list: " + e.getMessage(), e);
        }
    }
}
