package app.rpgrunner;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Path helpers shared by the file server, the fs bridge and the game detector. */
final class PathUtil {
    private PathUtil() {}

    /**
     * Lexically normalizes an absolute POSIX path: backslashes become '/', duplicate slashes collapse,
     * "." and ".." are resolved (".." can never climb above "/"). Returns null if the path is not absolute
     * or contains a NUL byte.
     */
    static String normalize(String p) {
        if (p == null || p.indexOf('\0') >= 0) return null;
        p = p.replace('\\', '/');
        if (p.length() == 0 || p.charAt(0) != '/') return null;
        List<String> out = new ArrayList<String>();
        int n = p.length();
        int start = 0;
        while (start <= n) {
            int end = p.indexOf('/', start);
            if (end < 0) end = n;
            String part = p.substring(start, end);
            if (part.length() == 0 || part.equals(".")) {
                // skip
            } else if (part.equals("..")) {
                if (!out.isEmpty()) out.remove(out.size() - 1);
            } else {
                out.add(part);
            }
            start = end + 1;
        }
        if (out.isEmpty()) return "/";
        StringBuilder sb = new StringBuilder();
        for (String part : out) sb.append('/').append(part);
        return sb.toString();
    }

    /** Exact-case child if it exists, otherwise a case-insensitive match, otherwise null. */
    static File findChild(File dir, String name) {
        if (dir == null || name == null || name.length() == 0) return null;
        File exact = new File(dir, name);
        if (exact.exists()) return exact;
        String[] names = dir.list();
        if (names == null) return null;
        for (String n : names) {
            if (n.equalsIgnoreCase(name)) return new File(dir, n);
        }
        return null;
    }

    /** Resolves a relative path ("www/index.html", "../x") below base, matching every component case-insensitively. */
    static File resolveRelative(File base, String rel) {
        if (rel == null) return null;
        rel = rel.replace('\\', '/');
        File cur = base;
        for (String part : rel.split("/")) {
            if (part.length() == 0 || part.equals(".")) continue;
            if (part.equals("..")) {
                cur = cur.getParentFile();
                if (cur == null) return null;
                continue;
            }
            cur = findChild(cur, part);
            if (cur == null) return null;
        }
        return cur;
    }

    static String lower(String s) {
        return s == null ? "" : s.toLowerCase(java.util.Locale.ROOT);
    }

    /**
     * Where an Android path lives, for the log: "internal storage", "removable volume ID" (SD card / USB stick: /storage/ID/...)
     * or "unknown". Reading many small files from a removable volume is often slower than from internal storage.
     */
    static String storageKind(String path) {
        String p = normalize(path);
        if (p == null) return "unknown";
        if (p.equals("/sdcard") || p.startsWith("/sdcard/") || p.startsWith("/storage/emulated/") || p.startsWith("/storage/self/")
                || p.startsWith("/data/") || p.startsWith("/mnt/sdcard") || p.startsWith("/mnt/user/")) {
            return "internal storage";
        }
        if (p.startsWith("/storage/")) {
            String rest = p.substring("/storage/".length());
            int slash = rest.indexOf('/');
            String id = slash < 0 ? rest : rest.substring(0, slash);
            if (id.length() > 0 && !id.equals("emulated") && !id.equals("self")) return "removable volume " + id + " (SD card / USB)";
        }
        return "unknown";
    }
}
