package app.rpgrunner;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Minimal HTTP/1.1 file server bound to 127.0.0.1.
 *
 * It serves the game folder under its real absolute path (so location.pathname inside the page equals
 * the file-system path, exactly like file:// inside NW.js), supports Range requests (needed for
 * &lt;video&gt;/&lt;audio&gt; seeking), resolves names case-insensitively, and injects the NW.js compatibility
 * layer into every HTML page it serves. Pure Java on purpose: it is unit-tested on a desktop JVM.
 */
public final class GameServer {
    public interface AssetSource {
        InputStream open(String name) throws IOException;
    }

    public interface Listener {
        void onLog(String level, String message);
    }

    private static final Charset LATIN1 = Charset.forName("ISO-8859-1");
    private static final Charset UTF8 = Charset.forName("UTF-8");

    /** NW.js games: config, then the Node/NW.js compatibility layer (before any game script), the lag diagnostics, then the touch overlay. */
    static final String INJECT =
            "<script src=\"/__rr/config.js\"></script>"
                    + "<script src=\"/__rr/shim.js\"></script>"
                    + "<script src=\"/__rr/perf.js\"></script>"
                    + "<script src=\"/__rr/overlay.js\" defer></script>";

    /**
     * The EasyRPG wrapper page must NOT see the Node emulation (Emscripten would mistake it for Node).
     * Its own on-screen buttons (#apad: no number keys, hidden in fullscreen) are replaced by the overlay's pad.
     */
    static final String INJECT_PLAYER =
            "<script src=\"/__rr/config.js\"></script>"
                    + "<script src=\"/__rr/perf.js\"></script>"
                    + "<style>#apad{display:none!important}</style>"
                    + "<script src=\"/__rr/overlay.js\" defer></script>";

    private static final String EASYRPG_PREFIX = "/__rr/easyrpg/";
    private static final Pattern EASYRPG_ASSET = Pattern.compile("[A-Za-z0-9_.-]+");
    private static final Pattern EASYRPG_KEY = Pattern.compile("[A-Za-z0-9_-]{1,64}");
    private static final int MAX_ASSET_BYTES = 64 * 1024 * 1024;

    private static final Pattern HEAD_TAG = Pattern.compile("<head(\\s[^>]*)?>", Pattern.CASE_INSENSITIVE);
    private static final Pattern HTML_TAG = Pattern.compile("<html(\\s[^>]*)?>", Pattern.CASE_INSENSITIVE);
    private static final Pattern DOCTYPE = Pattern.compile("<!doctype[^>]*>", Pattern.CASE_INSENSITIVE);
    private static final Pattern RR_ASSET = Pattern.compile("[A-Za-z0-9_.-]+\\.js");

    private final NativeFs fs;
    private final AssetSource assets;
    private final Listener listener;
    private final RequestStats stats;
    private volatile String configJs;

    private ServerSocket server;
    private Thread acceptor;
    private ExecutorService pool;
    private volatile boolean running;
    private int port;
    private final Set<Socket> openSockets = Collections.synchronizedSet(new HashSet<Socket>());
    private final Set<String> notFoundSeen = Collections.synchronizedSet(new HashSet<String>());
    private final Map<String, File> easyRpgGames = new ConcurrentHashMap<String, File>();

    public GameServer(NativeFs fs, AssetSource assets, String configJs, Listener listener) {
        this.fs = fs;
        this.assets = assets;
        this.configJs = configJs;
        this.listener = listener;
        this.stats = new RequestStats(new RequestStats.Sink() {
            @Override
            public void log(String level, String message) {
                GameServer.this.log(level, message);
            }
        });
    }

    /** For tests: log every request instead of only the slow ones. */
    void setSlowRequestMs(long ms) {
        stats.setSlowMs(ms);
    }

    public void setConfigJs(String js) {
        this.configJs = js;
    }

    public int port() {
        return port;
    }

    /**
     * Makes a RPG Maker 2000/2003 game folder available to the EasyRPG web player at
     * /__rr/easyrpg/games/&lt;key&gt;/ (index.json is generated on the fly).
     */
    public void registerEasyRpgGame(String key, File root) {
        if (key == null || !EASYRPG_KEY.matcher(key).matches()) throw new IllegalArgumentException("bad key");
        easyRpgGames.put(key, root);
    }

    public int start() throws IOException {
        return start(0);
    }

    /**
     * Binds 127.0.0.1. A stable port per game keeps the page origin (and therefore localStorage / IndexedDB, which is
     * where EasyRPG keeps its save files) the same between runs; if it is taken a random port is used instead.
     */
    public int start(int preferredPort) throws IOException {
        InetAddress lo = InetAddress.getByName("127.0.0.1");
        server = null;
        if (preferredPort > 0 && preferredPort < 65536) {
            // The previous run may still be releasing the port (the acceptor thread has to wake up first): retry briefly.
            for (int attempt = 0; attempt < 10 && server == null; attempt++) {
                try {
                    server = new ServerSocket(preferredPort, 128, lo);
                } catch (IOException busy) {
                    server = null;
                    try {
                        Thread.sleep(60);
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
            if (server == null) log("W", "port " + preferredPort + " is busy, using a random port (web storage will not carry over)");
        }
        if (server == null) server = new ServerSocket(0, 128, lo);
        port = server.getLocalPort();
        running = true;
        pool = Executors.newCachedThreadPool(new ThreadFactory() {
            private int n;

            public synchronized Thread newThread(Runnable r) {
                Thread t = new Thread(r, "rr-http-" + (++n));
                t.setDaemon(true);
                return t;
            }
        });
        acceptor = new Thread(new Runnable() {
            public void run() {
                while (running) {
                    try {
                        final Socket s = server.accept();
                        pool.execute(new Runnable() {
                            public void run() {
                                serve(s);
                            }
                        });
                    } catch (IOException e) {
                        if (running) log("E", "accept failed: " + e);
                        break;
                    } catch (RuntimeException e) {
                        break; // pool shut down
                    }
                }
            }
        }, "rr-http-accept");
        acceptor.setDaemon(true);
        acceptor.start();
        return port;
    }

    public void stop() {
        running = false;
        stats.finish(System.nanoTime() / 1000000L);
        try {
            if (server != null) server.close();
        } catch (IOException ignored) {
            // ignore
        }
        synchronized (openSockets) {
            for (Socket s : openSockets) {
                try {
                    s.close();
                } catch (IOException ignored) {
                    // ignore
                }
            }
            openSockets.clear();
        }
        if (pool != null) pool.shutdownNow();
        Thread a = acceptor;
        if (a != null && a != Thread.currentThread()) {
            try {
                a.join(800); // lets the listening socket be released before the next start() on the same port
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }
    }

    // ------------------------------------------------------------------ connection loop

    private void serve(Socket s) {
        openSockets.add(s);
        try {
            s.setTcpNoDelay(true);
            s.setSoTimeout(60000);
            InputStream in = new BufferedInputStream(s.getInputStream(), 8192);
            TimedOutput out = new TimedOutput(new BufferedOutputStream(s.getOutputStream(), 65536));
            while (running) {
                Request req = readRequest(in);
                if (req == null) break;
                long t0 = System.nanoTime();
                out.reset();
                boolean keep = handle(req, out);
                out.flush();
                long t1 = System.nanoTime();
                String shown = req.path == null ? null : percentDecode(req.path);
                stats.record(req.method == null ? "?" : req.method, shown != null ? shown : req.path, out.bytes, (t1 - t0) / 1000000L,
                        req.readNs / 1000000L, out.nanos / 1000000L, t1 / 1000000L);
                if (!keep) break;
            }
        } catch (IOException e) {
            // client went away / idle timeout: normal
        } catch (RuntimeException e) {
            log("E", "request crashed: " + e);
        } finally {
            openSockets.remove(s);
            try {
                s.close();
            } catch (IOException ignored) {
                // ignore
            }
        }
    }

    /** Counts what is written and how long handing it to the socket takes (blocks when the page does not read). */
    private static final class TimedOutput extends FilterOutputStream {
        long bytes;
        long nanos;

        TimedOutput(OutputStream out) {
            super(out);
        }

        @Override
        public void write(int b) throws IOException {
            long t = System.nanoTime();
            out.write(b);
            nanos += System.nanoTime() - t;
            bytes++;
        }

        @Override
        public void write(byte[] b, int off, int len) throws IOException {
            long t = System.nanoTime();
            out.write(b, off, len);
            nanos += System.nanoTime() - t;
            bytes += len;
        }

        @Override
        public void flush() throws IOException {
            long t = System.nanoTime();
            out.flush();
            nanos += System.nanoTime() - t;
        }

        void reset() {
            bytes = 0;
            nanos = 0;
        }
    }

    private static final class Request {
        String method;
        String path = "/";
        String version = "HTTP/1.1";
        boolean bad;
        long readNs; // time spent reading the file from storage (for the timing log)
        final Map<String, String> headers = new HashMap<String, String>();

        String header(String name) {
            return headers.get(name.toLowerCase(Locale.ROOT));
        }
    }

    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) >= 0) {
            if (c == '\n') {
                int len = sb.length();
                if (len > 0 && sb.charAt(len - 1) == '\r') sb.setLength(len - 1);
                return sb.toString();
            }
            sb.append((char) c);
            if (sb.length() > 16384) throw new IOException("header line too long");
        }
        return sb.length() == 0 ? null : sb.toString();
    }

    private static Request readRequest(InputStream in) throws IOException {
        String line = readLine(in);
        int guard = 0;
        while (line != null && line.length() == 0 && guard++ < 4) line = readLine(in);
        if (line == null) return null;
        Request r = new Request();
        String[] parts = line.split(" ");
        if (parts.length < 2) {
            r.bad = true;
        } else {
            r.method = parts[0];
            String target = parts[1];
            int cut = target.length();
            int q = target.indexOf('?');
            if (q >= 0) cut = q;
            int h = target.indexOf('#');
            if (h >= 0 && h < cut) cut = h;
            r.path = target.substring(0, cut);
            if (parts.length > 2) r.version = parts[2];
        }
        int count = 0;
        while (true) {
            String h = readLine(in);
            if (h == null) return null;
            if (h.length() == 0) break;
            if (++count > 100) throw new IOException("too many headers");
            int colon = h.indexOf(':');
            if (colon > 0) r.headers.put(h.substring(0, colon).trim().toLowerCase(Locale.ROOT), h.substring(colon + 1).trim());
        }
        return r;
    }

    // ------------------------------------------------------------------ routing

    private boolean handle(Request req, OutputStream out) throws IOException {
        boolean keep = "HTTP/1.1".equals(req.version) && !"close".equalsIgnoreCase(req.header("connection"));
        if (req.bad || req.method == null) {
            simple(out, 400, "Bad Request", false, false);
            return false;
        }
        // DNS-rebinding guard: only accept requests addressed to the loopback name we hand to the WebView
        String host = req.header("host");
        if (host != null) {
            String h = host.toLowerCase(Locale.ROOT);
            if (!(h.equals("127.0.0.1:" + port) || h.equals("localhost:" + port))) {
                simple(out, 403, "Forbidden", keep, false);
                return keep;
            }
        }
        boolean head = "HEAD".equals(req.method);
        if (!head && !"GET".equals(req.method)) {
            if ("OPTIONS".equals(req.method)) {
                writeHead(out, 204, "No Content", null, 0, keep, null);
                return keep;
            }
            simple(out, 405, "Method Not Allowed", keep, false);
            return keep;
        }
        String path = percentDecode(req.path);
        if (path == null) {
            simple(out, 400, "Bad Request", keep, head);
            return keep;
        }
        try {
            if (path.startsWith(EASYRPG_PREFIX)) return serveEasyRpg(path.substring(EASYRPG_PREFIX.length()), req, out, head, keep);
            if (path.startsWith("/__rr/")) return serveRR(path.substring(6), out, head, keep);
            return serveFile(path, req, out, head, keep);
        } catch (IOException e) {
            throw e;
        } catch (RuntimeException e) {
            log("E", "500 for " + path + ": " + e);
            simple(out, 500, "Internal Server Error", false, head);
            return false;
        }
    }

    private boolean serveRR(String name, OutputStream out, boolean head, boolean keep) throws IOException {
        byte[] body;
        if (name.equals("ping")) {
            body = "ok".getBytes(UTF8);
        } else if (name.equals("config.js")) {
            body = configJs.getBytes(UTF8);
        } else if (RR_ASSET.matcher(name).matches()) {
            InputStream in = null;
            try {
                in = assets.open("shim/" + name);
            } catch (IOException e) {
                in = null;
            }
            if (in == null) {
                simple(out, 404, "Not Found", keep, head);
                return keep;
            }
            ByteArrayOutputStream bos = new ByteArrayOutputStream(64 * 1024);
            try {
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            } finally {
                in.close();
            }
            body = bos.toByteArray();
        } else {
            simple(out, 404, "Not Found", keep, head);
            return keep;
        }
        String mime = name.equals("ping") ? "text/plain" : "application/javascript; charset=utf-8";
        writeHead(out, 200, "OK", mime, body.length, keep, null);
        if (!head) out.write(body);
        return keep;
    }

    private boolean serveFile(String path, Request req, OutputStream out, boolean head, boolean keep) throws IOException {
        File f = fs.resolve(path, true);
        if (f != null && f.isDirectory()) {
            File idx = PathUtil.findChild(f, "index.html");
            f = (idx != null && idx.isFile()) ? idx : null;
        }
        if (f == null || !f.isFile()) {
            if (notFoundSeen.add(path)) log("W", "404 " + path);
            simple(out, 404, "Not Found", keep, head);
            return keep;
        }
        String ext = extension(f.getName());
        if (ext.equals("html") || ext.equals("htm")) return serveHtml(f, req, out, head, keep);
        return serveStatic(f, ext, req, out, head, keep);
    }

    /** Plain file with Range support. */
    private boolean serveStatic(File f, String ext, Request req, OutputStream out, boolean head, boolean keep) throws IOException {
        long size = f.length();
        long start = 0;
        long end = size - 1;
        int status = 200;
        String range = req.header("range");
        if (range != null && size > 0 && range.startsWith("bytes=") && range.indexOf(',') < 0) {
            String spec = range.substring(6).trim();
            int dash = spec.indexOf('-');
            if (dash >= 0) {
                String a = spec.substring(0, dash).trim();
                String b = spec.substring(dash + 1).trim();
                try {
                    if (a.length() == 0) {
                        long suffix = Long.parseLong(b);
                        if (suffix <= 0) throw new NumberFormatException();
                        start = Math.max(0, size - suffix);
                        end = size - 1;
                    } else {
                        start = Long.parseLong(a);
                        end = b.length() == 0 ? size - 1 : Math.min(Long.parseLong(b), size - 1);
                    }
                    if (start >= size || start > end) {
                        writeHead(out, 416, "Range Not Satisfiable", "text/plain", 0, keep, "Content-Range: bytes */" + size + "\r\n");
                        return keep;
                    }
                    status = 206;
                } catch (NumberFormatException e) {
                    start = 0;
                    end = size - 1;
                    status = 200;
                }
            }
        }
        long len = size == 0 ? 0 : end - start + 1;
        String extra = status == 206 ? "Content-Range: bytes " + start + "-" + end + "/" + size + "\r\n" : null;
        writeHead(out, status, status == 206 ? "Partial Content" : "OK", mimeFor(ext), len, keep, extra);
        if (head || len == 0) return keep;
        RandomAccessFile raf = new RandomAccessFile(f, "r");
        try {
            raf.seek(start);
            byte[] buf = new byte[65536];
            long remaining = len;
            while (remaining > 0) {
                long tr = System.nanoTime();
                int n = raf.read(buf, 0, (int) Math.min(buf.length, remaining));
                req.readNs += System.nanoTime() - tr;
                if (n < 0) throw new IOException("file shrank while sending: " + f);
                out.write(buf, 0, n);
                remaining -= n;
            }
        } finally {
            raf.close();
        }
        return keep;
    }

    private boolean serveHtml(File f, Request req, OutputStream out, boolean head, boolean keep) throws IOException {
        if (f.length() > 16L * 1024 * 1024) {
            simple(out, 413, "Payload Too Large", keep, head);
            return keep;
        }
        long tr = System.nanoTime();
        byte[] raw = NativeFs.readAll(f);
        req.readNs += System.nanoTime() - tr;
        String html = new String(raw, LATIN1); // byte-transparent round trip
        byte[] body = inject(html).getBytes(LATIN1);
        String probe = html.length() > 4096 ? html.substring(0, 4096) : html;
        String mime = probe.toLowerCase(Locale.ROOT).contains("charset") ? "text/html" : "text/html; charset=utf-8";
        writeHead(out, 200, "OK", mime, body.length, keep, null);
        if (!head) out.write(body);
        return keep;
    }

    static String inject(String html) {
        return inject(html, INJECT);
    }

    static String inject(String html, String tags) {
        Matcher m = HEAD_TAG.matcher(html);
        if (m.find()) return html.substring(0, m.end()) + tags + html.substring(m.end());
        m = HTML_TAG.matcher(html);
        if (m.find()) return html.substring(0, m.end()) + tags + html.substring(m.end());
        m = DOCTYPE.matcher(html);
        if (m.find()) return html.substring(0, m.end()) + tags + html.substring(m.end());
        return tags + html;
    }

    // ------------------------------------------------------------------ EasyRPG web player

    /**
     * /__rr/easyrpg/games/&lt;key&gt;/...  -> the registered RPG Maker 2000/2003 game folder (index.json is synthesized)
     * /__rr/easyrpg/&lt;name&gt;           -> player files from the APK assets (easyrpg/index.js, index.wasm, rr-player.html)
     */
    private boolean serveEasyRpg(String rest, Request req, OutputStream out, boolean head, boolean keep) throws IOException {
        if (rest.startsWith("games/")) {
            String tail = rest.substring(6);
            int slash = tail.indexOf('/');
            String key = slash < 0 ? tail : tail.substring(0, slash);
            String sub = slash < 0 ? "" : tail.substring(slash + 1);
            File root = easyRpgGames.get(key);
            if (root == null || sub.length() == 0) {
                simple(out, 404, "Not Found", keep, head);
                return keep;
            }
            if (sub.equalsIgnoreCase("index.json")) {
                byte[] body = EasyRpgIndex.build(root).getBytes(UTF8);
                writeHead(out, 200, "OK", "application/json; charset=utf-8", body.length, keep, null);
                if (!head) out.write(body);
                return keep;
            }
            String abs = PathUtil.normalize("/" + sub);
            if (abs == null) {
                simple(out, 400, "Bad Request", keep, head);
                return keep;
            }
            File f = fs.resolve(root.getPath() + abs, true);
            if (f == null || !f.isFile()) {
                if (notFoundSeen.add("easyrpg:" + key + abs)) log("W", "404 (EasyRPG) " + abs);
                simple(out, 404, "Not Found", keep, head);
                return keep;
            }
            return serveStatic(f, extension(f.getName()), req, out, head, keep);
        }
        if (!EASYRPG_ASSET.matcher(rest).matches()) {
            simple(out, 404, "Not Found", keep, head);
            return keep;
        }
        byte[] body = readAsset("easyrpg/" + rest);
        if (body == null) {
            simple(out, 404, "Not Found", keep, head);
            return keep;
        }
        String ext = extension(rest);
        if (ext.equals("html")) {
            body = inject(new String(body, LATIN1), INJECT_PLAYER).getBytes(LATIN1);
        }
        writeHead(out, 200, "OK", mimeFor(ext), body.length, keep, null);
        if (!head) out.write(body);
        return keep;
    }

    /** Whole asset as bytes, or null if it does not exist. */
    private byte[] readAsset(String name) throws IOException {
        InputStream in;
        try {
            in = assets.open(name);
        } catch (IOException e) {
            return null;
        }
        if (in == null) return null;
        ByteArrayOutputStream bos = new ByteArrayOutputStream(64 * 1024);
        try {
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) {
                bos.write(buf, 0, n);
                if (bos.size() > MAX_ASSET_BYTES) throw new IOException("asset too large: " + name);
            }
        } finally {
            in.close();
        }
        return bos.toByteArray();
    }

    // ------------------------------------------------------------------ helpers

    private static void simple(OutputStream out, int code, String reason, boolean keep, boolean head) throws IOException {
        byte[] body = (code + " " + reason + "\n").getBytes(LATIN1);
        writeHead(out, code, reason, "text/plain; charset=utf-8", body.length, keep, null);
        if (!head) out.write(body);
    }

    private static void writeHead(OutputStream out, int status, String reason, String mime, long length, boolean keep, String extra)
            throws IOException {
        StringBuilder sb = new StringBuilder(256);
        sb.append("HTTP/1.1 ").append(status).append(' ').append(reason).append("\r\n");
        if (mime != null) sb.append("Content-Type: ").append(mime).append("\r\n");
        sb.append("Content-Length: ").append(length).append("\r\n");
        sb.append("Accept-Ranges: bytes\r\n");
        sb.append("Cache-Control: no-store\r\n");
        if (extra != null) sb.append(extra);
        sb.append(keep ? "Connection: keep-alive\r\n" : "Connection: close\r\n");
        sb.append("\r\n");
        out.write(sb.toString().getBytes(LATIN1));
    }

    private static String percentDecode(String s) {
        byte[] in = s.getBytes(LATIN1);
        ByteArrayOutputStream out = new ByteArrayOutputStream(in.length);
        for (int i = 0; i < in.length; i++) {
            int b = in[i] & 0xFF;
            if (b == '%') {
                if (i + 2 >= in.length) return null;
                int hi = hex(in[i + 1]);
                int lo = hex(in[i + 2]);
                if (hi < 0 || lo < 0) return null;
                out.write(hi * 16 + lo);
                i += 2;
            } else {
                out.write(b);
            }
        }
        return new String(out.toByteArray(), UTF8);
    }

    private static int hex(byte c) {
        if (c >= '0' && c <= '9') return c - '0';
        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
        return -1;
    }

    private static String extension(String name) {
        int dot = name.lastIndexOf('.');
        return dot < 0 ? "" : name.substring(dot + 1).toLowerCase(Locale.ROOT);
    }

    static String mimeFor(String ext) {
        switch (ext) {
            case "html":
            case "htm":
                return "text/html";
            case "js":
            case "mjs":
                return "application/javascript; charset=utf-8";
            case "json":
                return "application/json; charset=utf-8";
            case "css":
                return "text/css; charset=utf-8";
            case "txt":
            case "md":
                return "text/plain; charset=utf-8";
            case "xml":
                return "application/xml; charset=utf-8";
            case "png":
                return "image/png";
            case "jpg":
            case "jpeg":
                return "image/jpeg";
            case "gif":
                return "image/gif";
            case "webp":
                return "image/webp";
            case "svg":
                return "image/svg+xml";
            case "ico":
                return "image/x-icon";
            case "ogg":
            case "oga":
                return "audio/ogg";
            case "m4a":
                return "audio/mp4";
            case "mp3":
                return "audio/mpeg";
            case "wav":
                return "audio/wav";
            case "webm":
                return "video/webm";
            case "mp4":
                return "video/mp4";
            case "ttf":
                return "font/ttf";
            case "otf":
                return "font/otf";
            case "woff":
                return "font/woff";
            case "woff2":
                return "font/woff2";
            case "wasm":
                return "application/wasm";
            default:
                return "application/octet-stream";
        }
    }

    private void log(String level, String msg) {
        if (listener != null) listener.onLog(level, msg);
    }
}
