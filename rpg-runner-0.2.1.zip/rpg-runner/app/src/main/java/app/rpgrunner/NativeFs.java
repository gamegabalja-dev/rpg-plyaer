package app.rpgrunner;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Sandboxed file system used by both the HTTP file server and the JavaScript "fs" bridge.
 *
 * Every path has to live below one of the allowed roots (the game folder and the app's data folder).
 * Windows games are written with case-insensitive file systems in mind, so lookups fall back to a
 * case-insensitive match when the exact name does not exist.
 *
 * All bridge-facing methods return Strings: "" means success for mutators, a leading '!' means error
 * ("!ENOENT", "!EACCES", ...). Data-returning methods never legitimately start with '!'.
 */
public final class NativeFs {
    private final List<String> roots = new ArrayList<String>();
    private final Map<String, Boolean> insideCache = new HashMap<String, Boolean>();

    public NativeFs(File... allowedRoots) {
        for (File r : allowedRoots) {
            if (r == null) continue;
            try {
                roots.add(PathUtil.normalize(r.getCanonicalPath()));
            } catch (IOException e) {
                roots.add(PathUtil.normalize(r.getAbsolutePath()));
            }
        }
    }

    public List<String> roots() {
        return new ArrayList<String>(roots);
    }

    // ------------------------------------------------------------------ resolution

    /** Returns the real file for a client path, or null when it is outside the sandbox (or, with mustExist, missing). */
    public File resolve(String path, boolean mustExist) {
        String n = PathUtil.normalize(path);
        if (n == null) return null;
        for (String root : roots) {
            String rel = relativeTo(root, n);
            if (rel == null) continue;
            if (rel.length() == 0) return new File(root);
            File direct = new File(root, rel);
            if (direct.exists()) return insideSandbox(root, direct) ? direct : null;
            File cur = new File(root);
            String[] parts = rel.split("/");
            for (int k = 0; k < parts.length; k++) {
                File next = PathUtil.findChild(cur, parts[k]);
                if (next == null) {
                    if (mustExist) return null;
                    File rest = cur;
                    for (int j = k; j < parts.length; j++) rest = new File(rest, parts[j]);
                    return insideSandbox(root, rest) ? rest : null;
                }
                cur = next;
            }
            return insideSandbox(root, cur) ? cur : null;
        }
        return null;
    }

    /** Path of n below root ("" for root itself), or null if n is not below root. Falls back to a case-insensitive prefix match. */
    private static String relativeTo(String root, String n) {
        if (n.equals(root)) return "";
        String prefix = root.equals("/") ? "/" : root + "/";
        if (n.startsWith(prefix)) return n.substring(prefix.length());
        if (n.length() > prefix.length() && n.regionMatches(true, 0, prefix, 0, prefix.length())) {
            return n.substring(prefix.length());
        }
        if (n.equalsIgnoreCase(root)) return "";
        return null;
    }

    /** Guards against symlinks that point out of the sandbox. Result is cached per parent directory. */
    private boolean insideSandbox(String root, File f) {
        File parent = f.getParentFile();
        String key = root + "|" + (parent == null ? "" : parent.getPath());
        synchronized (insideCache) {
            Boolean hit = insideCache.get(key);
            if (hit != null) return hit.booleanValue();
        }
        boolean ok;
        try {
            String canon = PathUtil.normalize((parent == null ? f : parent).getCanonicalPath());
            ok = canon != null && (canon.equals(root) || canon.startsWith(root.equals("/") ? "/" : root + "/"));
        } catch (IOException e) {
            ok = false;
        }
        synchronized (insideCache) {
            if (insideCache.size() > 4096) insideCache.clear();
            insideCache.put(key, Boolean.valueOf(ok));
        }
        return ok;
    }

    // ------------------------------------------------------------------ queries

    public String exists(String path) {
        File f = resolve(path, true);
        return (f != null && f.exists()) ? "1" : "0";
    }

    public String stat(String path) {
        File f = resolve(path, true);
        if (f == null || !f.exists()) return "!ENOENT";
        return "{\"f\":" + (f.isFile() ? 1 : 0) + ",\"d\":" + (f.isDirectory() ? 1 : 0)
                + ",\"s\":" + f.length() + ",\"m\":" + f.lastModified() + "}";
    }

    public String readdir(String path) {
        File f = resolve(path, true);
        if (f == null || !f.exists()) return "!ENOENT";
        if (!f.isDirectory()) return "!ENOTDIR";
        String[] names = f.list();
        if (names == null) return "!EACCES";
        Arrays.sort(names);
        StringBuilder sb = new StringBuilder("[");
        for (int k = 0; k < names.length; k++) {
            if (k > 0) sb.append(',');
            MiniJson.writeString(sb, names[k]);
        }
        return sb.append(']').toString();
    }

    public String readBase64(String path) {
        File f = resolve(path, true);
        if (f == null || !f.exists()) return "!ENOENT";
        if (f.isDirectory()) return "!EISDIR";
        if (f.length() > 64L * 1024 * 1024) return "!EFBIG";
        try {
            return Base64Lite.encode(readAll(f));
        } catch (IOException e) {
            return "!EIO";
        }
    }

    // ------------------------------------------------------------------ mutations

    public String writeBase64(String path, String b64, boolean append) {
        byte[] data = Base64Lite.decode(b64 == null ? "" : b64);
        if (data == null) return "!EINVAL";
        return writeBytes(path, data, append);
    }

    public String writeBytes(String path, byte[] data, boolean append) {
        File f = resolve(path, false);
        if (f == null) return "!EACCES";
        File parent = f.getParentFile();
        if (parent == null || !parent.isDirectory()) return "!ENOENT";
        if (f.isDirectory()) return "!EISDIR";
        try {
            if (append) {
                FileOutputStream out = new FileOutputStream(f, true);
                try {
                    out.write(data);
                } finally {
                    out.close();
                }
            } else {
                // Write to a temp file and rename so that a crash / kill mid-save cannot corrupt a save file.
                File tmp = new File(parent, f.getName() + ".rr-tmp");
                FileOutputStream out = new FileOutputStream(tmp);
                try {
                    out.write(data);
                    out.flush();
                    try {
                        out.getFD().sync();
                    } catch (IOException ignored) {
                        // not all file systems support fsync
                    }
                } finally {
                    out.close();
                }
                if (!tmp.renameTo(f)) {
                    // rename over an existing file can fail on some file systems
                    if (f.exists() && !f.delete()) {
                        tmp.delete();
                        return "!EACCES";
                    }
                    if (!tmp.renameTo(f)) {
                        FileOutputStream direct = new FileOutputStream(f);
                        try {
                            direct.write(data);
                        } finally {
                            direct.close();
                        }
                        tmp.delete();
                    }
                }
            }
            invalidate();
            return "";
        } catch (IOException e) {
            return "!EIO";
        }
    }

    public String mkdir(String path, boolean recursive) {
        File f = resolve(path, false);
        if (f == null) return "!EACCES";
        if (f.exists()) return f.isDirectory() && recursive ? "" : "!EEXIST";
        boolean ok = recursive ? f.mkdirs() : f.mkdir();
        invalidate();
        if (ok) return "";
        File parent = f.getParentFile();
        return (parent != null && !parent.exists()) ? "!ENOENT" : "!EACCES";
    }

    public String unlink(String path) {
        File f = resolve(path, true);
        if (f == null || !f.exists()) return "!ENOENT";
        if (f.isDirectory()) return "!EISDIR";
        boolean ok = f.delete();
        invalidate();
        return ok ? "" : "!EACCES";
    }

    public String rmdir(String path, boolean recursive) {
        File f = resolve(path, true);
        if (f == null || !f.exists()) return "!ENOENT";
        if (!f.isDirectory()) return "!ENOTDIR";
        for (String r : roots) {
            if (f.getPath().equals(r)) return "!EACCES"; // never delete a sandbox root
        }
        String[] kids = f.list();
        if (kids != null && kids.length > 0 && !recursive) return "!ENOTEMPTY";
        boolean ok = deleteTree(f);
        invalidate();
        return ok ? "" : "!EACCES";
    }

    public String rename(String from, String to) {
        File a = resolve(from, true);
        if (a == null || !a.exists()) return "!ENOENT";
        File b = resolve(to, false);
        if (b == null) return "!EACCES";
        File parent = b.getParentFile();
        if (parent == null || !parent.isDirectory()) return "!ENOENT";
        if (b.exists() && b.isFile() && a.isFile()) b.delete();
        boolean ok = a.renameTo(b);
        invalidate();
        return ok ? "" : "!EACCES";
    }

    public String copy(String from, String to) {
        File a = resolve(from, true);
        if (a == null || !a.exists()) return "!ENOENT";
        if (a.isDirectory()) return "!EISDIR";
        File b = resolve(to, false);
        if (b == null) return "!EACCES";
        File parent = b.getParentFile();
        if (parent == null || !parent.isDirectory()) return "!ENOENT";
        try {
            InputStream in = new FileInputStream(a);
            try {
                OutputStream out = new FileOutputStream(b);
                try {
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                } finally {
                    out.close();
                }
            } finally {
                in.close();
            }
            invalidate();
            return "";
        } catch (IOException e) {
            return "!EIO";
        }
    }

    // ------------------------------------------------------------------ helpers

    private void invalidate() {
        synchronized (insideCache) {
            insideCache.clear();
        }
    }

    static byte[] readAll(File f) throws IOException {
        InputStream in = new FileInputStream(f);
        try {
            long len = f.length();
            if (len > Integer.MAX_VALUE) throw new IOException("too large");
            byte[] buf = new byte[(int) len];
            int off = 0;
            while (off < buf.length) {
                int n = in.read(buf, off, buf.length - off);
                if (n < 0) break;
                off += n;
            }
            return off == buf.length ? buf : Arrays.copyOf(buf, off);
        } finally {
            in.close();
        }
    }

    private static boolean deleteTree(File f) {
        if (f.isDirectory()) {
            File[] kids = f.listFiles();
            if (kids != null) {
                for (File k : kids) {
                    // do not follow symlinks out of the tree
                    try {
                        if (!k.getCanonicalPath().startsWith(f.getCanonicalPath() + File.separator)) {
                            k.delete();
                            continue;
                        }
                    } catch (IOException e) {
                        continue;
                    }
                    deleteTree(k);
                }
            }
        }
        return f.delete();
    }
}
