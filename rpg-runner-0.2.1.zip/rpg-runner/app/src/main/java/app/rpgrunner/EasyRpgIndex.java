package app.rpgrunner;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Builds the "index.json" the EasyRPG web player needs next to a game (format version 2, as parsed by
 * AsyncHandler::CreateRequestMapping in EasyRPG/Player). This is what the official "gencache" tool does;
 * generating it on the fly means the user never has to prepare the game folder.
 *
 * Rules the engine relies on:
 *  - files in the game root are looked up WITH their extension (RPG_RT.ldb, Map0001.lmu ...), lower-cased;
 *  - files in sub folders are looked up by name WITHOUT extension (Music/Foo.mid is requested as "Music", "Foo");
 *  - every directory object carries its real spelling in "_dirname", file values carry the real file name.
 */
public final class EasyRpgIndex {
    /** If several files share a base name inside one folder, the one with the earliest extension wins. */
    private static final List<String> EXT_ORDER = Arrays.asList(
            "png", "bmp", "xyz", "ogg", "opus", "oga", "mp3", "wav", "mid", "midi", "fon", "ttf", "otf", "ttc");
    private static final int MAX_DEPTH = 8;
    private static final int MAX_FILES = 200000;

    private EasyRpgIndex() {}

    public static String build(File gameDir) {
        StringBuilder sb = new StringBuilder(64 * 1024);
        sb.append("{\"metadata\":{\"version\":2},\"cache\":");
        int[] budget = {MAX_FILES};
        writeDir(sb, gameDir, null, 0, budget);
        sb.append('}');
        return sb.toString();
    }

    private static void writeDir(StringBuilder sb, File dir, String realName, int depth, int[] budget) {
        boolean root = realName == null;
        sb.append('{');
        boolean first = true;
        if (!root) {
            sb.append("\"_dirname\":");
            MiniJson.writeString(sb, realName);
            first = false;
        }
        File[] kids = dir.listFiles();
        if (kids == null) kids = new File[0];
        Arrays.sort(kids, new Comparator<File>() {
            public int compare(File a, File b) {
                return a.getName().compareTo(b.getName());
            }
        });

        // pass 1: files (resolve key collisions by extension preference)
        Map<String, String> files = new HashMap<String, String>();
        List<String> keyOrder = new ArrayList<String>();
        for (File k : kids) {
            String name = k.getName();
            if (!k.isFile() || skip(name)) continue;
            String key = lowerAscii(root ? name : stripExt(name));
            String old = files.get(key);
            if (old == null) {
                files.put(key, name);
                keyOrder.add(key);
            } else if (rank(name) < rank(old)) {
                files.put(key, name);
            }
        }
        for (String key : keyOrder) {
            if (budget[0]-- <= 0) break;
            if (!first) sb.append(',');
            first = false;
            MiniJson.writeString(sb, key);
            sb.append(':');
            MiniJson.writeString(sb, files.get(key));
        }

        // pass 2: sub directories (keys are prefixed so they can never collide with a file key; the engine ignores them)
        if (depth < MAX_DEPTH) {
            for (File k : kids) {
                String name = k.getName();
                if (!k.isDirectory() || skip(name)) continue;
                if (!first) sb.append(',');
                first = false;
                MiniJson.writeString(sb, "/" + lowerAscii(name));
                sb.append(':');
                writeDir(sb, k, name, depth + 1, budget);
            }
        }
        sb.append('}');
    }

    private static boolean skip(String name) {
        return name.startsWith(".") || name.endsWith(".rr-tmp") || name.equalsIgnoreCase("Thumbs.db")
                || name.equalsIgnoreCase("desktop.ini");
    }

    private static int rank(String fileName) {
        int dot = fileName.lastIndexOf('.');
        String ext = dot < 0 ? "" : fileName.substring(dot + 1).toLowerCase(Locale.ROOT);
        int i = EXT_ORDER.indexOf(ext);
        return i < 0 ? EXT_ORDER.size() : i;
    }

    static String stripExt(String name) {
        int dot = name.lastIndexOf('.');
        return dot <= 0 ? name : name.substring(0, dot);
    }

    /** ASCII-only lower casing, like the engine's Utils::LowerCase (non-ASCII letters keep their case). */
    static String lowerAscii(String s) {
        StringBuilder sb = null;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= 'A' && c <= 'Z') {
                if (sb == null) {
                    sb = new StringBuilder(s);
                }
                sb.setCharAt(i, (char) (c + 32));
            }
        }
        return sb == null ? s : sb.toString();
    }

    /** Kept for tests: every key the engine would be able to resolve, as "lowercase path" -> "real path". */
    static Map<String, String> flatten(File gameDir) {
        Map<String, String> out = new HashMap<String, String>();
        flattenInto(out, gameDir, "", "", true);
        return Collections.unmodifiableMap(out);
    }

    private static void flattenInto(Map<String, String> out, File dir, String lowerPath, String realPath, boolean root) {
        File[] kids = dir.listFiles();
        if (kids == null) return;
        for (File k : kids) {
            String name = k.getName();
            if (skip(name)) continue;
            if (k.isDirectory()) {
                flattenInto(out, k, lowerPath + lowerAscii(name) + "/", realPath + name + "/", false);
            } else if (k.isFile()) {
                String key = lowerPath + lowerAscii(root ? name : stripExt(name));
                String cur = out.get(key);
                if (cur == null || rank(name) < rank(cur.substring(cur.lastIndexOf('/') + 1))) out.put(key, realPath + name);
            }
        }
    }
}
