package app.rpgrunner;

import java.io.File;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Recognises RPG Maker / NW.js game folders. Pure Java (unit-tested on the desktop). */
public final class GameDetector {
    private static final int MAX_JSON_BYTES = 2 * 1024 * 1024;

    private GameDetector() {}

    /** Returns an entry (with default settings) if dir is a game folder, otherwise null. */
    public static GameEntry detect(File dir) {
        if (dir == null || !dir.isDirectory()) return null;

        // RPG Maker 2000 / 2003 (EasyRPG)
        File ldb = PathUtil.findChild(dir, "RPG_RT.ldb");
        File lmt = PathUtil.findChild(dir, "RPG_RT.lmt");
        File ini = PathUtil.findChild(dir, "RPG_RT.ini");
        if (ldb != null || lmt != null) {
            GameEntry g = base(dir);
            g.engine = GameEntry.ENGINE_RM2K;
            String t = ini == null ? null : iniValue(ini, "GameTitle");
            if (t != null && t.trim().length() > 0) g.name = t.trim();
            return g;
        }

        // NW.js / HTML5 (RPG Maker MV, MZ, others)
        File pkg = PathUtil.findChild(dir, "package.json");
        Map<String, Object> pj = pkg == null ? null : MiniJson.asMap(MiniJson.tryParse(readSmallText(pkg)));
        File main = null;
        String query = "";
        String mainRel = pj == null ? null : MiniJson.str(pj.get("main"), null);
        if (mainRel != null && mainRel.trim().length() > 0) {
            String rel = mainRel.trim();
            int hash = rel.indexOf('#');
            if (hash >= 0) rel = rel.substring(0, hash);
            int q = rel.indexOf('?');
            if (q >= 0) {
                query = rel.substring(q + 1);
                rel = rel.substring(0, q);
            }
            File f = PathUtil.resolveRelative(dir, rel);
            if (f != null && f.isFile() && isHtml(f.getName())) main = f;
            else query = "";
        }
        if (main == null) main = firstExisting(dir, "www/index.html", "index.html");
        if (main == null) return null;

        GameEntry g = base(dir);
        g.mainHtml = canonical(main);
        g.mainQuery = query;
        File webDir = main.getParentFile();
        File js = PathUtil.findChild(webDir, "js");
        if (js != null && PathUtil.findChild(js, "rmmz_core.js") != null) g.engine = GameEntry.ENGINE_MZ;
        else if (js != null && PathUtil.findChild(js, "rpg_core.js") != null) g.engine = GameEntry.ENGINE_MV;
        else g.engine = GameEntry.ENGINE_NWJS;

        String title = systemTitle(webDir);
        if (title == null && pj != null) {
            Map<String, Object> win = MiniJson.asMap(pj.get("window"));
            title = win == null ? null : MiniJson.str(win.get("title"), null);
            if (title != null && title.trim().length() == 0) title = null;
        }
        if (title != null && title.trim().length() > 0) g.name = title.trim();
        return g;
    }

    /** dir itself if it is a game, otherwise every game found up to depth levels below it. */
    public static List<GameEntry> scan(File dir, int depth) {
        List<GameEntry> out = new ArrayList<GameEntry>();
        int[] budget = {400}; // directories we are willing to look at
        scanInto(dir, depth, out, budget);
        return out;
    }

    private static void scanInto(File dir, int depth, List<GameEntry> out, int[] budget) {
        if (dir == null || budget[0]-- <= 0 || out.size() >= 50) return;
        GameEntry g = detect(dir);
        if (g != null) {
            out.add(g);
            return;
        }
        if (depth <= 0) return;
        File[] kids = dir.listFiles();
        if (kids == null) return;
        Arrays.sort(kids);
        for (File k : kids) {
            if (!k.isDirectory()) continue;
            String n = k.getName();
            if (n.startsWith(".") || n.equalsIgnoreCase("Android") || n.equalsIgnoreCase("node_modules")
                    || n.equalsIgnoreCase("www") || n.equalsIgnoreCase("save")) continue;
            scanInto(k, depth - 1, out, budget);
        }
    }

    // ------------------------------------------------------------------ helpers

    private static GameEntry base(File dir) {
        GameEntry g = new GameEntry();
        String p = canonical(dir);
        g.path = p;
        g.id = idFor(p);
        g.name = dir.getName();
        g.addedAt = System.currentTimeMillis();
        return g;
    }

    static String idFor(String path) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] h = md.digest(path.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (int k = 0; k < 6; k++) sb.append(String.format(Locale.ROOT, "%02x", h[k] & 0xFF));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            return Integer.toHexString(path.hashCode());
        } catch (java.io.UnsupportedEncodingException e) {
            return Integer.toHexString(path.hashCode());
        }
    }

    private static String canonical(File f) {
        try {
            return f.getCanonicalPath();
        } catch (IOException e) {
            return f.getAbsolutePath();
        }
    }

    private static boolean isHtml(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return n.endsWith(".html") || n.endsWith(".htm");
    }

    private static File firstExisting(File dir, String... rels) {
        for (String r : rels) {
            File f = PathUtil.resolveRelative(dir, r);
            if (f != null && f.isFile()) return f;
        }
        return null;
    }

    private static String systemTitle(File webDir) {
        File data = PathUtil.findChild(webDir, "data");
        if (data == null) return null;
        File sys = PathUtil.findChild(data, "System.json");
        if (sys == null) return null;
        Map<String, Object> m = MiniJson.asMap(MiniJson.tryParse(readSmallText(sys)));
        if (m == null) return null;
        String t = MiniJson.str(m.get("gameTitle"), null);
        return (t != null && t.trim().length() > 0) ? t : null;
    }

    private static String readSmallText(File f) {
        try {
            if (f.length() > MAX_JSON_BYTES) return "";
            return new String(NativeFs.readAll(f), "UTF-8");
        } catch (IOException e) {
            return "";
        }
    }

    /** Reads "Key=Value" from an .ini (RPG_RT.ini uses the system code page; titles are usually ASCII or Shift-JIS/CP949). */
    private static String iniValue(File ini, String key) {
        try {
            byte[] raw = NativeFs.readAll(ini);
            String text = new String(raw, "ISO-8859-1");
            for (String line : text.split("\r?\n")) {
                int eq = line.indexOf('=');
                if (eq > 0 && line.substring(0, eq).trim().equalsIgnoreCase(key)) {
                    String v = line.substring(eq + 1).trim();
                    // best effort: decode as UTF-8 when it is valid UTF-8, otherwise keep only printable ASCII
                    try {
                        String utf = new String(v.getBytes("ISO-8859-1"), "UTF-8");
                        if (utf.indexOf(0xFFFD) < 0) return utf;
                    } catch (java.io.UnsupportedEncodingException ignored) {
                        // fall through
                    }
                    return v.replaceAll("[^\\x20-\\x7E]", "").trim();
                }
            }
        } catch (IOException e) {
            // ignore
        }
        return null;
    }
}
