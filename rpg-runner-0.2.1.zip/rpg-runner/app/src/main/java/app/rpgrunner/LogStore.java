package app.rpgrunner;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.RandomAccessFile;
import java.io.Writer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Per-session log file. Every console message of the game, every failed request and every shim warning ends up here,
 * so a run that goes wrong can be diagnosed from the file alone (the launcher has a "copy log" button).
 */
public final class LogStore {
    private static final long MAX_BYTES = 6L * 1024 * 1024;

    private final File file;
    private Writer out;
    private long written;
    private boolean truncated;
    private String lastMsg;
    private int repeat;
    private final SimpleDateFormat stamp = new SimpleDateFormat("HH:mm:ss.SSS", Locale.US);

    private LogStore(File file) {
        this.file = file;
    }

    /** File-name part made of a game name: only [A-Za-z0-9._-], at most 40 characters, never empty. */
    static String safeName(String gameName) {
        String safe = gameName == null ? "game" : gameName.replaceAll("[^A-Za-z0-9._-]+", "_");
        if (safe.length() > 40) safe = safe.substring(0, 40);
        if (safe.length() == 0) safe = "game";
        return safe;
    }

    /**
     * Creates a new log file "<dir>/<name>-<gameId>-yyyyMMdd-HHmmss.log" (without the id part when gameId is empty). The id makes the file
     * findable per game even when the game is renamed or its name is not ASCII (see latestFor). If the file cannot be created the store
     * still works (memory only).
     */
    public static LogStore create(File dir, String gameName, String gameId) {
        String safe = safeName(gameName);
        String id = gameId == null ? "" : gameId.replaceAll("[^A-Za-z0-9_]+", "");
        String ts = new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(new Date());
        File f = new File(dir, safe + "-" + (id.length() > 0 ? id + "-" : "") + ts + ".log");
        LogStore ls = new LogStore(f);
        try {
            if (dir != null && (dir.isDirectory() || dir.mkdirs())) {
                ls.out = new OutputStreamWriter(new FileOutputStream(f, true), "UTF-8");
            }
        } catch (IOException e) {
            ls.out = null;
        }
        return ls;
    }

    /** The newest log written for the game with this id; newestFirst is the order list() returns. Null when there is none. */
    public static File latestFor(List<File> newestFirst, String gameId) {
        String id = gameId == null ? "" : gameId.replaceAll("[^A-Za-z0-9_]+", "");
        if (id.length() == 0 || newestFirst == null) return null;
        Pattern p = Pattern.compile(".+-" + Pattern.quote(id) + "-\\d{8}-\\d{6}\\.log");
        for (File f : newestFirst) {
            if (p.matcher(f.getName()).matches()) return f;
        }
        return null;
    }

    public File file() {
        return file;
    }

    public synchronized void log(String level, String msg) {
        if (msg == null) msg = "null";
        if (msg.equals(lastMsg)) {
            repeat++;
            return;
        }
        flushRepeat();
        lastMsg = msg;
        write(level, msg);
    }

    private void flushRepeat() {
        if (repeat > 0) {
            write("I", "(previous message repeated " + repeat + " more times)");
            repeat = 0;
        }
    }

    private void write(String level, String msg) {
        if (out == null) return;
        if (truncated) return;
        try {
            String line = stamp.format(new Date()) + " " + level + " " + msg + "\n";
            out.write(line);
            out.flush();
            written += line.length();
            if (written > MAX_BYTES) {
                truncated = true;
                out.write("-- log size limit reached, further messages dropped --\n");
                out.flush();
            }
        } catch (IOException e) {
            out = null;
        }
    }

    public synchronized void close() {
        flushRepeat();
        if (out != null) {
            try {
                out.close();
            } catch (IOException ignored) {
                // ignore
            }
            out = null;
        }
    }

    /** Last maxBytes of a log file as text (used by the "copy log" button). */
    public static String tail(File f, int maxBytes) {
        if (f == null || !f.isFile()) return "";
        try {
            RandomAccessFile raf = new RandomAccessFile(f, "r");
            try {
                long len = raf.length();
                long start = Math.max(0, len - maxBytes);
                raf.seek(start);
                byte[] buf = new byte[(int) (len - start)];
                raf.readFully(buf);
                String s = new String(buf, "UTF-8");
                if (start > 0) {
                    int nl = s.indexOf('\n');
                    if (nl >= 0) s = "... (earlier lines omitted)\n" + s.substring(nl + 1);
                }
                return s;
            } finally {
                raf.close();
            }
        } catch (IOException e) {
            return "";
        }
    }

    /** Log files in dir, newest first. */
    public static List<File> list(File dir) {
        List<File> res = new ArrayList<File>();
        File[] all = dir == null ? null : dir.listFiles();
        if (all == null) return res;
        for (File f : all) {
            if (f.isFile() && f.getName().endsWith(".log")) res.add(f);
        }
        Collections.sort(res, new Comparator<File>() {
            public int compare(File a, File b) {
                return Long.valueOf(b.lastModified()).compareTo(Long.valueOf(a.lastModified()));
            }
        });
        return res;
    }

    /** Keeps only the newest keep log files. */
    public static void prune(File dir, int keep) {
        List<File> files = list(dir);
        for (int k = keep; k < files.size(); k++) files.get(k).delete();
    }
}
