package app.rpgrunner;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Runs one game: starts the local file server, shows the game page in a full-screen WebView and exposes the small native
 * bridge ("RRNative") that the injected shim.js / overlay.js use for everything a browser cannot do (writing save files,
 * listing folders, logging, quitting, the pause menu).
 *
 * Runs in its own process (":game"): leaving the game kills the process, which frees all memory of heavy games.
 */
public final class GameActivity extends Activity {
    public static final String EXTRA_GAME_ID = "app.rpgrunner.GAME_ID";

    /** Show the red error banner on screen in addition to the log file (the log file is always written). */
    private static final boolean DEBUG_BANNER = true;
    private static final String EASYRPG_PACKAGE = "org.easyrpg.player";
    private static final Pattern CHROME_VERSION = Pattern.compile("Chrome/([0-9.]+)");

    private final Handler ui = new Handler(Looper.getMainLooper());
    private FrameLayout root;
    private TextView loading;
    private WebView web;
    private GameStore store;
    private GameEntry game;
    private LogStore log;
    private NativeFs fs;
    private GameServer server;
    private volatile boolean padOn;
    private boolean menuShown;
    private boolean fatalShown;
    private boolean destroyed;

    // ------------------------------------------------------------------ lifecycle

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            getWindow().setAttributes(lp);
        }
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
        applyImmersive();

        store = new GameStore(AppDirs.gamesFile(this));
        String id = getIntent() == null ? null : getIntent().getStringExtra(EXTRA_GAME_ID);
        game = id == null ? null : store.find(id);
        if (game == null) {
            Toast.makeText(this, "게임 정보를 찾을 수 없습니다. 런처에서 다시 추가해 주세요.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        File logDir = AppDirs.logDir(this);
        log = LogStore.create(logDir, game.name, game.id);
        LogStore.prune(logDir, 40);
        installCrashLogger();
        logEnvironment(logDir);
        padOn = game.pad;

        File gameDir = new File(game.path);
        if (!gameDir.isDirectory() || !gameDir.canRead()) {
            log.log("E", "game folder not readable: " + game.path);
            fatal("게임 폴더를 열 수 없습니다",
                    game.path + "\n\n• 폴더가 이동·삭제되었거나 SD 카드가 빠졌을 수 있습니다.\n• '모든 파일 접근' 권한이 꺼져 있을 수 있습니다 (런처 화면 위쪽에서 설정).");
            return;
        }
        if (game.isRm2k() && !webPlayerAvailable()) {
            log.log("E", "EasyRPG web player is not part of this APK (assets/easyrpg/rr-player.html missing)");
            offerEasyRpgApp();
            return;
        }
        startGame(gameDir);
    }

    /** Writes how the game folder looks (folders, language packs, plugins) to the log without delaying the start. */
    private void logLayout(final File gameDir) {
        final String mainHtml = game.mainHtml;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    for (String line : LayoutProbe.describe(gameDir, mainHtml)) log.log(line.startsWith("WARNING: ") ? "W" : "I", "layout: " + line);
                    if (LayoutProbe.DUMP_OMORI_DECRYPTED.equals(LayoutProbe.sourceDumpKind(gameDir, mainHtml))) {
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                Toast.makeText(GameActivity.this, "이 OMORI 폴더는 설치된 게임이 아니라 복호화된 소스(OmoriSource)로 보입니다. "
                                        + "이대로는 메뉴 이후 진행이 안 됩니다. 정식 설치 폴더(Steam: OMORI 우클릭 → 관리 → 로컬 파일 보기)를 선택해 주세요.", Toast.LENGTH_LONG).show();
                            }
                        });
                    }
                } catch (Throwable e) {
                    log.log("W", "layout probe failed: " + e);
                }
            }
        }, "layout-probe");
        t.setDaemon(true);
        t.start();
    }

    private void startGame(File gameDir) {
        logLayout(gameDir);
        File dataDir = new File(getFilesDir(), "data/" + game.id);
        File tmpDir = new File(getCacheDir(), "tmp/" + game.id);
        dataDir.mkdirs();
        tmpDir.mkdirs();
        fs = new NativeFs(gameDir, dataDir, tmpDir);
        String cfg = ConfigJs.build(game, dataDir.getPath(), tmpDir.getPath(), DEBUG_BANNER);
        server = new GameServer(fs, new GameServer.AssetSource() {
            @Override
            public InputStream open(String name) throws IOException {
                try {
                    return getAssets().open(name);
                } catch (FileNotFoundException e) {
                    return null;
                }
            }
        }, cfg, new GameServer.Listener() {
            @Override
            public void onLog(String level, String message) {
                if (log != null) log.log(level, "[server] " + message);
            }
        });
        if (game.isRm2k()) server.registerEasyRpgGame(game.id, gameDir);
        int port;
        try {
            port = server.start(stablePort(game.id));
        } catch (IOException e) {
            log.log("E", "cannot start the local server: " + e);
            fatal("내부 서버를 시작할 수 없습니다", String.valueOf(e));
            return;
        }
        String url = PageUrl.forGame(port, game);
        log.log("I", "server on 127.0.0.1:" + port + ", opening " + url);

        createWebView();
        showLoading();
        web.loadUrl(url);
    }

    /** Same port for the same game every time, so the page origin (and with it localStorage / IndexedDB saves) never changes. */
    static int stablePort(String id) {
        int h = 0;
        for (int i = 0; i < id.length(); i++) h = h * 31 + id.charAt(i);
        return 20000 + (h & 0x7fffffff) % 20000;
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyImmersive();
        if (web != null) {
            web.onResume();
            js("window.__RR&&__RR.setPaused&&__RR.setPaused(false)");
        }
    }

    @Override
    protected void onPause() {
        if (web != null) {
            js("window.__RR&&__RR.setPaused&&__RR.setPaused(true)"); // silence the audio before the WebView is frozen
            web.onPause();
        }
        if (log != null) log.log("I", "activity paused");
        super.onPause();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) applyImmersive();
    }

    @Override
    public void onTrimMemory(int level) {
        super.onTrimMemory(level);
        if (log != null) log.log("W", "onTrimMemory level=" + level);
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        if (log != null) log.log("W", "onLowMemory");
    }

    @Override
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        showGameMenu();
    }

    @Override
    protected void onDestroy() {
        destroyed = true;
        if (web != null) {
            try {
                root.removeView(web);
                web.stopLoading();
                web.removeJavascriptInterface("RRNative");
                web.destroy();
            } catch (Throwable ignored) {
                // going away anyway
            }
            web = null;
        }
        if (server != null) server.stop();
        if (log != null) {
            log.log("I", "game closed");
            log.close();
        }
        super.onDestroy();
        if (isFinishing()) {
            // The game has its own process: end it so a heavy game leaves nothing behind in memory.
            ui.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Process.killProcess(Process.myPid());
                }
            }, 250);
        }
    }

    // ------------------------------------------------------------------ window

    @SuppressWarnings("deprecation")
    private void applyImmersive() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    private void showLoading() {
        loading = new TextView(this);
        loading.setText(game.name + "\n불러오는 중…");
        loading.setTextColor(Color.rgb(200, 200, 210));
        loading.setTextSize(16);
        loading.setGravity(Gravity.CENTER);
        root.addView(loading, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
    }

    private void hideLoading() {
        if (loading != null) {
            root.removeView(loading);
            loading = null;
        }
    }

    // ------------------------------------------------------------------ WebView

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void createWebView() {
        boolean debuggable = (getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0;
        WebView.setWebContentsDebuggingEnabled(debuggable); // chrome://inspect over USB for bug reports
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setLongClickable(false);
        web.setHapticFeedbackEnabled(false);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false); // games start music without a tap
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(false);
        s.setTextZoom(100);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        // Pose as desktop Chrome: RPG Maker MV then picks WebGL and .ogg audio like it does inside NW.js on a PC.
        s.setUserAgentString(desktopUserAgent());

        web.addJavascriptInterface(new Bridge(), "RRNative");
        web.setWebViewClient(new GameWebViewClient());
        web.setWebChromeClient(new GameChromeClient());
        root.addView(web, 0, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        web.requestFocus();
    }

    private String desktopUserAgent() {
        String def = WebSettings.getDefaultUserAgent(this);
        Matcher m = CHROME_VERSION.matcher(def == null ? "" : def);
        String version = m.find() ? m.group(1) : "120.0.0.0";
        return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/" + version + " Safari/537.36";
    }

    private void js(String code) {
        WebView w = web;
        if (w != null && !destroyed) {
            try {
                w.evaluateJavascript(code, null);
            } catch (Throwable t) {
                if (log != null) log.log("W", "evaluateJavascript failed: " + t);
            }
        }
    }

    private boolean isLoopback(Uri u) {
        String host = u == null ? null : u.getHost();
        return "127.0.0.1".equals(host) || "localhost".equals(host);
    }

    private final class GameWebViewClient extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            if (isLoopback(u)) return false;
            log.log("W", "navigation to " + u + " blocked");
            String scheme = u == null ? null : u.getScheme();
            if (request.hasGesture() && ("http".equals(scheme) || "https".equals(scheme))) openExternal(u.toString());
            return true;
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            log.log("I", "page finished: " + url);
            hideLoading();
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            log.log("E", "load error " + error.getErrorCode() + " (" + error.getDescription() + ") for " + request.getUrl());
        }

        @Override
        public void onReceivedHttpError(WebView view, WebResourceRequest request, WebResourceResponse errorResponse) {
            // 404s are already logged by the file server (once per file); only report main-frame and server errors here
            if (request.isForMainFrame() || errorResponse.getStatusCode() >= 500) {
                log.log("W", "http " + errorResponse.getStatusCode() + " for " + request.getUrl());
            }
        }

        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            final boolean crashed = detail.didCrash();
            log.log("E", "WebView render process gone: " + (crashed ? "crashed" : "killed by the system (out of memory?)"));
            ui.post(new Runnable() {
                @Override
                public void run() {
                    fatal("게임 화면이 종료되었습니다", crashed
                            ? "웹뷰 렌더러가 비정상 종료했습니다. 로그를 확인해 주세요."
                            : "메모리 부족으로 시스템이 게임 화면을 종료했습니다.\nOMORI처럼 무거운 게임은 다른 앱을 모두 닫고 실행해 보세요.");
                }
            });
            return true;
        }
    }

    private final class GameChromeClient extends WebChromeClient {
        @Override
        public boolean onConsoleMessage(ConsoleMessage m) {
            String level;
            switch (m.messageLevel()) {
                case ERROR:
                    level = "E";
                    break;
                case WARNING:
                    level = "W";
                    break;
                case DEBUG:
                case TIP:
                    level = "D";
                    break;
                default:
                    level = "I";
                    break;
            }
            String src = m.sourceId();
            if (src != null) {
                int slash = src.lastIndexOf('/');
                if (slash >= 0) src = src.substring(slash + 1);
            }
            log.log(level, "[console] " + m.message() + "  (" + src + ":" + m.lineNumber() + ")");
            return true;
        }

        @Override
        public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
            log.log("W", "[alert] " + message);
            if (destroyed || isFinishing()) {
                result.confirm();
                return true;
            }
            new AlertDialog.Builder(GameActivity.this).setMessage(message).setCancelable(false)
                    .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            result.confirm();
                        }
                    }).show();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
            log.log("W", "[confirm] " + message);
            if (destroyed || isFinishing()) {
                result.cancel();
                return true;
            }
            new AlertDialog.Builder(GameActivity.this).setMessage(message).setCancelable(false)
                    .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            result.confirm();
                        }
                    })
                    .setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            result.cancel();
                        }
                    }).show();
            return true;
        }

        @Override
        public void onPermissionRequest(PermissionRequest request) {
            log.log("W", "web permission request denied: " + Arrays.toString(request.getResources()));
            request.deny();
        }
    }

    // ------------------------------------------------------------------ JavaScript bridge

    /**
     * window.RRNative. Names, argument counts and types are a contract with shim.js / overlay.js (the Chromium test mocks exactly
     * this surface and rejects any other call). Methods run on a WebView background thread, never on the UI thread.
     * File methods return "" / data on success and "!ECODE" on failure (see NativeFs).
     */
    private final class Bridge {
        @JavascriptInterface
        public String exists(String path) {
            return guard(fs == null ? "!EIO" : fs.exists(path));
        }

        @JavascriptInterface
        public String stat(String path) {
            return guard(fs == null ? "!EIO" : fs.stat(path));
        }

        @JavascriptInterface
        public String readdir(String path) {
            return guard(fs == null ? "!EIO" : fs.readdir(path));
        }

        @JavascriptInterface
        public String readBase64(String path) {
            return guard(fs == null ? "!EIO" : fs.readBase64(path));
        }

        @JavascriptInterface
        public String writeBase64(String path, String base64, boolean append) {
            try {
                return fs == null ? "!EIO" : fs.writeBase64(path, base64, append);
            } catch (RuntimeException e) {
                log.log("E", "writeBase64 failed for " + path + ": " + e);
                return "!EIO";
            }
        }

        @JavascriptInterface
        public String mkdir(String path, boolean recursive) {
            return guard(fs == null ? "!EIO" : fs.mkdir(path, recursive));
        }

        @JavascriptInterface
        public String unlink(String path) {
            return guard(fs == null ? "!EIO" : fs.unlink(path));
        }

        @JavascriptInterface
        public String rmdir(String path, boolean recursive) {
            return guard(fs == null ? "!EIO" : fs.rmdir(path, recursive));
        }

        @JavascriptInterface
        public String rename(String from, String to) {
            return guard(fs == null ? "!EIO" : fs.rename(from, to));
        }

        @JavascriptInterface
        public String copy(String from, String to) {
            return guard(fs == null ? "!EIO" : fs.copy(from, to));
        }

        @JavascriptInterface
        public void log(String level, String message) {
            if (log != null) log.log(level == null ? "I" : level, "[js] " + message);
        }

        @JavascriptInterface
        public void exit() {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    finish();
                }
            });
        }

        @JavascriptInterface
        public void showMenu() {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    showGameMenu();
                }
            });
        }

        @JavascriptInterface
        public void openUrl(final String url) {
            if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
            ui.post(new Runnable() {
                @Override
                public void run() {
                    openExternal(url);
                }
            });
        }

        private String guard(String result) {
            return result == null ? "!EIO" : result;
        }
    }

    // ------------------------------------------------------------------ menu and dialogs

    private void showGameMenu() {
        if (destroyed || isFinishing() || menuShown) return;
        menuShown = true;
        final String[] items = {"계속하기", padOn ? "가상 패드 끄기" : "가상 패드 켜기", "로그 복사", "게임 종료"};
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(game.name).setItems(items, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface d, int which) {
                if (which == 1) {
                    padOn = !padOn;
                    js("window.__RR_UI&&__RR_UI.setPad(" + padOn + ")");
                    try {
                        game.pad = padOn;
                        store.upsert(game);
                    } catch (RuntimeException e) {
                        log.log("W", "could not remember the pad setting: " + e);
                    }
                } else if (which == 2) {
                    copyLogToClipboard();
                } else if (which == 3) {
                    finish();
                }
            }
        }).create();
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface d) {
                menuShown = false;
                applyImmersive();
                if (web != null) web.requestFocus();
            }
        });
        dialog.show();
    }

    private void copyLogToClipboard() {
        if (log == null) return;
        String text = LogStore.tail(log.file(), 60 * 1024);
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm != null) {
            cm.setPrimaryClip(ClipData.newPlainText("RPG Runner log", text));
            Toast.makeText(this, "로그를 복사했습니다 (" + log.file().getName() + ")", Toast.LENGTH_LONG).show();
        }
    }

    /** A blocking error: shows the message and leaves the game when the button is pressed. */
    private void fatal(String title, String message) {
        if (destroyed || isFinishing() || fatalShown) return;
        fatalShown = true;
        hideLoading();
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setCancelable(false)
                .setPositiveButton("닫기", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        finish();
                    }
                }).show();
    }

    private boolean webPlayerAvailable() {
        try {
            String[] names = getAssets().list("easyrpg");
            return names != null && Arrays.asList(names).contains("rr-player.html");
        } catch (IOException e) {
            return false;
        }
    }

    private void offerEasyRpgApp() {
        final Intent launch = getPackageManager().getLaunchIntentForPackage(EASYRPG_PACKAGE);
        AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle("EasyRPG 웹 플레이어가 없습니다").setCancelable(false);
        StringBuilder msg = new StringBuilder("이 APK에는 EasyRPG 웹 플레이어가 들어 있지 않습니다 (빌드 중 다운로드가 실패한 경우).\n\n");
        if (launch != null) {
            msg.append("설치되어 있는 EasyRPG Player 앱으로 게임 폴더를 직접 열 수 있습니다. 폴더 경로를 복사해 두겠습니다.\n\n");
            b.setPositiveButton("EasyRPG 앱 열기", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                    if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("game folder", game.path));
                    try {
                        startActivity(launch);
                    } catch (ActivityNotFoundException ignored) {
                        // fall through to finish()
                    }
                    finish();
                }
            });
            b.setNegativeButton("닫기", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
        } else {
            msg.append("README의 안내대로 APK를 다시 빌드하거나, EasyRPG Player 앱(easyrpg.org)을 설치해 사용해 주세요.\n\n");
            b.setPositiveButton("닫기", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
        }
        msg.append("게임 폴더:\n").append(game.path);
        b.setMessage(msg.toString()).show();
    }

    private void openExternal(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (ActivityNotFoundException e) {
            log.log("W", "no app to open " + url);
        }
    }

    // ------------------------------------------------------------------ diagnostics

    private void installCrashLogger() {
        final Thread.UncaughtExceptionHandler previous = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override
            public void uncaughtException(Thread t, Throwable e) {
                try {
                    if (log != null) {
                        log.log("E", "FATAL uncaught exception in thread " + t.getName() + ":\n" + Log.getStackTraceString(e));
                        log.close();
                    }
                } catch (Throwable ignored) {
                    // never let logging hide the real crash
                }
                if (previous != null) previous.uncaughtException(t, e);
            }
        });
    }

    private void logEnvironment(File logDir) {
        String version = "?";
        try {
            version = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception ignored) {
            // keep "?"
        }
        log.log("I", "RPG Runner " + version + " | " + Build.MANUFACTURER + " " + Build.MODEL + " | Android " + Build.VERSION.RELEASE
                + " (API " + Build.VERSION.SDK_INT + ") | ABI " + Arrays.toString(Build.SUPPORTED_ABIS));
        try {
            ActivityManager am = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            log.log("I", "memory: total " + (mi.totalMem >> 20) + " MB, available " + (mi.availMem >> 20) + " MB, heap limit "
                    + am.getMemoryClass() + " MB (large " + am.getLargeMemoryClass() + " MB)");
        } catch (Exception e) {
            log.log("W", "memory info unavailable: " + e);
        }
        try {
            PackageInfo wv = WebView.getCurrentWebViewPackage();
            log.log("I", "WebView: " + (wv == null ? "unknown" : wv.packageName + " " + wv.versionName));
        } catch (Throwable e) {
            log.log("W", "WebView version unavailable: " + e);
        }
        DisplayMetrics dm = getResources().getDisplayMetrics();
        log.log("I", "display: " + dm.widthPixels + "x" + dm.heightPixels + " density " + dm.density);
        log.log("I", "game: " + game.name + " | engine " + game.engine + " | path " + game.path + " | main " + game.mainHtml
                + " | renderer " + game.renderer + " | fps " + game.fpsLimit + " | pad " + game.pad);
        log.log("I", "storage access: " + AppDirs.hasStorageAccess(this) + " | log folder " + logDir);
        log.log("I", "game folder is on: " + PathUtil.storageKind(game.path));
    }
}
