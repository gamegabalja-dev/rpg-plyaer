package app.rpgrunner;

/** Builds the loopback URL the WebView opens for a game. Pure Java (unit-tested on the desktop). */
public final class PageUrl {
    /** Where the EasyRPG web player page lives inside the server (see GameServer). */
    public static final String EASYRPG_PAGE = "/__rr/easyrpg/rr-player.html";

    private PageUrl() {}

    public static String forGame(int port, GameEntry g) {
        String base = "http://127.0.0.1:" + port;
        if (g.isRm2k()) {
            StringBuilder q = new StringBuilder("game=").append(g.id);
            String enc = g.encoding == null ? "" : g.encoding.trim();
            if (enc.matches("[A-Za-z0-9_-]{1,16}")) q.append("&encoding=").append(enc);
            return base + EASYRPG_PAGE + "?" + q;
        }
        StringBuilder url = new StringBuilder(base).append(encodePath(g.mainHtml));
        StringBuilder q = new StringBuilder();
        if (g.mainQuery != null && g.mainQuery.length() > 0) q.append(g.mainQuery);
        // RPG Maker MV reads "canvas" / "webgl" from the query string (Utils.isOptionValid); MZ ignores them.
        String opt = "canvas".equals(g.renderer) ? "canvas" : ("webgl".equals(g.renderer) ? "webgl" : null);
        if (opt != null && !hasToken(q.toString(), "canvas") && !hasToken(q.toString(), "webgl")) {
            if (q.length() > 0) q.append('&');
            q.append(opt);
        }
        if (q.length() > 0) url.append('?').append(q);
        return url.toString();
    }

    private static boolean hasToken(String query, String token) {
        for (String part : query.split("&")) {
            if (part.equals(token)) return true;
        }
        return false;
    }

    /** Characters that may appear unescaped in a URL path (RFC 3986 pchar plus '/'). Everything else becomes %XX of its UTF-8 bytes. */
    private static final String SAFE = "-_.~!$&'()*+,;=:@/";

    /** Percent-encodes an absolute file path for use as the path part of a URL (UTF-8, '/' kept). */
    static String encodePath(String absPath) {
        StringBuilder sb = new StringBuilder(absPath.length() + 16);
        byte[] bytes = absPath.getBytes(java.nio.charset.Charset.forName("UTF-8"));
        for (int i = 0; i < bytes.length; i++) {
            int c = bytes[i] & 0xFF;
            boolean plain = (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || (c < 128 && SAFE.indexOf(c) >= 0);
            if (plain) {
                sb.append((char) c);
            } else {
                sb.append('%').append(Character.toUpperCase(Character.forDigit(c >> 4, 16))).append(Character.toUpperCase(Character.forDigit(c & 15, 16)));
            }
        }
        return sb.toString();
    }
}
