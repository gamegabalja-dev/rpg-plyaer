package app.rpgrunner;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * A short, bounded description of a game folder for the log: what lies in the game folder and its web folder, the contents of
 * language / translation folders, language packs (*.cld), the enabled plugins and the most recently changed script / data files.
 * When a game complains about missing or broken files (for example a translation patch that was copied to the wrong place) the
 * log then shows how the folder really looks. Pure Java, never throws, never reads more than a few small files.
 */
public final class LayoutProbe {
    private static final int MAX_LINES = 60;
    private static final int MAX_LINE_CHARS = 1800;
    private static final int MAX_ENTRIES = 60;
    private static final int MAX_LANG_ENTRIES = 40;
    private static final int MAX_DIRS_VISITED = 300;
    private static final int MAX_READ_BYTES = 1024 * 1024;
    private static final String[] LANG_WORDS = {"lang", "locale", "translat", "i18n", "l10n", "localiz"};
    /** Folders that only hold pictures, sounds, saves ... and are never worth a visit. */
    private static final String[] SKIP_DIRS = {"img", "audio", "movies", "fonts", "node_modules", "save", "saves", "tmp", "icon"};
    private static final Pattern PLUGIN = Pattern.compile("\"name\"\\s*:\\s*\"([^\"]+)\"\\s*,\\s*\"status\"\\s*:\\s*(true|false)");

    /** {@link #sourceDumpKind}: an RPG Maker editor project (Game.rpgproject) - most of them still run. */
    public static final String DUMP_EDITOR_PROJECT = "editor-project";
    /** {@link #sourceDumpKind}: OMORI's decrypted source project (plain data files, no encrypted *.KEL) - cannot be run. */
    public static final String DUMP_OMORI_DECRYPTED = "omori-decrypted";

    private LayoutProbe() {}

    /**
     * Tells a folder that merely looks like a game apart from an installed one: OMORI's decrypted source project (the game's
     * plugins read the encrypted data/MapNNN.KEL files, which such a dump does not have) or any other RPG Maker editor project.
     *
     * @return {@link #DUMP_OMORI_DECRYPTED}, {@link #DUMP_EDITOR_PROJECT} or null for an ordinary game folder; never throws
     */
    public static String sourceDumpKind(File root, String mainHtml) {
        try {
            if (root == null || !root.isDirectory()) return null;
            File web = webFolder(root, mainHtml);
            File base = web != null ? web : root;
            if (isOmori(root) && hasPlainDataButNoKel(base)) return DUMP_OMORI_DECRYPTED;
            if (hasProjectFile(root) || hasProjectFile(base)) return DUMP_EDITOR_PROJECT;
        } catch (RuntimeException e) {
            // a hint must never get in the way
        }
        return null;
    }

    private static File webFolder(File root, String mainHtml) {
        if (mainHtml == null || mainHtml.length() == 0) return null;
        File parent = new File(mainHtml).getParentFile();
        return parent != null && parent.isDirectory() ? parent : null;
    }

    private static boolean isOmori(File root) {
        File pkg = PathUtil.findChild(root, "package.json");
        if (pkg == null || !pkg.isFile()) return false;
        String text = readText(pkg);
        Map<String, Object> pj = text == null ? null : MiniJson.asMap(MiniJson.tryParse(text));
        return pj != null && "omori".equalsIgnoreCase(MiniJson.str(pj.get("name"), "").trim());
    }

    /** data/ holds plain *.json files but not one encrypted *.KEL file. */
    private static boolean hasPlainDataButNoKel(File base) {
        File data = PathUtil.findChild(base, "data");
        if (data == null || !data.isDirectory()) return false;
        boolean json = false;
        for (File f : sortedChildren(data)) {
            String n = f.getName().toLowerCase(Locale.ROOT);
            if (n.endsWith(".kel")) return false;
            if (n.endsWith(".json")) json = true;
        }
        return json;
    }

    private static boolean hasProjectFile(File dir) {
        if (dir == null) return false;
        for (File f : sortedChildren(dir)) {
            String n = f.getName().toLowerCase(Locale.ROOT);
            if (f.isFile() && (n.endsWith(".rpgproject") || n.endsWith(".rmmzproject"))) return true;
        }
        return false;
    }

    /**
     * @param root     the game folder
     * @param mainHtml the page that is loaded (its folder is the "web folder", usually root/www); may be empty (RPG Maker 2000/2003)
     * @return log lines (without any prefix)
     */
    public static List<String> describe(File root, String mainHtml) {
        List<String> out = new ArrayList<String>();
        try {
            build(root, mainHtml, out);
        } catch (RuntimeException e) {
            out.add("layout probe failed: " + e);
        }
        List<String> res = new ArrayList<String>();
        for (String line : out) {
            if (res.size() >= MAX_LINES) {
                res.add("... (more lines left out)");
                break;
            }
            res.add(line.length() > MAX_LINE_CHARS ? line.substring(0, MAX_LINE_CHARS) + " ..." : line);
        }
        return res;
    }

    private static void build(File root, String mainHtml, List<String> out) {
        if (root == null || !root.isDirectory()) {
            out.add("game folder is not a readable directory: " + root);
            return;
        }
        File web = webFolder(root, mainHtml);
        boolean separateWeb = web != null && !PathUtil.normalize(web.getPath()).equals(PathUtil.normalize(root.getPath()));

        out.add("/ " + listing(root, MAX_ENTRIES));
        if (separateWeb) out.add(rel(root, web) + "/ " + listing(web, MAX_ENTRIES));

        File pkg = PathUtil.findChild(root, "package.json");
        if (pkg != null && pkg.isFile()) {
            String text = readText(pkg);
            Map<String, Object> pj = text == null ? null : MiniJson.asMap(MiniJson.tryParse(text));
            if (pj == null) {
                out.add("package.json: not readable as JSON");
            } else {
                Map<String, Object> win = MiniJson.asMap(pj.get("window"));
                out.add("package.json: name=" + clip(MiniJson.str(pj.get("name"), ""), 80) + " main=" + clip(MiniJson.str(pj.get("main"), ""), 120)
                        + (win == null ? "" : " window.title=" + clip(MiniJson.str(win.get("title"), ""), 80)));
            }
        }

        String dump = sourceDumpKind(root, mainHtml);
        if (DUMP_OMORI_DECRYPTED.equals(dump)) {
            out.add("WARNING: this OMORI folder has plain data (data/*.json, languages/*/*.yaml) and no encrypted *.KEL files: it is the decrypted source project"
                    + " (OmoriSource), not an installed game. The game's plugins read data/MapNNN.KEL, so it stops after the menu. Use the folder of a real"
                    + " installation (Steam: right-click OMORI > Manage > Browse local files).");
        } else if (DUMP_EDITOR_PROJECT.equals(dump)) {
            out.add("NOTE: this folder contains an RPG Maker editor project file (*.rpgproject): it is a project folder, not a deployed game. Most projects still run;"
                    + " if the game stops early or reports missing files, use the deployed / installed game folder instead.");
        }

        // language / translation folders and language packs, looked for a few levels deep (never inside picture / sound folders)
        File base = separateWeb ? web : root;
        List<File> langDirs = new ArrayList<File>();
        List<File> packs = new ArrayList<File>();
        int[] budget = {MAX_DIRS_VISITED};
        collect(root, 0, 3, langDirs, packs, budget);
        if (langDirs.isEmpty() && packs.isEmpty()) {
            out.add("no language / translation folder or *.cld file found (searched 3 levels below the game folder)");
        }
        int shown = 0;
        for (File d : langDirs) {
            if (shown++ >= 6) {
                out.add("... " + (langDirs.size() - 6) + " more language folder(s)");
                break;
            }
            out.add(rel(root, d) + "/ " + listing(d, MAX_LANG_ENTRIES));
            File[] kids = sortedChildren(d);
            int kidsShown = 0;
            for (File k : kids) {
                if (!k.isDirectory()) continue;
                if (kidsShown++ >= 10) break;
                out.add(rel(root, k) + "/ " + listing(k, 15));
            }
        }
        if (!packs.isEmpty()) {
            StringBuilder sb = new StringBuilder("language packs (*.cld):");
            for (File p : packs) sb.append(' ').append(rel(root, p)).append(" (").append(size(p.length())).append(')');
            out.add(sb.toString());
        }

        // plugins
        File jsDir = PathUtil.findChild(base, "js");
        File plugins = jsDir == null ? null : PathUtil.findChild(jsDir, "plugins.js");
        if (plugins != null && plugins.isFile()) {
            String text = readText(plugins);
            if (text == null) {
                out.add("js/plugins.js: not readable");
            } else {
                List<String> on = new ArrayList<String>();
                List<String> off = new ArrayList<String>();
                Matcher m = PLUGIN.matcher(text);
                while (m.find()) (m.group(2).equals("true") ? on : off).add(m.group(1));
                out.add("js/plugins.js: " + (on.size() + off.size()) + " plugins, " + on.size() + " enabled: " + join(on, 90));
                if (!off.isEmpty()) out.add("js/plugins.js disabled: " + join(off, 30));
            }
        }

        // the most recently changed script / data / language files: a patch that overwrote files shows up here
        List<File> files = new ArrayList<File>();
        int[] fileBudget = {1500};
        gather(jsDir, 0, 2, files, fileBudget);
        gather(PathUtil.findChild(base, "data"), 0, 1, files, fileBudget);
        for (File d : langDirs) gather(d, 0, 2, files, fileBudget);
        if (!files.isEmpty()) {
            sortByTimeDesc(files);
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US);
            StringBuilder sb = new StringBuilder("most recently changed:");
            for (int i = 0; i < files.size() && i < 8; i++) {
                File f = files.get(i);
                sb.append(' ').append(rel(root, f)).append(" (").append(fmt.format(new Date(f.lastModified()))).append(", ").append(size(f.length())).append(')');
                if (i < 7 && i < files.size() - 1) sb.append(';');
            }
            out.add(sb.toString());
        }
    }

    // ------------------------------------------------------------------ helpers

    private static void sortByTimeDesc(List<File> files) {
        File[] arr = files.toArray(new File[files.size()]);
        Arrays.sort(arr, new Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                long x = a.lastModified(), y = b.lastModified();
                if (x != y) return x < y ? 1 : -1;
                return a.getPath().compareTo(b.getPath());
            }
        });
        files.clear();
        files.addAll(Arrays.asList(arr));
    }

    private static boolean isLangName(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        for (String w : LANG_WORDS) if (n.indexOf(w) >= 0) return true;
        return false;
    }

    private static boolean isSkipped(String name) {
        for (String s : SKIP_DIRS) if (s.equalsIgnoreCase(name)) return true;
        return false;
    }

    /** Language-like folders (not entered further) and *.cld files up to maxDepth levels below dir. */
    private static void collect(File dir, int depth, int maxDepth, List<File> langDirs, List<File> packs, int[] budget) {
        File[] kids = sortedChildren(dir);
        for (File f : kids) {
            String name = f.getName();
            if (f.isDirectory()) {
                if (depth >= maxDepth || budget[0] <= 0 || isSkipped(name)) continue;
                budget[0]--;
                if (isLangName(name)) langDirs.add(f);
                else collect(f, depth + 1, maxDepth, langDirs, packs, budget);
            } else if (name.toLowerCase(Locale.ROOT).endsWith(".cld") && packs.size() < 30) {
                packs.add(f);
            }
        }
    }

    /** Regular files below dir (up to maxDepth levels), at most budget[0] of them. */
    private static void gather(File dir, int depth, int maxDepth, List<File> out, int[] budget) {
        if (dir == null || !dir.isDirectory()) return;
        for (File f : sortedChildren(dir)) {
            if (budget[0] <= 0) return;
            if (f.isDirectory()) {
                if (depth < maxDepth && !isSkipped(f.getName())) gather(f, depth + 1, maxDepth, out, budget);
            } else {
                budget[0]--;
                out.add(f);
            }
        }
    }

    private static File[] sortedChildren(File dir) {
        File[] kids = dir == null ? null : dir.listFiles();
        if (kids == null) return new File[0];
        Arrays.sort(kids, new Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                return a.getName().compareToIgnoreCase(b.getName());
            }
        });
        return kids;
    }

    /** "(12 entries) a/ b/ c 1.2 KB ..." */
    private static String listing(File dir, int max) {
        File[] kids = dir.listFiles();
        if (kids == null) return "(cannot be listed)";
        Arrays.sort(kids, new Comparator<File>() {
            @Override
            public int compare(File a, File b) {
                return a.getName().compareToIgnoreCase(b.getName());
            }
        });
        StringBuilder sb = new StringBuilder("(" + kids.length + (kids.length == 1 ? " entry)" : " entries)"));
        for (int i = 0; i < kids.length && i < max; i++) {
            File f = kids[i];
            sb.append(' ').append(f.getName());
            if (f.isDirectory()) sb.append('/');
            else sb.append(' ').append(size(f.length()));
            if (i < kids.length - 1 && i < max - 1) sb.append(',');
        }
        if (kids.length > max) sb.append(" ... and ").append(kids.length - max).append(" more");
        return sb.toString();
    }

    private static String size(long n) {
        if (n < 1024) return n + " B";
        if (n < 1024 * 1024) return (n / 1024) + " KB";
        return String.format(Locale.US, "%.1f MB", n / (1024.0 * 1024.0));
    }

    private static String rel(File root, File f) {
        String r = PathUtil.normalize(root.getPath());
        String p = PathUtil.normalize(f.getPath());
        if (r != null && p != null && p.startsWith(r)) {
            String s = p.substring(r.length());
            if (s.startsWith("/")) s = s.substring(1);
            return s.length() == 0 ? "." : s;
        }
        return f.getPath();
    }

    private static String join(List<String> names, int max) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < names.size() && i < max; i++) {
            if (i > 0) sb.append(", ");
            sb.append(names.get(i));
        }
        if (names.size() > max) sb.append(", ... and ").append(names.size() - max).append(" more");
        return sb.toString();
    }

    private static String clip(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }

    /** UTF-8 text of a small file, or null when it is missing, too big (over 1 MB) or unreadable. */
    private static String readText(File f) {
        if (f.length() > MAX_READ_BYTES) return null;
        InputStream in = null;
        try {
            in = new FileInputStream(f);
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            byte[] chunk = new byte[8192];
            int n;
            while ((n = in.read(chunk)) > 0) buf.write(chunk, 0, n);
            return new String(buf.toByteArray(), "UTF-8");
        } catch (IOException e) {
            return null;
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException ignored) {
                    // nothing to do
                }
            }
        }
    }
}
