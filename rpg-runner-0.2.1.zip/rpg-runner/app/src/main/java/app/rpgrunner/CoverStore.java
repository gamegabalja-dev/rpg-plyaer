package app.rpgrunner;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

/**
 * Cover pictures of the launcher tiles: at most one per game, kept as "<dir>/<gameId>.jpg" (or ".png" when the picture has
 * transparency). The picture itself is decoded, scaled and re-encoded in LauncherActivity (Android classes); this class only
 * does what can be tested on a desktop JVM: file naming, atomic replacement, deletion, and the size / rotation arithmetic.
 */
public final class CoverStore {
    /** Longest edge of a stored cover: sharp enough for a square tile on a 1080p screen, small enough to keep many games cheap. */
    public static final int MAX_EDGE = 1280;

    private final File dir;

    public CoverStore(File dir) {
        this.dir = dir;
    }

    /** Game ids are 12 hex digits (GameDetector.idFor). Anything that is not a plain token never reaches the file system. */
    public static boolean validId(String id) {
        if (id == null || id.length() == 0 || id.length() > 64) return false;
        for (int i = 0; i < id.length(); i++) {
            char c = id.charAt(i);
            boolean ok = (c >= '0' && c <= '9') || (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_' || c == '-';
            if (!ok) return false;
        }
        return true;
    }

    /** "png" or "jpg" when the bytes start like one of those files, otherwise null. Only pictures made by our own encoder are stored. */
    public static String sniff(byte[] d) {
        if (d == null) return null;
        if (d.length >= 8 && (d[0] & 0xff) == 0x89 && d[1] == 'P' && d[2] == 'N' && d[3] == 'G' && d[4] == 0x0d && d[5] == 0x0a && d[6] == 0x1a && d[7] == 0x0a) return "png";
        if (d.length >= 3 && (d[0] & 0xff) == 0xff && (d[1] & 0xff) == 0xd8 && (d[2] & 0xff) == 0xff) return "jpg";
        return null;
    }

    public static String mimeOf(File f) {
        return f != null && f.getName().endsWith(".png") ? "image/png" : "image/jpeg";
    }

    /** The cover file of the game, or null when it has none. */
    public File find(String id) {
        if (!validId(id)) return null;
        File jpg = new File(dir, id + ".jpg");
        File png = new File(dir, id + ".png");
        boolean j = jpg.isFile() && jpg.length() > 0;
        boolean p = png.isFile() && png.length() > 0;
        if (j && p) return jpg.lastModified() >= png.lastModified() ? jpg : png; // cannot happen through write(); be tolerant anyway
        if (j) return jpg;
        return p ? png : null;
    }

    /** Changes whenever the cover is replaced; the page appends it to the picture URL so a new cover is never served from a cache. */
    public String version(String id) {
        File f = find(id);
        return f == null ? "0" : Long.toString(f.lastModified(), 36) + "-" + Long.toString(f.length(), 36);
    }

    /**
     * Stores the encoded picture (PNG or JPEG bytes) as the cover of the game, replacing the previous one atomically
     * (temp file + rename), and removes the cover file of the other format.
     */
    public File write(String id, byte[] data) throws IOException {
        if (!validId(id)) throw new IOException("bad game id");
        String ext = sniff(data);
        if (ext == null) throw new IOException("not a PNG or JPEG picture");
        if (!dir.isDirectory() && !dir.mkdirs() && !dir.isDirectory()) throw new IOException("cannot create " + dir);
        File target = new File(dir, id + "." + ext);
        File tmp = new File(dir, id + ".tmp");
        try {
            OutputStream out = new FileOutputStream(tmp);
            try {
                out.write(data);
                out.flush();
            } finally {
                out.close();
            }
            if (!tmp.renameTo(target)) {
                target.delete();
                if (!tmp.renameTo(target)) throw new IOException("cannot replace " + target);
            }
        } finally {
            if (tmp.exists()) tmp.delete();
        }
        new File(dir, id + (ext.equals("png") ? ".jpg" : ".png")).delete();
        return target;
    }

    /** Removes the cover of the game. @return true if there was one. */
    public boolean delete(String id) {
        if (!validId(id)) return false;
        boolean any = false;
        for (String ext : new String[] {".jpg", ".png", ".tmp"}) {
            File f = new File(dir, id + ext);
            if (f.exists() && f.delete()) any = true;
        }
        return any;
    }

    // ------------------------------------------------------------------ picture arithmetic (used by LauncherActivity)

    /** Power-of-two decode sample size that keeps the decoded picture at least maxEdge pixels on its longest side (when the source has that many). */
    public static int sampleSize(int width, int height, int maxEdge) {
        int longest = Math.max(width, height);
        int s = 1;
        while (maxEdge > 0 && s < (1 << 20) && longest / (s * 2) >= maxEdge) s *= 2;
        return s;
    }

    /** {w, h} scaled down to fit maxEdge x maxEdge with the aspect ratio kept; never enlarges; each at least 1. */
    public static int[] fit(int width, int height, int maxEdge) {
        int w = Math.max(1, width);
        int h = Math.max(1, height);
        int longest = Math.max(w, h);
        if (longest <= maxEdge) return new int[] {w, h};
        double k = (double) maxEdge / longest;
        return new int[] {Math.max(1, (int) Math.round(w * k)), Math.max(1, (int) Math.round(h * k))};
    }

    /**
     * EXIF orientation (1..8) as {degrees clockwise, mirror horizontally afterwards (1) or not (0)}. The rotation is applied first.
     * Unknown values mean "as stored".
     */
    public static int[] exifOps(int orientation) {
        switch (orientation) {
            case 2: return new int[] {0, 1};
            case 3: return new int[] {180, 0};
            case 4: return new int[] {180, 1};
            case 5: return new int[] {90, 1};
            case 6: return new int[] {90, 0};
            case 7: return new int[] {270, 1};
            case 8: return new int[] {270, 0};
            default: return new int[] {0, 0};
        }
    }
}
