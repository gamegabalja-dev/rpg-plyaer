package app.rpgrunner;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;

import java.io.File;

/** Where the app keeps its files, and whether it may read the game folders. */
final class AppDirs {
    private AppDirs() {}

    static File gamesFile(Context c) {
        return new File(c.getFilesDir(), "games.json");
    }

    /** Cover pictures of the launcher tiles (private to the app, removed together with it). */
    static File coverDir(Context c) {
        return new File(c.getFilesDir(), "covers");
    }

    /**
     * Log folder. /sdcard/RPGRunner/logs is preferred because the user can reach it with any file manager; when the storage
     * permission is missing the app-specific folders are used instead.
     */
    static File logDir(Context c) {
        File[] candidates = new File[3];
        candidates[0] = new File(Environment.getExternalStorageDirectory(), "RPGRunner/logs");
        File ext = c.getExternalFilesDir(null);
        candidates[1] = ext == null ? null : new File(ext, "logs");
        candidates[2] = new File(c.getFilesDir(), "logs");
        for (File d : candidates) {
            if (d == null) continue;
            try {
                if ((d.isDirectory() || d.mkdirs()) && d.canWrite()) return d;
            } catch (SecurityException ignored) {
                // try the next one
            }
        }
        return candidates[2];
    }

    /** "All files access" on Android 11+, the classic storage permissions before that. */
    static boolean hasStorageAccess(Context c) {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return c.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                && c.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }
}
