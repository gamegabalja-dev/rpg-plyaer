package app.rpgrunner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Where the time goes while the game page loads its files, for the log: a request that took SLOW_MS or longer is logged on its
 * own (the first MAX_SLOW_LINES of them), everything is summed per file type, and that sum is written as one short line every
 * SUMMARY_EVERY_MS and once more for the whole session when the game ends. Lets a log show whether lag comes from reading the
 * storage (read), from the page not taking the data (write) or from something else (generated listings, path lookups).
 * Pure Java and thread safe; the caller passes the clock in so that it can be tested.
 */
final class RequestStats {
    interface Sink {
        void log(String level, String message);
    }

    static final int MAX_SLOW_LINES = 60;
    static final long SUMMARY_EVERY_MS = 30000;
    private static final int TOP_TYPES = 6;

    private static final class Bucket {
        int count;
        int slow;
        long bytes;
        long totalMs;
        long readMs;
        long writeMs;
        long maxMs;

        void add(long b, long total, long read, long write, boolean isSlow) {
            count++;
            if (isSlow) slow++;
            bytes += b;
            totalMs += total;
            readMs += read;
            writeMs += write;
            if (total > maxMs) maxMs = total;
        }
    }

    private final Sink sink;
    private volatile long slowMs = 150;
    private final Map<String, Bucket> window = new HashMap<String, Bucket>();
    private final Map<String, Bucket> session = new HashMap<String, Bucket>();
    private int slowLogged;
    private int slowTotal;
    private boolean periodicSummaryWritten;
    private long windowStartMs = -1;
    private long sessionStartMs = -1;

    RequestStats(Sink sink) {
        this.sink = sink;
    }

    /** Requests at least this slow are logged one by one (default 150 ms; 0 logs every request). */
    void setSlowMs(long ms) {
        slowMs = ms;
    }

    /**
     * @param path    the request path (already decoded)
     * @param bytes   bytes sent (headers included)
     * @param totalMs time from the parsed request to the last byte handed to the socket
     * @param readMs  time spent reading the file from storage
     * @param writeMs time spent handing data to the socket (long when the page does not take the data)
     * @param nowMs   a monotonic clock in milliseconds
     */
    void record(String method, String path, long bytes, long totalMs, long readMs, long writeMs, long nowMs) {
        String slowLine = null;
        String summary = null;
        synchronized (this) {
            if (sessionStartMs < 0) sessionStartMs = nowMs;
            if (windowStartMs < 0) windowStartMs = nowMs;
            String type = typeOf(path);
            boolean isSlow = totalMs >= slowMs;
            bucket(window, type).add(bytes, totalMs, readMs, writeMs, isSlow);
            bucket(session, type).add(bytes, totalMs, readMs, writeMs, isSlow);
            if (isSlow) {
                slowTotal++;
                if (slowLogged < MAX_SLOW_LINES) {
                    slowLogged++;
                    long other = Math.max(0, totalMs - readMs - writeMs);
                    slowLine = "slow request: " + method + " " + shortPath(path) + " " + fmtBytes(bytes) + " took " + totalMs + " ms (read " + readMs
                            + ", write " + writeMs + ", other " + other + ")" + (slowLogged == MAX_SLOW_LINES ? " - no more slow requests are listed, see the summaries" : "");
                }
            }
            if (nowMs - windowStartMs >= SUMMARY_EVERY_MS) {
                summary = describe(window, "requests in the last " + Math.max(1, (nowMs - windowStartMs + 500) / 1000) + " s");
                window.clear();
                windowStartMs = nowMs;
                periodicSummaryWritten = true;
            }
        }
        if (slowLine != null) emit(slowLine);
        if (summary != null) emit(summary);
    }

    /** Writes what is left of the current period and the totals of the whole session (when the game ends). */
    void finish(long nowMs) {
        String last = null;
        String all = null;
        synchronized (this) {
            if (periodicSummaryWritten && !window.isEmpty()) last = describe(window, "requests since the last summary");
            if (!session.isEmpty()) {
                all = describe(session, "requests in this session (" + Math.max(1, (nowMs - sessionStartMs + 500) / 1000) + " s)")
                        + (slowTotal > slowLogged ? "; " + (slowTotal - slowLogged) + " slow request(s) were not listed" : "");
            }
            window.clear();
            session.clear();
            slowLogged = 0;
            slowTotal = 0;
            periodicSummaryWritten = false;
            windowStartMs = -1;
            sessionStartMs = -1;
        }
        if (last != null) emit(last);
        if (all != null) emit(all);
    }

    // ------------------------------------------------------------------ helpers

    private void emit(String line) {
        try {
            sink.log("I", line);
        } catch (RuntimeException ignored) {
            // diagnostics must never disturb the server
        }
    }

    private static Bucket bucket(Map<String, Bucket> m, String type) {
        Bucket b = m.get(type);
        if (b == null) {
            b = new Bucket();
            m.put(type, b);
        }
        return b;
    }

    /** "png", "ogg", ... from the last path segment; "none" without an extension, "other" for odd ones. */
    static String typeOf(String path) {
        if (path == null) return "other";
        int slash = path.lastIndexOf('/');
        String name = slash >= 0 ? path.substring(slash + 1) : path;
        int dot = name.lastIndexOf('.');
        if (dot < 0 || dot == name.length() - 1) return "none";
        String ext = name.substring(dot + 1).toLowerCase(Locale.ROOT);
        if (ext.length() > 6) return "other";
        for (int i = 0; i < ext.length(); i++) {
            char c = ext.charAt(i);
            if (!((c >= 'a' && c <= 'z') || (c >= '0' && c <= '9'))) return "other";
        }
        return ext;
    }

    /** The last three segments of a path: "img/tilesets/Outside_A2.png". */
    static String shortPath(String path) {
        if (path == null) return "?";
        int end = path.length();
        int cuts = 0;
        int i = end;
        while (i > 0 && cuts < 3) {
            i = path.lastIndexOf('/', i - 1);
            if (i < 0) return path;
            cuts++;
        }
        return i + 1 >= end ? path : path.substring(i + 1);
    }

    static String fmtBytes(long n) {
        if (n < 1024) return n + " B";
        if (n < 1024 * 1024) return (n / 1024) + " KB";
        return String.format(Locale.US, "%.1f MB", n / (1024.0 * 1024.0));
    }

    private static String describe(Map<String, Bucket> m, String title) {
        List<Map.Entry<String, Bucket>> entries = new ArrayList<Map.Entry<String, Bucket>>(m.entrySet());
        Collections.sort(entries, new Comparator<Map.Entry<String, Bucket>>() {
            @Override
            public int compare(Map.Entry<String, Bucket> a, Map.Entry<String, Bucket> b) {
                long x = a.getValue().totalMs, y = b.getValue().totalMs;
                if (x != y) return x < y ? 1 : -1;
                return a.getKey().compareTo(b.getKey());
            }
        });
        Bucket all = new Bucket();
        for (Bucket b : m.values()) {
            all.count += b.count;
            all.slow += b.slow;
            all.bytes += b.bytes;
            all.totalMs += b.totalMs;
            all.readMs += b.readMs;
            all.writeMs += b.writeMs;
            if (b.maxMs > all.maxMs) all.maxMs = b.maxMs;
        }
        StringBuilder sb = new StringBuilder(title).append(": ").append(all.count).append(", ").append(fmtBytes(all.bytes))
                .append(", busy ").append(all.totalMs).append(" ms (read ").append(all.readMs).append(", write ").append(all.writeMs)
                .append("), slowest ").append(all.maxMs).append(" ms, slow ").append(all.slow);
        int shown = 0;
        for (Map.Entry<String, Bucket> e : entries) {
            if (shown++ >= TOP_TYPES) {
                sb.append(" | ... ").append(entries.size() - TOP_TYPES).append(" more type(s)");
                break;
            }
            Bucket b = e.getValue();
            sb.append(" | ").append(e.getKey()).append(' ').append(b.count).append(" (").append(fmtBytes(b.bytes)).append(", ").append(b.totalMs)
                    .append(" ms, read ").append(b.readMs).append(", max ").append(b.maxMs).append(')');
        }
        return sb.toString();
    }
}
