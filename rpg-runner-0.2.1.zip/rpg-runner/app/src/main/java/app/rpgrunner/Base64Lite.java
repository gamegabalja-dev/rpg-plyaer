package app.rpgrunner;

import java.util.Arrays;

/** Minimal Base64 (java.util.Base64 needs API 26, android.util.Base64 is not available on a desktop JVM). */
final class Base64Lite {
    private static final char[] ENC =
            "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/".toCharArray();
    private static final int[] DEC = new int[256];

    static {
        Arrays.fill(DEC, -1);
        for (int k = 0; k < 64; k++) DEC[ENC[k]] = k;
        DEC['-'] = 62; // url-safe variants
        DEC['_'] = 63;
    }

    private Base64Lite() {}

    static String encode(byte[] b, int off, int len) {
        StringBuilder sb = new StringBuilder(((len + 2) / 3) * 4);
        int end = off + len;
        int p = off;
        while (p + 2 < end) {
            int v = ((b[p] & 0xFF) << 16) | ((b[p + 1] & 0xFF) << 8) | (b[p + 2] & 0xFF);
            sb.append(ENC[(v >> 18) & 63]).append(ENC[(v >> 12) & 63]).append(ENC[(v >> 6) & 63]).append(ENC[v & 63]);
            p += 3;
        }
        int rem = end - p;
        if (rem == 1) {
            int v = (b[p] & 0xFF) << 16;
            sb.append(ENC[(v >> 18) & 63]).append(ENC[(v >> 12) & 63]).append("==");
        } else if (rem == 2) {
            int v = ((b[p] & 0xFF) << 16) | ((b[p + 1] & 0xFF) << 8);
            sb.append(ENC[(v >> 18) & 63]).append(ENC[(v >> 12) & 63]).append(ENC[(v >> 6) & 63]).append('=');
        }
        return sb.toString();
    }

    static String encode(byte[] b) {
        return encode(b, 0, b.length);
    }

    /** Lenient decoder: ignores whitespace and padding, accepts url-safe alphabet. Returns null on garbage. */
    static byte[] decode(String s) {
        byte[] out = new byte[(s.length() * 3) / 4 + 3];
        int o = 0;
        int acc = 0;
        int bits = 0;
        for (int k = 0; k < s.length(); k++) {
            char c = s.charAt(k);
            if (c == '=' || c == '\n' || c == '\r' || c == ' ' || c == '\t') continue;
            int d = c < 256 ? DEC[c] : -1;
            if (d < 0) return null;
            acc = (acc << 6) | d;
            bits += 6;
            if (bits >= 8) {
                bits -= 8;
                out[o++] = (byte) ((acc >> bits) & 0xFF);
            }
        }
        return Arrays.copyOf(out, o);
    }
}
