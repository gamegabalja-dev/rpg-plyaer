/*!
 * RPG Runner - lag diagnostics. Injected into every page the local server hands out (NW.js games and the EasyRPG player page).
 * It changes nothing about the game; it only writes short "perf:" lines to the game log so that a log shows WHERE a stutter comes
 * from: a frame that took too long (with the files that arrived meanwhile and the script task that blocked the page), a file that
 * arrived slowly, how long a new RPG Maker MV/MZ scene needed until it was ready (map changes!), and a summary every 15 seconds
 * (frames per second, worst frame, memory). At most a few hundred lines per run. Inputs: window.RRNative.log (optional) and
 * window.__RR_CONFIG.perf (false switches it off).
 */
(function (global) {
  'use strict';
  if (global.top !== global || global.__RR_PERF) return;
  var N = global.RRNative || null;
  var P = global.performance;
  var CFG = global.__RR_CONFIG || {};
  if (!N || typeof N.log !== 'function' || !P || typeof P.now !== 'function' || CFG.perf === false) return;

  var STALL_MS = 120;      // a frame that took this long is reported
  var SLOW_FILE_MS = 300;  // a file that took this long to arrive is reported
  var SLOW_SCENE_MS = 300; // a scene that needed this long until it was ready is reported
  var SUMMARY_MS = 15000;
  var BUDGET = { stall: 70, file: 40, scene: 40, summary: 40 };
  var rAF = global.requestAnimationFrame ? global.requestAnimationFrame.bind(global) : null;
  var setT = global.setTimeout.bind(global);

  var state = global.__RR_PERF = {
    frames: 0, stalls: 0, longTasks: 0, files: 0, slowFiles: 0, scenes: 0, lines: 0,
    flush: function () { reportStalls(); summary(P.now(), true); }
  };

  function log(msg) {
    state.lines++;
    try { N.log('I', 'perf: ' + msg); } catch (e) { /* the bridge may be gone */ }
  }
  function r(n) { return Math.round(n); }
  function secs(ms) { return (ms / 1000).toFixed(1) + ' s'; }
  function bytes(n) {
    if (!n) return '';
    if (n < 1024) return n + ' B';
    if (n < 1048576) return r(n / 1024) + ' KB';
    return (n / 1048576).toFixed(1) + ' MB';
  }
  /** "img/tilesets/Outside_A2.png": the last three segments of a URL, without host and query. */
  function shortName(url) {
    var u = String(url);
    if (u.length > 300) return u.slice(0, 40) + '... (' + u.length + ' characters)';
    try {
      var q = u.indexOf('?');
      if (q >= 0) u = u.slice(0, q);
      var h = u.indexOf('://');
      if (h >= 0) { var s = u.indexOf('/', h + 3); u = s >= 0 ? u.slice(s) : '/'; }
      try { u = decodeURIComponent(u); } catch (e) { /* keep it encoded */ }
      var parts = u.split('/');
      return parts.slice(-3).join('/');
    } catch (e) {
      return u.slice(-60);
    }
  }

  // ------------------------------------------------------------------ files (Resource Timing) and long tasks
  var recentFiles = [];  // { n, s, e, d, w, k, z }  name, start, end, duration, wait for the first byte, initiator, size
  var fileIndex = 0;     // entries of the timeline that were handled already
  var winFiles = 0, winFileMs = 0, winFileMax = 0;
  var recentTasks = [];  // { s, d }
  var winTasks = 0, winTaskMax = 0;

  try { if (P.setResourceTimingBufferSize) P.setResourceTimingBufferSize(600); } catch (e) { /* ignore */ }

  function drainFiles() {
    var all;
    try { all = P.getEntriesByType('resource'); } catch (e) { return; }
    for (; fileIndex < all.length; fileIndex++) {
      var e = all[fileIndex];
      var d = e.duration || 0;
      var f = { n: shortName(e.name), s: e.startTime, e: e.responseEnd || (e.startTime + d), d: d, w: (e.responseStart || e.startTime) - e.startTime,
        k: e.initiatorType || '', z: e.encodedBodySize || e.transferSize || 0 };
      state.files++; winFiles++; winFileMs += d;
      if (d > winFileMax) winFileMax = d;
      recentFiles.push(f);
      if (recentFiles.length > 80) recentFiles.shift();
      if (d >= SLOW_FILE_MS) {
        state.slowFiles++;
        if (BUDGET.file > 0) {
          BUDGET.file--;
          log('slow file: ' + f.n + (f.z ? ' ' + bytes(f.z) : '') + ' took ' + r(d) + ' ms (first byte after ' + r(f.w) + ', download ' + r(f.e - f.s - f.w) + ') type ' +
            f.k + ', requested at +' + secs(f.s) + (BUDGET.file === 0 ? ' - no more slow files are listed, see the summaries' : ''));
        }
      }
    }
    if (all.length >= 500) { // keep the timeline small
      try { P.clearResourceTimings(); fileIndex = 0; } catch (e2) { /* ignore */ }
    }
  }

  try {
    P.addEventListener('resourcetimingbufferfull', function () {
      drainFiles();
      try { P.clearResourceTimings(); fileIndex = 0; } catch (e) { /* ignore */ }
    });
  } catch (e) { /* ignore */ }

  try {
    if (global.PerformanceObserver) {
      var po = new global.PerformanceObserver(function (list) {
        var es = list.getEntries();
        for (var i = 0; i < es.length; i++) {
          state.longTasks++; winTasks++;
          if (es[i].duration > winTaskMax) winTaskMax = es[i].duration;
          recentTasks.push({ s: es[i].startTime, d: es[i].duration });
          if (recentTasks.length > 30) recentTasks.shift();
        }
      });
      try { po.observe({ type: 'longtask', buffered: true }); } catch (e) { po.observe({ entryTypes: ['longtask'] }); }
    }
  } catch (e) { /* long tasks are not supported: stalls are still found by the frame timer */ }

  // ------------------------------------------------------------------ RPG Maker MV / MZ scenes
  var curScene = null, sceneLabel = '', sceneBorn = 0, sceneDone = true, winSceneMs = 0;
  function sceneText() {
    var SM = global.SceneManager;
    var sc = SM && SM._scene;
    if (!sc) return '';
    var name = (sc.constructor && sc.constructor.name) || 'scene';
    var extra = '';
    if (name === 'Scene_Map') {
      var gp = global.$gamePlayer, gm = global.$gameMap;
      if (gp && gp._transferring) extra = ' (going to map ' + gp._newMapId + ')';
      else if (gm && typeof gm.mapId === 'function') extra = ' (map ' + gm.mapId() + ')';
    }
    return name + extra;
  }
  function sceneProbe(t) {
    var SM = global.SceneManager;
    if (!SM) return;
    var sc = SM._scene;
    if (sc !== curScene) {
      curScene = sc; sceneBorn = t; sceneDone = !sc; sceneLabel = sc ? sceneText() : '';
    }
    if (!sceneDone) {
      var started = typeof sc.isStarted === 'function' ? sc.isStarted() : !!SM._sceneStarted;
      if (started) {
        sceneDone = true; state.scenes++;
        var took = t - sceneBorn;
        winSceneMs += took;
        if (took >= SLOW_SCENE_MS && BUDGET.scene > 0) {
          BUDGET.scene--;
          log('scene ' + sceneLabel + ' needed ' + r(took) + ' ms until it was ready (loading its files and pictures) at +' + secs(t));
        }
      }
    }
  }

  // ------------------------------------------------------------------ frames
  var lastDrain = 0;
  var lastT = 0, hidden = !!(global.document && global.document.hidden);
  var wFrames = 0, wSum = 0, wWorst = 0, w100 = 0, w250 = 0, w500 = 0, wStart = 0;
  var pending = []; // stalls waiting for the observers to deliver their entries
  var pendingTimer = 0;

  function heap() {
    var m = P.memory;
    return m && m.usedJSHeapSize ? r(m.usedJSHeapSize / 1048576) + '/' + r(m.jsHeapSizeLimit / 1048576) + ' MB' : '';
  }

  function reportStalls() {
    pendingTimer = 0;
    if (!pending.length) return;
    drainFiles();
    var list = pending;
    pending = [];
    for (var i = 0; i < list.length; i++) {
      var st = list[i], parts = [];
      var task = 0, j;
      for (j = 0; j < recentTasks.length; j++) {
        var tk = recentTasks[j];
        if (tk.s < st.t && tk.s + tk.d > st.prev && tk.d > task) task = tk.d;
      }
      var files = [];
      for (j = 0; j < recentFiles.length; j++) {
        var f = recentFiles[j];
        if (f.e >= st.prev - 30 && f.e <= st.t + 30) files.push(f);
      }
      files.sort(function (a, b) { return b.d - a.d; });
      parts.push('frame took ' + r(st.gap) + ' ms at +' + secs(st.t));
      if (task) parts.push('script task ' + r(task) + ' ms');
      if (files.length) {
        var names = [];
        for (j = 0; j < files.length && j < 4; j++) names.push(files[j].n + ' ' + r(files[j].d) + ' ms');
        parts.push(files.length + ' file(s) arrived: ' + names.join(', ') + (files.length > 4 ? ', ...' : ''));
      }
      if (st.scene) parts.push(st.scene);
      var h = heap();
      if (h) parts.push('heap ' + h);
      if (BUDGET.stall > 0) {
        BUDGET.stall--;
        log('stall: ' + parts.join(' | ') + (BUDGET.stall === 0 ? ' - no more stalls are listed, see the summaries' : ''));
      }
    }
  }

  function summary(t, force) {
    if (!wFrames) return;
    drainFiles();
    var span = t - wStart;
    var line = secs(span) + ': ' + (wFrames * 1000 / Math.max(1, wSum)).toFixed(1) + ' fps (worst frame ' + r(wWorst) + ' ms; frames >= 100 ms: ' + w100 +
      ', >= 250 ms: ' + w250 + ', >= 500 ms: ' + w500 + ')';
    if (winTasks) line += ' | script tasks >= 50 ms: ' + winTasks + ' (longest ' + r(winTaskMax) + ' ms)';
    if (winFiles) line += ' | files: ' + winFiles + ' (' + (winFileMs / 1000).toFixed(1) + ' s together, slowest ' + r(winFileMax) + ' ms)';
    if (winSceneMs) line += ' | scene loading ' + r(winSceneMs) + ' ms';
    var h = heap(), sc = sceneText();
    if (h) line += ' | heap ' + h;
    if (sc) line += ' | ' + sc;
    var notable = w100 > 0 || wFrames * 1000 / Math.max(1, wSum) < 50;
    if (force || BUDGET.summary > 0 || notable) { // after 10 minutes only the summaries that show a problem
      if (BUDGET.summary > 0) BUDGET.summary--;
      log(line);
    }
    wFrames = 0; wSum = 0; wWorst = 0; w100 = 0; w250 = 0; w500 = 0; wStart = t;
    winFiles = 0; winFileMs = 0; winFileMax = 0; winTasks = 0; winTaskMax = 0; winSceneMs = 0;
  }

  function frame(t) {
    rAF(frame);
    state.frames++;
    if (hidden) { lastT = 0; return; }
    if (!wStart) wStart = t;
    if (lastT) {
      var gap = t - lastT;
      wFrames++; wSum += gap;
      if (gap > wWorst) wWorst = gap;
      if (gap >= 100) w100++;
      if (gap >= 250) w250++;
      if (gap >= 500) w500++;
      if (gap >= STALL_MS && gap < 15000) { // longer gaps are the app being paused, not a stutter
        state.stalls++;
        if (BUDGET.stall > 0) {
          pending.push({ prev: lastT, t: t, gap: gap, scene: sceneText() });
          if (!pendingTimer) pendingTimer = setT(reportStalls, 300); // the observers deliver their entries a moment later
        }
      }
    }
    lastT = t;
    sceneProbe(t);
    if (t - lastDrain >= 2000) { lastDrain = t; drainFiles(); } // keeps the browser's file timeline from filling up
    if (t - wStart >= SUMMARY_MS) summary(t, false);
  }

  if (global.document && global.document.addEventListener) {
    global.document.addEventListener('visibilitychange', function () {
      hidden = !!global.document.hidden;
      lastT = 0;
      wStart = 0; wFrames = 0; wSum = 0; wWorst = 0; w100 = 0; w250 = 0; w500 = 0;
    });
  }

  // ------------------------------------------------------------------ start-up
  function startLine() {
    var nav = null;
    try { nav = P.getEntriesByType('navigation')[0]; } catch (e) { /* ignore */ }
    var dom = nav ? nav.domContentLoadedEventEnd : 0, load = nav ? nav.loadEventEnd : 0;
    log('page: ' + (dom ? 'DOM ready after ' + r(dom) + ' ms, ' : '') + (load ? 'load event after ' + r(load) + ' ms, ' : '') + 'now +' + secs(P.now()) +
      (global.SceneManager ? ' (RPG Maker MV/MZ)' : ''));
  }
  if (global.document && global.document.readyState === 'complete') setT(startLine, 0);
  else global.addEventListener('load', function () { setT(startLine, 0); });

  if (rAF) rAF(frame);
})(window);
