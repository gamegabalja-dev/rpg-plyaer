/*!
 * RPG Runner - touch overlay: virtual pad (D-pad, OK, Cancel, Dash, Q/W) and the menu button.
 * RPG Maker 2000/2003 games (EasyRPG player page) get the number keys 1/3/5/9 instead of Q/W.
 * Injected (deferred) into every page the local server hands out. Works with keyboard events only, so it is
 * engine independent: RPG Maker MV/MZ listen for keydown/keyup on the document, exactly like on a PC.
 * Inputs: window.__RR_CONFIG (pad, padOpacity, padScale, engine) and window.RRNative (optional Android bridge).
 */
(function (global) {
  'use strict';
  if (global.top !== global || global.__RR_UI) return;

  var CFG = global.__RR_CONFIG || {};
  var N = global.RRNative || null;
  var RR = global.__RR = global.__RR || {};
  // RPG Maker 2000/2003 (EasyRPG player page). The stock web player only has a couple of on-screen buttons and none for the
  // number keys, but Yume Nikki needs them (1 = use effect, 3 = cancel effect, 5 = drop effect, 9 = pinch cheek / wake up).
  // The server hides the stock buttons (#apad) on that page, this overlay replaces them.
  var isRm2k = CFG.engine === 'rm2k';

  // ------------------------------------------------------------------ synthetic keyboard
  var KEYS = {
    up: { key: 'ArrowUp', code: 'ArrowUp', kc: 38 }, down: { key: 'ArrowDown', code: 'ArrowDown', kc: 40 },
    left: { key: 'ArrowLeft', code: 'ArrowLeft', kc: 37 }, right: { key: 'ArrowRight', code: 'ArrowRight', kc: 39 },
    ok: { key: 'z', code: 'KeyZ', kc: 90 }, cancel: { key: 'x', code: 'KeyX', kc: 88 }, dash: { key: 'Shift', code: 'ShiftLeft', kc: 16 },
    pageup: { key: 'q', code: 'KeyQ', kc: 81 }, pagedown: { key: 'w', code: 'KeyW', kc: 87 },
    enter: { key: 'Enter', code: 'Enter', kc: 13 }, escape: { key: 'Escape', code: 'Escape', kc: 27 },
    // keypad digits: EasyRPG maps Num1/Num3/Num5/Num9 (not the top-row digits) to the RPG Maker 2000/2003 number buttons
    n1: { key: '1', code: 'Numpad1', kc: 97 }, n3: { key: '3', code: 'Numpad3', kc: 99 },
    n5: { key: '5', code: 'Numpad5', kc: 101 }, n9: { key: '9', code: 'Numpad9', kc: 105 }
  };
  var held = {};

  /** Where synthetic key events go. EasyRPG's SDL listens on window/document/canvas: the canvas is below all of them. */
  function keyTarget() {
    if (isRm2k) {
      var c = document.getElementById('canvas') || document.querySelector('canvas');
      if (c) return c;
    }
    return document.activeElement || document.body || document;
  }

  /** Presses (down=true) or releases a key by logical name. Repeated calls with the same state are ignored. */
  function fire(name, down) {
    var k = KEYS[name];
    if (!k || !!held[name] === !!down) return;
    held[name] = !!down;
    var ev = new KeyboardEvent(down ? 'keydown' : 'keyup', { key: k.key, code: k.code, keyCode: k.kc, which: k.kc, bubbles: true, cancelable: true, view: global });
    if (ev.keyCode !== k.kc) { // the init dictionary ignored the legacy fields
      try {
        Object.defineProperty(ev, 'keyCode', { get: function () { return k.kc; } });
        Object.defineProperty(ev, 'which', { get: function () { return k.kc; } });
      } catch (e) { /* ignore */ }
    }
    keyTarget().dispatchEvent(ev);
  }
  function releaseAll() {
    for (var n in held) if (held[n]) fire(n, false);
    if (dpadEl) dpadEl.className = dpadEl.className.replace(/\s(u|d|l|r)\b/g, '');
  }

  // ------------------------------------------------------------------ DOM
  var CSS = '' +
    '#rr-ui{position:fixed;left:0;top:0;right:0;bottom:0;z-index:2147483647;pointer-events:none;touch-action:none;' +
    '-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;font-family:system-ui,sans-serif}' +
    '#rr-ui .rr-c{position:absolute;pointer-events:auto;touch-action:none;box-sizing:border-box;opacity:var(--op);transition:opacity .35s}' +
    '#rr-ui.idle .rr-c{opacity:calc(var(--op) * .5)}' +
    '#rr-ui.nopad .rr-pad,#rr-ui.gp .rr-pad{display:none}' +
    '#rr-ui .rr-dpad{left:calc(3vmin + env(safe-area-inset-left,0px) + 12px);bottom:calc(4vmin + env(safe-area-inset-bottom,0px));' +
    'width:calc(36vmin * var(--s));height:calc(36vmin * var(--s));border-radius:50%;background:rgba(255,255,255,.10);border:2px solid rgba(255,255,255,.35)}' +
    '#rr-ui .rr-dpad svg{position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none}' +
    '#rr-ui .rr-dpad path{fill:rgba(255,255,255,.55)}' +
    '#rr-ui .rr-dpad.u .pu,#rr-ui .rr-dpad.d .pd,#rr-ui .rr-dpad.l .pl,#rr-ui .rr-dpad.r .pr{fill:#fff}' +
    '#rr-ui .rr-btn{border-radius:50%;background:rgba(255,255,255,.14);border:2px solid rgba(255,255,255,.45);color:#fff;display:flex;' +
    'align-items:center;justify-content:center;font-weight:700;text-shadow:0 1px 2px rgba(0,0,0,.6);line-height:1}' +
    '#rr-ui .rr-btn.on{background:rgba(255,255,255,.55);color:#000;text-shadow:none}' +
    '#rr-ui .rr-a{right:calc(3vmin + env(safe-area-inset-right,0px) + 12px);bottom:calc(7vmin + env(safe-area-inset-bottom,0px));' +
    'width:calc(19vmin * var(--s));height:calc(19vmin * var(--s));font-size:calc(4.6vmin * var(--s))}' +
    '#rr-ui .rr-b{right:calc(3vmin + 19vmin * var(--s) + 2.5vmin + env(safe-area-inset-right,0px) + 12px);bottom:calc(13vmin + env(safe-area-inset-bottom,0px));' +
    'width:calc(17vmin * var(--s));height:calc(17vmin * var(--s));font-size:calc(4.2vmin * var(--s))}' +
    '#rr-ui .rr-dash{right:calc(4vmin + env(safe-area-inset-right,0px) + 12px);bottom:calc(7vmin + 19vmin * var(--s) + 2.5vmin + env(safe-area-inset-bottom,0px));' +
    'width:calc(15vmin * var(--s));height:calc(15vmin * var(--s));font-size:calc(3.4vmin * var(--s))}' +
    '#rr-ui .rr-sh{top:calc(3vmin + env(safe-area-inset-top,0px));width:calc(13vmin * var(--s));height:calc(8vmin * var(--s));border-radius:2vmin;font-size:calc(3.6vmin * var(--s))}' +
    '#rr-ui .rr-n{top:calc(3vmin + env(safe-area-inset-top,0px));left:calc(3vmin + env(safe-area-inset-left,0px) + 12px + var(--i) * (13vmin * var(--s) + 1.5vmin));' +
    'width:calc(13vmin * var(--s));height:calc(8vmin * var(--s));border-radius:2vmin;font-size:calc(3.8vmin * var(--s))}' +
    '#rr-ui .rr-q{left:calc(3vmin + env(safe-area-inset-left,0px) + 12px)}' +
    '#rr-ui .rr-w{right:calc(14vmin + env(safe-area-inset-right,0px) + 12px)}' +
    '#rr-ui .rr-menu{top:calc(3vmin + env(safe-area-inset-top,0px));right:calc(3vmin + env(safe-area-inset-right,0px) + 12px);' +
    'width:9vmin;height:9vmin;font-size:5vmin;opacity:calc(var(--op) * .75)}' +
    '#rr-ui .rr-panel{left:50%;top:50%;transform:translate(-50%,-50%);background:rgba(20,20,30,.95);border:1px solid #666;border-radius:10px;padding:12px;display:none;' +
    'flex-direction:column;gap:8px;opacity:1;min-width:40vmin}' +
    '#rr-ui .rr-panel button{font:inherit;font-size:16px;padding:10px 14px;border-radius:8px;border:1px solid #777;background:#2a2a3a;color:#fff}';

  var root, dpadEl = null, idleTimer = 0, panel = null;

  function el(tag, cls, parent, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text) e.textContent = text;
    if (parent) parent.appendChild(e);
    return e;
  }

  function wake() {
    root.classList.remove('idle');
    clearTimeout(idleTimer);
    idleTimer = setTimeout(function () { root.classList.add('idle'); }, 3500);
  }

  /** 8-way direction from the offset to the pad centre: cardinal within +-32.5 degrees of an axis, diagonal in between. */
  function dirsFor(dx, dy, r) {
    var out = { up: false, down: false, left: false, right: false };
    if (Math.sqrt(dx * dx + dy * dy) < r * 0.2) return out; // dead zone
    var a = ((Math.atan2(dy, dx) * 180 / Math.PI) + 360) % 360; // 0 = right, 90 = down
    var shifted = (a + 45) % 360, sector = Math.floor(shifted / 90), off = (shifted % 90) - 45; // sector 0 right, 1 down, 2 left, 3 up
    var axes = ['right', 'down', 'left', 'up'];
    out[axes[sector]] = true;
    if (Math.abs(off) > 32.5) out[axes[(sector + (off > 0 ? 1 : 3)) % 4]] = true;
    return out;
  }

  function bindDpad(pad) {
    var id = null, cx = 0, cy = 0, rad = 1;
    function apply(d) {
      fire('up', d.up); fire('down', d.down); fire('left', d.left); fire('right', d.right);
      pad.className = 'rr-c rr-pad rr-dpad' + (d.up ? ' u' : '') + (d.down ? ' d' : '') + (d.left ? ' l' : '') + (d.right ? ' r' : '');
    }
    function update(e) { apply(dirsFor(e.clientX - cx, e.clientY - cy, rad)); }
    pad.addEventListener('pointerdown', function (e) {
      if (id !== null) return;
      id = e.pointerId;
      try { pad.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ }
      var r = pad.getBoundingClientRect();
      cx = r.left + r.width / 2; cy = r.top + r.height / 2; rad = r.width / 2;
      update(e); wake(); e.preventDefault(); e.stopPropagation();
    });
    pad.addEventListener('pointermove', function (e) { if (e.pointerId === id) { update(e); e.preventDefault(); e.stopPropagation(); } });
    ['pointerup', 'pointercancel'].forEach(function (t) {
      pad.addEventListener(t, function (e) { if (e.pointerId === id) { id = null; apply({}); wake(); e.stopPropagation(); } });
    });
  }

  function bindButton(btn, name) {
    var ids = {}, count = 0;
    btn.addEventListener('pointerdown', function (e) {
      if (!ids[e.pointerId]) { ids[e.pointerId] = 1; count++; }
      try { btn.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ }
      fire(name, true); btn.classList.add('on'); wake(); e.preventDefault(); e.stopPropagation();
    });
    ['pointerup', 'pointercancel'].forEach(function (t) {
      btn.addEventListener(t, function (e) {
        if (!ids[e.pointerId]) return;
        delete ids[e.pointerId]; count--;
        if (count <= 0) { count = 0; fire(name, false); btn.classList.remove('on'); }
        wake(); e.stopPropagation();
      });
    });
  }

  function fallbackMenu() { // only used when there is no Android bridge (desktop testing)
    if (!panel) {
      panel = el('div', 'rr-c rr-panel', root);
      var b1 = el('button', '', panel, '계속하기');
      var b2 = el('button', '', panel, '가상 패드 켜기/끄기');
      var b3 = el('button', '', panel, '게임 종료');
      b1.addEventListener('click', function () { panel.style.display = 'none'; });
      b2.addEventListener('click', function () { ui.setPad(!ui.isPad()); });
      b3.addEventListener('click', function () { if (RR.exit) RR.exit(); });
    }
    panel.style.display = panel.style.display === 'flex' ? 'none' : 'flex';
  }

  function showMenu() {
    releaseAll();
    try { if (N && typeof N.showMenu === 'function') { N.showMenu(); return; } } catch (e) { /* fall through */ }
    fallbackMenu();
  }

  function build() {
    var style = el('style', '', document.head || document.documentElement);
    style.id = 'rr-ui-style';
    style.textContent = CSS;

    root = el('div', '', null);
    root.id = 'rr-ui';
    var op = Math.max(10, Math.min(100, parseInt(CFG.padOpacity, 10) || 60)) / 100;
    var sc = Math.max(50, Math.min(160, parseInt(CFG.padScale, 10) || 100)) / 100;
    root.style.setProperty('--op', String(op));
    root.style.setProperty('--s', String(sc));
    if (CFG.pad === false) root.classList.add('nopad');

    dpadEl = el('div', 'rr-c rr-pad rr-dpad', root);
    dpadEl.innerHTML = '<svg viewBox="0 0 100 100" aria-hidden="true">' +
      '<path class="pu" d="M50 10 L68 34 H32 Z"/><path class="pd" d="M50 90 L68 66 H32 Z"/>' +
      '<path class="pl" d="M10 50 L34 32 V68 Z"/><path class="pr" d="M90 50 L66 32 V68 Z"/></svg>';
    bindDpad(dpadEl);
    var map = [['rr-a', 'ok', '확인'], ['rr-b', 'cancel', '취소'], ['rr-dash', 'dash', '달리기']];
    if (isRm2k) map.push(['rr-n', 'n1', '1'], ['rr-n', 'n3', '3'], ['rr-n', 'n5', '5'], ['rr-n', 'n9', '9']);
    else map.push(['rr-sh rr-q', 'pageup', 'Q'], ['rr-sh rr-w', 'pagedown', 'W']);
    var numIndex = 0;
    map.forEach(function (m) {
      var b = el('div', 'rr-c rr-pad rr-btn ' + m[0], root, m[2]);
      if (m[0] === 'rr-n') b.style.setProperty('--i', String(numIndex++));
      bindButton(b, m[1]);
    });
    var menu = el('div', 'rr-c rr-btn rr-menu', root, '☰');
    menu.addEventListener('pointerdown', function (e) { wake(); e.preventDefault(); e.stopPropagation(); });
    menu.addEventListener('pointerup', function (e) { e.stopPropagation(); showMenu(); });

    // Nothing that happens on the overlay may reach the game's own mouse/touch handling (they would see a tap behind the button).
    ['touchstart', 'touchmove', 'touchend', 'touchcancel', 'mousedown', 'mousemove', 'mouseup', 'click', 'dblclick', 'wheel', 'contextmenu'].forEach(function (t) {
      root.addEventListener(t, function (e) {
        if (e.target === root) return;
        e.stopPropagation();
        if (e.cancelable && t !== 'click') e.preventDefault();
      }, { passive: false });
    });

    (document.body || document.documentElement).appendChild(root);
    wake();
  }

  global.addEventListener('gamepadconnected', function () { if (root) root.classList.add('gp'); });
  global.addEventListener('gamepaddisconnected', function () {
    var list = (navigator.getGamepads && navigator.getGamepads()) || [], any = false;
    for (var i = 0; i < list.length; i++) if (list[i]) any = true;
    if (!any && root) root.classList.remove('gp');
  });
  document.addEventListener('visibilitychange', function () { if (document.hidden) releaseAll(); });
  global.addEventListener('blur', releaseAll);

  var ui = global.__RR_UI = {
    key: fire, releaseAll: releaseAll, showMenu: showMenu,
    setPad: function (on) { if (!root) return; root.classList.toggle('nopad', !on); if (!on) releaseAll(); },
    isPad: function () { return !!root && !root.classList.contains('nopad'); },
    held: function () { var o = []; for (var n in held) if (held[n]) o.push(n); return o; }
  };
  RR.ui = ui;

  if (document.body) build(); else document.addEventListener('DOMContentLoaded', build);
})(window);
