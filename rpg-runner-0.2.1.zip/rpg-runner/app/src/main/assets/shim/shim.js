/*!
 * RPG Runner - NW.js / Node compatibility layer (part 1: core).
 * Injected by the local game server before any script of the game runs.
 * Inputs: window.__RR_CONFIG (/__rr/config.js) and window.RRNative (Android JS interface, may be absent).
 */
(function (global) {
  'use strict';
  if (global.__RR && global.__RR.loaded) return;

  var CFG = global.__RR_CONFIG || {};
  var N = global.RRNative || null;
  var RR = global.__RR = { loaded: true, version: '0.2.1', cfg: CFG, native: N, paused: false, modules: {}, lazy: {} };

  // ------------------------------------------------------------------ logging / errors
  var warned = {};
  function nlog(level, msg) {
    try { if (N && typeof N.log === 'function') N.log(level, String(msg).slice(0, 4000)); } catch (e) { /* ignore */ }
  }
  RR.log = nlog;
  RR.warnOnce = function (key, msg) {
    if (warned[key]) return;
    warned[key] = true;
    nlog('W', msg || key);
  };

  var ERR_TEXT = { ENOENT: 'no such file or directory', EACCES: 'permission denied', EEXIST: 'file already exists',
    EISDIR: 'illegal operation on a directory', ENOTDIR: 'not a directory', ENOTEMPTY: 'directory not empty',
    EIO: 'i/o error', EINVAL: 'invalid argument', EFBIG: 'file too large', ENOSYS: 'function not implemented', EBADF: 'bad file descriptor' };
  var ERR_NUM = { ENOENT: -2, EIO: -5, EBADF: -9, EACCES: -13, EEXIST: -17, ENOTDIR: -20, EISDIR: -21, EINVAL: -22, EFBIG: -27, ENOSYS: -38, ENOTEMPTY: -39 };
  function fsError(code, syscall, p) {
    var e = new Error(code + ': ' + (ERR_TEXT[code] || 'error') + ', ' + syscall + (p ? " '" + p + "'" : ''));
    e.code = code; e.errno = ERR_NUM[code] || -1; e.syscall = syscall;
    if (p) e.path = p;
    return e;
  }
  RR.fsError = fsError;

  // ------------------------------------------------------------------ encodings
  var B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  var B64REV = (function () { var t = {}; for (var i = 0; i < 64; i++) t[B64.charAt(i)] = i; t['-'] = 62; t['_'] = 63; return t; })();
  function b64enc(u8) {
    var out = [], chunk = '', i = 0, n = u8.length, v;
    for (; i + 2 < n; i += 3) {
      v = (u8[i] << 16) | (u8[i + 1] << 8) | u8[i + 2];
      chunk += B64.charAt(v >> 18) + B64.charAt((v >> 12) & 63) + B64.charAt((v >> 6) & 63) + B64.charAt(v & 63);
      if (chunk.length >= 8192) { out.push(chunk); chunk = ''; }
    }
    if (i < n) {
      var two = i + 1 < n;
      v = (u8[i] << 16) | ((two ? u8[i + 1] : 0) << 8);
      chunk += B64.charAt(v >> 18) + B64.charAt((v >> 12) & 63) + (two ? B64.charAt((v >> 6) & 63) : '=') + '=';
    }
    out.push(chunk);
    return out.join('');
  }
  function b64dec(s) {
    var clean = String(s).replace(/[^A-Za-z0-9+\/_-]/g, '');
    var n = clean.length, outLen = (n * 3) >> 2, out = new Uint8Array(outLen), o = 0, acc = 0, bits = 0;
    for (var i = 0; i < n; i++) {
      acc = (acc << 6) | B64REV[clean.charAt(i)];
      bits += 6;
      if (bits >= 8) { bits -= 8; out[o++] = (acc >> bits) & 255; acc &= (1 << bits) - 1; }
    }
    return o === outLen ? out : out.subarray(0, o);
  }
  var TE = typeof TextEncoder === 'function' ? new TextEncoder() : null;
  var TD = typeof TextDecoder === 'function' ? new TextDecoder('utf-8', { ignoreBOM: true }) : null;
  function utf8enc(s) {
    if (TE) return TE.encode(s);
    var u = unescape(encodeURIComponent(s)), o = new Uint8Array(u.length);
    for (var i = 0; i < u.length; i++) o[i] = u.charCodeAt(i);
    return o;
  }
  function utf8dec(u8) {
    if (TD) return TD.decode(u8);
    var s = '';
    for (var i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]);
    try { return decodeURIComponent(escape(s)); } catch (e) { return s; }
  }
  function latin1dec(u8) {
    var out = [];
    for (var i = 0; i < u8.length; i += 8192) out.push(String.fromCharCode.apply(null, u8.subarray(i, Math.min(u8.length, i + 8192))));
    return out.join('');
  }
  var HEX = (function () { var t = []; for (var i = 0; i < 256; i++) t.push((i < 16 ? '0' : '') + i.toString(16)); return t; })();
  function normEnc(e) {
    e = String(e || 'utf8').toLowerCase();
    if (e === 'utf-8') return 'utf8';
    if (e === 'binary') return 'latin1';
    if (e === 'ucs2' || e === 'ucs-2' || e === 'utf-16le') return 'utf16le';
    return e;
  }
  function strToBytes(s, enc) {
    var i, o;
    switch (normEnc(enc)) {
      case 'utf8': return utf8enc(s);
      case 'hex':
        o = new Uint8Array(s.length >> 1);
        for (i = 0; i < o.length; i++) {
          var b = parseInt(s.substr(i * 2, 2), 16);
          if (b !== b) return o.subarray(0, i);
          o[i] = b;
        }
        return o;
      case 'base64': case 'base64url': return b64dec(s);
      case 'latin1': case 'ascii':
        o = new Uint8Array(s.length);
        for (i = 0; i < s.length; i++) o[i] = s.charCodeAt(i) & 255;
        return o;
      case 'utf16le':
        o = new Uint8Array(s.length * 2);
        for (i = 0; i < s.length; i++) { var c = s.charCodeAt(i); o[i * 2] = c & 255; o[i * 2 + 1] = c >> 8; }
        return o;
    }
    throw new TypeError('Unknown encoding: ' + enc);
  }
  function bytesToStr(u8, enc) {
    var i, s;
    switch (normEnc(enc)) {
      case 'utf8': return utf8dec(u8);
      case 'hex': s = ''; for (i = 0; i < u8.length; i++) s += HEX[u8[i]]; return s;
      case 'base64': return b64enc(u8);
      case 'base64url': return b64enc(u8).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
      case 'latin1': return latin1dec(u8);
      case 'ascii': s = ''; for (i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i] & 127); return s;
      case 'utf16le': s = ''; for (i = 0; i + 1 < u8.length; i += 2) s += String.fromCharCode(u8[i] | (u8[i + 1] << 8)); return s;
    }
    throw new TypeError('Unknown encoding: ' + enc);
  }
  RR.b64enc = b64enc; RR.b64dec = b64dec; RR.utf8enc = utf8enc; RR.utf8dec = utf8dec;
  RR.strToBytes = strToBytes; RR.bytesToStr = bytesToStr;

  // ------------------------------------------------------------------ Buffer (Uint8Array subclass)
  var Buffer = (function () {
    class Buffer extends Uint8Array {
      static from(v, a, b) {
        var o, i;
        if (typeof v === 'string') { var bytes = strToBytes(v, a); o = new Buffer(bytes.length); o.set(bytes); return o; }
        if (v instanceof ArrayBuffer) return new Buffer(v, a === undefined ? 0 : a, b === undefined ? v.byteLength - (a || 0) : b);
        if (v && v.type === 'Buffer' && Array.isArray(v.data)) v = v.data;
        if (ArrayBuffer.isView(v) && !(v instanceof Uint8Array)) return new Buffer(v.buffer, v.byteOffset, v.byteLength);
        if (v && typeof v.length === 'number') {
          o = new Buffer(v.length);
          for (i = 0; i < v.length; i++) o[i] = v[i] & 255;
          return o;
        }
        throw new TypeError('The first argument must be of type string or an instance of Buffer, ArrayBuffer, or Array or an Array-like Object.');
      }
      static alloc(n, fill, enc) { var o = new Buffer(n); if (fill !== undefined && fill !== 0) o.fill(fill, 0, n, enc); return o; }
      static allocUnsafe(n) { return new Buffer(n); }
      static allocUnsafeSlow(n) { return new Buffer(n); }
      static isBuffer(b) { return b instanceof Buffer; }
      static isEncoding(e) { try { normEnc(e); strToBytes('', e); return true; } catch (x) { return false; } }
      static byteLength(s, enc) { return typeof s === 'string' ? strToBytes(s, enc).length : s.byteLength; }
      static concat(list, total) {
        var n = 0, i;
        for (i = 0; i < list.length; i++) n += list[i].length;
        if (total === undefined) total = n;
        var o = new Buffer(total), pos = 0;
        for (i = 0; i < list.length && pos < total; i++) {
          var part = list[i].length > total - pos ? list[i].subarray(0, total - pos) : list[i];
          o.set(part, pos); pos += part.length;
        }
        return o;
      }
      static compare(a, b) {
        var n = Math.min(a.length, b.length);
        for (var i = 0; i < n; i++) if (a[i] !== b[i]) return a[i] < b[i] ? -1 : 1;
        return a.length < b.length ? -1 : (a.length > b.length ? 1 : 0);
      }
      toString(enc, start, end) {
        start = start === undefined ? 0 : Math.max(0, start | 0);
        end = end === undefined ? this.length : Math.min(this.length, end | 0);
        return bytesToStr(start === 0 && end === this.length ? this : this.subarray(start, end), enc);
      }
      toJSON() { return { type: 'Buffer', data: Array.prototype.slice.call(this) }; }
      equals(o) { return Buffer.compare(this, o) === 0; }
      compare(o) { return Buffer.compare(this, o); }
      slice(s, e) { return this.subarray(s, e); }
      copy(target, ts, ss, se) {
        ts = ts || 0; ss = ss || 0; se = se === undefined ? this.length : se;
        var part = this.subarray(ss, se);
        if (part.length > target.length - ts) part = part.subarray(0, target.length - ts);
        target.set(part, ts);
        return part.length;
      }
      fill(v, s, e, enc) {
        if (typeof s === 'string') { enc = s; s = 0; e = this.length; }
        s = s === undefined ? 0 : s; e = e === undefined ? this.length : e;
        if (typeof v === 'string') {
          var pat = strToBytes(v, enc);
          if (pat.length === 0) return super.fill(0, s, e);
          for (var i = s, k = 0; i < e; i++, k++) this[i] = pat[k % pat.length];
          return this;
        }
        return super.fill(v & 255, s, e);
      }
      write(str, off, len, enc) {
        if (typeof off === 'string') { enc = off; off = 0; len = undefined; } else if (typeof len === 'string') { enc = len; len = undefined; }
        off = off || 0;
        var bytes = strToBytes(str, enc);
        var n = Math.min(bytes.length, this.length - off, len === undefined ? Infinity : len);
        this.set(bytes.subarray(0, n), off);
        return n;
      }
      indexOf(v, from, enc) {
        if (typeof v === 'number') return super.indexOf(v & 255, from);
        var pat = typeof v === 'string' ? strToBytes(v, enc) : v;
        for (var i = from || 0; i + pat.length <= this.length; i++) {
          var k = 0;
          while (k < pat.length && this[i + k] === pat[k]) k++;
          if (k === pat.length) return i;
        }
        return -1;
      }
      includes(v, from, enc) { return this.indexOf(v, from, enc) !== -1; }
      readUInt8(o) { return this[o || 0]; }
      readInt8(o) { var v = this[o || 0]; return v > 127 ? v - 256 : v; }
      readUInt16LE(o) { o = o || 0; return this[o] | (this[o + 1] << 8); }
      readUInt16BE(o) { o = o || 0; return (this[o] << 8) | this[o + 1]; }
      readInt16LE(o) { var v = this.readUInt16LE(o); return v > 32767 ? v - 65536 : v; }
      readInt16BE(o) { var v = this.readUInt16BE(o); return v > 32767 ? v - 65536 : v; }
      readUInt32LE(o) { o = o || 0; return (this[o] | (this[o + 1] << 8) | (this[o + 2] << 16)) + this[o + 3] * 16777216; }
      readUInt32BE(o) { o = o || 0; return this[o] * 16777216 + ((this[o + 1] << 16) | (this[o + 2] << 8) | this[o + 3]); }
      readInt32LE(o) { o = o || 0; return this[o] | (this[o + 1] << 8) | (this[o + 2] << 16) | (this[o + 3] << 24); }
      readInt32BE(o) { o = o || 0; return (this[o] << 24) | (this[o + 1] << 16) | (this[o + 2] << 8) | this[o + 3]; }
      writeUInt8(v, o) { o = o || 0; this[o] = v; return o + 1; }
      writeUInt16LE(v, o) { o = o || 0; this[o] = v; this[o + 1] = v >>> 8; return o + 2; }
      writeUInt16BE(v, o) { o = o || 0; this[o] = v >>> 8; this[o + 1] = v; return o + 2; }
      writeUInt32LE(v, o) { o = o || 0; this[o] = v; this[o + 1] = v >>> 8; this[o + 2] = v >>> 16; this[o + 3] = v >>> 24; return o + 4; }
      writeUInt32BE(v, o) { o = o || 0; this[o] = v >>> 24; this[o + 1] = v >>> 16; this[o + 2] = v >>> 8; this[o + 3] = v; return o + 4; }
      writeInt32LE(v, o) { return this.writeUInt32LE(v >>> 0, o); }
      writeInt32BE(v, o) { return this.writeUInt32BE(v >>> 0, o); }
    }
    return Buffer;
  })();
  RR.Buffer = Buffer;
  if (typeof global.Buffer === 'undefined') global.Buffer = Buffer;

  RR.toBytes = function (data, enc) {
    if (typeof data === 'string') return strToBytes(data, enc);
    if (data instanceof Uint8Array) return data;
    if (data instanceof ArrayBuffer) return new Uint8Array(data);
    if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    if (data === null || data === undefined) throw new TypeError('data must not be null or undefined');
    return strToBytes(String(data), enc);
  };

  // ------------------------------------------------------------------ EventEmitter
  function EventEmitter() { this._events = {}; this._max = 10; }
  EventEmitter.defaultMaxListeners = 10;
  EventEmitter.prototype._list = function (n) { return this._events[n] || (this._events[n] = []); };
  EventEmitter.prototype.on = EventEmitter.prototype.addListener = function (n, fn) {
    if (typeof fn !== 'function') throw new TypeError('The "listener" argument must be of type function');
    this._list(n).push({ fn: fn, once: false }); return this;
  };
  EventEmitter.prototype.prependListener = function (n, fn) { this._list(n).unshift({ fn: fn, once: false }); return this; };
  EventEmitter.prototype.once = function (n, fn) { this._list(n).push({ fn: fn, once: true }); return this; };
  EventEmitter.prototype.off = EventEmitter.prototype.removeListener = function (n, fn) {
    var l = this._events[n];
    if (!l) return this;
    for (var i = l.length - 1; i >= 0; i--) if (l[i].fn === fn || l[i].fn.listener === fn) { l.splice(i, 1); break; }
    return this;
  };
  EventEmitter.prototype.removeAllListeners = function (n) { if (n === undefined) this._events = {}; else delete this._events[n]; return this; };
  EventEmitter.prototype.emit = function (n) {
    var l = this._events[n];
    if (!l || !l.length) {
      if (n === 'error') { var er = arguments[1]; throw er instanceof Error ? er : new Error('Unhandled error. (' + er + ')'); }
      return false;
    }
    var args = Array.prototype.slice.call(arguments, 1), copy = l.slice();
    for (var i = 0; i < copy.length; i++) {
      if (copy[i].once) this.removeListener(n, copy[i].fn);
      try { copy[i].fn.apply(this, args); } catch (e) { nlog('E', 'event "' + n + '" listener threw: ' + (e && e.stack || e)); }
    }
    return true;
  };
  EventEmitter.prototype.listeners = function (n) { return (this._events[n] || []).map(function (x) { return x.fn; }); };
  EventEmitter.prototype.listenerCount = function (n) { return (this._events[n] || []).length; };
  EventEmitter.prototype.eventNames = function () { return Object.keys(this._events); };
  EventEmitter.prototype.setMaxListeners = function (n) { this._max = n; return this; };
  EventEmitter.prototype.getMaxListeners = function () { return this._max; };
  EventEmitter.EventEmitter = EventEmitter;

  // ------------------------------------------------------------------ path (POSIX)
  function normalizeParts(parts, abs) {
    var out = [];
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i];
      if (!p || p === '.') continue;
      if (p === '..') { if (out.length && out[out.length - 1] !== '..') out.pop(); else if (!abs) out.push('..'); }
      else out.push(p);
    }
    return out;
  }
  var path = {
    sep: '/', delimiter: ':',
    isAbsolute: function (p) { return String(p).charAt(0) === '/'; },
    normalize: function (p) {
      p = String(p);
      if (!p) return '.';
      var abs = p.charAt(0) === '/', trail = p.charAt(p.length - 1) === '/';
      var s = normalizeParts(p.split('/'), abs).join('/');
      if (!s && !abs) s = '.';
      if (s && trail) s += '/';
      return (abs ? '/' : '') + s;
    },
    join: function () {
      var parts = [];
      for (var i = 0; i < arguments.length; i++) {
        if (typeof arguments[i] !== 'string') throw new TypeError('The "path" argument must be of type string. Received ' + typeof arguments[i]);
        if (arguments[i]) parts.push(arguments[i]);
      }
      return parts.length ? path.normalize(parts.join('/')) : '.';
    },
    resolve: function () {
      var resolved = '', abs = false;
      for (var i = arguments.length - 1; i >= -1 && !abs; i--) {
        var p = i >= 0 ? arguments[i] : (global.process && global.process.cwd ? global.process.cwd() : '/');
        if (typeof p !== 'string') throw new TypeError('The "path" argument must be of type string');
        if (!p) continue;
        resolved = p + '/' + resolved;
        abs = p.charAt(0) === '/';
      }
      var s = normalizeParts(resolved.split('/'), abs).join('/');
      return ((abs ? '/' : '') + s) || '.';
    },
    dirname: function (p) {
      p = String(p);
      if (!p) return '.';
      var end = p.length;
      while (end > 1 && p.charAt(end - 1) === '/') end--;
      var i = p.lastIndexOf('/', end - 1);
      if (i < 0) return '.';
      if (i === 0) return '/';
      while (i > 1 && p.charAt(i - 1) === '/') i--;
      return p.slice(0, i);
    },
    basename: function (p, ext) {
      p = String(p);
      var end = p.length;
      while (end > 1 && p.charAt(end - 1) === '/') end--;
      p = p.slice(0, end);
      var b = p.slice(p.lastIndexOf('/') + 1);
      if (ext && b.length > ext.length && b.slice(-ext.length) === ext) b = b.slice(0, -ext.length);
      return b;
    },
    extname: function (p) {
      var b = path.basename(p), i = b.lastIndexOf('.');
      return (i <= 0) ? '' : b.slice(i);
    },
    relative: function (from, to) {
      from = path.resolve(from).split('/').filter(Boolean);
      to = path.resolve(to).split('/').filter(Boolean);
      var i = 0;
      while (i < from.length && i < to.length && from[i] === to[i]) i++;
      var up = [];
      for (var k = i; k < from.length; k++) up.push('..');
      return up.concat(to.slice(i)).join('/');
    },
    parse: function (p) {
      p = String(p);
      var root = p.charAt(0) === '/' ? '/' : '', base = path.basename(p), ext = path.extname(p);
      var dir = path.dirname(p);
      return { root: root, dir: dir === '.' && p.indexOf('/') < 0 ? '' : dir, base: base, ext: ext, name: ext ? base.slice(0, -ext.length) : base };
    },
    format: function (o) {
      var dir = o.dir || o.root || '', base = o.base || ((o.name || '') + (o.ext || ''));
      if (!dir) return base;
      return dir === o.root ? dir + base : dir + '/' + base;
    },
    toNamespacedPath: function (p) { return p; }
  };
  path.posix = path;
  path.win32 = path;

  // ------------------------------------------------------------------ process
  var stdTty = function (name) {
    return { isTTY: false, columns: 80, rows: 24, fd: name === 'stdout' ? 1 : 2,
      write: function (s) { nlog(name === 'stderr' ? 'W' : 'I', String(s).replace(/\n$/, '')); return true; },
      on: function () { return this; }, once: function () { return this; }, end: function () {}, removeListener: function () { return this; } };
  };
  var ROOT = String(CFG.root || '/');
  var DATA = String(CFG.dataDir || (ROOT + '/.rr-data'));
  var TMP = String(CFG.tmpDir || '/tmp');
  var MAIN = String(CFG.mainHtml || (ROOT + '/index.html'));
  var NWV = String(CFG.nwVersion || '0.78.1');
  var startedAt = Date.now();
  var proc = new EventEmitter();
  var chromeVer = (/Chrome\/([\d.]+)/.exec(global.navigator ? global.navigator.userAgent : '') || [0, '108.0.0.0'])[1];
  var env = { HOME: DATA, USER: 'player', USERNAME: 'player', LOGNAME: 'player', SHELL: '/bin/sh', LANG: 'en_US.UTF-8', PATH: '/usr/bin:/bin',
    TMPDIR: TMP, TEMP: TMP, TMP: TMP, APPDATA: DATA, LOCALAPPDATA: DATA, XDG_CONFIG_HOME: DATA, XDG_DATA_HOME: DATA, PWD: ROOT };
  var mainModule = { id: '.', filename: MAIN, path: path.dirname(MAIN), exports: {}, loaded: true, parent: null, children: [], paths: [], require: null };
  var processProps = {
    platform: String(CFG.platform || 'linux'), arch: 'x64', pid: 4242, ppid: 1, title: 'nw', version: 'v16.14.2',
    versions: { node: '16.14.2', nw: NWV, 'node-webkit': NWV, 'nw-flavor': 'normal', chromium: chromeVer, v8: '10.8.168.21', modules: '93' },
    release: { name: 'node' }, env: env, argv: ['nw', ROOT], execArgv: [], execPath: ROOT + '/nw', exitCode: undefined,
    mainModule: mainModule, config: { variables: {} }, features: {}, stdout: stdTty('stdout'), stderr: stdTty('stderr'), stdin: stdTty('stdin'),
    cwd: function () { return ROOT; }, chdir: function () {}, umask: function () { return 18; },
    uptime: function () { return (Date.now() - startedAt) / 1000; },
    hrtime: function (prev) {
      var t = global.performance && global.performance.now ? global.performance.now() : Date.now() - startedAt;
      var s = Math.floor(t / 1000), ns = Math.floor((t % 1000) * 1e6);
      if (prev) { s -= prev[0]; ns -= prev[1]; if (ns < 0) { s--; ns += 1e9; } }
      return [s, ns];
    },
    memoryUsage: function () {
      var m = global.performance && global.performance.memory;
      return { rss: m ? m.totalJSHeapSize : 0, heapTotal: m ? m.totalJSHeapSize : 0, heapUsed: m ? m.usedJSHeapSize : 0, external: 0, arrayBuffers: 0 };
    },
    cpuUsage: function () { return { user: 0, system: 0 }; },
    nextTick: function (fn) { var a = Array.prototype.slice.call(arguments, 1); Promise.resolve().then(function () { fn.apply(null, a); }); },
    emitWarning: function (w) { nlog('W', 'process warning: ' + (w && w.message || w)); },
    binding: function (n) { throw new Error('No such module: ' + n); },
    kill: function () { return true; }, abort: function () { RR.exit(); },
    exit: function (code) { proc.exitCode = code; try { proc.emit('exit', code || 0); } catch (e) { /* ignore */ } RR.exit(); },
    reallyExit: function () { RR.exit(); }
  };
  processProps.hrtime.bigint = function () {
    var t = processProps.hrtime();
    return typeof BigInt === 'function' ? BigInt(t[0]) * BigInt(1000000000) + BigInt(t[1]) : t[0] * 1e9 + t[1];
  };
  Object.keys(processProps).forEach(function (k) { proc[k] = processProps[k]; });
  mainModule.require = function (n) { return global.require(n); };
  RR.exit = function () {
    try { if (N && typeof N.exit === 'function') { N.exit(); return; } } catch (e) { /* ignore */ }
    try { global.close(); } catch (e2) { /* ignore */ }
  };

  // ------------------------------------------------------------------ fs
  // The Android JS bridge matches Java methods by name AND argument count, so never pass extra/undefined arguments.
  // The first distinct failures go to the log: when a game cannot find a file it expects (a language pack, a plugin resource, ...)
  // the log then names the path. existsSync() probes are counted separately because they are routine.
  var missSeen = {}, missCount = { probe: 0, fail: 0 }, MISS_CAP = { probe: 40, fail: 80 };
  function logMiss(kind, syscall, p, code) {
    var key = kind + ':' + syscall + ':' + p;
    if (missSeen[key] || missCount[kind] >= MISS_CAP[kind]) return;
    missSeen[key] = true;
    missCount[kind]++;
    nlog(kind === 'probe' ? 'I' : 'W', 'fs ' + syscall + (code ? ' ' + code : '') + ': ' + p +
      (missCount[kind] === MISS_CAP[kind] ? '  (further ' + (kind === 'probe' ? 'missing-path probes' : 'fs failures') + ' are not logged)' : ''));
  }
  // Data written through file descriptors (part 23) is kept in memory until close / fsync / a short idle time; every path based call
  // flushes it first so that readFileSync, statSync, rename ... always see what was written.
  var dirtyFds = 0, flushing = false, flushAll = function () {}, fdPathHook = null;
  function nativeCall(name, syscall, p, a, b) {
    var r, n = arguments.length - 3;
    if (dirtyFds && !flushing) flushAll();
    if (!N || typeof N[name] !== 'function') throw fsError('ENOSYS', syscall, p);
    r = n === 0 ? N[name](p) : n === 1 ? N[name](p, a) : N[name](p, a, b);
    if (typeof r === 'string' && r.charAt(0) === '!') { logMiss('fail', syscall, p, r.slice(1)); throw fsError(r.slice(1), syscall, p); }
    if (fdPathHook && (name === 'unlink' || name === 'rmdir' || name === 'rename')) fdPathHook(name, p, a);
    return r;
  }
  function pstr(p, fn) {
    if (p && typeof p === 'object' && typeof p.pathname === 'string') p = decodeURIComponent(p.pathname); // file: URL objects
    if (p instanceof Uint8Array) p = utf8dec(p);
    if (typeof p !== 'string') { var e = new TypeError('The "path" argument must be of type string or an instance of Buffer or URL. Received ' + (p === null ? 'null' : typeof p)); e.code = 'ERR_INVALID_ARG_TYPE'; throw e; }
    if (p.indexOf('file://') === 0) p = decodeURIComponent(p.replace(/^file:\/\/(localhost)?/, ''));
    if (p.charAt(0) !== '/') p = path.resolve(p); // relative to process.cwd(), like Node
    return p;
  }
  function Stats(o) {
    this.size = o.s; this.mtimeMs = o.m; this.mtime = new Date(o.m); this.ctimeMs = o.m; this.ctime = this.mtime;
    this.atimeMs = o.m; this.atime = this.mtime; this.birthtimeMs = o.m; this.birthtime = this.mtime;
    this.mode = o.d ? 16877 : 33188; this.uid = 0; this.gid = 0; this.nlink = 1; this.dev = 0; this.ino = 0; this.blksize = 4096; this.blocks = Math.ceil(o.s / 512);
    this._d = !!o.d; this._f = !!o.f;
  }
  Stats.prototype.isFile = function () { return this._f; };
  Stats.prototype.isDirectory = function () { return this._d; };
  Stats.prototype.isSymbolicLink = Stats.prototype.isFIFO = Stats.prototype.isSocket = Stats.prototype.isBlockDevice = Stats.prototype.isCharacterDevice = function () { return false; };
  function Dirent(name, st) { this.name = name; this._st = st; }
  Dirent.prototype.isFile = function () { return this._st.isFile(); };
  Dirent.prototype.isDirectory = function () { return this._st.isDirectory(); };
  Dirent.prototype.isSymbolicLink = function () { return false; };

  function optEnc(o) { return typeof o === 'string' ? o : (o && o.encoding) || null; }

  function xhrRead(p, asText) {
    if (dirtyFds && !flushing) flushAll();
    var url = global.location.origin + encodeURI(p).replace(/#/g, '%23').replace(/\?/g, '%3F');
    var x = new XMLHttpRequest();
    x.open('GET', url, false);
    x.overrideMimeType(asText ? 'text/plain; charset=utf-8' : 'text/plain; charset=x-user-defined');
    try { x.send(null); } catch (e) { throw fsError('EIO', 'read', p); }
    if (x.status === 404 || x.status === 403) { logMiss('fail', 'open', p, 'ENOENT'); throw fsError('ENOENT', 'open', p); }
    if (x.status !== 200 && x.status !== 0) throw fsError('EIO', 'read', p);
    return x.responseText;
  }

  var fs = {
    constants: { F_OK: 0, R_OK: 4, W_OK: 2, X_OK: 1, COPYFILE_EXCL: 1 }, F_OK: 0, R_OK: 4, W_OK: 2, X_OK: 1,
    Stats: Stats, Dirent: Dirent,
    existsSync: function (p) {
      try {
        var q = pstr(p), yes = nativeCall('exists', 'access', q) === '1';
        if (!yes) logMiss('probe', 'exists', q, 'false');
        return yes;
      } catch (e) { return false; }
    },
    accessSync: function (p) { if (nativeCall('exists', 'access', pstr(p)) !== '1') throw fsError('ENOENT', 'access', p); },
    statSync: function (p, o) {
      p = pstr(p);
      var r;
      try { r = nativeCall('stat', 'stat', p); } catch (e) { if (o && o.throwIfNoEntry === false && e.code === 'ENOENT') return undefined; throw e; }
      return new Stats(JSON.parse(r));
    },
    readdirSync: function (p, o) {
      p = pstr(p);
      var names = JSON.parse(nativeCall('readdir', 'scandir', p));
      if (o && typeof o === 'object' && o.withFileTypes) {
        return names.map(function (n) { return new Dirent(n, fs.statSync(p + '/' + n)); });
      }
      return names;
    },
    readFileSync: function (p, o) {
      p = pstr(p);
      var enc = optEnc(o), e = enc ? normEnc(enc) : null;
      if (e === 'utf8') return xhrRead(p, true);
      var raw = xhrRead(p, false), n = raw.length, u8 = new Uint8Array(n);
      for (var i = 0; i < n; i++) u8[i] = raw.charCodeAt(i) & 255;
      if (e) return bytesToStr(u8, e);
      var b = new Buffer(n); b.set(u8); return b;
    },
    writeFileSync: function (p, data, o) {
      p = pstr(p);
      var enc = optEnc(o), flag = o && typeof o === 'object' ? o.flag : undefined;
      var bytes = RR.toBytes(data, enc);
      nativeCall('writeBase64', 'open', p, b64enc(bytes), flag === 'a' || flag === 'a+');
    },
    appendFileSync: function (p, data, o) {
      p = pstr(p);
      nativeCall('writeBase64', 'open', p, b64enc(RR.toBytes(data, optEnc(o))), true);
    },
    mkdirSync: function (p, o) {
      var rec = !!(o && typeof o === 'object' && o.recursive);
      p = pstr(p);
      nativeCall('mkdir', 'mkdir', p, rec);
      return rec ? p : undefined;
    },
    unlinkSync: function (p) { nativeCall('unlink', 'unlink', pstr(p)); },
    rmdirSync: function (p, o) { nativeCall('rmdir', 'rmdir', pstr(p), !!(o && o.recursive)); },
    rmSync: function (p, o) {
      p = pstr(p);
      var st;
      try { st = fs.statSync(p); } catch (e) { if (o && o.force) return; throw e; }
      if (st.isDirectory()) nativeCall('rmdir', 'rm', p, !!(o && o.recursive)); else nativeCall('unlink', 'rm', p);
    },
    renameSync: function (a, b) { nativeCall('rename', 'rename', pstr(a), pstr(b)); },
    copyFileSync: function (a, b) { nativeCall('copy', 'copyfile', pstr(a), pstr(b)); },
    realpathSync: function (p) { p = pstr(p); fs.accessSync(p); return path.normalize(p); },
    utimesSync: function () {}, chmodSync: function () {}, chownSync: function () {}, symlinkSync: function (a, b) { throw fsError('ENOSYS', 'symlink', b); },
    watch: function () { var w = new EventEmitter(); w.close = function () {}; return w; }, watchFile: function () {}, unwatchFile: function () {},
    openSync: function (p) { throw fsError('ENOSYS', 'open', p); }, closeSync: function () {}
  };
  fs.lstatSync = fs.statSync;
  // callback + promise flavours are generated from the synchronous ones
  ['exists', 'access', 'stat', 'lstat', 'readdir', 'readFile', 'writeFile', 'appendFile', 'mkdir', 'unlink', 'rmdir', 'rm', 'rename', 'copyFile', 'realpath', 'utimes', 'chmod', 'chown'].forEach(function (name) {
    var sync = fs[name + 'Sync'];
    fs[name] = function () {
      var args = Array.prototype.slice.call(arguments), cb = args.pop();
      if (typeof cb !== 'function') throw new TypeError('The "cb" argument must be of type function');
      setTimeout(function () {
        var res, err = null;
        try { res = sync.apply(fs, args); } catch (e) { err = e; }
        if (name === 'exists') cb(!err && res); else if (err) cb(err); else cb(null, res);
      }, 0);
    };
  });
  fs.promises = {};
  ['access', 'stat', 'lstat', 'readdir', 'readFile', 'writeFile', 'appendFile', 'mkdir', 'unlink', 'rmdir', 'rm', 'rename', 'copyFile', 'realpath'].forEach(function (name) {
    var sync = fs[name + 'Sync'];
    fs.promises[name] = function () {
      var args = arguments;
      return new Promise(function (res, rej) { try { res(sync.apply(fs, args)); } catch (e) { rej(e); } });
    };
  });

  // ------------------------------------------------------------------ os, util, misc modules
  var os = {
    EOL: '\n', platform: function () { return proc.platform; }, type: function () { return 'Linux'; }, arch: function () { return 'x64'; },
    release: function () { return '5.10.0'; }, hostname: function () { return 'localhost'; }, homedir: function () { return DATA; },
    tmpdir: function () { return TMP; }, endianness: function () { return 'LE'; }, uptime: function () { return proc.uptime(); },
    totalmem: function () { return (global.navigator && global.navigator.deviceMemory || 4) * 1073741824; },
    freemem: function () { return 536870912; }, loadavg: function () { return [0, 0, 0]; }, networkInterfaces: function () { return {}; },
    cpus: function () {
      var n = global.navigator && global.navigator.hardwareConcurrency || 4, a = [];
      for (var i = 0; i < n; i++) a.push({ model: 'cpu', speed: 2000, times: { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 } });
      return a;
    },
    userInfo: function () { return { username: 'player', uid: 1000, gid: 1000, shell: '/bin/sh', homedir: DATA }; },
    constants: { signals: {}, errno: {} }
  };
  var util = {
    inherits: function (c, s) { c.super_ = s; c.prototype = Object.create(s.prototype, { constructor: { value: c, writable: true, configurable: true } }); },
    format: function (f) {
      var a = Array.prototype.slice.call(arguments, 1), i = 0;
      if (typeof f !== 'string') return [f].concat(a).map(function (x) { return util.inspect(x); }).join(' ');
      var s = f.replace(/%[sdifjoO%]/g, function (m) {
        if (m === '%%') return '%';
        if (i >= a.length) return m;
        var v = a[i++];
        return m === '%s' ? String(v) : (m === '%d' || m === '%i') ? String(parseInt(v, 10)) : m === '%f' ? String(parseFloat(v)) : util.inspect(v);
      });
      for (; i < a.length; i++) s += ' ' + (typeof a[i] === 'string' ? a[i] : util.inspect(a[i]));
      return s;
    },
    inspect: function (v) { if (typeof v === 'string') return "'" + v + "'"; try { return JSON.stringify(v, function (k, x) { return typeof x === 'function' ? '[Function]' : x; }); } catch (e) { return String(v); } },
    promisify: function (fn) { return function () { var a = Array.prototype.slice.call(arguments), self = this; return new Promise(function (res, rej) { a.push(function (err, v) { err ? rej(err) : res(v); }); fn.apply(self, a); }); }; },
    deprecate: function (fn) { return fn; }, isArray: Array.isArray, isDeepStrictEqual: function (a, b) { return JSON.stringify(a) === JSON.stringify(b); },
    TextEncoder: global.TextEncoder, TextDecoder: global.TextDecoder, types: {}
  };
  var urlMod = {
    URL: global.URL, URLSearchParams: global.URLSearchParams,
    parse: function (s) {
      try { var u = new URL(s, 'http://localhost'); return { href: s, protocol: /^[a-z]+:/i.test(s) ? u.protocol : null, host: u.host, hostname: u.hostname, port: u.port || null, pathname: u.pathname, search: u.search, query: u.search.slice(1), hash: u.hash, path: u.pathname + u.search }; }
      catch (e) { return { href: s, pathname: s }; }
    },
    fileURLToPath: function (u) { return decodeURIComponent(String(u && u.pathname || u).replace(/^file:\/\//, '')); },
    pathToFileURL: function (p) { return new URL('file://' + encodeURI(p)); }
  };
  var stubFn = function () { throw new Error('This feature is not available on Android'); };
  var childProcess = {
    exec: function (cmd, o, cb) { cb = typeof o === 'function' ? o : cb; RR.warnOnce('child_process.exec', 'child_process.exec ignored: ' + cmd); if (cb) setTimeout(function () { cb(new Error('child_process is not available on Android'), '', ''); }, 0); return new EventEmitter(); },
    spawn: function (cmd) { RR.warnOnce('child_process.spawn', 'child_process.spawn ignored: ' + cmd); var e = new EventEmitter(); e.stdout = new EventEmitter(); e.stderr = new EventEmitter(); e.kill = function () {}; setTimeout(function () { e.emit('error', new Error('spawn ' + cmd + ' ENOENT')); }, 0); return e; },
    execSync: stubFn, spawnSync: stubFn, execFile: function () { return childProcess.exec.apply(null, arguments); }, fork: stubFn
  };
  // hashes, HMAC, PBKDF2 and the random helpers are added by 26-crypto.js
  var cryptoMod = {
    randomUUID: function () { return global.crypto && global.crypto.randomUUID ? global.crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) { var r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16); }); }
  };
  var stringDecoder = { StringDecoder: function (enc) { this.write = function (b) { return bytesToStr(b, enc || 'utf8'); }; this.end = function () { return ''; }; } };
  var timersMod = { setTimeout: global.setTimeout.bind(global), setInterval: global.setInterval.bind(global), clearTimeout: global.clearTimeout.bind(global), clearInterval: global.clearInterval.bind(global), setImmediate: function (f) { var a = Array.prototype.slice.call(arguments, 1); return setTimeout(function () { f.apply(null, a); }, 0); }, clearImmediate: global.clearTimeout.bind(global) };
  if (typeof global.setImmediate === 'undefined') global.setImmediate = timersMod.setImmediate;
  var assertMod = function (v, m) { if (!v) throw new Error(m || 'Assertion failed'); };
  assertMod.ok = assertMod; assertMod.equal = function (a, b, m) { if (a != b) throw new Error(m || (a + ' != ' + b)); };
  assertMod.strictEqual = function (a, b, m) { if (a !== b) throw new Error(m || (a + ' !== ' + b)); };
  assertMod.deepStrictEqual = assertMod.deepEqual = function (a, b, m) { if (!util.isDeepStrictEqual(a, b)) throw new Error(m || 'not deep equal'); };
  assertMod.throws = function (fn) { try { fn(); } catch (e) { return; } throw new Error('Missing expected exception'); };
  // ------------------------------------------------------------------ stream: StringDecoder, Stream, Readable
  // A compact implementation of Node's stream classes (the app has no real Node): flowing and paused reading, push() / read(),
  // 'readable', pipe() with back-pressure, async iteration, destroy(). Writable, Duplex, Transform and pipeline() follow in part 22.
  var streamTick = function (fn) {
    var a = Array.prototype.slice.call(arguments, 1);
    Promise.resolve().then(function () { fn.apply(null, a); });
  };
  function sErr(Ctor, code, msg) { var e = new Ctor(msg); e.code = code; return e; }
  function describeVal(v) {
    if (v === null || v === undefined) return String(v);
    if (typeof v === 'object' || typeof v === 'function') return 'an instance of ' + ((v.constructor && v.constructor.name) || 'Object');
    if (typeof v === 'string') return "type string ('" + (v.length > 28 ? v.slice(0, 25) + '...' : v) + "')";
    return 'type ' + typeof v + ' (' + String(v) + ')';
  }
  function toBuf(u8) { return u8 instanceof Buffer ? u8 : new Buffer(u8.buffer, u8.byteOffset, u8.length); }

  // string_decoder: multi-byte characters (and base64 / utf16 units) that are split across chunks are held back until complete
  function StringDecoder(enc) {
    this.encoding = normEnc(enc);
    if (!Buffer.isEncoding(this.encoding)) throw sErr(TypeError, 'ERR_UNKNOWN_ENCODING', 'Unknown encoding: ' + enc);
    this._td = this.encoding === 'utf8' && typeof TextDecoder === 'function' ? new TextDecoder('utf-8', { ignoreBOM: true }) : null;
    this._carry = null;
  }
  StringDecoder.prototype.write = function (buf) {
    if (typeof buf === 'string') return buf;
    var u = RR.toBytes(buf), enc = this.encoding;
    if (enc === 'utf8' && this._td) return this._td.decode(u, { stream: true });
    var unit = enc === 'utf16le' ? 2 : (enc === 'base64' || enc === 'base64url') ? 3 : 1;
    if (unit === 1) return bytesToStr(u, enc);
    var joined = u, keep;
    if (this._carry && this._carry.length) { joined = new Uint8Array(this._carry.length + u.length); joined.set(this._carry); joined.set(u, this._carry.length); }
    keep = joined.length % unit;
    this._carry = keep ? joined.slice(joined.length - keep) : null;
    return bytesToStr(keep ? joined.subarray(0, joined.length - keep) : joined, enc);
  };
  StringDecoder.prototype.end = function (buf) {
    var r = buf === undefined ? '' : this.write(buf);
    if (this._td) r += this._td.decode();
    else if (this._carry && this._carry.length) r += bytesToStr(this._carry, this.encoding);
    this._carry = null;
    return r;
  };
  stringDecoder.StringDecoder = StringDecoder;

  function Stream(opts) { EventEmitter.call(this); this.destroyed = false; }
  util.inherits(Stream, EventEmitter);
  Stream.prototype.pipe = function (dest, opts) { // old-style streams
    var src = this;
    src.on('data', function (c) { if (dest.write(c) === false && typeof src.pause === 'function') src.pause(); });
    dest.on('drain', function () { if (typeof src.resume === 'function') src.resume(); });
    if (!opts || opts.end !== false) src.on('end', function () { dest.end(); });
    dest.emit('pipe', src);
    return dest;
  };

  function Readable(opts) {
    if (!(this instanceof Readable)) return new Readable(opts);
    Stream.call(this);
    opts = opts || {};
    var om = !!(opts.objectMode || opts.readableObjectMode), hwm = opts.readableHighWaterMark;
    if (hwm === undefined) hwm = opts.highWaterMark;
    if (hwm === undefined) hwm = om ? 16 : 16384;
    this._r = { om: om, hwm: hwm, buf: [], len: 0, flowing: null, ended: false, endEmitted: false, endScheduled: false, reading: false, sync: true, pumping: false,
      listening: false, emittedReadable: false, needReadable: false, decoder: null, pipes: [], awaitDrain: 0, autoDestroy: opts.autoDestroy !== false };
    this._emitClose = opts.emitClose !== false;
    this.readable = true;
    if (typeof opts.read === 'function') this._read = opts.read;
    if (typeof opts.destroy === 'function') this._destroy = opts.destroy;
    if (opts.encoding) this.setEncoding(opts.encoding);
  }
  util.inherits(Readable, Stream);
  Readable.prototype._read = function () { throw sErr(Error, 'ERR_METHOD_NOT_IMPLEMENTED', 'The _read() method is not implemented'); };

  function errorOrDestroy(s, err) {
    if (s.destroyed) return;
    if ((s._r && s._r.autoDestroy) || (s._w && s._w.autoDestroy)) s.destroy(err);
    else if (err && !s._errorEmitted) { s._errorEmitted = true; s.errored = err; streamTick(function () { s.emit('error', err); }); }
  }
  function destroyImpl(err, cb) {
    var s = this, called = false;
    if (typeof err === 'function') { cb = err; err = null; }
    if (s.destroyed) { if (typeof cb === 'function') streamTick(cb); return s; }
    s.destroyed = true; s.readable = false; s.writable = false;
    if (err) s.errored = err;
    function after(er) {
      if (called) return;
      called = true;
      er = er || err;
      streamTick(function () {
        if (er && !s._errorEmitted) { s._errorEmitted = true; s.emit('error', er); }
        if (s._emitClose !== false && !s._closeEmitted) { s._closeEmitted = true; s.emit('close'); }
        if (typeof cb === 'function') cb(er);
      });
    }
    try { s._destroy(err || null, after); } catch (e) { after(e); }
    if (s._w && typeof failQueued === 'function') failQueued(s);
    return s;
  }
  Readable.prototype.destroy = destroyImpl;
  Readable.prototype._destroy = function (err, cb) { cb(err); };

  // push() only buffers; the pump (a microtask) delivers 'data' / 'readable' / 'end' and asks the source for more
  function addChunk(s, chunk, enc, front) {
    var r = s._r, rest;
    if (chunk === null) {
      r.reading = false;
      if (!r.ended) {
        if (r.decoder) { rest = r.decoder.end(); if (rest) { r.buf.push(rest); r.len += rest.length; } }
        r.ended = true;
        if (r.flowing && r.len === 0) endReadable(s); else schedulePump(s);
      }
      return false;
    }
    if (r.ended && !front) { errorOrDestroy(s, sErr(Error, 'ERR_STREAM_PUSH_AFTER_EOF', 'stream.push() after EOF')); return false; }
    if (!r.om) {
      if (typeof chunk === 'string') {
        enc = enc || 'utf8';
        if (!r.decoder || normEnc(enc) !== r.decoder.encoding) chunk = toBuf(strToBytes(chunk, enc));
      } else if (chunk instanceof Uint8Array) {
        chunk = toBuf(chunk);
      } else if (chunk !== undefined) {
        errorOrDestroy(s, sErr(TypeError, 'ERR_INVALID_ARG_TYPE', 'The "chunk" argument must be of type string or an instance of Buffer or Uint8Array. Received ' + describeVal(chunk)));
        return false;
      }
      if (chunk !== undefined && r.decoder && typeof chunk !== 'string') chunk = r.decoder.write(chunk);
      if (chunk === undefined || chunk.length === 0) { r.reading = false; schedulePump(s); return r.len < r.hwm; }
    }
    r.reading = false;
    if (r.flowing && r.len === 0 && !r.sync && !front && s.listenerCount('data') > 0) { // nobody is waiting: hand it over right away
      s.emit('data', chunk);
      schedulePump(s);
      return true;
    }
    if (front) r.buf.unshift(chunk); else r.buf.push(chunk);
    r.len += r.om ? 1 : chunk.length;
    schedulePump(s);
    return r.len < r.hwm || r.len === 0;
  }
  Readable.prototype.push = function (chunk, enc) { return addChunk(this, chunk, enc, false); };
  Readable.prototype.unshift = function (chunk, enc) { addChunk(this, chunk, enc, true); };

  function schedulePump(s) {
    var r = s._r;
    if (r.pumping || s.destroyed) return;
    r.pumping = true;
    streamTick(pump, s);
  }
  function pump(s) {
    var r = s._r;
    r.pumping = false;
    if (s.destroyed) return;
    if (r.flowing) {
      do { s.read(); } while (r.flowing && !s.destroyed && r.len > 0); // read() emits 'data'; with an empty buffer it asks for more or ends
    } else if (r.listening && !r.emittedReadable && (r.len > 0 || r.ended)) {
      r.emittedReadable = true; r.needReadable = false;
      s.emit('readable');
    } else {
      maybeRead(s);
    }
  }
  function maybeRead(s) {
    var r = s._r;
    if (r.reading || r.ended || s.destroyed || r.len >= r.hwm) return;
    r.reading = true; r.sync = true;
    try { s._read(r.hwm); } catch (e) { r.reading = false; errorOrDestroy(s, e); }
    r.sync = false;
  }
  function endReadable(s) {
    var r = s._r;
    if (r.endScheduled || r.endEmitted || s.destroyed) return;
    r.endScheduled = true;
    streamTick(function () {
      if (s.destroyed || r.endEmitted) return;
      if (r.len > 0) { r.endScheduled = false; return; } // something was unshift()ed meanwhile
      r.endEmitted = true; s.readable = false;
      s.emit('end');
      if (r.autoDestroy && !s.destroyed && (!s._w || s._w.finished)) s.destroy();
    });
  }

  // n units (bytes / characters / one object) from the buffer, or null when there are not enough yet
  function takeChunk(s, n) {
    var r = s._r, b = r.buf, first, all, str, ret;
    if (r.len === 0) return null;
    if (r.om) { r.len--; return b.shift(); }
    if (n !== n) { // read() without a size: the first chunk while flowing, everything otherwise
      if (r.flowing) { first = b.shift(); r.len -= first.length; return first; }
      n = r.len;
    }
    if (n > r.len) { if (!r.ended) return null; n = r.len; }
    first = b[0]; str = typeof first === 'string';
    if (first.length === n) { b.shift(); r.len -= n; return first; }
    if (first.length > n) { b[0] = str ? first.slice(n) : first.subarray(n); r.len -= n; return str ? first.slice(0, n) : first.subarray(0, n); }
    all = str ? b.join('') : Buffer.concat(b);
    ret = all.length === n ? all : (str ? all.slice(0, n) : all.subarray(0, n));
    r.buf = all.length === n ? [] : [str ? all.slice(n) : all.subarray(n)];
    r.len -= n;
    return ret;
  }
  Readable.prototype.read = function (n) {
    var r = this._r, ret;
    n = n === undefined ? NaN : Number(n);
    if (n === 0) { if (r.ended && r.len === 0) schedulePump(this); else maybeRead(this); return null; }
    ret = takeChunk(this, n);
    r.emittedReadable = false;
    if (ret === null) {
      r.needReadable = true;
      if (r.ended && r.len === 0) endReadable(this); else maybeRead(this);
      return null;
    }
    if (r.ended && r.len === 0) endReadable(this); else maybeRead(this);
    this.emit('data', ret);
    return ret;
  };

  function listenSideEffects(s, ev) {
    var r = s._r;
    if (ev === 'data') {
      r.listening = s.listenerCount('readable') > 0;
      if (r.flowing !== false) s.resume();
    } else if (ev === 'readable' && !r.endEmitted && !r.listening) {
      r.listening = r.needReadable = true; r.flowing = false; r.emittedReadable = false;
      schedulePump(s);
    }
  }
  Readable.prototype.on = Readable.prototype.addListener = function (ev, fn) { EventEmitter.prototype.on.call(this, ev, fn); listenSideEffects(this, ev); return this; };
  Readable.prototype.once = function (ev, fn) { EventEmitter.prototype.once.call(this, ev, fn); listenSideEffects(this, ev); return this; };
  Readable.prototype.resume = function () {
    var r = this._r, s = this;
    if (!r.flowing) {
      r.flowing = !r.listening;
      if (r.flowing) streamTick(function () { if (!s.destroyed && r.flowing) s.emit('resume'); });
    }
    schedulePump(this);
    return this;
  };
  Readable.prototype.pause = function () {
    if (this._r.flowing !== false) { this._r.flowing = false; this.emit('pause'); }
    return this;
  };
  Readable.prototype.isPaused = function () { return this._r.flowing === false; };
  Readable.prototype.setEncoding = function (enc) {
    var r = this._r, d = new StringDecoder(enc), joined = '', i;
    r.decoder = d;
    for (i = 0; i < r.buf.length; i++) joined += typeof r.buf[i] === 'string' ? r.buf[i] : d.write(r.buf[i]);
    r.buf = joined ? [joined] : []; r.len = joined.length;
    return this;
  };

  Readable.prototype.pipe = function (dest, opts) {
    var src = this, r = this._r, blocked = false, rec;
    var doEnd = (!opts || opts.end !== false) && dest !== proc.stdout && dest !== proc.stderr;
    function ondata(chunk) {
      if (dest.write(chunk) === false && !blocked) { blocked = true; r.awaitDrain++; src.pause(); dest.once('drain', ondrain); }
    }
    function ondrain() { if (!blocked) return; blocked = false; if (--r.awaitDrain <= 0) { r.awaitDrain = 0; src.resume(); } }
    function onend() { dest.end(); }
    function cleanup() {
      src.removeListener('data', ondata); src.removeListener('end', onend);
      dest.removeListener('drain', ondrain); dest.removeListener('error', onerror);
      dest.removeListener('close', onclose); dest.removeListener('finish', onfinish);
      if (blocked) { blocked = false; r.awaitDrain = Math.max(0, r.awaitDrain - 1); }
    }
    function unpipe() { var i = r.pipes.indexOf(rec); cleanup(); if (i >= 0) r.pipes.splice(i, 1); dest.emit('unpipe', src); }
    function onerror(er) { unpipe(); if (dest.listenerCount('error') === 0) dest.emit('error', er); }
    function onclose() { dest.removeListener('finish', onfinish); unpipe(); }
    function onfinish() { dest.removeListener('close', onclose); unpipe(); }
    rec = { dest: dest, unpipe: unpipe };
    r.pipes.push(rec);
    src.on('data', ondata);
    src.once('end', doEnd ? onend : unpipe);
    dest.prependListener('error', onerror);
    dest.once('close', onclose); dest.once('finish', onfinish);
    dest.emit('pipe', src);
    if (!r.flowing) src.resume();
    return dest;
  };
  Readable.prototype.unpipe = function (dest) {
    var list = this._r.pipes.slice(), i;
    for (i = 0; i < list.length; i++) if (!dest || list[i].dest === dest) list[i].unpipe();
    return this;
  };

  Object.defineProperties(Readable.prototype, {
    readableFlowing: { get: function () { return this._r.flowing; } },
    readableLength: { get: function () { return this._r.len; } },
    readableHighWaterMark: { get: function () { return this._r.hwm; } },
    readableEnded: { get: function () { return this._r.endEmitted; } },
    readableObjectMode: { get: function () { return this._r.om; } },
    readableEncoding: { get: function () { return this._r.decoder ? this._r.decoder.encoding : null; } }
  });

  Readable.from = function (iterable, opts) {
    var it, rd, busy = false;
    if (iterable === null || iterable === undefined) throw sErr(TypeError, 'ERR_INVALID_ARG_TYPE', 'The "iterable" argument must be an instance of Iterable. Received ' + describeVal(iterable));
    if (typeof iterable === 'string' || iterable instanceof Uint8Array) iterable = [iterable];
    it = iterable[Symbol.asyncIterator] ? iterable[Symbol.asyncIterator]() : iterable[Symbol.iterator]();
    rd = new Readable(Object.assign({ objectMode: true, highWaterMark: 1 }, opts));
    rd._read = function () {
      if (busy) return;
      busy = true;
      Promise.resolve().then(function () { return it.next(); }).then(function (res) {
        if (res.done) { busy = false; rd.push(null); return undefined; }
        return Promise.resolve(res.value).then(function (v) {
          busy = false;
          if (v === null) throw sErr(TypeError, 'ERR_STREAM_NULL_VALUES', 'May not write null values to stream');
          rd.push(v);
        });
      }).catch(function (e) { busy = false; rd.destroy(e); });
    };
    return rd;
  };

  if (typeof Symbol === 'function' && Symbol.asyncIterator) {
    Readable.prototype[Symbol.asyncIterator] = function () {
      var s = this, q = [], wake = null, done = false, err = null, it;
      function poke() { var w = wake; wake = null; if (w) w(); }
      s.on('data', function (c) { q.push(c); s.pause(); poke(); });
      s.on('end', function () { done = true; poke(); });
      s.on('error', function (e) { err = e; poke(); });
      s.on('close', function () { if (!done && !err) err = sErr(Error, 'ERR_STREAM_PREMATURE_CLOSE', 'Premature close'); poke(); });
      it = {
        next: function () {
          return new Promise(function (resolve, reject) {
            (function step() {
              if (q.length) { resolve({ value: q.shift(), done: false }); return; }
              if (err) { reject(err); return; }
              if (done) { resolve({ value: undefined, done: true }); return; }
              wake = step; s.resume();
            })();
          });
        },
        'return': function () { s.destroy(); return Promise.resolve({ value: undefined, done: true }); }
      };
      it[Symbol.asyncIterator] = function () { return this; };
      return it;
    };
  }
  // ------------------------------------------------------------------ stream: Writable, Duplex, Transform, PassThrough, pipeline, finished
  function Writable(opts) {
    if (!(this instanceof Writable) && !(this instanceof Duplex)) return new Writable(opts);
    Stream.call(this);
    opts = opts || {};
    var om = !!(opts.objectMode || opts.writableObjectMode), hwm = opts.writableHighWaterMark;
    if (hwm === undefined) hwm = opts.highWaterMark;
    if (hwm === undefined) hwm = om ? 16 : 16384;
    this._w = { om: om, hwm: hwm, queue: [], len: 0, writing: false, draining: false, ending: false, finished: false, needDrain: false,
      corked: 0, decode: opts.decodeStrings !== false, defEnc: opts.defaultEncoding || 'utf8', pending: 0, finalCalled: false,
      onFinished: [], autoDestroy: opts.autoDestroy !== false };
    this._emitClose = opts.emitClose !== false;
    this.writable = true;
    if (typeof opts.write === 'function') this._write = opts.write;
    if (typeof opts.final === 'function') this._final = opts.final;
    if (typeof opts.destroy === 'function') this._destroy = opts.destroy;
  }
  util.inherits(Writable, Stream);
  if (typeof Symbol === 'function' && Symbol.hasInstance) { // a Duplex counts as a Writable, like in Node
    Object.defineProperty(Writable, Symbol.hasInstance, { value: function (o) {
      if (Function.prototype[Symbol.hasInstance].call(this, o)) return true;
      return this === Writable && !!(o && o._w);
    } });
  }
  Writable.prototype._write = function (chunk, enc, cb) { cb(sErr(Error, 'ERR_METHOD_NOT_IMPLEMENTED', 'The _write() method is not implemented')); };
  Writable.prototype.destroy = destroyImpl;
  Writable.prototype._destroy = function (err, cb) { cb(err); };

  function failQueued(s) {
    var w = s._w, q = w.queue, i, err = sErr(Error, 'ERR_STREAM_DESTROYED', 'Cannot call write after a stream was destroyed');
    var ends = w.onFinished.splice(0);
    w.queue = [];
    for (i = 0; i < q.length; i++) { w.pending--; w.len -= q[i].size; if (q[i].cb) streamTick(q[i].cb, err); }
    for (i = 0; i < ends.length; i++) streamTick(ends[i], s.errored || null); // end(cb) callbacks of a stream that never finished
  }
  function doWrite(s, item) {
    var w = s._w, done = false, sync = true;
    w.writing = true;
    function onwrite(er) {
      if (done) return;
      done = true;
      w.writing = false; w.len -= item.size;
      if (er) {
        w.pending--;
        if (item.cb) streamTick(item.cb, er);
        errorOrDestroy(s, er);
        return;
      }
      clearQueue(s);
      if (sync) streamTick(afterWrite, s, item.cb); else afterWrite(s, item.cb);
    }
    try { s._write(item.chunk, item.enc, onwrite); } catch (e) { onwrite(e); }
    sync = false;
  }
  function clearQueue(s) { // not recursive: a write that completes synchronously just lets the running loop continue
    var w = s._w;
    if (w.draining) return;
    w.draining = true;
    while (w.queue.length && !w.writing && !w.corked && !s.destroyed) doWrite(s, w.queue.shift());
    w.draining = false;
  }
  function afterWrite(s, cb) {
    var w = s._w;
    if (!w.ending && !s.destroyed && w.len === 0 && w.needDrain) { w.needDrain = false; s.emit('drain'); }
    w.pending--;
    if (cb) cb();
    finishMaybe(s);
  }
  function finishMaybe(s) {
    var w = s._w, called = false;
    if (!w.ending || w.finished || w.finalCalled || w.len > 0 || w.queue.length || w.writing || s.destroyed) return;
    w.finalCalled = true;
    function fin() {
      streamTick(function () {
        if (s.destroyed) return;
        var ends = w.onFinished.splice(0), i;
        w.finished = true;
        for (i = 0; i < ends.length; i++) ends[i](); // end(cb) callbacks run before the 'finish' listeners, like in Node
        s.emit('finish');
        if (w.autoDestroy && !s.destroyed && (!s._r || s._r.endEmitted)) s.destroy();
      });
    }
    if (typeof s._final !== 'function') { s.emit('prefinish'); fin(); return; }
    try {
      s._final(function (er) {
        if (called) return;
        called = true;
        if (er) errorOrDestroy(s, er); else { s.emit('prefinish'); fin(); }
      });
    } catch (e) { errorOrDestroy(s, e); }
  }

  Writable.prototype.write = function (chunk, enc, cb) {
    var w = this._w, err, size, ret;
    if (typeof enc === 'function') { cb = enc; enc = null; }
    if (chunk === null) throw sErr(TypeError, 'ERR_STREAM_NULL_VALUES', 'May not write null values to stream');
    if (!w.om) {
      if (typeof chunk === 'string') {
        if (w.decode) { chunk = toBuf(strToBytes(chunk, enc || w.defEnc)); enc = 'buffer'; } else enc = enc || w.defEnc;
      } else if (chunk instanceof Uint8Array) {
        chunk = toBuf(chunk); enc = 'buffer';
      } else {
        throw sErr(TypeError, 'ERR_INVALID_ARG_TYPE', 'The "chunk" argument must be of type string or an instance of Buffer or Uint8Array. Received ' + describeVal(chunk));
      }
    }
    if (w.ending) err = sErr(Error, 'ERR_STREAM_WRITE_AFTER_END', 'write after end');
    else if (this.destroyed) err = sErr(Error, 'ERR_STREAM_DESTROYED', 'Cannot call write after a stream was destroyed');
    if (err) {
      if (typeof cb === 'function') streamTick(cb, err);
      errorOrDestroy(this, err);
      return false;
    }
    w.pending++;
    size = w.om ? 1 : chunk.length;
    w.len += size;
    ret = w.len < w.hwm;
    if (!ret) w.needDrain = true;
    if (w.writing || w.corked) w.queue.push({ chunk: chunk, enc: enc, cb: cb, size: size });
    else doWrite(this, { chunk: chunk, enc: enc, cb: cb, size: size });
    return ret;
  };
  Writable.prototype.end = function (chunk, enc, cb) {
    var w = this._w, err;
    if (typeof chunk === 'function') { cb = chunk; chunk = null; enc = null; } else if (typeof enc === 'function') { cb = enc; enc = null; }
    if (chunk !== null && chunk !== undefined) this.write(chunk, enc);
    if (w.corked) { w.corked = 1; this.uncork(); }
    if (!w.ending && !this.destroyed) { w.ending = true; finishMaybe(this); }
    else if (w.finished) err = sErr(Error, 'ERR_STREAM_ALREADY_FINISHED', 'Cannot call end after a stream was finished');
    else if (this.destroyed) err = sErr(Error, 'ERR_STREAM_DESTROYED', 'Cannot call end after a stream was destroyed');
    if (typeof cb === 'function') {
      if (err || w.finished) streamTick(cb, err); else w.onFinished.push(cb);
    }
    return this;
  };
  Writable.prototype.cork = function () { this._w.corked++; };
  Writable.prototype.uncork = function () {
    var w = this._w;
    if (w.corked) { w.corked--; if (!w.writing && !w.corked) clearQueue(this); }
  };
  Writable.prototype.setDefaultEncoding = function (enc) {
    enc = normEnc(enc);
    if (!Buffer.isEncoding(enc)) throw sErr(TypeError, 'ERR_UNKNOWN_ENCODING', 'Unknown encoding: ' + enc);
    this._w.defEnc = enc;
    return this;
  };
  Object.defineProperties(Writable.prototype, {
    writableLength: { get: function () { return this._w.len; } },
    writableHighWaterMark: { get: function () { return this._w.hwm; } },
    writableEnded: { get: function () { return this._w.ending; } },
    writableFinished: { get: function () { return this._w.finished; } },
    writableObjectMode: { get: function () { return this._w.om; } },
    writableCorked: { get: function () { return this._w.corked; } },
    writableNeedDrain: { get: function () { var w = this._w; return !this.destroyed && !w.ending && w.needDrain; } }
  });

  function Duplex(opts) {
    if (!(this instanceof Duplex)) return new Duplex(opts);
    Readable.call(this, opts);
    Writable.call(this, opts);
    this.allowHalfOpen = !(opts && opts.allowHalfOpen === false);
    if (!this.allowHalfOpen) this.once('end', function () { this.end(); });
  }
  util.inherits(Duplex, Readable);
  Object.getOwnPropertyNames(Writable.prototype).forEach(function (k) {
    if (k !== 'constructor' && !(k in Duplex.prototype)) Object.defineProperty(Duplex.prototype, k, Object.getOwnPropertyDescriptor(Writable.prototype, k));
  });

  function Transform(opts) {
    if (!(this instanceof Transform)) return new Transform(opts);
    Duplex.call(this, opts);
    this._r.sync = false; // _read() is a no-op, so nothing has to wait for a first _read() call (same as Node)
    if (opts && typeof opts.transform === 'function') this._transform = opts.transform;
    if (opts && typeof opts.flush === 'function') this._flush = opts.flush;
  }
  util.inherits(Transform, Duplex);
  Transform.prototype._transform = function () { throw sErr(Error, 'ERR_METHOD_NOT_IMPLEMENTED', 'The _transform() method is not implemented'); };
  Transform.prototype._read = function () {}; // push-driven: nothing to ask for
  Transform.prototype._write = function (chunk, enc, cb) {
    var self = this;
    this._transform(chunk, enc, function (err, data) {
      if (err) { cb(err); return; }
      if (data !== undefined && data !== null) self.push(data);
      cb();
    });
  };
  Transform.prototype._final = function (cb) {
    var self = this;
    function done(err, data) {
      if (err) { cb(err); return; }
      if (data !== undefined && data !== null) self.push(data);
      self.push(null);
      cb();
    }
    if (typeof this._flush === 'function') this._flush(done); else done();
  };
  function PassThrough(opts) {
    if (!(this instanceof PassThrough)) return new PassThrough(opts);
    Transform.call(this, opts);
  }
  util.inherits(PassThrough, Transform);
  PassThrough.prototype._transform = function (chunk, enc, cb) { cb(null, chunk); };

  // finished(): calls back once the stream has ended and / or finished, failed or closed early
  function noop() {}
  function finished(stream, opts, cb) {
    if (typeof opts === 'function') { cb = opts; opts = {}; }
    opts = opts || {};
    var wantR = opts.readable !== undefined ? !!opts.readable : (stream.readable === true || !!stream._r);
    var wantW = opts.writable !== undefined ? !!opts.writable : (stream.writable === true || !!stream._w);
    var rDone = !wantR || (stream._r ? stream._r.endEmitted : false);
    var wDone = !wantW || (stream._w ? stream._w.finished : false);
    var called = false;
    function cleanup() {
      stream.removeListener('end', onend); stream.removeListener('finish', onfinish);
      stream.removeListener('error', onerror); stream.removeListener('close', onclose);
    }
    function call(err) { if (called) return; called = true; cleanup(); cb.call(stream, err); }
    function onend() { rDone = true; if (wDone) call(); }
    function onfinish() { wDone = true; if (rDone) call(); }
    function onerror(e) { call(e); }
    function onclose() { call(!rDone || !wDone ? sErr(Error, 'ERR_STREAM_PREMATURE_CLOSE', 'Premature close') : undefined); }
    stream.on('end', onend); stream.on('finish', onfinish); stream.on('error', onerror); stream.on('close', onclose);
    if (rDone && wDone) streamTick(call);
    return cleanup;
  }
  function pipeline() {
    var args = Array.prototype.slice.call(arguments), cb = typeof args[args.length - 1] === 'function' ? args.pop() : null;
    var streams = args.length === 1 && Array.isArray(args[0]) ? args[0] : args, cleanups = [], over = false, i;
    if (streams.length < 2) throw sErr(TypeError, 'ERR_MISSING_ARGS', 'The "streams" argument must be specified');
    function done(err) {
      if (over) return;
      over = true;
      cleanups.forEach(function (c) { c(); });
      streams.forEach(function (s) { s.on('error', noop); if (err && typeof s.destroy === 'function') s.destroy(); });
      if (cb) cb(err);
    }
    streams.forEach(function (s, idx) {
      cleanups.push(finished(s, { readable: idx < streams.length - 1, writable: idx > 0 }, function (err) {
        if (err) done(err); else if (idx === streams.length - 1) done();
      }));
    });
    for (i = 0; i < streams.length - 1; i++) streams[i].pipe(streams[i + 1]);
    return streams[streams.length - 1];
  }
  Stream.Stream = Stream; Stream.Readable = Readable; Stream.Writable = Writable; Stream.Duplex = Duplex;
  Stream.Transform = Transform; Stream.PassThrough = PassThrough; Stream.pipeline = pipeline; Stream.finished = finished;
  Stream.promises = {
    pipeline: function () {
      var args = Array.prototype.slice.call(arguments);
      return new Promise(function (res, rej) { args.push(function (e) { if (e) rej(e); else res(); }); pipeline.apply(null, args); });
    },
    finished: function (stream, opts) {
      return new Promise(function (res, rej) { finished(stream, opts || {}, function (e) { if (e) rej(e); else res(); }); });
    }
  };
  var streamMod = Stream;
  // ------------------------------------------------------------------ fs: file descriptors
  // openSync / readSync / writeSync / fstatSync / ftruncateSync / fsyncSync / closeSync on top of the path based bridge. A file is
  // loaded into memory when it is first read or modified and written back as a whole on close / fsync / after a short idle time;
  // every path based call flushes pending data first (see nativeCall), so other code always sees what was written.
  (function (c) { for (var k in c) fs.constants[k] = c[k]; })({ O_RDONLY: 0, O_WRONLY: 1, O_RDWR: 2, O_CREAT: 64, O_EXCL: 128, O_TRUNC: 512,
    O_APPEND: 1024, O_SYNC: 1052672, O_DIRECTORY: 65536, S_IFMT: 61440, S_IFREG: 32768, S_IFDIR: 16384, UV_FS_COPYFILE_EXCL: 1 });

  var fdTable = {}, nextFd = 24, flushTimer = 0;

  function flushEntry(e) {
    if (!e.dirty) return;
    if (e.gone) { e.dirty = false; dirtyFds--; return; } // its file was deleted meanwhile: nothing to write back
    var was = flushing;
    flushing = true;
    e.dirty = false; dirtyFds--;
    try {
      nativeCall('writeBase64', 'write', e.p, b64enc(e.data.subarray(0, e.size)), false);
    } catch (err) {
      e.err = err;
      nlog('W', 'fs write-back failed: ' + e.p + ' ' + err.message);
    } finally { flushing = was; }
  }
  flushAll = function () {
    var k;
    if (flushing) return;
    flushing = true;
    try { for (k in fdTable) flushEntry(fdTable[k]); } finally { flushing = false; }
  };
  // a file that is deleted or moved while a descriptor is open: the descriptor keeps following the file, like on a real file system
  fdPathHook = function (name, p, to) {
    var k, e, pre = p + '/';
    for (k in fdTable) {
      e = fdTable[k];
      if (name === 'rename') { if (e.p === p) e.p = to; else if (e.p.indexOf(pre) === 0) e.p = to + e.p.slice(p.length); }
      else if (name === 'unlink' ? e.p === p : e.p.indexOf(pre) === 0) e.gone = true;
    }
  };
  function raiseFlushError(e) { if (e.err) { var er = e.err; e.err = null; throw er; } }
  function markDirty(e) {
    e.mtime = Date.now();
    if (!e.dirty) { e.dirty = true; dirtyFds++; }
    if (!flushTimer) flushTimer = setTimeout(function () { flushTimer = 0; flushAll(); }, 300);
  }
  if (global.addEventListener) {
    global.addEventListener('pagehide', function () { flushAll(); });
    global.addEventListener('visibilitychange', function () { if (global.document && global.document.visibilityState === 'hidden') flushAll(); });
  }
  RR.flushFiles = function () { flushAll(); };

  function argTypeErr(name, what, v) {
    return sErr(TypeError, 'ERR_INVALID_ARG_TYPE', 'The "' + name + '" argument must be ' + what + '. Received ' + describeVal(v));
  }
  function rangeErr(name, range, v) {
    return sErr(RangeError, 'ERR_OUT_OF_RANGE', 'The value of "' + name + '" is out of range. It must be ' + range + '. Received ' + v);
  }
  function getFd(fd, syscall) {
    if (typeof fd !== 'number') throw argTypeErr('fd', 'of type number', fd);
    var e = fdTable[fd];
    if (!e) throw fsError('EBADF', syscall);
    return e;
  }
  function parseFlags(f) {
    var r = { read: true, write: false, append: false, create: false, excl: false, trunc: false }, s, plus, kind;
    if (f === undefined || f === null) return r;
    if (typeof f === 'number') {
      kind = f & 3;
      r.read = kind !== 1; r.write = kind !== 0; r.append = !!(f & 1024); r.create = !!(f & 64); r.excl = !!(f & 128); r.trunc = !!(f & 512);
      return r;
    }
    s = String(f);
    if (!/^(?:rs?\+?|sr\+?|wx?\+?|xw\+?|a[sx]?\+?|[sx]a\+?)$/.test(s)) {
      throw sErr(TypeError, 'ERR_INVALID_ARG_VALUE', "The argument 'flags' is invalid. Received '" + s + "'");
    }
    plus = s.indexOf('+') >= 0;
    kind = s.replace(/[sx+]/g, '');
    r.excl = s.indexOf('x') >= 0;
    if (kind === 'r') { r.write = plus; } else if (kind === 'w') { r.write = true; r.read = plus; r.create = true; r.trunc = true; } else { r.write = true; r.append = true; r.read = plus; r.create = true; }
    return r;
  }
  function quietStat(p, syscall) { // like statSync but a missing file is a normal answer (null), not a logged failure
    var r;
    if (!N || typeof N.stat !== 'function') throw fsError('ENOSYS', syscall, p);
    if (dirtyFds && !flushing) flushAll();
    r = N.stat(p);
    if (typeof r === 'string' && r.charAt(0) === '!') {
      if (r === '!ENOENT') return null;
      throw fsError(r.slice(1), syscall, p);
    }
    return JSON.parse(r);
  }
  function openFd(p, flags) {
    var q = pstr(p), fl = parseFlags(flags), st = quietStat(q, 'open'), e, fresh = false, fd;
    if (st && st.d) throw fsError('EISDIR', 'open', q);
    if (st && fl.create && fl.excl) throw fsError('EEXIST', 'open', q);
    if (!st) {
      if (!fl.create) { logMiss('fail', 'open', q, 'ENOENT'); throw fsError('ENOENT', 'open', q); }
      nativeCall('writeBase64', 'open', q, '', false); // creates the empty file (ENOENT when its folder is missing)
      fresh = true;
    } else if (fl.trunc) {
      nativeCall('writeBase64', 'open', q, '', false);
      fresh = true;
    }
    e = { p: q, fl: fl, pos: 0, data: fresh ? new Uint8Array(0) : null, size: fresh ? 0 : st.s, mtime: st ? st.m : Date.now(), loaded: fresh, dirty: false, err: null };
    fd = nextFd++;
    fdTable[fd] = e;
    return fd;
  }
  function ensureLoaded(e) {
    if (e.loaded) return;
    var raw = xhrRead(e.p, false), n = raw.length, u8 = new Uint8Array(n), i;
    for (i = 0; i < n; i++) u8[i] = raw.charCodeAt(i) & 255;
    e.data = u8; e.size = n; e.loaded = true;
  }
  function growTo(e, n) {
    var bigger;
    if (n <= e.data.length) return;
    bigger = new Uint8Array(Math.max(n, e.data.length * 2, 1024));
    bigger.set(e.data.subarray(0, e.size));
    e.data = bigger;
  }
  function isPos(position) { return (typeof position === 'number' && position >= 0) || (typeof position === 'bigint' && position >= 0); }
  function byteView(buf) {
    if (buf instanceof Uint8Array) return buf;
    if (ArrayBuffer.isView(buf)) return new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
    return null;
  }

  function readFd(fd, view, off, len, position) {
    var e = getFd(fd, 'read'), at, n;
    if (!e.fl.read) throw fsError('EBADF', 'read');
    if (len === 0) return 0;
    ensureLoaded(e);
    at = isPos(position) ? Number(position) : e.pos;
    n = Math.max(0, Math.min(len, e.size - at));
    if (n > 0) view.set(e.data.subarray(at, at + n), off);
    if (!isPos(position)) e.pos = at + n;
    return n;
  }
  function writeFd(fd, bytes, position) {
    var e = getFd(fd, 'write'), at, end;
    if (!e.fl.write) throw fsError('EBADF', 'write');
    ensureLoaded(e);
    at = e.fl.append ? e.size : isPos(position) ? Number(position) : e.pos;
    end = at + bytes.length;
    growTo(e, end);
    e.data.set(bytes, at);
    if (end > e.size) e.size = end;
    if (e.fl.append || !isPos(position)) e.pos = end;
    markDirty(e);
    return bytes.length;
  }
  function truncFd(fd, len) {
    var e = getFd(fd, 'ftruncate');
    if (len === undefined || len === null) len = 0;
    if (typeof len !== 'number') throw argTypeErr('len', 'of type number', len);
    if (len !== Math.floor(len)) throw rangeErr('len', 'an integer', len);
    len = Math.max(0, len); // like Node, a negative length means 0
    if (!e.fl.write) throw fsError('EINVAL', 'ftruncate');
    if (len === 0 && !e.loaded) { e.data = new Uint8Array(0); e.size = 0; e.loaded = true; } else ensureLoaded(e);
    if (len < e.size) e.data.fill(0, len, e.size); else growTo(e, len);
    e.size = len;
    markDirty(e);
  }
  function syncFd(fd) {
    var e = getFd(fd, 'fsync');
    flushEntry(e);
    raiseFlushError(e);
  }
  function closeFd(fd) {
    var e = getFd(fd, 'close');
    flushEntry(e);
    delete fdTable[fd];
    raiseFlushError(e);
  }

  // (buffer, offset | options, length, position) -> { view, off, len, pos }
  function readArgs(buffer, a, b, c, nargs) {
    var view = byteView(buffer), off = 0, len, pos = null;
    if (!view) throw argTypeErr('buffer', 'an instance of Buffer, TypedArray, or DataView', buffer);
    if (nargs <= 3 && a !== undefined && a !== null && typeof a !== 'object') throw argTypeErr('options', 'of type object', a);
    if (a !== null && a !== undefined && typeof a === 'object') { off = a.offset || 0; len = a.length; pos = a.position === undefined ? null : a.position; }
    else { off = a === undefined ? 0 : a; len = b; pos = c === undefined ? null : c; }
    if (typeof off !== 'number') throw argTypeErr('offset', 'of type number', off);
    if (off < 0 || off > view.length) throw rangeErr('offset', '>= 0 && <= ' + view.length, off);
    if (len === undefined) len = view.length - off;
    if (typeof len !== 'number') throw argTypeErr('length', 'of type number', len);
    if (len < 0 || off + len > view.length) throw rangeErr('length', '>= 0 && <= ' + (view.length - off), len);
    return { view: view, off: off, len: len, pos: pos };
  }
  // (buffer, offset | options, length, position) or (string, position, encoding) -> { bytes, pos }
  function writeArgs(data, a, b, c) {
    var view, off, len, pos = null;
    if (typeof data === 'string') {
      if (a !== null && a !== undefined && typeof a === 'object') { pos = a.position === undefined ? null : a.position; b = a.encoding; } else { pos = a === undefined ? null : a; }
      return { bytes: strToBytes(data, typeof b === 'string' ? b : 'utf8'), pos: pos };
    }
    view = byteView(data);
    if (!view) throw argTypeErr('buffer', 'of type string or an instance of Buffer, TypedArray, or DataView', data);
    if (a !== null && a !== undefined && typeof a === 'object') { off = a.offset || 0; len = a.length; pos = a.position === undefined ? null : a.position; }
    else { off = a === undefined ? 0 : a; len = b; pos = c === undefined ? null : c; }
    if (len === undefined) len = view.length - off;
    if (off < 0 || off > view.length) throw rangeErr('offset', '>= 0 && <= ' + view.length, off);
    if (len < 0 || off + len > view.length) throw rangeErr('length', '>= 0 && <= ' + (view.length - off), len);
    return { bytes: view.subarray(off, off + len), pos: pos };
  }

  fs.openSync = function (p, flags) { return openFd(p, flags); };
  fs.closeSync = function (fd) { closeFd(fd); };
  fs.readSync = function (fd, buffer, a, b, c) { var r = readArgs(buffer, a, b, c, arguments.length); return readFd(fd, r.view, r.off, r.len, r.pos); };
  fs.writeSync = function (fd, data, a, b, c) { var r = writeArgs(data, a, b, c); return writeFd(fd, r.bytes, r.pos); };
  fs.fstatSync = function (fd) { var e = getFd(fd, 'fstat'); return new Stats({ s: e.size, m: e.mtime, d: 0, f: 1 }); };
  fs.ftruncateSync = function (fd, len) { truncFd(fd, len); };
  fs.fsyncSync = fs.fdatasyncSync = function (fd) { syncFd(fd); };
  fs.fchmodSync = fs.fchownSync = fs.futimesSync = function (fd) { getFd(fd, 'fchmod'); };
  fs.truncateSync = function (p, len) {
    var fd = openFd(p, 'r+');
    try { truncFd(fd, len); } finally { closeFd(fd); }
  };
  fs.mkdtempSync = function (prefix) {
    var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', tries, i, s;
    for (tries = 0; tries < 20; tries++) {
      s = String(prefix);
      for (i = 0; i < 6; i++) s += chars.charAt(Math.floor(Math.random() * chars.length));
      try { fs.mkdirSync(s); return s; } catch (e) { if (e.code !== 'EEXIST') throw e; }
    }
    throw fsError('EEXIST', 'mkdtemp', prefix + 'XXXXXX');
  };

  // readFileSync / writeFileSync / appendFileSync also accept a file descriptor
  ['readFileSync', 'writeFileSync', 'appendFileSync'].forEach(function (name) {
    var orig = fs[name];
    fs[name] = function (p, data, o) {
      if (typeof p !== 'number') return orig.apply(fs, arguments);
      var e, enc, bytes, b;
      if (name === 'readFileSync') {
        e = getFd(p, 'read');
        if (!e.fl.read) throw fsError('EBADF', 'read');
        ensureLoaded(e);
        bytes = e.data.slice(e.pos, e.size);
        e.pos = e.size;
        enc = optEnc(data);
        if (enc) return bytesToStr(bytes, normEnc(enc));
        b = new Buffer(bytes.length); b.set(bytes);
        return b;
      }
      writeFd(p, RR.toBytes(data, optEnc(o)), null);
    };
  });
  // ------------------------------------------------------------------ fs: callback / promise flavours of the descriptor functions, FileHandle, streams
  function later(fn) { setTimeout(fn, 0); }
  function takeCb(args) {
    var cb = args.pop();
    if (typeof cb !== 'function') throw argTypeErr('cb', 'of type function', cb);
    return cb;
  }
  function checkFd(fd) { if (typeof fd !== 'number') throw argTypeErr('fd', 'of type number', fd); }

  fs.open = function (p) {
    var args = Array.prototype.slice.call(arguments), cb = takeCb(args), pp = pstr(args[0]), fl = args[1];
    parseFlags(fl);
    later(function () { var fd; try { fd = openFd(pp, fl); } catch (e) { cb(e); return; } cb(null, fd); });
  };
  fs.close = function (fd, cb) {
    checkFd(fd);
    later(function () { try { closeFd(fd); } catch (e) { if (cb) cb(e); return; } if (cb) cb(null); });
  };
  fs.read = function (fd) {
    var args = Array.prototype.slice.call(arguments, 1), cb = takeCb(args), o, buffer, r;
    checkFd(fd);
    if (!byteView(args[0])) { // read(fd, [options,] cb)
      o = args[0] || {};
      buffer = o.buffer || new Buffer(16384);
      args = [buffer, { offset: o.offset, length: o.length, position: o.position }];
    }
    r = readArgs(args[0], args[1], args[2], args[3], 5);
    later(function () { var n; try { n = readFd(fd, r.view, r.off, r.len, r.pos); } catch (e) { cb(e); return; } cb(null, n, args[0]); });
  };
  fs.write = function (fd, data) {
    var args = Array.prototype.slice.call(arguments, 2), cb = takeCb(args), r;
    checkFd(fd);
    r = writeArgs(data, args[0], args[1], args[2]);
    later(function () { var n; try { n = writeFd(fd, r.bytes, r.pos); } catch (e) { cb(e); return; } cb(null, n, data); });
  };
  fs.fstat = function (fd, cb) {
    checkFd(fd);
    later(function () { var s; try { s = fs.fstatSync(fd); } catch (e) { cb(e); return; } cb(null, s); });
  };
  fs.fsync = fs.fdatasync = function (fd, cb) {
    checkFd(fd);
    later(function () { try { syncFd(fd); } catch (e) { cb(e); return; } cb(null); });
  };
  fs.ftruncate = function (fd, len, cb) {
    if (typeof len === 'function') { cb = len; len = 0; }
    checkFd(fd);
    later(function () { try { truncFd(fd, len); } catch (e) { cb(e); return; } cb(null); });
  };
  fs.truncate = function (p, len, cb) {
    if (typeof len === 'function') { cb = len; len = 0; }
    later(function () { try { fs.truncateSync(p, len); } catch (e) { cb(e); return; } cb(null); });
  };
  fs.mkdtemp = function (prefix, o, cb) {
    if (typeof o === 'function') cb = o;
    later(function () { var d; try { d = fs.mkdtempSync(prefix); } catch (e) { cb(e); return; } cb(null, d); });
  };

  function promised(fn) { return new Promise(function (res, rej) { try { res(fn()); } catch (e) { rej(e); } }); }
  function FileHandle(fd) { this.fd = fd; }
  FileHandle.prototype.read = function (buffer, a, b, c) {
    var self = this;
    return promised(function () {
      var o, r;
      if (!byteView(buffer)) { o = buffer || {}; buffer = o.buffer || new Buffer(16384); a = { offset: o.offset, length: o.length, position: o.position }; }
      r = readArgs(buffer, a, b, c, 5);
      return { bytesRead: readFd(self.fd, r.view, r.off, r.len, r.pos), buffer: buffer };
    });
  };
  FileHandle.prototype.write = function (data, a, b, c) {
    var self = this;
    return promised(function () { var r = writeArgs(data, a, b, c); return { bytesWritten: writeFd(self.fd, r.bytes, r.pos), buffer: data }; });
  };
  FileHandle.prototype.readFile = function (o) { var self = this; return promised(function () { return fs.readFileSync(self.fd, o); }); };
  FileHandle.prototype.writeFile = FileHandle.prototype.appendFile = function (data, o) { var self = this; return promised(function () { fs.writeFileSync(self.fd, data, o); }); };
  FileHandle.prototype.stat = function () { var self = this; return promised(function () { return fs.fstatSync(self.fd); }); };
  FileHandle.prototype.truncate = function (len) { var self = this; return promised(function () { truncFd(self.fd, len); }); };
  FileHandle.prototype.sync = FileHandle.prototype.datasync = function () { var self = this; return promised(function () { syncFd(self.fd); }); };
  FileHandle.prototype.chmod = FileHandle.prototype.chown = FileHandle.prototype.utimes = function () { var self = this; return promised(function () { getFd(self.fd, 'fchmod'); }); };
  FileHandle.prototype.close = function () {
    var self = this;
    return promised(function () { var fd = self.fd; if (fd === -1) return; self.fd = -1; closeFd(fd); });
  };
  FileHandle.prototype.createReadStream = function (o) { return new ReadStream(null, Object.assign({}, o, { fd: this.fd })); };
  FileHandle.prototype.createWriteStream = function (o) { return new WriteStream(null, Object.assign({}, o, { fd: this.fd })); };
  fs.promises.open = function (p, flags) { return promised(function () { return new FileHandle(openFd(p, flags)); }); };
  fs.promises.truncate = function (p, len) { return promised(function () { fs.truncateSync(p, len); }); };
  fs.promises.mkdtemp = function (prefix) { return promised(function () { return fs.mkdtempSync(prefix); }); };
  fs.promises.constants = fs.constants;

  // ReadStream: the descriptor is opened on the next tick ('open', 'ready'), then the file is delivered in highWaterMark sized chunks
  function closeOwned(s, err) {
    if (s.fd !== null && s.autoClose) {
      try { if (fdTable[s.fd]) closeFd(s.fd); } catch (e) { err = err || e; }
      s.fd = null;
    }
    return err;
  }
  function checkRange(name, v) {
    if (typeof v !== 'number') throw argTypeErr(name, 'of type number', v);
    if (v < 0 || v !== Math.floor(v)) throw rangeErr(name, '>= 0 && <= 9007199254740991', v);
  }
  function ReadStream(p, opts) {
    if (!(this instanceof ReadStream)) return new ReadStream(p, opts);
    var self = this;
    opts = typeof opts === 'string' ? { encoding: opts } : Object.assign({}, opts);
    if (opts.highWaterMark === undefined) opts.highWaterMark = 65536;
    Readable.call(this, opts);
    this.fd = typeof opts.fd === 'number' ? opts.fd : null;
    this.path = this.fd === null ? p : undefined;
    this._q = this.fd === null ? pstr(p) : null; // a bad path type throws right away, like in Node
    this.flags = opts.flags === undefined ? 'r' : opts.flags;
    this.mode = opts.mode === undefined ? 438 : opts.mode;
    this.start = opts.start;
    this.end = opts.end === undefined ? Infinity : opts.end;
    this.pos = undefined;
    this.bytesRead = 0;
    this.autoClose = opts.autoClose !== false;
    if (this.start !== undefined) { checkRange('start', this.start); this.pos = this.start; }
    if (this.end !== Infinity) {
      checkRange('end', this.end);
      if (this.start !== undefined && this.start > this.end) {
        throw rangeErr('start', '<= "end" (here: ' + this.end + ')', this.start);
      }
    }
    this._opened = this.fd !== null;
    this._wantRead = false;
    if (!this._opened) streamTick(function () { self._open(); });
  }
  util.inherits(ReadStream, Readable);
  ReadStream.prototype._open = function () {
    if (this.destroyed) return;
    try { this.fd = openFd(this._q, this.flags); } catch (e) { this.destroy(e); return; }
    this._opened = true;
    this.emit('open', this.fd);
    this.emit('ready');
    if (this._wantRead) { this._wantRead = false; this._read(this._r.hwm); }
  };
  ReadStream.prototype._read = function (n) {
    var want, buf, got;
    if (!this._opened) { this._wantRead = true; return; }
    if (this.destroyed || this.fd === null) return;
    want = this.pos !== undefined ? Math.min(this.end - this.pos + 1, n) : Math.min(this.end - this.bytesRead + 1, n);
    if (want <= 0) { this.push(null); return; }
    try {
      buf = new Buffer(want);
      got = readFd(this.fd, buf, 0, want, this.pos === undefined ? null : this.pos);
    } catch (e) { this.destroy(e); return; }
    if (got === 0) { this.push(null); return; }
    if (this.pos !== undefined) this.pos += got;
    this.bytesRead += got;
    this.push(got === want ? buf : buf.subarray(0, got));
  };
  ReadStream.prototype._destroy = function (err, cb) { cb(closeOwned(this, err)); };
  ReadStream.prototype.close = function (cb) { if (typeof cb === 'function') finished(this, cb); this.destroy(); };
  Object.defineProperty(ReadStream.prototype, 'pending', { get: function () { return this.fd === null; } });

  function WriteStream(p, opts) {
    if (!(this instanceof WriteStream)) return new WriteStream(p, opts);
    var self = this;
    opts = typeof opts === 'string' ? { encoding: opts } : Object.assign({}, opts);
    opts.decodeStrings = true;
    Writable.call(this, opts);
    if (opts.encoding) this.setDefaultEncoding(opts.encoding);
    this.fd = typeof opts.fd === 'number' ? opts.fd : null;
    this.path = this.fd === null ? p : undefined;
    this.flags = opts.flags === undefined ? 'w' : opts.flags;
    this.mode = opts.mode === undefined ? 438 : opts.mode;
    this.start = opts.start;
    this.pos = undefined;
    this.bytesWritten = 0;
    this.autoClose = opts.autoClose !== false;
    this._openErr = null;
    this._ready = this.fd !== null; // 'pending' stays true until the open has been announced, as in Node
    if (this.start !== undefined) { checkRange('start', this.start); this.pos = this.start; }
    if (this.fd === null) {
      this._q = pstr(p);
      try { this.fd = openFd(this._q, this.flags); } catch (e) { this._openErr = e; }
      streamTick(function () {
        if (self.destroyed) return;
        if (self._openErr) { self.destroy(self._openErr); return; }
        self._ready = true;
        self.emit('open', self.fd);
        self.emit('ready');
      });
    }
  }
  util.inherits(WriteStream, Writable);
  WriteStream.prototype._write = function (chunk, enc, cb) {
    var n;
    if (this._openErr) { cb(this._openErr); return; }
    try { n = writeFd(this.fd, chunk, this.pos === undefined ? null : this.pos); } catch (e) { cb(e); return; }
    this.bytesWritten += n;
    if (this.pos !== undefined) this.pos += n;
    cb();
  };
  WriteStream.prototype._final = function (cb) {
    try { if (this.fd !== null && fdTable[this.fd]) syncFd(this.fd); } catch (e) { cb(e); return; }
    cb();
  };
  WriteStream.prototype._destroy = function (err, cb) { cb(closeOwned(this, err)); };
  WriteStream.prototype.close = function (cb) {
    if (typeof cb === 'function') { if (this._closeEmitted) streamTick(cb); else this.once('close', cb); }
    if (!this.autoClose) this.once('finish', this.destroy);
    this.end();
  };
  WriteStream.prototype.destroySoon = WriteStream.prototype.end;
  Object.defineProperty(WriteStream.prototype, 'pending', { get: function () { return !this._ready; } });

  fs.ReadStream = ReadStream;
  fs.WriteStream = WriteStream;
  fs.createReadStream = function (p, o) { return new ReadStream(p, o); };
  fs.createWriteStream = function (p, o) { return new WriteStream(p, o); };

  // ------------------------------------------------------------------ zlib
  // Pure-JS stand-in for Node's zlib. Decompression handles stored / fixed / dynamic blocks in zlib, gzip (multi-member, header
  // flags, CRC-16) and raw streams with the same checks and error codes as Node. Compression writes valid streams (stored
  // blocks for level 0, otherwise LZ77 + the fixed Huffman code) that every inflater reads; they are not byte-identical to zlib's.
  // Everything is synchronous underneath; the callback and stream flavours only defer the work. Brotli is not available.
  var zlibMod = (function () {
    var CONST = {
      Z_NO_FLUSH: 0, Z_PARTIAL_FLUSH: 1, Z_SYNC_FLUSH: 2, Z_FULL_FLUSH: 3, Z_FINISH: 4, Z_BLOCK: 5,
      Z_OK: 0, Z_STREAM_END: 1, Z_NEED_DICT: 2, Z_ERRNO: -1, Z_STREAM_ERROR: -2, Z_DATA_ERROR: -3, Z_MEM_ERROR: -4, Z_BUF_ERROR: -5, Z_VERSION_ERROR: -6,
      Z_NO_COMPRESSION: 0, Z_BEST_SPEED: 1, Z_BEST_COMPRESSION: 9, Z_DEFAULT_COMPRESSION: -1,
      Z_FILTERED: 1, Z_HUFFMAN_ONLY: 2, Z_RLE: 3, Z_FIXED: 4, Z_DEFAULT_STRATEGY: 0, ZLIB_VERNUM: 4880,
      DEFLATE: 1, INFLATE: 2, GZIP: 3, GUNZIP: 4, DEFLATERAW: 5, INFLATERAW: 6, UNZIP: 7,
      Z_MIN_WINDOWBITS: 8, Z_MAX_WINDOWBITS: 15, Z_DEFAULT_WINDOWBITS: 15, Z_MIN_CHUNK: 64, Z_MAX_CHUNK: Infinity, Z_DEFAULT_CHUNK: 16384,
      Z_MIN_MEMLEVEL: 1, Z_MAX_MEMLEVEL: 9, Z_DEFAULT_MEMLEVEL: 8, Z_MIN_LEVEL: -1, Z_MAX_LEVEL: 9, Z_DEFAULT_LEVEL: -1
    };
    var CODES = {};
    ['Z_OK', 'Z_STREAM_END', 'Z_NEED_DICT', 'Z_ERRNO', 'Z_STREAM_ERROR', 'Z_DATA_ERROR', 'Z_MEM_ERROR', 'Z_BUF_ERROR', 'Z_VERSION_ERROR'].forEach(function (k) {
      CODES[k] = CONST[k]; CODES[CONST[k]] = k;
    });
    var M_DEFLATE = 1, M_INFLATE = 2, M_GZIP = 3, M_GUNZIP = 4, M_DEFLATERAW = 5, M_INFLATERAW = 6, M_UNZIP = 7;
    var Z_FINISH = 4;

    // ---------------------------------------------------------------- errors and argument checks
    function zerr(errno, msg) { var e = new Error(msg); e.errno = errno; e.code = CODES[errno]; return e; }
    function eofErr() { return zerr(-5, 'unexpected end of file'); }
    function describe(v) {
      if (v === null || v === undefined) return String(v);
      if (typeof v === 'function') return 'function ' + v.name;
      if (typeof v === 'object') return 'an instance of ' + ((v.constructor && v.constructor.name) || 'Object');
      var s = typeof v === 'string' ? "'" + (v.length > 28 ? v.slice(0, 25) + '...' : v) + "'" : String(v);
      return 'type ' + typeof v + ' (' + s + ')';
    }
    function argError(name, expected, v) {
      var e = new TypeError('The "' + name + '" argument must be ' + expected + '. Received ' + describe(v));
      e.code = 'ERR_INVALID_ARG_TYPE';
      return e;
    }
    function input(v) {
      if (typeof v === 'string') return strToBytes(v, 'utf8');
      if (v instanceof Uint8Array) return v;
      if (v instanceof ArrayBuffer) return new Uint8Array(v);
      if (ArrayBuffer.isView(v)) return new Uint8Array(v.buffer, v.byteOffset, v.byteLength);
      throw argError('buffer', 'of type string or an instance of Buffer, TypedArray, DataView, or ArrayBuffer', v);
    }
    function wrap(u8) {
      if (u8.buffer.byteLength > 4096 && u8.length * 2 < u8.buffer.byteLength) { var c = new Buffer(u8.length); c.set(u8); return c; }
      return new Buffer(u8.buffer, u8.byteOffset, u8.length);
    }
    function concat(list, total) {
      if (list.length === 1) return list[0];
      var o = new Uint8Array(total), p = 0;
      for (var i = 0; i < list.length; i++) { o.set(list[i], p); p += list[i].length; }
      return o;
    }

    // ---------------------------------------------------------------- checksums
    var CRC_T = (function () {
      var t = new Int32Array(256);
      for (var n = 0; n < 256; n++) {
        var c = n;
        for (var k = 0; k < 8; k++) c = (c & 1) ? (-306674912 ^ (c >>> 1)) : (c >>> 1); // 0xEDB88320
        t[n] = c;
      }
      return t;
    })();
    function crc32(u8, prev, i, n) {
      var c = ~(prev | 0);
      if (i === undefined) i = 0;
      if (n === undefined) n = u8.length;
      for (; i < n; i++) c = CRC_T[(c ^ u8[i]) & 255] ^ (c >>> 8);
      return (~c) >>> 0;
    }
    function adler32(u8, i, n) {
      var a = 1, b = 0;
      while (i < n) {
        var e = Math.min(n, i + 5552);
        for (; i < e; i++) { a += u8[i]; b += a; }
        a %= 65521; b %= 65521;
      }
      return ((b << 16) | a) >>> 0;
    }

    // ---------------------------------------------------------------- inflate
    var LBASE = new Uint16Array([3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258]);
    var LEXT = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0]);
    var DBASE = new Uint16Array([1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577]);
    var DEXT = new Uint8Array([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13]);
    var CL_ORDER = new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);

    // Decoding table of a canonical Huffman code: index = the next `bits` input bits, entry = (symbol << 4) | code length (0 = no code).
    // kind: 0 = code-length code, 1 = literal/length code, 2 = distance code. Returns null for an over-subscribed or (like zlib)
    // incomplete code; the only incomplete code allowed is a lone 1-bit code, and a code with no symbols at all (valid for distances).
    function huff(lens, n, kind) {
      var count = new Uint16Array(16), i, sym;
      for (sym = 0; sym < n; sym++) count[lens[sym]]++;
      var max = 15;
      while (max >= 1 && count[max] === 0) max--;
      // No codes at all. For distances that is fine until a distance is needed. zlib quirk for the code-length code: every
      // 1-bit pattern then decodes as "length 0" (so such a block fails later, not here); mimic it to report the same errors.
      if (max === 0) return { t: kind === 0 ? new Uint16Array([1, 1]) : new Uint16Array(2), bits: 1 };
      var left = 1;
      for (i = 1; i <= 15; i++) { left = (left << 1) - count[i]; if (left < 0) return null; }
      if (left > 0 && (kind === 0 || max !== 1)) return null;
      count[0] = 0;
      var next = new Uint16Array(16), code = 0;
      for (i = 1; i <= 15; i++) { code = (code + count[i - 1]) << 1; next[i] = code; }
      var size = 1 << max, t = new Uint16Array(size);
      for (sym = 0; sym < n; sym++) {
        var len = lens[sym];
        if (!len) continue;
        var c = next[len]++, r = 0;
        for (i = 0; i < len; i++) { r = (r << 1) | (c & 1); c >>= 1; } // deflate packs Huffman codes most significant bit first
        var entry = (sym << 4) | len;
        for (i = r; i < size; i += 1 << len) t[i] = entry;
      }
      return { t: t, bits: max };
    }
    var fixedL = null, fixedD = null;
    function fixedTables() {
      if (fixedL) return;
      var l = new Uint8Array(288), d = new Uint8Array(32), i;
      for (i = 0; i < 144; i++) l[i] = 8;
      for (; i < 256; i++) l[i] = 9;
      for (; i < 280; i++) l[i] = 7;
      for (; i < 288; i++) l[i] = 8;
      for (i = 0; i < 32; i++) d[i] = 5;
      fixedL = huff(l, 288, 1); fixedD = huff(d, 32, 2);
    }
    function grow(out, used, need) {
      var c = out.length * 2;
      while (c < used + need) c *= 2;
      var o = new Uint8Array(c);
      o.set(out.subarray(0, used));
      return o;
    }

    // Decodes the raw deflate stream that starts at src[start]. `preset` is an optional dictionary, `hint` the expected output size.
    // Returns { out, base, end, pos, ended }: the data is out[base..end), pos is the input position behind the stream, and
    // ended is false when the input ran out first (the data decoded so far is still returned). Corrupt data throws.
    function inflateCore(src, start, preset, hint) {
      var n = src.length, p = start, bb = 0, bc = 0, eof = false, last = 0;
      var base = preset ? preset.length : 0;
      var cap = Math.min(Math.max(4096, hint > 0 ? hint : n * 4), 1 << 26) + base;
      var out = new Uint8Array(cap), op = base;
      var i, k, e, l, sym, eb, len, dist, from, type, lt, dt, lmask, dmask, ltab, dtab;
      if (base) out.set(preset);

      function refill() { while (bc <= 24 && p < n) { bb |= src[p++] << bc; bc += 8; } }
      function bits(cnt) {
        if (bc < cnt) { refill(); if (bc < cnt) { eof = true; return 0; } }
        var v = bb & ((1 << cnt) - 1);
        bb >>>= cnt; bc -= cnt;
        return v;
      }

      do {
        last = bits(1);
        type = bits(2);
        if (eof) break;
        if (type === 0) {
          // stored block: drop the rest of the current byte, give the look-ahead bytes back to the input, read LEN / NLEN
          p -= bc >> 3; bb = 0; bc = 0;
          if (p + 4 > n) { eof = true; break; }
          len = src[p] | (src[p + 1] << 8);
          if ((len ^ 0xffff) !== (src[p + 2] | (src[p + 3] << 8))) throw zerr(-3, 'invalid stored block lengths');
          p += 4;
          k = Math.min(len, n - p);
          if (op + k > out.length) out = grow(out, op, k);
          out.set(src.subarray(p, p + k), op);
          op += k; p += k;
          if (k < len) { eof = true; break; }
          continue;
        }
        if (type === 3) throw zerr(-3, 'invalid block type');
        if (type === 1) {
          fixedTables(); lt = fixedL; dt = fixedD;
        } else {
          var hlit = bits(5) + 257, hdist = bits(5) + 1, hclen = bits(4) + 4;
          if (eof) break;
          if (hlit > 286 || hdist > 30) throw zerr(-3, 'too many length or distance symbols');
          var cl = new Uint8Array(19);
          for (i = 0; i < hclen; i++) cl[CL_ORDER[i]] = bits(3);
          if (eof) break;
          var ct = huff(cl, 19, 0);
          if (!ct) throw zerr(-3, 'invalid code lengths set');
          var total = hlit + hdist, lens = new Uint8Array(total), cmask = (1 << ct.bits) - 1;
          k = 0;
          while (k < total) {
            if (bc < 15) refill();
            e = ct.t[bb & cmask]; l = e & 15;
            if (l === 0) throw zerr(-3, 'invalid code lengths set');
            if (l > bc) { eof = true; break; }
            bb >>>= l; bc -= l;
            sym = e >> 4;
            if (sym < 16) { lens[k++] = sym; continue; }
            var rep, val = 0;
            if (sym === 16) {
              if (k === 0) throw zerr(-3, 'invalid bit length repeat');
              val = lens[k - 1]; rep = 3 + bits(2);
            } else if (sym === 17) rep = 3 + bits(3);
            else rep = 11 + bits(7);
            if (eof) break;
            if (k + rep > total) throw zerr(-3, 'invalid bit length repeat');
            while (rep-- > 0) lens[k++] = val;
          }
          if (eof) break;
          if (lens[256] === 0) throw zerr(-3, 'invalid code -- missing end-of-block');
          lt = huff(lens.subarray(0, hlit), hlit, 1);
          if (!lt) throw zerr(-3, 'invalid literal/lengths set');
          dt = huff(lens.subarray(hlit), hdist, 2);
          if (!dt) throw zerr(-3, 'invalid distances set');
        }
        ltab = lt.t; lmask = (1 << lt.bits) - 1; dtab = dt.t; dmask = (1 << dt.bits) - 1;
        for (;;) {
          if (op + 258 > out.length) out = grow(out, op, 258);
          if (bc < 15) refill();
          e = ltab[bb & lmask]; l = e & 15;
          if (l === 0) throw zerr(-3, 'invalid literal/length code');
          if (l > bc) { eof = true; break; }
          bb >>>= l; bc -= l;
          sym = e >> 4;
          if (sym < 256) { out[op++] = sym; continue; }
          if (sym === 256) break;
          sym -= 257;
          if (sym >= 29) throw zerr(-3, 'invalid literal/length code');
          eb = LEXT[sym]; len = LBASE[sym];
          if (eb) {
            if (bc < eb) refill();
            if (bc < eb) { eof = true; break; }
            len += bb & ((1 << eb) - 1); bb >>>= eb; bc -= eb;
          }
          if (bc < 15) refill();
          e = dtab[bb & dmask]; l = e & 15;
          if (l === 0) throw zerr(-3, 'invalid distance code');
          if (l > bc) { eof = true; break; }
          bb >>>= l; bc -= l;
          sym = e >> 4;
          if (sym >= 30) throw zerr(-3, 'invalid distance code');
          eb = DEXT[sym]; dist = DBASE[sym];
          if (eb) {
            if (bc < eb) refill();
            if (bc < eb) { eof = true; break; }
            dist += bb & ((1 << eb) - 1); bb >>>= eb; bc -= eb;
          }
          if (dist > op) throw zerr(-3, 'invalid distance too far back');
          from = op - dist;
          for (i = 0; i < len; i++) out[op + i] = out[from + i]; // byte by byte on purpose: the source may overlap the destination
          op += len;
        }
      } while (!last && !eof);
      if (!eof) p -= bc >> 3;
      return { out: out, base: base, end: op, pos: p, ended: !eof };
    }

    // Container level: zlib / gzip / raw / auto-detect, with Node's checks. Returns a Buffer.
    function decode(mode, src, opts) {
      var finish = opts.finishFlush === undefined ? Z_FINISH : opts.finishFlush;
      var dict = opts.dictionary ? input(opts.dictionary) : null;
      var n = src.length, pos = 0, parts = [], total = 0, truncated = false, r, q, flg;
      if (mode === M_UNZIP) mode = (n >= 2 && src[0] === 0x1f && src[1] === 0x8b) ? M_GUNZIP : M_INFLATE;
      member: for (;;) {
        var hdr = pos, hint = 0;
        if (mode === M_INFLATE) {
          if (n - pos < 2) { truncated = true; break; }
          var cmf = src[pos], fl = src[pos + 1];
          if ((cmf * 256 + fl) % 31 !== 0) throw zerr(-3, 'incorrect header check');
          if ((cmf & 15) !== 8) throw zerr(-3, 'unknown compression method');
          if ((cmf >> 4) > 7) throw zerr(-3, 'invalid window size');
          pos += 2;
          if (fl & 0x20) {
            if (n - pos < 4) { truncated = true; break; }
            var did = ((src[pos] << 24) | (src[pos + 1] << 16) | (src[pos + 2] << 8) | src[pos + 3]) >>> 0;
            pos += 4;
            if (!dict) throw zerr(2, 'Missing dictionary');
            if (adler32(dict, 0, dict.length) !== did) throw zerr(2, 'Bad dictionary');
          }
        } else if (mode === M_GUNZIP) {
          // zlib validates while the bytes arrive: magic after 2 bytes, method + flags after 4, the rest after 10
          if (n - pos < 2) { truncated = true; break; }
          if (src[pos] !== 0x1f || src[pos + 1] !== 0x8b) throw zerr(-3, 'incorrect header check');
          if (n - pos < 4) { truncated = true; break; }
          if (src[pos + 2] !== 8) throw zerr(-3, 'unknown compression method');
          flg = src[pos + 3];
          if (flg & 0xe0) throw zerr(-3, 'unknown header flags set');
          if (n - pos < 10) { truncated = true; break; }
          q = pos + 10;
          if (flg & 4) {
            if (n - q < 2) { truncated = true; break; }
            q += 2 + (src[q] | (src[q + 1] << 8));
            if (q > n) { truncated = true; break; }
          }
          if (flg & 8) { while (q < n && src[q] !== 0) q++; if (q >= n) { truncated = true; break; } q++; }
          if (flg & 16) { while (q < n && src[q] !== 0) q++; if (q >= n) { truncated = true; break; } q++; }
          if (flg & 2) {
            if (n - q < 2) { truncated = true; break; }
            if ((crc32(src, 0, pos, q) & 0xffff) !== (src[q] | (src[q + 1] << 8))) throw zerr(-3, 'header crc mismatch');
            q += 2;
          }
          pos = q;
          if (n - pos >= 8 && hdr === 0) { // the ISIZE trailer of a single-member file tells the output size (a hint only)
            hint = (src[n - 4] | (src[n - 3] << 8) | (src[n - 2] << 16) | (src[n - 1] << 24)) >>> 0;
            if (hint > n * 64 || hint > (1 << 27)) hint = 0;
          }
        }
        r = inflateCore(src, pos, mode === M_INFLATE || mode === M_INFLATERAW ? dict : null, hint);
        if (!r.ended) {
          if (r.end > r.base) { parts.push(r.out.subarray(r.base, r.end)); total += r.end - r.base; }
          truncated = true; break;
        }
        pos = r.pos;
        if (mode === M_INFLATE) {
          if (n - pos < 4) { parts.push(r.out.subarray(r.base, r.end)); total += r.end - r.base; truncated = true; break; }
          var want = ((src[pos] << 24) | (src[pos + 1] << 16) | (src[pos + 2] << 8) | src[pos + 3]) >>> 0;
          if (adler32(r.out, r.base, r.end) !== want) throw zerr(-3, 'incorrect data check');
          pos += 4;
        } else if (mode === M_GUNZIP) {
          // the CRC is checked as soon as its 4 bytes are there, the length once the other 4 have arrived
          if (n - pos < 4) { parts.push(r.out.subarray(r.base, r.end)); total += r.end - r.base; truncated = true; break; }
          var wcrc = (src[pos] | (src[pos + 1] << 8) | (src[pos + 2] << 16) | (src[pos + 3] << 24)) >>> 0;
          if (crc32(r.out, 0, r.base, r.end) !== wcrc) throw zerr(-3, 'incorrect data check');
          if (n - pos < 8) { parts.push(r.out.subarray(r.base, r.end)); total += r.end - r.base; truncated = true; break; }
          var wlen = (src[pos + 4] | (src[pos + 5] << 8) | (src[pos + 6] << 16) | (src[pos + 7] << 24)) >>> 0;
          if (((r.end - r.base) >>> 0) !== wlen) throw zerr(-3, 'incorrect length check');
          pos += 8;
        }
        parts.push(r.out.subarray(r.base, r.end)); total += r.end - r.base;
        // like Node: after a gzip member more input is read as the next member unless it is zero padding
        if (mode === M_GUNZIP && pos < n && src[pos] !== 0) continue member;
        break;
      }
      if (truncated && finish === Z_FINISH) throw eofErr();
      return wrap(total ? concat(parts, total) : new Uint8Array(0));
    }

    // ---------------------------------------------------------------- deflate
    var FIX_CODE = null, FIX_LEN = null, LSYM = null, DSYM = null, REV5 = null;
    function revBits(v, len) { var r = 0; for (var i = 0; i < len; i++) { r = (r << 1) | (v & 1); v >>= 1; } return r; }
    function deflateTables() {
      if (FIX_CODE) return;
      var i, j, code, len;
      FIX_CODE = new Uint16Array(288); FIX_LEN = new Uint8Array(288);
      for (i = 0; i < 288; i++) {
        if (i < 144) { code = 0x30 + i; len = 8; }
        else if (i < 256) { code = 0x190 + i - 144; len = 9; }
        else if (i < 280) { code = i - 256; len = 7; }
        else { code = 0xc0 + i - 280; len = 8; }
        FIX_CODE[i] = revBits(code, len); FIX_LEN[i] = len;
      }
      LSYM = new Uint8Array(259);
      for (i = 0; i < 29; i++) {
        var hi = i === 28 ? 258 : LBASE[i] + (1 << LEXT[i]) - 1;
        for (j = LBASE[i]; j <= hi; j++) LSYM[j] = i;
      }
      DSYM = new Uint8Array(32769);
      for (i = 0; i < 30; i++) for (j = DBASE[i]; j < DBASE[i] + (1 << DEXT[i]); j++) DSYM[j] = i;
      REV5 = new Uint8Array(32);
      for (i = 0; i < 32; i++) REV5[i] = revBits(i, 5);
    }
    function storedSize(n) { return n + Math.max(1, Math.ceil(n / 65535)) * 5; }
    function deflateStored(src) {
      var n = src.length, nb = Math.max(1, Math.ceil(n / 65535)), out = new Uint8Array(storedSize(n)), op = 0, pos = 0;
      for (var b = 0; b < nb; b++) {
        var len = Math.min(65535, n - pos);
        out[op++] = b === nb - 1 ? 1 : 0;
        out[op++] = len & 255; out[op++] = len >> 8; out[op++] = ~len & 255; out[op++] = (~len >> 8) & 255;
        out.set(src.subarray(pos, pos + len), op);
        op += len; pos += len;
      }
      return out;
    }
    function deflateFixed(src, level) {
      deflateTables();
      var n = src.length;
      var chain = level <= 1 ? 4 : level <= 3 ? 8 : level <= 5 ? 16 : level === 6 ? 32 : level <= 8 ? 128 : 256;
      var out = new Uint8Array(n + (n >> 3) + 64), op = 0, acc = 0, nb = 0;
      function put(code, len) {
        acc |= code << nb; nb += len;
        while (nb >= 8) { out[op++] = acc & 255; acc >>>= 8; nb -= 8; }
      }
      var head = new Int32Array(32768), prev = new Int32Array(32768);
      head.fill(-1);
      put(1, 1); put(1, 2); // BFINAL = 1, BTYPE = 01 (fixed Huffman codes)
      var i = 0, j, h, cand, l, maxl, bestLen, bestDist, ch, sym, ds;
      while (i < n) {
        if (op + 16 > out.length) out = grow(out, op, 16);
        bestLen = 0; bestDist = 0;
        if (i + 2 < n) {
          h = ((src[i] << 10) ^ (src[i + 1] << 5) ^ src[i + 2]) & 32767;
          cand = head[h];
          maxl = n - i < 258 ? n - i : 258;
          ch = chain;
          while (cand >= 0 && i - cand <= 32768 && ch-- > 0) {
            if (src[cand + bestLen] === src[i + bestLen]) {
              l = 0;
              while (l < maxl && src[cand + l] === src[i + l]) l++;
              if (l > bestLen) { bestLen = l; bestDist = i - cand; if (l >= maxl) break; }
            }
            cand = prev[cand & 32767];
          }
        }
        if (bestLen >= 3) {
          sym = LSYM[bestLen];
          put(FIX_CODE[257 + sym], FIX_LEN[257 + sym]);
          if (LEXT[sym]) put(bestLen - LBASE[sym], LEXT[sym]);
          ds = DSYM[bestDist];
          put(REV5[ds], 5);
          if (DEXT[ds]) put(bestDist - DBASE[ds], DEXT[ds]);
          for (j = 0; j < bestLen; j++, i++) {
            if (i + 2 < n) { h = ((src[i] << 10) ^ (src[i + 1] << 5) ^ src[i + 2]) & 32767; prev[i & 32767] = head[h]; head[h] = i; }
          }
        } else {
          put(FIX_CODE[src[i]], FIX_LEN[src[i]]);
          if (i + 2 < n) { h = ((src[i] << 10) ^ (src[i + 1] << 5) ^ src[i + 2]) & 32767; prev[i & 32767] = head[h]; head[h] = i; }
          i++;
        }
      }
      put(FIX_CODE[256], FIX_LEN[256]);
      if (nb > 0) out[op++] = acc & 255;
      return out.subarray(0, op);
    }

    function encode(mode, src, opts) {
      var level = opts.level === undefined || opts.level === null ? -1 : opts.level;
      if (typeof level !== 'number' || level !== level || level < -1 || level > 9) {
        var re = new RangeError('The value of "options.level" is out of range. It must be >= -1 and <= 9. Received ' + String(level));
        re.code = 'ERR_OUT_OF_RANGE';
        throw re;
      }
      var lv = level === -1 ? 6 : Math.floor(level);
      var body = lv === 0 ? deflateStored(src) : deflateFixed(src, lv);
      if (lv !== 0 && body.length > storedSize(src.length)) body = deflateStored(src); // incompressible: never grow more than stored blocks do
      if (mode === M_DEFLATERAW) return wrap(body);
      var head, tail, dict = mode === M_DEFLATE && opts.dictionary ? input(opts.dictionary) : null;
      if (mode === M_DEFLATE) {
        var fl = ((lv < 2 ? 0 : lv < 6 ? 1 : lv === 6 ? 2 : 3) << 6) | (dict ? 0x20 : 0);
        fl += 31 - (((0x78 << 8) | fl) % 31);
        head = [0x78, fl];
        if (dict) { var d = adler32(dict, 0, dict.length); head.push(d >>> 24, (d >>> 16) & 255, (d >>> 8) & 255, d & 255); }
        var a = adler32(src, 0, src.length);
        tail = [a >>> 24, (a >>> 16) & 255, (a >>> 8) & 255, a & 255];
      } else {
        head = [0x1f, 0x8b, 8, 0, 0, 0, 0, 0, lv === 9 ? 2 : lv < 2 ? 4 : 0, 3];
        var c = crc32(src, 0), sz = src.length >>> 0;
        tail = [c & 255, (c >>> 8) & 255, (c >>> 16) & 255, c >>> 24, sz & 255, (sz >>> 8) & 255, (sz >>> 16) & 255, sz >>> 24];
      }
      var res = new Buffer(head.length + body.length + tail.length), i;
      for (i = 0; i < head.length; i++) res[i] = head[i];
      res.set(body, head.length);
      for (i = 0; i < tail.length; i++) res[head.length + body.length + i] = tail[i];
      return res;
    }

    // ---------------------------------------------------------------- public API
    var mod = { constants: CONST, codes: CODES };
    Object.keys(CONST).forEach(function (k) { if (/^Z_/.test(k)) mod[k] = CONST[k]; });
    mod.crc32 = function (data, value) {
      if (value === undefined) value = 0;
      if (typeof value !== 'number' || value !== value || value < 0 || value > 4294967295 || Math.floor(value) !== value) {
        var e = new RangeError('The value of "value" is out of range. It must be an integer >= 0 and <= 4294967295. Received ' + String(value));
        e.code = 'ERR_OUT_OF_RANGE';
        throw e;
      }
      if (typeof data !== 'string' && !(data instanceof Uint8Array) && !ArrayBuffer.isView(data)) throw argError('data', 'of type string or an instance of Buffer, TypedArray, or DataView', data);
      return crc32(input(data), value);
    };

    var KINDS = [['deflate', M_DEFLATE, encode], ['inflate', M_INFLATE, decode], ['gzip', M_GZIP, encode], ['gunzip', M_GUNZIP, decode],
      ['deflateRaw', M_DEFLATERAW, encode], ['inflateRaw', M_INFLATERAW, decode], ['unzip', M_UNZIP, decode]];
    KINDS.forEach(function (kd) {
      var mode = kd[1], fn = kd[2];
      mod[kd[0] + 'Sync'] = function (data, opts) { return fn(mode, input(data), opts || {}); };
      mod[kd[0]] = function (data, opts, cb) {
        if (typeof opts === 'function') { cb = opts; opts = {}; }
        var src = input(data);
        if (typeof cb !== 'function') throw argError('callback', 'of type function', cb);
        setTimeout(function () {
          var res, err = null;
          try { res = fn(mode, src, opts || {}); } catch (e) { err = e; }
          if (err) cb(err); else cb(null, res);
        }, 0);
      };
    });

    // Minimal buffering streams: everything written is processed when end() is called, then emitted as one 'data' chunk.
    function ZStream(mode, fn, opts) {
      EventEmitter.call(this);
      this._mode = mode; this._fn = fn; this._opts = opts || {}; this._chunks = []; this._size = 0; this._ended = false;
      this.bytesWritten = 0; this.readable = true; this.writable = true;
    }
    ZStream.prototype = Object.create(EventEmitter.prototype);
    ZStream.prototype.constructor = ZStream;
    ZStream.prototype.write = function (chunk, enc, cb) {
      if (typeof enc === 'function') { cb = enc; enc = undefined; }
      var self = this;
      if (this._ended) {
        var we = new Error('write after end'); we.code = 'ERR_STREAM_WRITE_AFTER_END';
        setTimeout(function () { self.emit('error', we); }, 0);
        return false;
      }
      var u8 = typeof chunk === 'string' ? strToBytes(chunk, enc || 'utf8') : input(chunk);
      this._chunks.push(new Uint8Array(u8)); this._size += u8.length; this.bytesWritten += u8.length;
      if (cb) setTimeout(cb, 0);
      return true;
    };
    ZStream.prototype.end = function (chunk, enc, cb) {
      if (typeof chunk === 'function') { cb = chunk; chunk = null; enc = undefined; }
      else if (typeof enc === 'function') { cb = enc; enc = undefined; }
      if (chunk !== undefined && chunk !== null) this.write(chunk, enc);
      if (this._ended) return this;
      this._ended = true;
      var self = this;
      setTimeout(function () {
        var res = null, err = null;
        try { res = self._fn(self._mode, concat(self._chunks.length ? self._chunks : [new Uint8Array(0)], self._size), self._opts); } catch (e) { err = e; }
        self._chunks = [];
        if (err) { self.emit('error', err); return; }
        if (res.length) self.emit('data', res);
        self.emit('finish'); self.emit('end'); self.emit('close');
        if (cb) cb();
      }, 0);
      return this;
    };
    ZStream.prototype.pipe = function (dest, o) {
      this.on('data', function (c) { if (dest && typeof dest.write === 'function') dest.write(c); });
      if (!o || o.end !== false) this.on('end', function () { if (dest && typeof dest.end === 'function') dest.end(); });
      return dest;
    };
    ZStream.prototype.flush = function (kind, cb) { if (typeof kind === 'function') cb = kind; if (typeof cb === 'function') setTimeout(cb, 0); };
    ZStream.prototype.params = function (level, strategy, cb) { if (typeof cb === 'function') setTimeout(cb, 0); };
    ZStream.prototype.reset = function () { this._chunks = []; this._size = 0; this._ended = false; };
    ZStream.prototype.close = ZStream.prototype.destroy = function (cb) {
      if (typeof cb === 'function') setTimeout(cb, 0);
      this._ended = true; this._chunks = [];
      return this;
    };
    ZStream.prototype.setEncoding = function () { return this; };
    [['Deflate', 'createDeflate', M_DEFLATE, encode], ['Inflate', 'createInflate', M_INFLATE, decode], ['Gzip', 'createGzip', M_GZIP, encode],
      ['Gunzip', 'createGunzip', M_GUNZIP, decode], ['DeflateRaw', 'createDeflateRaw', M_DEFLATERAW, encode],
      ['InflateRaw', 'createInflateRaw', M_INFLATERAW, decode], ['Unzip', 'createUnzip', M_UNZIP, decode]].forEach(function (kd) {
      mod[kd[0]] = function (o) { return new ZStream(kd[2], kd[3], o); };
      mod[kd[1]] = function (o) { return new ZStream(kd[2], kd[3], o); };
    });

    ['brotliCompress', 'brotliCompressSync', 'brotliDecompress', 'brotliDecompressSync', 'createBrotliCompress', 'createBrotliDecompress',
      'BrotliCompress', 'BrotliDecompress'].forEach(function (name) {
      mod[name] = function () {
        RR.warnOnce('zlib:' + name, 'zlib.' + name + ' is not available in RPG Runner (brotli is not implemented)');
        throw new Error('zlib.' + name + ' is not available in RPG Runner');
      };
    });
    mod._internals = { inflateCore: inflateCore, deflateFixed: deflateFixed, adler32: adler32, crc32: crc32 };
    return mod;
  })();

  // ------------------------------------------------------------------ crypto: hashes, HMAC, PBKDF2, random helpers
  // Node's crypto module needs OpenSSL. Here the parts games commonly use are written in JS: md5, sha1, sha224/256/384/512,
  // HMAC, PBKDF2 and the random helpers (the AES ciphers are in 27-crypto-aes.js). Signatures, key exchange and the other
  // ciphers are not available: calling them logs a warning (so the log shows what the game tried) and throws.
  (function () {
    var i, j;
    function rotl(x, n) { return (x << n) | (x >>> (32 - n)); }
    function rotr(x, n) { return (x >>> n) | (x << (32 - n)); }
    function be32(b, o) { return (b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]; }
    function putBe32(out, o, v) { out[o] = v >>> 24; out[o + 1] = v >>> 16; out[o + 2] = v >>> 8; out[o + 3] = v; }
    function putLe32(out, o, v) { out[o] = v; out[o + 1] = v >>> 8; out[o + 2] = v >>> 16; out[o + 3] = v >>> 24; }

    function describe(v) {
      if (v === null || v === undefined) return String(v);
      if (typeof v === 'function') return 'function ' + v.name;
      if (typeof v === 'object') return 'an instance of ' + ((v.constructor && v.constructor.name) || 'Object');
      var s = typeof v === 'string' ? "'" + (v.length > 28 ? v.slice(0, 25) + '...' : v) + "'" : String(v);
      return 'type ' + typeof v + ' (' + s + ')';
    }
    function codedError(Ctor, code, msg) { var e = new Ctor(msg); e.code = code; return e; }
    function argError(name, expected, v) { return codedError(TypeError, 'ERR_INVALID_ARG_TYPE', 'The "' + name + '" argument must be ' + expected + '. Received ' + describe(v)); }
    // string (with encoding) or any binary view -> Uint8Array without copying
    function bytesArg(v, enc, name, expected) {
      if (typeof v === 'string') return strToBytes(v, enc || 'utf8');
      if (v instanceof Uint8Array) return v;
      if (v instanceof ArrayBuffer) return new Uint8Array(v);
      if (ArrayBuffer.isView(v)) return new Uint8Array(v.buffer, v.byteOffset, v.byteLength);
      throw argError(name, expected, v);
    }
    function outBuf(u8, enc) {
      var b = new Buffer(u8.length);
      b.set(u8);
      return !enc || enc === 'buffer' ? b : bytesToStr(b, enc);
    }

    // ---------------------------------------------------------------- constants
    var primes = [];
    for (i = 2; primes.length < 80; i++) {
      var isPrime = true;
      for (j = 0; j < primes.length && primes[j] * primes[j] <= i; j++) if (i % primes[j] === 0) { isPrime = false; break; }
      if (isPrime) primes.push(i);
    }
    function frac32(x) { return Math.floor((x - Math.floor(x)) * 4294967296); }
    var MD5_R = new Uint8Array([7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
      4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21]);
    var MD5_K = new Int32Array(64);
    for (i = 0; i < 64; i++) MD5_K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296);
    var K256 = new Int32Array(64), H256 = new Int32Array(8);
    for (i = 0; i < 64; i++) K256[i] = frac32(Math.cbrt(primes[i]));
    for (i = 0; i < 8; i++) H256[i] = frac32(Math.sqrt(primes[i]));
    var H224 = new Int32Array([0xc1059ed8, 0x367cd507, 0x3070dd17, 0xf70e5939, 0xffc00b31, 0x68581511, 0x64f98fa7, 0xbefa4fa4]);
    // SHA-384/512 constants are 64-bit fractions of roots of the first primes: exact integer roots with BigInt, on first use
    var c512 = null;
    function sha512Constants() {
      if (c512) return c512;
      if (typeof BigInt !== 'function') throw new Error('sha384/sha512 need BigInt, which this WebView does not have');
      var B = BigInt, mask = (B(1) << B(64)) - B(1);
      function isqrt(n) {
        var x = B(1) << B((n.toString(2).length >> 1) + 1), y;
        for (;;) { y = (x + n / x) >> B(1); if (y >= x) return x; x = y; }
      }
      function icbrt(n) {
        var x = B(1) << B(Math.floor(n.toString(2).length / 3) + 1), y;
        for (;;) { y = (B(2) * x + n / (x * x)) / B(3); if (y >= x) return x; x = y; }
      }
      function pair(arr, k, v) { arr[2 * k] = Number(v >> B(32)) | 0; arr[2 * k + 1] = Number(v & B(4294967295)) | 0; }
      var K = new Int32Array(160), H512 = new Int32Array(16), H384 = new Int32Array(16), k;
      for (k = 0; k < 80; k++) pair(K, k, icbrt(B(primes[k]) << B(192)) & mask);
      for (k = 0; k < 8; k++) { pair(H512, k, isqrt(B(primes[k]) << B(128)) & mask); pair(H384, k, isqrt(B(primes[8 + k]) << B(128)) & mask); }
      c512 = { K: K, H512: H512, H384: H384 };
      return c512;
    }

    // ---------------------------------------------------------------- compression functions (state: Int32Array)
    var W16 = new Int32Array(16), W80 = new Int32Array(80), W64 = new Int32Array(64), W160 = new Int32Array(160);
    function md5Block(h, b, o) {
      var w = W16, a = h[0], bb = h[1], c = h[2], d = h[3], f, g, t, k;
      for (k = 0; k < 16; k++) w[k] = b[o + 4 * k] | (b[o + 4 * k + 1] << 8) | (b[o + 4 * k + 2] << 16) | (b[o + 4 * k + 3] << 24);
      for (k = 0; k < 64; k++) {
        if (k < 16) { f = (bb & c) | (~bb & d); g = k; }
        else if (k < 32) { f = (d & bb) | (~d & c); g = (5 * k + 1) & 15; }
        else if (k < 48) { f = bb ^ c ^ d; g = (3 * k + 5) & 15; }
        else { f = c ^ (bb | ~d); g = (7 * k) & 15; }
        t = d; d = c; c = bb;
        bb = (bb + rotl((a + f + MD5_K[k] + w[g]) | 0, MD5_R[k])) | 0;
        a = t;
      }
      h[0] = (h[0] + a) | 0; h[1] = (h[1] + bb) | 0; h[2] = (h[2] + c) | 0; h[3] = (h[3] + d) | 0;
    }
    function sha1Block(h, b, o) {
      var w = W80, a = h[0], bb = h[1], c = h[2], d = h[3], e = h[4], f, kk, t, k;
      for (k = 0; k < 16; k++) w[k] = be32(b, o + 4 * k);
      for (k = 16; k < 80; k++) w[k] = rotl(w[k - 3] ^ w[k - 8] ^ w[k - 14] ^ w[k - 16], 1);
      for (k = 0; k < 80; k++) {
        if (k < 20) { f = (bb & c) | (~bb & d); kk = 0x5a827999; }
        else if (k < 40) { f = bb ^ c ^ d; kk = 0x6ed9eba1; }
        else if (k < 60) { f = (bb & c) | (bb & d) | (c & d); kk = 0x8f1bbcdc | 0; }
        else { f = bb ^ c ^ d; kk = 0xca62c1d6 | 0; }
        t = (rotl(a, 5) + f + e + kk + w[k]) | 0;
        e = d; d = c; c = rotl(bb, 30); bb = a; a = t;
      }
      h[0] = (h[0] + a) | 0; h[1] = (h[1] + bb) | 0; h[2] = (h[2] + c) | 0; h[3] = (h[3] + d) | 0; h[4] = (h[4] + e) | 0;
    }
    function sha256Block(h, b, o) {
      var w = W64, a = h[0], bb = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7], k, x, y, t1, t2;
      for (k = 0; k < 16; k++) w[k] = be32(b, o + 4 * k);
      for (k = 16; k < 64; k++) {
        x = w[k - 15]; y = w[k - 2];
        w[k] = (w[k - 16] + (rotr(x, 7) ^ rotr(x, 18) ^ (x >>> 3)) + w[k - 7] + (rotr(y, 17) ^ rotr(y, 19) ^ (y >>> 10))) | 0;
      }
      for (k = 0; k < 64; k++) {
        t1 = (hh + (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) + ((e & f) ^ (~e & g)) + K256[k] + w[k]) | 0;
        t2 = ((rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) + ((a & bb) ^ (a & c) ^ (bb & c))) | 0;
        hh = g; g = f; f = e; e = (d + t1) | 0; d = c; c = bb; bb = a; a = (t1 + t2) | 0;
      }
      h[0] = (h[0] + a) | 0; h[1] = (h[1] + bb) | 0; h[2] = (h[2] + c) | 0; h[3] = (h[3] + d) | 0;
      h[4] = (h[4] + e) | 0; h[5] = (h[5] + f) | 0; h[6] = (h[6] + g) | 0; h[7] = (h[7] + hh) | 0;
    }
    // 64-bit words are kept as (high, low) pairs of int32; carries are added through doubles (all sums stay below 2^53)
    function sha512Block(h, b, o) {
      var W = W160, K = sha512Constants().K, k, lo;
      var xh, xl, yh, yl, s0h, s0l, s1h, s1l;
      for (k = 0; k < 32; k++) W[k] = be32(b, o + 4 * k);
      for (k = 16; k < 80; k++) {
        xh = W[2 * k - 30]; xl = W[2 * k - 29]; yh = W[2 * k - 4]; yl = W[2 * k - 3];
        s0h = ((xh >>> 1) | (xl << 31)) ^ ((xh >>> 8) | (xl << 24)) ^ (xh >>> 7);
        s0l = ((xl >>> 1) | (xh << 31)) ^ ((xl >>> 8) | (xh << 24)) ^ ((xl >>> 7) | (xh << 25));
        s1h = ((yh >>> 19) | (yl << 13)) ^ ((yl >>> 29) | (yh << 3)) ^ (yh >>> 6);
        s1l = ((yl >>> 19) | (yh << 13)) ^ ((yh >>> 29) | (yl << 3)) ^ ((yl >>> 6) | (yh << 26));
        lo = (W[2 * k - 31] >>> 0) + (s0l >>> 0) + (W[2 * k - 13] >>> 0) + (s1l >>> 0);
        W[2 * k + 1] = lo | 0;
        W[2 * k] = (W[2 * k - 32] + s0h + W[2 * k - 14] + s1h + Math.floor(lo / 4294967296)) | 0;
      }
      var ah = h[0], al = h[1], bh = h[2], bl = h[3], ch = h[4], cl = h[5], dh = h[6], dl = h[7];
      var eh = h[8], el = h[9], fh = h[10], fl = h[11], gh = h[12], gl = h[13], hh = h[14], hl = h[15];
      var S1h, S1l, chh, chl, t1h, t1l, S0h, S0l, mjh, mjl, t2h, t2l, l1, l2;
      for (k = 0; k < 80; k++) {
        S1h = ((eh >>> 14) | (el << 18)) ^ ((eh >>> 18) | (el << 14)) ^ ((el >>> 9) | (eh << 23));
        S1l = ((el >>> 14) | (eh << 18)) ^ ((el >>> 18) | (eh << 14)) ^ ((eh >>> 9) | (el << 23));
        chh = (eh & fh) ^ (~eh & gh); chl = (el & fl) ^ (~el & gl);
        l1 = (hl >>> 0) + (S1l >>> 0) + (chl >>> 0) + (K[2 * k + 1] >>> 0) + (W[2 * k + 1] >>> 0);
        t1l = l1 | 0;
        t1h = (hh + S1h + chh + K[2 * k] + W[2 * k] + Math.floor(l1 / 4294967296)) | 0;
        S0h = ((ah >>> 28) | (al << 4)) ^ ((al >>> 2) | (ah << 30)) ^ ((al >>> 7) | (ah << 25));
        S0l = ((al >>> 28) | (ah << 4)) ^ ((ah >>> 2) | (al << 30)) ^ ((ah >>> 7) | (al << 25));
        mjh = (ah & bh) ^ (ah & ch) ^ (bh & ch); mjl = (al & bl) ^ (al & cl) ^ (bl & cl);
        l2 = (S0l >>> 0) + (mjl >>> 0);
        t2l = l2 | 0;
        t2h = (S0h + mjh + Math.floor(l2 / 4294967296)) | 0;
        hh = gh; hl = gl; gh = fh; gl = fl; fh = eh; fl = el;
        l1 = (dl >>> 0) + (t1l >>> 0);
        el = l1 | 0; eh = (dh + t1h + Math.floor(l1 / 4294967296)) | 0;
        dh = ch; dl = cl; ch = bh; cl = bl; bh = ah; bl = al;
        l1 = (t1l >>> 0) + (t2l >>> 0);
        al = l1 | 0; ah = (t1h + t2h + Math.floor(l1 / 4294967296)) | 0;
      }
      var v = [ah, al, bh, bl, ch, cl, dh, dl, eh, el, fh, fl, gh, gl, hh, hl];
      for (k = 0; k < 8; k++) {
        lo = (h[2 * k + 1] >>> 0) + (v[2 * k + 1] >>> 0);
        h[2 * k + 1] = lo | 0;
        h[2 * k] = (h[2 * k] + v[2 * k] + Math.floor(lo / 4294967296)) | 0;
      }
    }

    function words(h, count, le) {
      var o = new Uint8Array(count * 4);
      for (var k = 0; k < count; k++) (le ? putLe32 : putBe32)(o, 4 * k, h[k]);
      return o;
    }
    var SPECS = {
      md5: { block: 64, lenBytes: 8, le: true, size: 16, init: function () { return new Int32Array([0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476]); }, compress: md5Block, out: function (h) { return words(h, 4, true); } },
      sha1: { block: 64, lenBytes: 8, le: false, size: 20, init: function () { return new Int32Array([0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0]); }, compress: sha1Block, out: function (h) { return words(h, 5, false); } },
      sha224: { block: 64, lenBytes: 8, le: false, size: 28, init: function () { return new Int32Array(H224); }, compress: sha256Block, out: function (h) { return words(h, 7, false); } },
      sha256: { block: 64, lenBytes: 8, le: false, size: 32, init: function () { return new Int32Array(H256); }, compress: sha256Block, out: function (h) { return words(h, 8, false); } },
      sha384: { block: 128, lenBytes: 16, le: false, size: 48, init: function () { return new Int32Array(sha512Constants().H384); }, compress: sha512Block, out: function (h) { return words(h, 12, false); } },
      sha512: { block: 128, lenBytes: 16, le: false, size: 64, init: function () { return new Int32Array(sha512Constants().H512); }, compress: sha512Block, out: function (h) { return words(h, 16, false); } }
    };
    function specOf(alg) {
      var a = String(alg).toLowerCase().replace(/^rsa-/, '');
      var m = /^sha(?:2-|-)?(\d+)$/.exec(a); // sha256, sha-256, sha2-256
      if (m) a = 'sha' + m[1];
      return Object.prototype.hasOwnProperty.call(SPECS, a) ? SPECS[a] : null;
    }

    // ---------------------------------------------------------------- streaming hasher, HMAC
    function Hasher(spec) { this.s = spec; this.h = spec.init(); this.buf = new Uint8Array(spec.block); this.n = 0; this.len = 0; }
    Hasher.prototype.update = function (u8) {
      var s = this.s, bs = s.block, k = 0, len = u8.length;
      this.len += len;
      if (this.n) {
        var take = Math.min(bs - this.n, len);
        this.buf.set(u8.subarray(0, take), this.n);
        this.n += take; k = take;
        if (this.n < bs) return;
        s.compress(this.h, this.buf, 0); this.n = 0;
      }
      for (; k + bs <= len; k += bs) s.compress(this.h, u8, k);
      if (k < len) { this.buf.set(u8.subarray(k), 0); this.n = len - k; }
    };
    Hasher.prototype.digest = function () {
      var s = this.s, bs = s.block, lb = s.lenBytes, total = this.len;
      var zeros = (bs - ((this.n + 1 + lb) % bs)) % bs, tail = new Uint8Array(1 + zeros + lb);
      tail[0] = 0x80;
      var hi = Math.floor(total / 536870912), lo = ((total % 536870912) * 8) >>> 0; // bit length = hi * 2^32 + lo
      var o = tail.length - 8;
      if (s.le) { putLe32(tail, o, lo); putLe32(tail, o + 4, hi); } else { putBe32(tail, o, hi); putBe32(tail, o + 4, lo); }
      this.update(tail);
      return s.out(this.h);
    };
    Hasher.prototype.clone = function () {
      var c = new Hasher(this.s);
      c.h = new Int32Array(this.h); c.buf.set(this.buf); c.n = this.n; c.len = this.len;
      return c;
    };
    function Hmac(spec, key) {
      var bs = spec.block, k = key, ipad = new Uint8Array(bs), opad = new Uint8Array(bs), x;
      if (k.length > bs) { var kh = new Hasher(spec); kh.update(k); k = kh.digest(); }
      for (x = 0; x < bs; x++) { var kb = x < k.length ? k[x] : 0; ipad[x] = kb ^ 0x36; opad[x] = kb ^ 0x5c; }
      this.spec = spec; this.inner = new Hasher(spec); this.inner.update(ipad); this.opad = opad;
    }
    Hmac.prototype.update = function (u8) { this.inner.update(u8); };
    Hmac.prototype.digest = function () {
      var d = this.inner.digest(), o = new Hasher(this.spec);
      o.update(this.opad); o.update(d);
      return o.digest();
    };
    Hmac.prototype.clone = function () {
      var c = Object.create(Hmac.prototype);
      c.spec = this.spec; c.inner = this.inner.clone(); c.opad = this.opad;
      return c;
    };

    function finalized() { return codedError(Error, 'ERR_CRYPTO_HASH_FINALIZED', 'Digest already called'); }
    var DATA_TYPES = 'of type string or an instance of Buffer, TypedArray, or DataView';
    // like in Node a Hash / Hmac is also a Transform stream: input.pipe(hash), hash.write() / end(), hash.read() gives the digest
    function Hash(h) { Transform.call(this); this._h = h; this._done = false; }
    util.inherits(Hash, Transform);
    Hash.prototype._transform = function (chunk, enc, cb) { try { this.update(chunk); } catch (e) { cb(e); return; } cb(); };
    Hash.prototype._flush = function (cb) { var d; try { d = this.digest(); } catch (e) { cb(e); return; } this.push(d); cb(); };
    Hash.prototype.update = function (data, enc) {
      if (this._done) throw finalized();
      this._h.update(bytesArg(data, enc, 'data', DATA_TYPES));
      return this;
    };
    Hash.prototype.digest = function (enc) {
      if (this._done) throw finalized();
      this._done = true;
      return outBuf(this._h.digest(), enc);
    };
    Hash.prototype.copy = function () {
      if (this._done) throw finalized();
      return new Hash(this._h.clone());
    };

    // ---------------------------------------------------------------- public API
    cryptoMod.createHash = function (alg) {
      var s = specOf(alg);
      if (!s) throw new Error('Digest method not supported');
      return new Hash(new Hasher(s));
    };
    cryptoMod.createHmac = function (alg, key) {
      var s = specOf(alg);
      if (!s) throw codedError(TypeError, 'ERR_CRYPTO_INVALID_DIGEST', 'Invalid digest: ' + alg);
      return new Hash(new Hmac(s, bytesArg(key, 'utf8', 'key', 'of type string or an instance of ArrayBuffer, Buffer, TypedArray, DataView, KeyObject, or CryptoKey')));
    };
    cryptoMod.getHashes = function () { return ['md5', 'sha1', 'sha224', 'sha256', 'sha384', 'sha512']; };
    cryptoMod.getCurves = function () { return []; };
    cryptoMod.pbkdf2Sync = function (password, salt, iterations, keylen, digest) {
      var pw = bytesArg(password, 'utf8', 'password', 'of type string or an instance of ArrayBuffer, Buffer, TypedArray, or DataView');
      var sl = bytesArg(salt, 'utf8', 'salt', 'of type string or an instance of ArrayBuffer, Buffer, TypedArray, or DataView');
      if (typeof iterations !== 'number') throw argError('iterations', 'of type number', iterations);
      if (typeof keylen !== 'number') throw argError('keylen', 'of type number', keylen);
      if (!(iterations >= 1) || Math.floor(iterations) !== iterations) throw codedError(RangeError, 'ERR_OUT_OF_RANGE', 'The value of "iterations" is out of range. It must be >= 1 && <= 2147483647. Received ' + iterations);
      if (!(keylen >= 0) || Math.floor(keylen) !== keylen) throw codedError(RangeError, 'ERR_OUT_OF_RANGE', 'The value of "keylen" is out of range. It must be >= 0 && <= 2147483647. Received ' + keylen);
      if (typeof digest !== 'string') throw argError('digest', 'of type string', digest);
      var s = specOf(digest);
      if (!s) throw codedError(TypeError, 'ERR_CRYPTO_INVALID_DIGEST', 'Invalid digest: ' + digest);
      var base = new Hmac(s, pw), out = new Uint8Array(keylen), blocks = Math.ceil(keylen / s.size), b, k, h, u, t, cnt = new Uint8Array(4);
      for (b = 1; b <= blocks; b++) {
        putBe32(cnt, 0, b);
        h = base.clone(); h.update(sl); h.update(cnt);
        u = h.digest(); t = new Uint8Array(u);
        for (j = 1; j < iterations; j++) {
          h = base.clone(); h.update(u); u = h.digest();
          for (k = 0; k < t.length; k++) t[k] ^= u[k];
        }
        out.set(t.subarray(0, Math.min(s.size, keylen - (b - 1) * s.size)), (b - 1) * s.size);
      }
      return outBuf(out);
    };
    cryptoMod.pbkdf2 = function (password, salt, iterations, keylen, digest, cb) {
      if (typeof cb !== 'function') throw argError('callback', 'of type function', cb);
      var res, err = null;
      try { res = cryptoMod.pbkdf2Sync(password, salt, iterations, keylen, digest); } catch (e) { err = e; }
      setTimeout(function () { if (err) cb(err); else cb(null, res); }, 0);
    };

    function fillRandom(u8) {
      var c = global.crypto;
      if (c && typeof c.getRandomValues === 'function') {
        for (var k = 0; k < u8.length; k += 65536) c.getRandomValues(u8.subarray(k, Math.min(u8.length, k + 65536))); // 64 KiB per call at most
      } else {
        for (var m = 0; m < u8.length; m++) u8[m] = Math.floor(Math.random() * 256);
      }
      return u8;
    }
    cryptoMod.randomBytes = function (n, cb) {
      if (typeof n !== 'number') throw argError('size', 'of type number', n);
      if (!(n >= 0 && n <= 2147483647) || Math.floor(n) !== n) throw codedError(RangeError, 'ERR_OUT_OF_RANGE', 'The value of "size" is out of range. It must be >= 0 && <= 2147483647. Received ' + n);
      var b = new Buffer(n);
      fillRandom(b);
      if (typeof cb === 'function') { setTimeout(function () { cb(null, b); }, 0); return undefined; }
      return b;
    };
    cryptoMod.randomFillSync = function (buf, offset, size) {
      var u = bytesArg(buf, undefined, 'buf', 'an instance of ArrayBuffer, Buffer, TypedArray, or DataView');
      offset = offset === undefined ? 0 : offset;
      size = size === undefined ? u.length - offset : size;
      if (!(offset >= 0 && offset <= u.length)) throw codedError(RangeError, 'ERR_OUT_OF_RANGE', 'The value of "offset" is out of range. It must be >= 0 && <= ' + u.length + '. Received ' + offset);
      if (!(size >= 0 && size <= u.length - offset)) throw codedError(RangeError, 'ERR_OUT_OF_RANGE', 'The value of "size" is out of range. It must be >= 0 && <= ' + (u.length - offset) + '. Received ' + size);
      fillRandom(u.subarray(offset, offset + size));
      return buf;
    };
    cryptoMod.randomFill = function (buf, offset, size, cb) {
      if (typeof offset === 'function') { cb = offset; offset = undefined; size = undefined; }
      else if (typeof size === 'function') { cb = size; size = undefined; }
      if (typeof cb !== 'function') throw argError('callback', 'of type function', cb);
      var err = null;
      try { cryptoMod.randomFillSync(buf, offset, size); } catch (e) { err = e; }
      setTimeout(function () { if (err) cb(err); else cb(null, buf); }, 0);
    };
    cryptoMod.randomInt = function (min, max, cb) {
      if (cb === undefined && typeof max === 'function') { cb = max; max = undefined; }
      if (max === undefined) { max = min; min = 0; }
      if (!Number.isSafeInteger(min)) throw argError('min', 'a safe integer', min);
      if (!Number.isSafeInteger(max)) throw argError('max', 'a safe integer', max);
      if (max <= min) throw codedError(RangeError, 'ERR_OUT_OF_RANGE', 'The value of "max" is out of range. It must be greater than the value of "min" (' + min + '). Received ' + max);
      var range = max - min;
      if (range > 281474976710655) throw codedError(RangeError, 'ERR_OUT_OF_RANGE', 'The value of "max - min" is out of range. It must be <= 281474976710655. Received ' + range);
      var limit = Math.floor(281474976710656 / range) * range, r, b;
      do { // rejection sampling over 48 random bits: every value in [min, max) is equally likely
        b = fillRandom(new Uint8Array(6));
        r = ((((b[0] * 256 + b[1]) * 256 + b[2]) * 256 + b[3]) * 256 + b[4]) * 256 + b[5];
      } while (r >= limit);
      var v = min + (r % range);
      if (typeof cb === 'function') { setTimeout(function () { cb(null, v); }, 0); return undefined; }
      return v;
    };
    cryptoMod.timingSafeEqual = function (a, b) {
      var x = bytesArg(a, undefined, 'buf1', 'an instance of ArrayBuffer, Buffer, TypedArray, or DataView'), y = bytesArg(b, undefined, 'buf2', 'an instance of ArrayBuffer, Buffer, TypedArray, or DataView');
      if (typeof a === 'string') throw argError('buf1', 'an instance of ArrayBuffer, Buffer, TypedArray, or DataView', a);
      if (typeof b === 'string') throw argError('buf2', 'an instance of ArrayBuffer, Buffer, TypedArray, or DataView', b);
      if (x.length !== y.length) throw codedError(RangeError, 'ERR_CRYPTO_TIMING_SAFE_EQUAL_LENGTH', 'Input buffers must have the same byte length');
      var d = 0;
      for (var k = 0; k < x.length; k++) d |= x[k] ^ y[k];
      return d === 0;
    };
    cryptoMod.getRandomValues = function (arr) { return global.crypto.getRandomValues(arr); };
    cryptoMod.webcrypto = global.crypto;
    cryptoMod.subtle = global.crypto && global.crypto.subtle;
    cryptoMod.constants = cryptoMod.constants || {};

    ['createSign', 'createVerify', 'createECDH', 'createDiffieHellman',
      'createDiffieHellmanGroup', 'scrypt', 'scryptSync', 'generateKeyPair', 'generateKeyPairSync', 'generateKey', 'generateKeySync',
      'publicEncrypt', 'privateDecrypt', 'privateEncrypt', 'publicDecrypt', 'sign', 'verify', 'hkdf', 'hkdfSync', 'createPrivateKey',
      'createPublicKey', 'createSecretKey', 'generatePrime', 'generatePrimeSync', 'checkPrime', 'checkPrimeSync'].forEach(function (name) {
      cryptoMod[name] = function () {
        RR.warnOnce('crypto:' + name, 'crypto.' + name + ' is not available in RPG Runner (only hashes, HMAC, PBKDF2, random numbers and AES ciphers are)');
        throw new Error('crypto.' + name + ' is not available in RPG Runner');
      };
    });
  })();
  // ------------------------------------------------------------------ crypto: AES ciphers (cbc, ecb, ctr)
  // createCipheriv / createDecipheriv (and the legacy password based createCipher / createDecipher) for aes-128/192/256 in the
  // modes cbc, ecb and ctr, written in JS because Node's OpenSSL is not available. Block handling, padding rules, error
  // messages and the update()/final() state machine follow OpenSSL 3 as Node 22 reports it. Other ciphers (gcm, cfb, des ...)
  // log what the game asked for and throw.
  (function () {
    var SBOX = new Uint8Array(256), ISBOX = new Uint8Array(256);
    var TE0 = new Int32Array(256), TE1 = new Int32Array(256), TE2 = new Int32Array(256), TE3 = new Int32Array(256);
    var TD0 = new Int32Array(256), TD1 = new Int32Array(256), TD2 = new Int32Array(256), TD3 = new Int32Array(256);
    var tablesReady = false;

    function precompute() {
      var d = [], th = [], i, k, x, x2 = 0, x4, x8, xInv, s, tEnc, tDec, te = [TE0, TE1, TE2, TE3], td = [TD0, TD1, TD2, TD3];
      for (i = 0; i < 256; i++) th[(d[i] = (i << 1) ^ ((i >> 7) * 283)) ^ i] = i;
      for (i = 0, x = 0, xInv = 0; i < 256; i++, x ^= x2 || 1, xInv = th[xInv] || 1) {
        s = xInv ^ (xInv << 1) ^ (xInv << 2) ^ (xInv << 3) ^ (xInv << 4);
        s = (s >> 8) ^ (s & 255) ^ 99;
        SBOX[x] = s; ISBOX[s] = x;
        x8 = d[x4 = d[x2 = d[x]]];
        tDec = x8 * 0x1010101 ^ x4 * 0x10001 ^ x2 * 0x101 ^ x * 0x1010100;
        tEnc = d[s] * 0x101 ^ s * 0x1010100;
        for (k = 0; k < 4; k++) {
          te[k][x] = tEnc = (tEnc << 24) ^ (tEnc >>> 8);
          td[k][s] = tDec = (tDec << 24) ^ (tDec >>> 8);
        }
      }
      tablesReady = true;
    }

    // key: 16 / 24 / 32 bytes -> round keys for encryption and for the equivalent inverse cipher
    function expandKey(key) {
      if (!tablesReady) precompute();
      var kl = key.length >> 2, total = 4 * kl + 28, ek = new Int32Array(total), dk = new Int32Array(total), i, j, tmp, rcon = 1;
      for (i = 0; i < kl; i++) ek[i] = (key[4 * i] << 24) | (key[4 * i + 1] << 16) | (key[4 * i + 2] << 8) | key[4 * i + 3];
      for (i = kl; i < total; i++) {
        tmp = ek[i - 1];
        if (i % kl === 0 || (kl === 8 && i % kl === 4)) {
          tmp = (SBOX[tmp >>> 24] << 24) ^ (SBOX[(tmp >> 16) & 255] << 16) ^ (SBOX[(tmp >> 8) & 255] << 8) ^ SBOX[tmp & 255];
          if (i % kl === 0) { tmp = (tmp << 8) ^ (tmp >>> 24) ^ (rcon << 24); rcon = (rcon << 1) ^ ((rcon >> 7) * 283); }
        }
        ek[i] = ek[i - kl] ^ tmp;
      }
      for (j = 0, i = total; i; j++, i--) {
        tmp = ek[j & 3 ? i : i - 4];
        dk[j] = (i <= 4 || j < 4) ? tmp : TD0[SBOX[tmp >>> 24]] ^ TD1[SBOX[(tmp >> 16) & 255]] ^ TD2[SBOX[(tmp >> 8) & 255]] ^ TD3[SBOX[tmp & 255]];
      }
      return { enc: ek, dec: dk };
    }

    // one 16-byte block, src[so..so+16) -> dst[doff..doff+16); src and dst may be the same array
    function encBlock(rk, src, so, dst, doff) {
      var a = ((src[so] << 24) | (src[so + 1] << 16) | (src[so + 2] << 8) | src[so + 3]) ^ rk[0],
        b = ((src[so + 4] << 24) | (src[so + 5] << 16) | (src[so + 6] << 8) | src[so + 7]) ^ rk[1],
        c = ((src[so + 8] << 24) | (src[so + 9] << 16) | (src[so + 10] << 8) | src[so + 11]) ^ rk[2],
        d = ((src[so + 12] << 24) | (src[so + 13] << 16) | (src[so + 14] << 8) | src[so + 15]) ^ rk[3],
        a2, b2, c2, k = 4, n = (rk.length >> 2) - 2, i, o0, o1, o2, o3;
      for (i = 0; i < n; i++) {
        a2 = TE0[a >>> 24] ^ TE1[(b >> 16) & 255] ^ TE2[(c >> 8) & 255] ^ TE3[d & 255] ^ rk[k];
        b2 = TE0[b >>> 24] ^ TE1[(c >> 16) & 255] ^ TE2[(d >> 8) & 255] ^ TE3[a & 255] ^ rk[k + 1];
        c2 = TE0[c >>> 24] ^ TE1[(d >> 16) & 255] ^ TE2[(a >> 8) & 255] ^ TE3[b & 255] ^ rk[k + 2];
        d = TE0[d >>> 24] ^ TE1[(a >> 16) & 255] ^ TE2[(b >> 8) & 255] ^ TE3[c & 255] ^ rk[k + 3];
        k += 4; a = a2; b = b2; c = c2;
      }
      o0 = ((SBOX[a >>> 24] << 24) ^ (SBOX[(b >> 16) & 255] << 16) ^ (SBOX[(c >> 8) & 255] << 8) ^ SBOX[d & 255]) ^ rk[k];
      o1 = ((SBOX[b >>> 24] << 24) ^ (SBOX[(c >> 16) & 255] << 16) ^ (SBOX[(d >> 8) & 255] << 8) ^ SBOX[a & 255]) ^ rk[k + 1];
      o2 = ((SBOX[c >>> 24] << 24) ^ (SBOX[(d >> 16) & 255] << 16) ^ (SBOX[(a >> 8) & 255] << 8) ^ SBOX[b & 255]) ^ rk[k + 2];
      o3 = ((SBOX[d >>> 24] << 24) ^ (SBOX[(a >> 16) & 255] << 16) ^ (SBOX[(b >> 8) & 255] << 8) ^ SBOX[c & 255]) ^ rk[k + 3];
      dst[doff] = o0 >>> 24; dst[doff + 1] = o0 >>> 16; dst[doff + 2] = o0 >>> 8; dst[doff + 3] = o0;
      dst[doff + 4] = o1 >>> 24; dst[doff + 5] = o1 >>> 16; dst[doff + 6] = o1 >>> 8; dst[doff + 7] = o1;
      dst[doff + 8] = o2 >>> 24; dst[doff + 9] = o2 >>> 16; dst[doff + 10] = o2 >>> 8; dst[doff + 11] = o2;
      dst[doff + 12] = o3 >>> 24; dst[doff + 13] = o3 >>> 16; dst[doff + 14] = o3 >>> 8; dst[doff + 15] = o3;
    }
    function decBlock(rk, src, so, dst, doff) {
      var a = ((src[so] << 24) | (src[so + 1] << 16) | (src[so + 2] << 8) | src[so + 3]) ^ rk[0],
        b = ((src[so + 12] << 24) | (src[so + 13] << 16) | (src[so + 14] << 8) | src[so + 15]) ^ rk[1],
        c = ((src[so + 8] << 24) | (src[so + 9] << 16) | (src[so + 10] << 8) | src[so + 11]) ^ rk[2],
        d = ((src[so + 4] << 24) | (src[so + 5] << 16) | (src[so + 6] << 8) | src[so + 7]) ^ rk[3],
        a2, b2, c2, k = 4, n = (rk.length >> 2) - 2, i, o0, o1, o2, o3;
      for (i = 0; i < n; i++) {
        a2 = TD0[a >>> 24] ^ TD1[(b >> 16) & 255] ^ TD2[(c >> 8) & 255] ^ TD3[d & 255] ^ rk[k];
        b2 = TD0[b >>> 24] ^ TD1[(c >> 16) & 255] ^ TD2[(d >> 8) & 255] ^ TD3[a & 255] ^ rk[k + 1];
        c2 = TD0[c >>> 24] ^ TD1[(d >> 16) & 255] ^ TD2[(a >> 8) & 255] ^ TD3[b & 255] ^ rk[k + 2];
        d = TD0[d >>> 24] ^ TD1[(a >> 16) & 255] ^ TD2[(b >> 8) & 255] ^ TD3[c & 255] ^ rk[k + 3];
        k += 4; a = a2; b = b2; c = c2;
      }
      o0 = ((ISBOX[a >>> 24] << 24) ^ (ISBOX[(b >> 16) & 255] << 16) ^ (ISBOX[(c >> 8) & 255] << 8) ^ ISBOX[d & 255]) ^ rk[k];
      o3 = ((ISBOX[b >>> 24] << 24) ^ (ISBOX[(c >> 16) & 255] << 16) ^ (ISBOX[(d >> 8) & 255] << 8) ^ ISBOX[a & 255]) ^ rk[k + 1];
      o2 = ((ISBOX[c >>> 24] << 24) ^ (ISBOX[(d >> 16) & 255] << 16) ^ (ISBOX[(a >> 8) & 255] << 8) ^ ISBOX[b & 255]) ^ rk[k + 2];
      o1 = ((ISBOX[d >>> 24] << 24) ^ (ISBOX[(a >> 16) & 255] << 16) ^ (ISBOX[(b >> 8) & 255] << 8) ^ ISBOX[c & 255]) ^ rk[k + 3];
      dst[doff] = o0 >>> 24; dst[doff + 1] = o0 >>> 16; dst[doff + 2] = o0 >>> 8; dst[doff + 3] = o0;
      dst[doff + 4] = o1 >>> 24; dst[doff + 5] = o1 >>> 16; dst[doff + 6] = o1 >>> 8; dst[doff + 7] = o1;
      dst[doff + 8] = o2 >>> 24; dst[doff + 9] = o2 >>> 16; dst[doff + 10] = o2 >>> 8; dst[doff + 11] = o2;
      dst[doff + 12] = o3 >>> 24; dst[doff + 13] = o3 >>> 16; dst[doff + 14] = o3 >>> 8; dst[doff + 15] = o3;
    }

    // ---------------------------------------------------------------- errors (OpenSSL 3 wording, as Node 22 reports them)
    function codedError(Ctor, code, msg) { var e = new Ctor(msg); if (code) e.code = code; return e; }
    function ossl(reason, hex) {
      var e = new Error('error:' + hex + ':Provider routines::' + reason);
      e.library = 'Provider routines'; e.reason = reason;
      e.code = 'ERR_OSSL_' + reason.toUpperCase().replace(/ /g, '_');
      return e;
    }
    function describeArg(v) {
      if (v === null || v === undefined) return String(v);
      if (typeof v === 'function') return 'function ' + v.name;
      if (typeof v === 'object') return 'an instance of ' + ((v.constructor && v.constructor.name) || 'Object');
      var s = typeof v === 'string' ? "'" + (v.length > 28 ? v.slice(0, 25) + '...' : v) + "'" : String(v);
      return 'type ' + typeof v + ' (' + s + ')';
    }
    function argType(name, expected, v) {
      return codedError(TypeError, 'ERR_INVALID_ARG_TYPE', 'The "' + name + '" argument must be ' + expected + '. Received ' + describeArg(v));
    }
    function toU8(v, enc) {
      if (typeof v === 'string') { var e = normEnc(enc); try { return strToBytes(v, Buffer.isEncoding(e) ? e : 'utf8'); } catch (x) { return strToBytes(v, 'utf8'); } }
      if (v instanceof Uint8Array) return v;
      if (v instanceof ArrayBuffer) return new Uint8Array(v);
      if (ArrayBuffer.isView(v)) return new Uint8Array(v.buffer, v.byteOffset, v.byteLength);
      return null;
    }

    // ---------------------------------------------------------------- the cipher engine (one EVP context)
    function Engine(decrypt, mode, key, iv) {
      var ks = expandKey(key);
      this.dec = decrypt; this.mode = mode;
      this.rk = decrypt && mode !== 'ctr' ? ks.dec : ks.enc;
      this.iv = iv && iv.length ? new Uint8Array(iv) : null; // chaining value (cbc) or counter (ctr)
      this.pad = true;
      this.buf = new Uint8Array(16); this.bufLen = 0;        // pending input (cbc / ecb); a decrypting padded engine holds a whole block back
      this.ks = new Uint8Array(16); this.ksPos = 16;         // ctr key stream
      this.tmp = new Uint8Array(16);
    }
    // whole blocks, src[so .. so+n) -> dst[doff ..]
    Engine.prototype.blocks = function (src, so, n, dst, doff) {
      var rk = this.rk, iv = this.iv, tmp = this.tmp, j, end = so + n;
      if (this.mode === 'ecb') {
        for (; so < end; so += 16, doff += 16) { if (this.dec) decBlock(rk, src, so, dst, doff); else encBlock(rk, src, so, dst, doff); }
      } else if (this.dec) { // cbc decrypt
        for (; so < end; so += 16, doff += 16) {
          for (j = 0; j < 16; j++) tmp[j] = src[so + j];
          decBlock(rk, src, so, dst, doff);
          for (j = 0; j < 16; j++) { dst[doff + j] ^= iv[j]; iv[j] = tmp[j]; }
        }
      } else { // cbc encrypt
        for (; so < end; so += 16, doff += 16) {
          for (j = 0; j < 16; j++) tmp[j] = src[so + j] ^ iv[j];
          encBlock(rk, tmp, 0, dst, doff);
          for (j = 0; j < 16; j++) iv[j] = dst[doff + j];
        }
      }
    };
    Engine.prototype.ctr = function (data) {
      var out = Buffer.alloc(data.length), ks = this.ks, iv = this.iv, rk = this.rk, pos = this.ksPos, i, j;
      for (i = 0; i < data.length; i++) {
        if (pos === 16) {
          encBlock(rk, iv, 0, ks, 0);
          for (j = 15; j >= 0; j--) { iv[j] = (iv[j] + 1) & 255; if (iv[j]) break; } // 128 bit big-endian counter
          pos = 0;
        }
        out[i] = data[i] ^ ks[pos++];
      }
      this.ksPos = pos;
      return out;
    };
    // OpenSSL's generic block update: a decrypting padded engine keeps the last whole block until it knows whether more follows
    Engine.prototype.update = function (data) {
      if (this.mode === 'ctr') return this.ctr(data);
      var enc = !this.dec, pad = this.pad, buf = this.buf, inPos = 0, inl = data.length, outLen = 0, parts = [], take, nextBlocks, blk, o;
      if (this.bufLen) {
        take = Math.min(16 - this.bufLen, inl);
        buf.set(data.subarray(0, take), this.bufLen);
        this.bufLen += take; inPos = take; inl -= take;
      }
      nextBlocks = inl - (inl % 16);
      if (this.bufLen === 16 && (enc || inl > 0 || !pad)) {
        o = Buffer.alloc(16); this.blocks(buf, 0, 16, o, 0); parts.push(o); outLen += 16; this.bufLen = 0;
      }
      if (nextBlocks > 0) {
        if (!enc && pad && nextBlocks === inl) nextBlocks -= 16;
        if (nextBlocks > 0) {
          o = Buffer.alloc(nextBlocks); this.blocks(data, inPos, nextBlocks, o, 0); parts.push(o); outLen += nextBlocks;
          inPos += nextBlocks; inl -= nextBlocks;
        }
      }
      if (inl > 0) { buf.set(data.subarray(inPos, inPos + inl), this.bufLen); this.bufLen += inl; }
      if (parts.length === 1) return parts[0];
      blk = Buffer.alloc(outLen);
      for (var p = 0, at = 0; p < parts.length; p++) { blk.set(parts[p], at); at += parts[p].length; }
      return blk;
    };
    Engine.prototype.final = function () {
      var buf = this.buf, n = this.bufLen, o, padv, i;
      if (this.mode === 'ctr') return Buffer.alloc(0);
      if (!this.dec) {
        if (this.pad) { padv = 16 - n; for (i = n; i < 16; i++) buf[i] = padv; }
        else if (n === 0) return Buffer.alloc(0);
        else if (n !== 16) throw ossl('wrong final block length', '1C80006B');
        o = Buffer.alloc(16); this.blocks(buf, 0, 16, o, 0); this.bufLen = 0;
        return o;
      }
      if (n !== 16) {
        if (n === 0 && !this.pad) return Buffer.alloc(0);
        throw ossl('wrong final block length', '1C80006B');
      }
      o = Buffer.alloc(16); this.blocks(buf, 0, 16, o, 0); this.bufLen = 0;
      if (!this.pad) return o;
      padv = o[15];
      if (padv === 0 || padv > 16) throw ossl('bad decrypt', '1C800064');
      for (i = 16 - padv; i < 16; i++) if (o[i] !== padv) throw ossl('bad decrypt', '1C800064');
      return o.slice(0, 16 - padv);
    };

    // ---------------------------------------------------------------- Node's Cipheriv / Decipheriv
    function CipherBase(engine) { Transform.call(this); this._e = engine; this._state = 0; this._decoder = null; }
    util.inherits(CipherBase, Transform);
    function Cipheriv(engine) { CipherBase.call(this, engine); }
    util.inherits(Cipheriv, CipherBase);
    function Decipheriv(engine) { CipherBase.call(this, engine); }
    util.inherits(Decipheriv, CipherBase);

    CipherBase.prototype.update = function (data, inputEncoding, outputEncoding) {
      var u, enc, out;
      if (typeof data === 'string') {
        enc = !inputEncoding || inputEncoding === 'buffer' ? 'utf8' : inputEncoding;
        if (normEnc(enc) === 'hex' && data.length % 2 !== 0) {
          throw codedError(TypeError, 'ERR_INVALID_ARG_VALUE', "The argument 'encoding' is invalid for data of length " + data.length + ". Received '" + inputEncoding + "'");
        }
        u = toU8(data, enc);
      } else if (ArrayBuffer.isView(data)) {
        u = toU8(data);
      } else {
        throw argType('data', 'of type string or an instance of Buffer, TypedArray, or DataView', data);
      }
      if (this._state) throw new Error('Trying to add data in unsupported state');
      out = this._e.update(u);
      if (outputEncoding && outputEncoding !== 'buffer') {
        this._decoder = this._decoder || new StringDecoder(outputEncoding);
        return this._decoder.write(out);
      }
      return out;
    };
    CipherBase.prototype.final = function (outputEncoding) {
      var out;
      if (this._state) throw codedError(Error, 'ERR_CRYPTO_INVALID_STATE', 'Invalid state');
      this._state = 1; // like Node, the context is gone after final(), even when it failed
      out = this._e.final();
      if (outputEncoding && outputEncoding !== 'buffer') {
        this._decoder = this._decoder || new StringDecoder(outputEncoding);
        return this._decoder.end(out);
      }
      return out;
    };
    CipherBase.prototype.setAutoPadding = function (ap) {
      if (this._state) throw codedError(Error, 'ERR_CRYPTO_INVALID_STATE', 'Invalid state for operation setAutoPadding');
      this._e.pad = !!ap; // like Node 22: no argument means false
      return this;
    };
    CipherBase.prototype._transform = function (chunk, enc, cb) {
      var out;
      try { out = this._e.update(toU8(chunk, enc) || chunk); } catch (e) { cb(e); return; }
      if (out.length) this.push(out);
      cb();
    };
    CipherBase.prototype._flush = function (cb) {
      var out;
      try { this._state = 1; out = this._e.final(); } catch (e) { cb(e); return; }
      if (out.length) this.push(out);
      cb();
    };

    // ---------------------------------------------------------------- algorithm names, factory functions
    var KNOWN_UNSUPPORTED = /^(aes-(128|192|256)-(cfb|cfb1|cfb8|ofb|gcm|ccm|ocb|xts|wrap|cts)|aes-(128|256)-xts|des|des3|des-|bf|blowfish|rc2|rc4|chacha20|camellia|aria|seed|sm4|cast|idea|id-)/i;
    function parseAlgorithm(name) {
      var lower = name.toLowerCase(), m = /^aes-(128|192|256)-(cbc|ecb|ctr)$/.exec(lower), a = /^aes(128|192|256)$/.exec(lower);
      if (m) return { keyLen: m[1] / 8, mode: m[2] };
      if (a) return { keyLen: a[1] / 8, mode: 'cbc' };
      if (KNOWN_UNSUPPORTED.test(lower)) {
        RR.warnOnce('crypto:cipher:' + lower, 'crypto cipher "' + name + '" is not available in RPG Runner (only aes-128/192/256 in the modes cbc, ecb and ctr are)');
        throw new Error('Cipher "' + name + '" is not available in RPG Runner');
      }
      throw codedError(Error, 'ERR_CRYPTO_UNKNOWN_CIPHER', 'Unknown cipher');
    }
    var KEY_TYPES = 'of type string or an instance of ArrayBuffer, Buffer, TypedArray, DataView, KeyObject, or CryptoKey';
    function makeCipher(decrypt, algorithm, key, iv, options) {
      var k, v = null, alg, enc = options && typeof options === 'object' ? options.encoding : undefined;
      if (typeof algorithm !== 'string') throw argType('cipher', 'of type string', algorithm);
      k = toU8(key, enc);
      if (!k) throw argType('key', KEY_TYPES, key);
      if (iv !== null) {
        v = toU8(iv, undefined);
        if (!v) throw argType('iv', 'of type string or an instance of ArrayBuffer, Buffer, TypedArray, or DataView', iv);
      }
      alg = parseAlgorithm(algorithm);
      if (alg.mode === 'ecb' ? (v && v.length) : (!v || v.length !== 16)) throw codedError(TypeError, 'ERR_CRYPTO_INVALID_IV', 'Invalid initialization vector');
      if (k.length !== alg.keyLen) throw codedError(RangeError, 'ERR_CRYPTO_INVALID_KEYLEN', 'Invalid key length');
      var engine = new Engine(decrypt, alg.mode, k, v);
      return decrypt ? new Decipheriv(engine) : new Cipheriv(engine);
    }
    cryptoMod.createCipheriv = function (algorithm, key, iv, options) { return makeCipher(false, algorithm, key, iv, options); };
    cryptoMod.createDecipheriv = function (algorithm, key, iv, options) { return makeCipher(true, algorithm, key, iv, options); };

    // legacy createCipher / createDecipher: key and IV from the password with OpenSSL's EVP_BytesToKey (md5, no salt, 1 round)
    function bytesToKey(password, keyLen, ivLen) {
      var out = new Uint8Array(keyLen + ivLen), have = 0, prev = new Uint8Array(0), h, d;
      while (have < out.length) {
        h = cryptoMod.createHash('md5');
        h.update(prev); h.update(password);
        d = h.digest();
        out.set(d.subarray(0, Math.min(d.length, out.length - have)), have);
        have += d.length; prev = d;
      }
      return { key: out.subarray(0, keyLen), iv: out.subarray(keyLen) };
    }
    function makeLegacy(decrypt, algorithm, password, options) {
      var pw, alg, kd;
      if (typeof algorithm !== 'string') throw argType('cipher', 'of type string', algorithm);
      pw = toU8(password, undefined);
      if (!pw) throw argType('password', 'of type string or an instance of ArrayBuffer, Buffer, TypedArray, or DataView', password);
      alg = parseAlgorithm(algorithm);
      kd = bytesToKey(pw, alg.keyLen, alg.mode === 'ecb' ? 0 : 16);
      var engine = new Engine(decrypt, alg.mode, kd.key, alg.mode === 'ecb' ? null : kd.iv);
      return decrypt ? new Decipheriv(engine) : new Cipheriv(engine);
    }
    cryptoMod.createCipher = function (algorithm, password, options) { return makeLegacy(false, algorithm, password, options); };
    cryptoMod.createDecipher = function (algorithm, password, options) { return makeLegacy(true, algorithm, password, options); };
    cryptoMod.Cipheriv = Cipheriv;
    cryptoMod.Decipheriv = Decipheriv;
    cryptoMod.getCiphers = function () {
      return ['aes-128-cbc', 'aes-128-ctr', 'aes-128-ecb', 'aes-192-cbc', 'aes-192-ctr', 'aes-192-ecb', 'aes-256-cbc', 'aes-256-ctr', 'aes-256-ecb', 'aes128', 'aes192', 'aes256'];
    };
    // for the tests: the raw block functions
    cryptoMod._aesBlock = function (key, block, decrypt) {
      var ks = expandKey(key), out = new Uint8Array(16);
      (decrypt ? decBlock : encBlock)(decrypt ? ks.dec : ks.enc, block, 0, out, 0);
      return out;
    };
  })();

  // ------------------------------------------------------------------ stand-ins for modules that cannot exist on Android
  // Steam / Discord add-ons: every call is a harmless no-op returning undefined (so "init failed" paths are taken).
  var NOOP_MODULE = /(^|[\/\\])(greenworks[^\/\\]*|steamworks(\.js)?|steam_api[^\/\\]*|discord[-_]?rpc|discord-rich-presence)(\.node|\.js)?$/i;
  function noopStub(name) {
    var target = function () {};
    if (typeof Proxy !== 'function') return {};
    return new Proxy(target, {
      get: function (t, k) {
        if (k === 'then' || typeof k === 'symbol') return undefined; // keep it non-thenable / non-iterable
        if (k === '__esModule') return false;
        RR.warnOnce('noop:' + name + '.' + String(k), 'native module "' + name + '": ' + String(k) + ' is a no-op on Android');
        return noopStub(name + '.' + String(k));
      },
      apply: function () { return undefined; },
      construct: function () { return noopStub(name + '()'); },
      set: function () { return true; },
      has: function () { return true; }
    });
  }
  // Node core modules the app does not implement: requiring them works, using them throws a clear error.
  function unavailable(name) {
    RR.warnOnce('unavailable:' + name, 'require("' + name + '"): this Node module is not available in RPG Runner, using it will throw');
    var fail = function (what) {
      RR.warnOnce('unavailable-use:' + name + '.' + what, 'Node module "' + name + '" was used (' + what + ') but is not available in RPG Runner');
      throw new Error("Node module '" + name + "' is not available in RPG Runner");
    };
    if (typeof Proxy !== 'function') return { __unavailable: name };
    return new Proxy(function () {}, {
      get: function (t, k) { return (k === 'then' || typeof k === 'symbol') ? undefined : function () { return fail(String(k)); }; },
      apply: function () { return fail('call'); }, construct: function () { return fail('new'); }
    });
  }
  var UNAVAILABLE = ['http', 'https', 'http2', 'net', 'tls', 'dns', 'dgram', 'cluster', 'vm', 'readline', 'repl', 'worker_threads', 'tty',
    'v8', 'inspector', 'async_hooks', 'domain', 'punycode', 'sys', 'constants', 'module', 'electron', 'node-fetch'];

  var querystring = {
    parse: function (s) { var o = {}; new URLSearchParams(String(s)).forEach(function (v, k) { o[k] = (k in o) ? [].concat(o[k], v) : v; }); return o; },
    stringify: function (o) { return Object.keys(o || {}).map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(o[k]); }).join('&'); }
  };

  var builtins = {
    fs: fs, path: path, os: os, util: util, events: EventEmitter, url: urlMod, child_process: childProcess, crypto: cryptoMod, zlib: zlibMod,
    string_decoder: stringDecoder, timers: timersMod, assert: assertMod, process: proc, stream: streamMod, querystring: querystring,
    buffer: { Buffer: Buffer, SlowBuffer: Buffer, kMaxLength: 2147483647 },
    perf_hooks: { performance: global.performance }
  };
  RR.builtins = builtins;

  // ------------------------------------------------------------------ require()
  var moduleCache = {};
  function isFile(p) { try { return fs.statSync(p).isFile(); } catch (e) { return false; } }
  function isDir(p) { try { return fs.statSync(p).isDirectory(); } catch (e) { return false; } }
  function tryFile(p) {
    if (isFile(p)) return p;
    var exts = ['.js', '.json', '.node'];
    for (var i = 0; i < exts.length; i++) if (isFile(p + exts[i])) return p + exts[i];
    return null;
  }
  function tryDir(p) {
    if (!isDir(p)) return null;
    var pj = p + '/package.json';
    if (isFile(pj)) {
      try {
        var m = JSON.parse(xhrRead(pj, true)).main;
        if (m) { var q = path.resolve(p, m), r = tryFile(q) || tryFile(q + '/index'); if (r) return r; }
      } catch (e) { /* fall through to index */ }
    }
    return tryFile(p + '/index');
  }
  function resolveFile(name, dir) {
    if (/^(\.{1,2}(\/|$)|\/)/.test(name)) {
      var base = path.resolve(dir, name);
      return tryFile(base) || tryDir(base);
    }
    for (var d = dir; ; d = path.dirname(d)) {
      var cand = path.join(d, 'node_modules', name), r = tryFile(cand) || tryDir(cand);
      if (r) return r;
      if (d === '/' || d === '.' || !d) break;
    }
    return null;
  }
  function evalModule(file, code) {
    if (code.charCodeAt(0) === 35) code = '//' + code; // "#!shebang"
    var mod = { id: file, filename: file, path: path.dirname(file), exports: {}, loaded: false, parent: mainModule, children: [], paths: [] };
    mod.require = makeRequire(mod.path);
    moduleCache[file] = mod;
    var fn;
    try {
      fn = new Function('exports', 'require', 'module', '__filename', '__dirname', code + '\n//# sourceURL=' + file);
    } catch (e) {
      delete moduleCache[file];
      nlog('E', 'syntax error in module ' + file + ': ' + e);
      throw e;
    }
    try { fn.call(mod.exports, mod.exports, mod.require, mod, file, mod.path); } catch (e2) { delete moduleCache[file]; throw e2; }
    mod.loaded = true;
    return mod.exports;
  }
  function requireFrom(request, dir) {
    var n = String(request).replace(/^node:/, '');
    if (n === 'nw.gui' || n === 'nw') return global.nw;
    if (Object.prototype.hasOwnProperty.call(builtins, n)) return builtins[n];
    if (NOOP_MODULE.test(n)) return noopStub(n);
    if (UNAVAILABLE.indexOf(n) >= 0) return unavailable(n);
    var file = resolveFile(n, dir) || (dir !== ROOT ? resolveFile(n, ROOT) : null);
    if (!file) {
      var err = new Error("Cannot find module '" + request + "'");
      err.code = 'MODULE_NOT_FOUND';
      nlog('W', 'require("' + request + '") from ' + dir + ' failed: module not found');
      throw err;
    }
    if (moduleCache[file]) return moduleCache[file].exports;
    if (/\.node$/i.test(file)) return noopStub(file);
    if (/\.json$/i.test(file)) {
      var j = { exports: JSON.parse(xhrRead(file, true)) };
      moduleCache[file] = j;
      return j.exports;
    }
    return evalModule(file, xhrRead(file, true));
  }
  function makeRequire(dir) {
    var req = function (name) {
      if (typeof name !== 'string') { var e = new TypeError('The "id" argument must be of type string. Received ' + typeof name); e.code = 'ERR_INVALID_ARG_TYPE'; throw e; }
      return requireFrom(name, dir);
    };
    req.resolve = function (name) {
      var n = String(name).replace(/^node:/, '');
      if (Object.prototype.hasOwnProperty.call(builtins, n) || n === 'nw.gui') return n;
      var f = resolveFile(n, dir);
      if (!f) { var e = new Error("Cannot find module '" + name + "'"); e.code = 'MODULE_NOT_FOUND'; throw e; }
      return f;
    };
    req.cache = moduleCache; req.main = mainModule; req.extensions = {};
    return req;
  }
  global.global = global;
  global.process = proc;
  global.require = makeRequire(path.dirname(MAIN));
  RR.require = global.require;

  // ------------------------------------------------------------------ nw (NW.js API surface)
  function MenuStub(o) { this.items = []; this.options = o || {}; }
  MenuStub.prototype.append = function (i) { this.items.push(i); };
  MenuStub.prototype.insert = function (i, at) { this.items.splice(at, 0, i); };
  MenuStub.prototype.remove = function (i) { var k = this.items.indexOf(i); if (k >= 0) this.items.splice(k, 1); };
  MenuStub.prototype.removeAt = function (k) { this.items.splice(k, 1); };
  MenuStub.prototype.popup = MenuStub.prototype.createMacBuiltin = function () {};
  function ItemStub(o) { EventEmitter.call(this); for (var k in (o || {})) this[k] = o[k]; }
  util.inherits(ItemStub, EventEmitter);
  function TrayStub(o) { EventEmitter.call(this); for (var k in (o || {})) this[k] = o[k]; }
  util.inherits(TrayStub, EventEmitter);
  TrayStub.prototype.remove = function () {};

  var NOOP = function () {};
  var win = new EventEmitter();
  var winState = { closing: false };
  function emitFs(on) { win.isFullscreen = on; win.emit(on ? 'enter-fullscreen' : 'leave-fullscreen'); }
  win.window = global; win.id = 1; win.x = 0; win.y = 0; win.zoomLevel = 0; win.menu = null;
  win.isFullscreen = true; win.isKioskMode = false; win.isTransparent = false; win.isAlwaysOnTop = false;
  Object.defineProperty(win, 'width', { get: function () { return global.innerWidth; }, set: NOOP, enumerable: true });
  Object.defineProperty(win, 'height', { get: function () { return global.innerHeight; }, set: NOOP, enumerable: true });
  Object.defineProperty(win, 'title', { get: function () { return document.title; }, set: function (t) { document.title = t; }, enumerable: true });
  win.enterFullscreen = function () { emitFs(true); };
  win.leaveFullscreen = NOOP; // the app is always full screen
  win.toggleFullscreen = NOOP;
  win.isDevToolsOpen = function () { return false; };
  win.close = function (force) {
    if (!force && !winState.closing && win.listenerCount('close') > 0) {
      winState.closing = true; // NW.js: a 'close' handler decides; it ends the window with this.close(true)
      win.emit('close');
      winState.closing = false;
      return;
    }
    RR.exit();
  };
  ('show hide focus blur minimize maximize unmaximize restore setPosition moveTo moveBy resizeTo resizeBy setMinimumSize setMaximumSize ' +
    'setResizable setAlwaysOnTop setVisibleOnAllWorkspaces setShowInTaskbar requestAttention setBadgeLabel showDevTools closeDevTools print ' +
    'enterKioskMode leaveKioskMode toggleKioskMode setTransparent setProgressBar setMaximumSize').split(' ').forEach(function (m) { win[m] = NOOP; });
  win.reload = win.reloadDev = win.reloadIgnoringCache = function () { global.location.reload(); };
  win.eval = function (frame, code) { return (0, global.eval)(code); };
  win.capturePage = function (cb) { if (typeof cb === 'function') setTimeout(function () { cb(''); }, 0); };
  win.cookies = { get: NOOP, getAll: NOOP, set: NOOP, remove: NOOP, onChanged: new EventEmitter() };
  var winProxy = typeof Proxy === 'function' ? new Proxy(win, {
    get: function (t, k) {
      if (k in t || typeof k === 'symbol') return t[k];
      RR.warnOnce('win.' + String(k), 'nw.Window.' + String(k) + ' is not implemented (no-op)');
      return NOOP;
    }
  }) : win;
  // browser focus / blur / resize -> NW.js window events
  global.addEventListener('focus', function () { win.emit('focus'); });
  global.addEventListener('blur', function () { win.emit('blur'); });
  global.addEventListener('resize', function () { win.emit('resize', global.innerWidth, global.innerHeight); });

  var manifest = null;
  var App = {
    argv: [], fullArgv: [], filteredArgv: [], dataPath: DATA, startPath: ROOT,
    quit: function () { RR.exit(); }, closeAllWindows: function () { RR.exit(); },
    clearCache: NOOP, setProxyConfig: NOOP, crashBrowser: NOOP, crashRenderer: NOOP, getProxyForURL: function () { return 'DIRECT'; },
    registerGlobalHotKey: NOOP, unregisterGlobalHotKey: NOOP, addOriginAccessWhitelistEntry: NOOP, removeOriginAccessWhitelistEntry: NOOP,
    on: NOOP, once: NOOP, removeListener: NOOP, removeAllListeners: NOOP
  };
  Object.defineProperty(App, 'manifest', {
    enumerable: true,
    get: function () {
      if (!manifest) {
        try { manifest = JSON.parse(xhrRead(ROOT + '/package.json', true)); } catch (e) { manifest = { name: CFG.name || 'game', main: MAIN }; }
      }
      return manifest;
    }
  });
  var clipboard = {
    get: function () { return { get: function () { return ''; }, set: NOOP, clear: NOOP, readAvailableTypes: function () { return ['text']; } }; }
  };
  var nw = {
    Window: { get: function () { return winProxy; }, open: function (url, o, cb) { RR.warnOnce('win.open', 'nw.Window.open ignored: ' + url); if (typeof o === 'function') cb = o; if (cb) cb(winProxy); return winProxy; }, getAll: function (cb) { if (cb) cb([winProxy]); } },
    App: App,
    Shell: {
      openExternal: function (u) { try { if (N && N.openUrl) N.openUrl(String(u)); } catch (e) { /* ignore */ } },
      openItem: NOOP, showItemInFolder: NOOP
    },
    Clipboard: clipboard,
    Screen: {
      Init: NOOP, on: NOOP, removeListener: NOOP, chooseDesktopMedia: NOOP,
      get screens() {
        var w = global.screen ? global.screen.width : global.innerWidth, h = global.screen ? global.screen.height : global.innerHeight;
        return [{ id: 0, bounds: { x: 0, y: 0, width: w, height: h }, work_area: { x: 0, y: 0, width: w, height: h }, scaleFactor: global.devicePixelRatio || 1, isBuiltIn: true }];
      }
    },
    Menu: MenuStub, MenuItem: ItemStub, Tray: TrayStub, Shortcut: ItemStub,
    require: global.require, global: global, process: proc
  };
  global.nw = nw;
  RR.nw = nw;
  RR.nwWindow = win;

  // ------------------------------------------------------------------ audio: keep every AudioContext reachable, unlock on first gesture, suspend while paused
  var audioCtxs = [];
  var BaseAudioContext = global.AudioContext || global.webkitAudioContext;
  if (BaseAudioContext) {
    var RRAudioContext = class extends BaseAudioContext {
      constructor(o) { super(o); audioCtxs.push(this); }
    };
    global.AudioContext = RRAudioContext;
    global.webkitAudioContext = RRAudioContext;
  }
  RR.audioContexts = audioCtxs;
  function unlockAudio() {
    if (RR.paused) return;
    for (var i = 0; i < audioCtxs.length; i++) {
      if (audioCtxs[i].state === 'suspended') { try { var p = audioCtxs[i].resume(); if (p && p.catch) p.catch(NOOP); } catch (e) { /* ignore */ } }
    }
  }
  ['pointerdown', 'touchstart', 'mousedown', 'keydown'].forEach(function (ev) { global.addEventListener(ev, unlockAudio, true); });

  var pausedMedia = [];
  /** Called by the Android activity from onPause()/onResume(). */
  RR.setPaused = function (p) {
    p = !!p;
    if (p === RR.paused) return;
    RR.paused = p;
    var i, m;
    if (p) {
      for (i = 0; i < audioCtxs.length; i++) {
        try { if (audioCtxs[i].state === 'running') { audioCtxs[i].suspend(); audioCtxs[i].__rrSuspended = true; } } catch (e) { /* ignore */ }
      }
      pausedMedia = [];
      var media = document.querySelectorAll('video,audio');
      for (i = 0; i < media.length; i++) { m = media[i]; if (!m.paused) { try { m.pause(); pausedMedia.push(m); } catch (e2) { /* ignore */ } } }
    } else {
      for (i = 0; i < audioCtxs.length; i++) {
        if (audioCtxs[i].__rrSuspended) { audioCtxs[i].__rrSuspended = false; try { audioCtxs[i].resume(); } catch (e3) { /* ignore */ } }
      }
      for (i = 0; i < pausedMedia.length; i++) { try { var pr = pausedMedia[i].play(); if (pr && pr.catch) pr.catch(NOOP); } catch (e4) { /* ignore */ } }
      pausedMedia = [];
    }
    nlog('I', 'paused=' + p);
  };

  // The WebView reports visibility changes too (onPause/onResume, screen off): follow them even if the native call was lost.
  document.addEventListener('visibilitychange', function () { RR.setPaused(!!document.hidden); });

  // ------------------------------------------------------------------ optional frame limiter (battery / heat)
  (function () {
    var limit = parseInt(CFG.fpsLimit, 10) || 0;
    if (limit < 10 || limit >= 60 || !global.requestAnimationFrame) return;
    var interval = 1000 / limit, raf = global.requestAnimationFrame.bind(global);
    var queue = [], nextId = 1, last = 0, scheduled = false;
    function schedule() { if (!scheduled) { scheduled = true; raf(pump); } }
    function pump(t) {
      scheduled = false;
      if (t - last < interval - 2) { if (queue.length) schedule(); return; }
      last = t;
      var q = queue;
      queue = [];
      for (var i = 0; i < q.length; i++) {
        if (q[i].dead) continue;
        try { q[i].cb(t); } catch (e) { (function (err) { setTimeout(function () { throw err; }, 0); })(e); }
      }
      if (queue.length) schedule();
    }
    global.requestAnimationFrame = function (cb) { var h = { id: nextId++, cb: cb, dead: false }; queue.push(h); schedule(); return h.id; };
    global.cancelAnimationFrame = function (id) { for (var i = 0; i < queue.length; i++) if (queue[i].id === id) queue[i].dead = true; };
    nlog('I', 'frame limiter active: ' + limit + ' fps');
  })();

  // ------------------------------------------------------------------ error reporting (log file + short on-screen banner)
  var bannerCount = 0, bannerEl = null, bannerTimer = 0;
  function showBanner(text) {
    if (!CFG.debug || bannerCount >= 4 || !document.documentElement) return;
    bannerCount++;
    if (!bannerEl) {
      bannerEl = document.createElement('div');
      bannerEl.style.cssText = 'position:fixed;left:0;right:0;top:0;z-index:2147483646;padding:6px 10px;background:rgba(160,0,0,.88);' +
        'color:#fff;font:12px/1.35 monospace;white-space:pre-wrap;max-height:35vh;overflow:hidden;pointer-events:auto';
      bannerEl.addEventListener('click', function () { bannerEl.style.display = 'none'; });
      document.documentElement.appendChild(bannerEl);
    }
    bannerEl.textContent = String(text).slice(0, 600) + '\n(탭하면 닫힘 · 로그에 기록됨)';
    bannerEl.style.display = 'block';
    clearTimeout(bannerTimer);
    bannerTimer = setTimeout(function () { bannerEl.style.display = 'none'; }, 9000);
  }
  global.addEventListener('error', function (ev) {
    var t = ev.target;
    if (t && t !== global && t.tagName) { // a <script>/<img>/<link> that failed to load (does not bubble, hence capture)
      nlog('W', 'resource failed: <' + String(t.tagName).toLowerCase() + '> ' + (t.src || t.href || ''));
      return;
    }
    var msg = ev.message + ' @ ' + ev.filename + ':' + ev.lineno + ':' + ev.colno;
    if (ev.error && ev.error.stack) msg += '\n' + ev.error.stack;
    nlog('E', 'uncaught: ' + msg);
    showBanner(ev.message + '\n' + ev.filename + ':' + ev.lineno);
  }, true);
  global.addEventListener('unhandledrejection', function (ev) {
    var r = ev.reason;
    nlog('E', 'unhandled rejection: ' + ((r && r.stack) || r));
    showBanner('Unhandled rejection: ' + ((r && r.message) || r));
  });

  // ------------------------------------------------------------------ page fix-ups: viewport, background, no text selection / context menu
  function onDomReady(fn) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn();
  }
  onDomReady(function () {
    var head = document.head || document.documentElement;
    var meta = document.querySelector('meta[name=viewport]');
    if (!meta) { meta = document.createElement('meta'); meta.name = 'viewport'; head.appendChild(meta); }
    meta.setAttribute('content', 'width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover');
    var st = document.createElement('style');
    st.textContent = 'html,body{margin:0;padding:0;background:#000;overflow:hidden;touch-action:none;-webkit-tap-highlight-color:transparent}' +
      '*{-webkit-touch-callout:none;-webkit-user-select:none;user-select:none}input,textarea{-webkit-user-select:text;user-select:text}';
    head.appendChild(st);
  });
  document.addEventListener('contextmenu', function (e) { e.preventDefault(); }, true);
  global.close = function () { RR.exit(); }; // games quit with window.close() when they are not running in NW.js

  nlog('I', 'shim ' + RR.version + ' ready: engine=' + CFG.engine + ' root=' + ROOT + ' main=' + MAIN);
  nlog('I', 'UA ' + (global.navigator ? global.navigator.userAgent : '?') + ' dpr=' + global.devicePixelRatio + ' ' + global.innerWidth + 'x' + global.innerHeight);
  RR.ready = true;
})(window);
