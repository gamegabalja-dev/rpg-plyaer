EasyRPG Player web build goes here (Yume Nikki / RPG Maker 2000 and 2003 games).

It is downloaded by tools/fetch-easyrpg-web.sh (the GitHub Actions workflow runs it before building).
The script puts index.js, index.wasm and rr-player.html (the player page) into this folder.
Without them the APK still works for RPG Maker MV/MZ games.

The EasyRPG Player is free software under the GNU GPL v3: https://github.com/EasyRPG/Player
