#!/bin/sh
# Downloads the official EasyRPG Player *web build* and unpacks it into app/src/main/assets/easyrpg/.
# RPG Maker 2000/2003 games (Yume Nikki) run through it. It is optional: without it the APK still runs the
# RPG Maker MV/MZ games, and for 2000/2003 games the app offers to open the installed EasyRPG Player app instead.
#
# Usage:   sh tools/fetch-easyrpg-web.sh [archive-url-or-local-file]
# Env:     EASYRPG_WEB_URL   overrides the default download URL
# Exit:    0 = installed, 1 = failed (assets/easyrpg is left empty, the build can continue without it)
#
# The archive (https://easyrpg.org/player/guide/webplayer/) holds index.html, index.js, index.wasm and a games/
# folder. The app serves the player files from a flat folder, so everything except games/ is copied as it is
# and index.html is stored as rr-player.html (the name the app looks for).
set -u

DEFAULT_URL="https://easyrpg.org/downloads/player/latest/easyrpg-player-latest-js.tar.gz"
SRC="${1:-${EASYRPG_WEB_URL:-$DEFAULT_URL}}"

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$ROOT/app/src/main/assets/easyrpg"

fail() {
    echo "fetch-easyrpg-web: $*" >&2
    echo "fetch-easyrpg-web: continuing without the web player (Yume Nikki / RPG Maker 2000/2003 will not run inside this APK)" >&2
    exit 1
}

TMP="$(mktemp -d 2>/dev/null || mktemp -d -t rrfetch)" || fail "cannot create a temporary directory"
trap 'rm -rf "$TMP"' EXIT INT TERM

ARCHIVE="$TMP/player.tar.gz"
case "$SRC" in
    http://* | https://*)
        echo "fetch-easyrpg-web: downloading $SRC"
        if command -v curl >/dev/null 2>&1; then
            curl -fsSL --retry 4 --retry-delay 3 --retry-all-errors --connect-timeout 20 --max-time 300 \
                -o "$ARCHIVE" "$SRC" || fail "download failed"
        elif command -v wget >/dev/null 2>&1; then
            wget -q --tries=4 --timeout=60 -O "$ARCHIVE" "$SRC" || fail "download failed"
        else
            fail "neither curl nor wget is available"
        fi
        ;;
    *)
        [ -f "$SRC" ] || fail "no such file: $SRC"
        cp "$SRC" "$ARCHIVE" || fail "cannot read $SRC"
        ;;
esac

mkdir -p "$TMP/x" || fail "cannot create a temporary directory"
tar -xzf "$ARCHIVE" -C "$TMP/x" 2>"$TMP/tar.err" || { cat "$TMP/tar.err" >&2; fail "the download is not a valid .tar.gz archive"; }

# The files may sit at the top of the archive or inside one folder.
PLAYER=""
for d in "$TMP/x" "$TMP/x"/*/; do
    d="${d%/}"
    if [ -f "$d/index.html" ]; then
        PLAYER="$d"
        break
    fi
done
[ -n "$PLAYER" ] || fail "index.html not found in the archive"

JS_COUNT=0
WASM_COUNT=0
for f in "$PLAYER"/*.js; do [ -f "$f" ] && JS_COUNT=$((JS_COUNT + 1)); done
for f in "$PLAYER"/*.wasm; do [ -f "$f" ] && WASM_COUNT=$((WASM_COUNT + 1)); done
[ "$JS_COUNT" -ge 1 ] || fail "no .js file in the archive"
[ "$WASM_COUNT" -ge 1 ] || fail "no .wasm file in the archive"

mkdir -p "$DEST" || fail "cannot create $DEST"
# Remove an older copy (keep the placeholder note).
for f in "$DEST"/*; do
    [ -e "$f" ] || continue
    [ "$(basename "$f")" = "README.txt" ] && continue
    rm -rf "$f"
done

COPIED=0
SKIPPED=""
for f in "$PLAYER"/*; do
    [ -e "$f" ] || continue
    name="$(basename "$f")"
    [ "$name" = "games" ] && continue
    if [ -d "$f" ]; then
        # the app serves a flat folder only
        SKIPPED="$SKIPPED $name/"
        continue
    fi
    case "$name" in
        *[!A-Za-z0-9_.-]*) SKIPPED="$SKIPPED $name"; continue ;;
    esac
    cp "$f" "$DEST/$name" || fail "cannot copy $name"
    COPIED=$((COPIED + 1))
done

cp "$PLAYER/index.html" "$DEST/rr-player.html" || fail "cannot create rr-player.html"
rm -f "$DEST/index.html"

[ -s "$DEST/rr-player.html" ] || fail "rr-player.html is empty"
ls "$DEST"/*.wasm >/dev/null 2>&1 || fail "the .wasm file did not make it into $DEST"

[ -z "$SKIPPED" ] || echo "fetch-easyrpg-web: note: not copied (the app serves a flat folder):$SKIPPED" >&2
echo "fetch-easyrpg-web: installed $((COPIED)) file(s) into $DEST"
ls -l "$DEST"
exit 0
