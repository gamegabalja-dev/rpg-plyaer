'use strict';
// Compares the pure-JS zlib and crypto modules of the NW.js compatibility layer (dev/shim-parts/25-zlib.js and 26-crypto.js)
// with Node's own implementations: same results for every stream Node can make, same errors for broken streams, and streams we
// write must be readable by Node. The shim parts are loaded into Node by shim-node-harness.js; the real browser integration is
// covered by shim.test.js.
//
//   usage: node dev/test/zlib-crypto.test.js
const fs = require('fs');
const path = require('path');
const nodeZlib = require('zlib');
const nodeCrypto = require('crypto');
const { loadShim } = require('./shim-node-harness');

const ROOT = path.resolve(__dirname, '..', '..');
let pass = 0, fail = 0;
function ok(cond, msg, extra) {
  if (cond) { pass++; } else { fail++; if (fail <= 60) console.log('FAIL: ' + msg + (extra !== undefined ? '   -> ' + (typeof extra === 'string' ? extra : JSON.stringify(extra)) : '')); }
}
function eq(got, want, msg) { ok(JSON.stringify(got) === JSON.stringify(want), msg, { got, want }); }
const same = (a, b) => Buffer.from(a.buffer, a.byteOffset, a.length).equals(Buffer.from(b.buffer, b.byteOffset, b.length));

// ------------------------------------------------------------------------------------------------ load the shim parts
// the real shim parts (10 .. 26) run in Node with a fake window and a fake Android bridge, see shim-node-harness.js
const sh = loadShim(fs.mkdtempSync(path.join(require('os').tmpdir(), 'rr-zc-')));
const ShimBuffer = sh.Buffer;
const logged = sh.logs; // everything the shim logs ("W brotli ... not available")
const Z = sh.zlib, C = sh.crypto;

// ------------------------------------------------------------------------------------------------ test data
function rng(seed) {
  let a = seed >>> 0;
  return function () { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
function randomBytes(n, seed) { const r = rng(seed), b = Buffer.alloc(n); for (let i = 0; i < n; i++) b[i] = (r() * 256) | 0; return b; }
const WORDS = ('the coffin of andy and leyley a house in the woods witch ghost dream room door key nikki effect madotsuki dark light ' +
  'language default english korean 한국어 日本語 {"name":"x","value":123} ["a","b"] <div class="menu"> undefined function return var').split(' ');
function textBytes(n, seed) {
  const r = rng(seed); let s = '';
  while (s.length < n) s += WORDS[(r() * WORDS.length) | 0] + (r() < 0.1 ? '\n' : ' ');
  return Buffer.from(s.slice(0, n), 'utf8');
}
function datasets() {
  const out = [];
  const add = (name, buf) => out.push({ name, buf });
  add('empty', Buffer.alloc(0));
  add('1 byte', Buffer.from([65]));
  add('2 bytes', Buffer.from('ab'));
  add('3 same', Buffer.from('aaa'));
  add('run of a 100000', Buffer.alloc(100000, 97));
  add('run of zeros 1 MB', Buffer.alloc(1 << 20));
  add('abc repeated', Buffer.from('abc'.repeat(30000)));
  add('period 258', Buffer.concat(Array.from({ length: 200 }, () => randomBytes(258, 5))));
  add('random 1000', randomBytes(1000, 1));
  add('random 70000', randomBytes(70000, 2));
  add('random 300000', randomBytes(300000, 3));
  add('text 1k', textBytes(1000, 4));
  add('text 100k', textBytes(100000, 5));
  add('text 2 MB', textBytes(2 << 20, 6));
  const mix = []; const r = rng(7);
  for (let i = 0; i < 60; i++) mix.push(r() < 0.5 ? randomBytes(((r() * 5000) | 0) + 1, i) : textBytes(((r() * 8000) | 0) + 1, i), Buffer.alloc(((r() * 600) | 0), (r() * 256) | 0));
  add('mixed', Buffer.concat(mix));
  const far = Buffer.concat([randomBytes(32000, 8), randomBytes(700, 9)]); // matches at the maximum distance
  add('far matches', Buffer.concat([far, far.subarray(0, 32768), far]));
  return out;
}
const DATA = datasets();

// ------------------------------------------------------------------------------------------------ 1. Node writes, we read
const KINDS = [['deflate', 'inflate'], ['gzip', 'gunzip'], ['deflateRaw', 'inflateRaw']];
for (const ds of DATA) {
  const variants = [];
  for (let level = 0; level <= 9; level++) variants.push({ level });
  variants.push({ level: -1 }, { strategy: nodeZlib.constants.Z_FILTERED }, { strategy: nodeZlib.constants.Z_HUFFMAN_ONLY },
    { strategy: nodeZlib.constants.Z_RLE }, { strategy: nodeZlib.constants.Z_FIXED }, { windowBits: 9 }, { memLevel: 1, level: 9 });
  const big = ds.buf.length > 500000;
  for (const [w, r] of KINDS) {
    for (const opt of variants) {
      if (big && !(opt.level === 6 || opt.level === 0 || opt.level === 1 || opt.strategy === nodeZlib.constants.Z_FIXED || opt.level === 9)) continue;
      const comp = nodeZlib[w + 'Sync'](ds.buf, opt);
      let got;
      try { got = Z[r + 'Sync'](comp); } catch (e) { ok(false, 'node ' + w + ' ' + JSON.stringify(opt) + ' of "' + ds.name + '" -> our ' + r + ' threw ' + e.message); continue; }
      ok(same(got, ds.buf), 'node ' + w + ' ' + JSON.stringify(opt) + ' of "' + ds.name + '" -> our ' + r + ' gives the original (len ' + got.length + ' vs ' + ds.buf.length + ')');
      ok(got instanceof ShimBuffer, 'result is a Buffer');
      if (w !== 'deflateRaw' && !big && (opt.level === 6 || opt.level === 1)) ok(same(Z.unzipSync(comp), ds.buf), 'unzip auto-detects ' + w + ' of "' + ds.name + '"');
    }
  }
}

// ------------------------------------------------------------------------------------------------ 2. we write, Node reads
let ratioText = 0, ratioRandom = 0;
for (const ds of DATA) {
  for (const level of [-1, 0, 1, 6, 9]) {
    for (const [w, r] of KINDS) {
      const comp = Z[w + 'Sync'](ds.buf, { level });
      let back;
      try { back = nodeZlib[r + 'Sync'](comp); } catch (e) { ok(false, 'our ' + w + ' level ' + level + ' of "' + ds.name + '" is rejected by node: ' + e.message); continue; }
      ok(same(back, ds.buf), 'our ' + w + ' level ' + level + ' of "' + ds.name + '" is read back by node');
      if (w === 'gzip' && level === 6) {
        ok(same(Z.unzipSync(comp), ds.buf), 'our gzip is read by our unzip');
        if (ds.name === 'text 100k') ratioText = comp.length / ds.buf.length;
        if (ds.name === 'random 70000') ratioRandom = comp.length / ds.buf.length;
        ok(comp.length <= ds.buf.length + 5 * Math.max(1, Math.ceil(ds.buf.length / 65535)) + 18, 'our gzip of "' + ds.name + '" never grows more than stored blocks do', comp.length);
      }
    }
  }
}
ok(ratioText > 0 && ratioText < 0.5, 'text compresses to less than half (' + ratioText.toFixed(3) + ')');
ok(ratioRandom > 1 && ratioRandom < 1.002, 'random data falls back to stored blocks (' + ratioRandom.toFixed(4) + ')');
// level 0 and the empty input look exactly like zlib's output
for (const w of ['deflate', 'deflateRaw', 'gzip']) {
  for (const buf of [Buffer.alloc(0), Buffer.from('hello world')]) {
    ok(Buffer.from(Z[w + 'Sync'](buf, { level: 0 })).equals(nodeZlib[w + 'Sync'](buf, { level: 0 })), 'level 0 ' + w + ' of ' + buf.length + ' bytes is byte-identical to node');
  }
}
ok(Buffer.from(Z.deflateRawSync(Buffer.alloc(0))).equals(nodeZlib.deflateRawSync(Buffer.alloc(0))), 'empty raw deflate equals node (03 00)');
for (const level of [-1, 0, 1, 2, 5, 6, 7, 9]) {
  const a = Buffer.from(Z.deflateSync('x', { level })).subarray(0, 2), b = nodeZlib.deflateSync('x', { level }).subarray(0, 2);
  ok(a.equals(b), 'zlib header for level ' + level + ' equals node (' + a.toString('hex') + ' vs ' + b.toString('hex') + ')');
  const g = Buffer.from(Z.gzipSync('x', { level })).subarray(0, 10), h = nodeZlib.gzipSync('x', { level }).subarray(0, 10);
  ok(g.equals(h), 'gzip header for level ' + level + ' equals node (' + g.toString('hex') + ' vs ' + h.toString('hex') + ')');
}
for (const bad of [-2, 10, NaN, 'x']) {
  let err = null; try { Z.deflateSync('x', { level: bad }); } catch (e) { err = e; }
  ok(err && err.code === 'ERR_OUT_OF_RANGE', 'level ' + String(bad) + ' is rejected', err && err.code);
}

// ------------------------------------------------------------------------------------------------ 3. broken and truncated streams
function outcome(fn) {
  try { const r = fn(); return { ok: true, out: Buffer.from(r.buffer, r.byteOffset, r.length) }; }
  catch (e) { return { ok: false, code: e.code, errno: e.errno, msg: e.message }; }
}
const mismatches = [];
function report() {
  const groups = new Map();
  for (const m of mismatches) { const g = groups.get(m.key) || { n: 0, example: m.label }; g.n++; groups.set(m.key, g); }
  for (const [key, g] of groups) console.log('  ' + g.n + ' x ' + key + '   e.g. ' + g.example);
  mismatches.length = 0;
}
function compareOutcome(label, nodeFn, ourFn) {
  const a = outcome(nodeFn), b = outcome(ourFn);
  const d = (o) => o.ok ? 'ok' : o.code + '/' + o.errno + ' "' + o.msg + '"';
  if (a.ok !== b.ok) { mismatches.push({ label, key: 'node ' + d(a) + ' / ours ' + d(b) }); return; }
  if (a.ok) { if (!a.out.equals(b.out)) mismatches.push({ label, key: 'both ok, different output (' + a.out.length + ' vs ' + b.out.length + ')' }); return; }
  if (a.code !== b.code || a.errno !== b.errno || a.msg !== b.msg) mismatches.push({ label, key: 'node ' + d(a) + ' / ours ' + d(b) });
}
const smallStreams = [];
{
  const samples = [Buffer.from('hello hello hello hello world'), textBytes(3000, 11), randomBytes(200, 12), Buffer.alloc(0), Buffer.from('a'),
    Buffer.concat([textBytes(500, 13), randomBytes(50, 14), textBytes(500, 15)])];
  for (const s of samples) {
    for (const opt of [{ level: 0 }, { level: 6 }, { level: 9, strategy: nodeZlib.constants.Z_FIXED }, { level: 1 }]) {
      for (const [w, r] of KINDS) smallStreams.push({ w, r, buf: nodeZlib[w + 'Sync'](s, opt), name: w + JSON.stringify(opt) + '/' + s.length });
    }
  }
}
{
  const r = rng(99);
  let cases = 0;
  for (const st of smallStreams) {
    // every truncation length
    for (let cut = 0; cut < st.buf.length; cut++) {
      const part = st.buf.subarray(0, cut);
      compareOutcome(st.name + ' cut ' + cut, () => nodeZlib[st.r + 'Sync'](part), () => Z[st.r + 'Sync'](part));
      cases++;
    }
    // single byte changes everywhere (a few masks each)
    for (let pos = 0; pos < st.buf.length; pos++) {
      for (const mask of [1, 0x80, (r() * 255 + 1) | 0]) {
        const bad = Buffer.from(st.buf); bad[pos] ^= mask;
        compareOutcome(st.name + ' flip ' + pos + '^' + mask, () => nodeZlib[st.r + 'Sync'](bad), () => Z[st.r + 'Sync'](bad));
        cases++;
      }
    }
  }
  ok(cases > 20000, 'ran many corruption cases', cases);
}
{
  // random garbage and tiny inputs through every reader
  const r = rng(5);
  for (let i = 0; i < 3000; i++) {
    const g = randomBytes(((r() * 40) | 0), 1000 + i);
    for (const rd of ['inflate', 'gunzip', 'inflateRaw', 'unzip']) compareOutcome('garbage #' + i + ' ' + rd, () => nodeZlib[rd + 'Sync'](g), () => Z[rd + 'Sync'](g));
  }
  // garbage that starts like a real header, to get past the header checks
  for (let i = 0; i < 3000; i++) {
    const g = Buffer.concat([Buffer.from(i % 2 ? [0x78, 0x9c] : [0x1f, 0x8b, 8, 0, 0, 0, 0, 0, 0, 3]), randomBytes(((r() * 60) | 0), 5000 + i)]);
    const rd = i % 2 ? 'inflate' : 'gunzip';
    compareOutcome('headed garbage #' + i + ' ' + rd, () => nodeZlib[rd + 'Sync'](g), () => Z[rd + 'Sync'](g));
  }
}
{
  // truncated input with Z_SYNC_FLUSH returns what was decoded so far instead of failing
  const F = { finishFlush: nodeZlib.constants.Z_SYNC_FLUSH };
  for (const st of smallStreams) {
    for (let cut = 0; cut < st.buf.length; cut++) {
      const part = st.buf.subarray(0, cut);
      compareOutcome(st.name + ' sync-flush cut ' + cut, () => nodeZlib[st.r + 'Sync'](part, F), () => Z[st.r + 'Sync'](part, F));
    }
  }
}
eq(mismatches.length, 0, 'broken, truncated and garbage streams give the same result / error as node (' + mismatches.length + ' differ)');
if (mismatches.length) report();

// ------------------------------------------------------------------------------------------------ 4. gzip headers, members, trailing bytes
function gzipHand(raw, o) {
  o = o || {};
  const comp = nodeZlib.deflateRawSync(raw);
  let flg = 0; const head = [Buffer.from([0x1f, 0x8b, 8, 0, 0x10, 0x20, 0x30, 0x40, 0, 255])];
  if (o.extra) { flg |= 4; const x = Buffer.from(o.extra); head.push(Buffer.from([x.length & 255, x.length >> 8]), x); }
  if (o.name) { flg |= 8; head.push(Buffer.from(o.name + '\0')); }
  if (o.comment) { flg |= 16; head.push(Buffer.from(o.comment + '\0')); }
  head[0][3] = flg | (o.hcrc ? 2 : 0) | (o.flagBits || 0);
  if (o.hcrc) {
    const h = Buffer.concat(head); const c = nodeZlib.crc32(h) & 0xffff;
    head.push(Buffer.from([(c & 255) ^ (o.badCrc ? 1 : 0), c >> 8]));
  }
  const tail = Buffer.alloc(8); tail.writeUInt32LE(nodeZlib.crc32(raw), 0); tail.writeUInt32LE(raw.length >>> 0, 4);
  return Buffer.concat([...head, comp, tail]);
}
{
  const raw = textBytes(2000, 21);
  const cases = {
    'extra': gzipHand(raw, { extra: 'ab\0cd' }), 'name': gzipHand(raw, { name: 'file.txt' }), 'comment': gzipHand(raw, { comment: 'c' }),
    'all': gzipHand(raw, { extra: 'EXTRA', name: 'n.bin', comment: 'hello', hcrc: true }), 'hcrc': gzipHand(raw, { hcrc: true }),
    'bad hcrc': gzipHand(raw, { hcrc: true, badCrc: true }), 'reserved flag': gzipHand(raw, { flagBits: 0x20 })
  };
  for (const k of Object.keys(cases)) compareOutcome('gzip header ' + k, () => nodeZlib.gunzipSync(cases[k]), () => Z.gunzipSync(cases[k]));
  ok(same(Z.gunzipSync(cases.all), raw), 'gzip with all header fields is read');
  const a = nodeZlib.gzipSync('first '), b = nodeZlib.gzipSync('second');
  const multi = {
    'two members': Buffer.concat([a, b]), 'three members': Buffer.concat([a, b, a]),
    'zero padding': Buffer.concat([a, Buffer.alloc(7)]), 'garbage after': Buffer.concat([a, Buffer.from('garbage')]),
    'member + zero + member': Buffer.concat([a, Buffer.alloc(3), b]), 'truncated 2nd member': Buffer.concat([a, b.subarray(0, 12)]),
    'bad crc': (() => { const x = Buffer.from(a); x[x.length - 8] ^= 1; return x; })(), 'bad isize': (() => { const x = Buffer.from(a); x[x.length - 1] ^= 1; return x; })()
  };
  for (const k of Object.keys(multi)) {
    compareOutcome('gzip ' + k, () => nodeZlib.gunzipSync(multi[k]), () => Z.gunzipSync(multi[k]));
    compareOutcome('unzip ' + k, () => nodeZlib.unzipSync(multi[k]), () => Z.unzipSync(multi[k]));
  }
  // zlib stream followed by junk: ignored like in node
  const zl = Buffer.concat([nodeZlib.deflateSync('abc'), Buffer.from('trailing junk')]);
  compareOutcome('zlib + junk', () => nodeZlib.inflateSync(zl), () => Z.inflateSync(zl));
  const rawj = Buffer.concat([nodeZlib.deflateRawSync('abc'), Buffer.from('trailing junk')]);
  compareOutcome('raw + junk', () => nodeZlib.inflateRawSync(rawj), () => Z.inflateRawSync(rawj));
  // wrong container for the reader
  compareOutcome('gunzip of zlib data', () => nodeZlib.gunzipSync(nodeZlib.deflateSync('abc')), () => Z.gunzipSync(nodeZlib.deflateSync('abc')));
  compareOutcome('inflate of gzip data', () => nodeZlib.inflateSync(nodeZlib.gzipSync('abc')), () => Z.inflateSync(nodeZlib.gzipSync('abc')));
  compareOutcome('inflate of raw data', () => nodeZlib.inflateSync(nodeZlib.deflateRawSync('abc')), () => Z.inflateSync(nodeZlib.deflateRawSync('abc')));
}
eq(mismatches.length, 0, 'gzip headers / members / trailing bytes behave like node (' + mismatches.length + ' differ)');
if (mismatches.length) report();

// ------------------------------------------------------------------------------------------------ 5. dictionaries
{
  const dict = Buffer.from('{"name":"language","value":"default english korean"}');
  const msg = Buffer.from('{"name":"language","value":"default english korean"} {"name":"x"}'.repeat(20));
  for (const [w, r] of [['deflate', 'inflate'], ['deflateRaw', 'inflateRaw']]) {
    const comp = nodeZlib[w + 'Sync'](msg, { dictionary: dict });
    ok(same(Z[r + 'Sync'](comp, { dictionary: dict }), msg), 'node ' + w + ' with dictionary -> our ' + r);
    const mine = Z[w + 'Sync'](msg, { dictionary: dict });
    ok(same(nodeZlib[r + 'Sync'](mine, { dictionary: dict }), msg), 'our ' + w + ' with dictionary -> node ' + r);
  }
  const withDict = nodeZlib.deflateSync(msg, { dictionary: dict });
  compareOutcome('missing dictionary', () => nodeZlib.inflateSync(withDict), () => Z.inflateSync(withDict));
  compareOutcome('wrong dictionary', () => nodeZlib.inflateSync(withDict, { dictionary: Buffer.from('nope') }), () => Z.inflateSync(withDict, { dictionary: Buffer.from('nope') }));
}
eq(mismatches.length, 0, 'dictionary errors behave like node (' + mismatches.length + ' differ)');
if (mismatches.length) report();

// ------------------------------------------------------------------------------------------------ 6. input types, crc32, constants
{
  const s = 'héllo 한글 ✓ ' + 'x'.repeat(50);
  const exp = Buffer.from(s, 'utf8');
  ok(same(Z.inflateSync(Z.deflateSync(s)), exp), 'string input is UTF-8');
  ok(same(Z.inflateSync(Z.deflateSync(new Uint8Array(exp))), exp), 'Uint8Array input');
  ok(same(Z.inflateSync(Z.deflateSync(exp.buffer.slice(exp.byteOffset, exp.byteOffset + exp.length))), exp), 'ArrayBuffer input');
  ok(same(Z.inflateSync(Z.deflateSync(new DataView(exp.buffer, exp.byteOffset, exp.length))), exp), 'DataView input');
  ok(same(Z.inflateSync(nodeZlib.deflateSync(s).buffer.slice(nodeZlib.deflateSync(s).byteOffset, nodeZlib.deflateSync(s).byteOffset + nodeZlib.deflateSync(s).length)), exp), 'ArrayBuffer input to inflate');
  for (const bad of [123, null, undefined, {}, [1, 2]]) {
    let err = null; try { Z.deflateSync(bad); } catch (e) { err = e; }
    let nerr = null; try { nodeZlib.deflateSync(bad); } catch (e) { nerr = e; }
    ok(err instanceof TypeError && err.code === 'ERR_INVALID_ARG_TYPE' && nerr && nerr.code === err.code, 'deflateSync(' + JSON.stringify(bad) + ') throws ERR_INVALID_ARG_TYPE', err && err.message);
  }
  for (const [data, v] of [['', undefined], ['hello', undefined], [Buffer.from('hello world'), 0], ['abc', 12345], [randomBytes(100000, 4), undefined], ['한글', 4294967295]]) {
    eq(Z.crc32(data, v), nodeZlib.crc32(data, v), 'crc32 equals node for ' + (typeof data === 'string' ? data : data.length + ' bytes'));
  }
  const part1 = randomBytes(1000, 31), part2 = randomBytes(777, 32);
  eq(Z.crc32(part2, Z.crc32(part1)), nodeZlib.crc32(Buffer.concat([part1, part2])), 'crc32 can be chained');
  let rerr = null; try { Z.crc32('a', -1); } catch (e) { rerr = e; } ok(rerr && rerr.code === 'ERR_OUT_OF_RANGE', 'crc32 rejects a negative start value');
  for (const k of Object.keys(nodeZlib.constants)) if (!/^(BROTLI|ZSTD)/.test(k)) eq(Z.constants[k], nodeZlib.constants[k], 'constant ' + k);
  eq(Z.codes.Z_DATA_ERROR, -3, 'codes.Z_DATA_ERROR'); eq(Z.codes[-5], 'Z_BUF_ERROR', 'codes[-5]');
  eq(Z.Z_BEST_COMPRESSION, 9, 'legacy alias Z_BEST_COMPRESSION');
  for (const k of ['deflate', 'inflate', 'gzip', 'gunzip', 'deflateRaw', 'inflateRaw', 'unzip']) {
    ok(typeof Z[k] === 'function' && typeof Z[k + 'Sync'] === 'function', 'has ' + k + ' and ' + k + 'Sync');
  }
  for (const k of ['createDeflate', 'createInflate', 'createGzip', 'createGunzip', 'createDeflateRaw', 'createInflateRaw', 'createUnzip', 'crc32']) ok(typeof Z[k] === 'function', 'has ' + k);
  let berr = null; try { Z.brotliCompressSync('x'); } catch (e) { berr = e; }
  ok(berr && /not available/.test(berr.message) && logged.some((m) => /brotli/.test(m)), 'brotli throws a clear error and logs it');
}

// ------------------------------------------------------------------------------------------------ 7. callback and stream flavours
async function main() {
  const s = textBytes(50000, 41);
  for (const [w, r] of KINDS) {
    const comp = await new Promise((res, rej) => Z[w](s, (e, v) => e ? rej(e) : res(v)));
    ok(same(nodeZlib[r + 'Sync'](comp), s), 'callback ' + w + ' -> node ' + r);
    const back = await new Promise((res, rej) => Z[r](comp, { }, (e, v) => e ? rej(e) : res(v)));
    ok(same(back, s), 'callback ' + r);
    const err = await new Promise((res) => Z[r](Buffer.from('definitely not compressed'), (e) => res(e)));
    ok(err instanceof Error && err.code === 'Z_DATA_ERROR', 'callback ' + r + ' reports bad data through the callback', err && err.code);
    let thrown = null; try { Z[w](s); } catch (e) { thrown = e; } ok(thrown && thrown.code === 'ERR_INVALID_ARG_TYPE', 'callback ' + w + ' without a callback throws');
  }
  const promisified = await new Promise((res, rej) => require('util').promisify(Z.gzip)('promised', (e, v) => e ? rej(e) : res(v))).catch(() => null);
  void promisified;
  for (const [w, r, mk, mkr] of [['gzip', 'gunzip', 'createGzip', 'createGunzip'], ['deflate', 'inflate', 'createDeflate', 'createInflate'], ['deflateRaw', 'inflateRaw', 'createDeflateRaw', 'createInflateRaw']]) {
    const events = [], chunks = [];
    const st = Z[mk]();
    st.on('data', (c) => { chunks.push(Buffer.from(c)); events.push('data'); });
    st.on('finish', () => events.push('finish')); st.on('end', () => events.push('end')); st.on('close', () => events.push('close'));
    st.write(s.subarray(0, 20000)); st.write(s.subarray(20000, 20001)); st.end(s.subarray(20001));
    await new Promise((res) => st.on('close', res));
    const comp = Buffer.concat(chunks);
    ok(same(nodeZlib[r + 'Sync'](comp), s), mk + ' stream output is read by node');
    eq(events, ['data', 'finish', 'end', 'close'], mk + ' emits data, finish, end, close');
    // pipe a compressor into a decompressor into a collector
    const out = [];
    const sink = { write(c) { out.push(Buffer.from(c)); return true; }, end() { sink.ended = true; } };
    const ds = Z[mkr]();
    Z[mk]().pipe(ds).pipe(sink);
    const comp2 = Z[mk]();
    void comp2;
  }
  {
    const out = [], sink = { write(c) { out.push(Buffer.from(c)); return true; }, end() { sink.ended = true; } };
    const g = Z.createGzip(), u = Z.createGunzip();
    g.pipe(u).pipe(sink);
    g.end(s);
    await new Promise((res) => setTimeout(res, 100));
    ok(sink.ended && same(Buffer.concat(out), s), 'gzip stream piped into gunzip stream piped into a sink restores the data');
    const bad = Z.createGunzip();
    const errP = new Promise((res) => bad.on('error', res));
    bad.end(Buffer.from('this is not gzip data at all'));
    const e = await errP;
    ok(e && e.code === 'Z_DATA_ERROR', 'stream reports corrupt data as an error event', e && e.code);
    const after = Z.createGzip(); after.end('x');
    const werr = new Promise((res) => after.on('error', res));
    after.write('late');
    const we = await werr;
    ok(we && we.code === 'ERR_STREAM_WRITE_AFTER_END', 'write after end is an error', we && we.code);
    await new Promise((res) => setTimeout(res, 20));
  }
}

// ------------------------------------------------------------------------------------------------ 8. crypto (only when part 26 exists)
// ------------------------------------------------------------------------------------------------ 8. crypto
{
  const ALGS = ['md5', 'sha1', 'sha224', 'sha256', 'sha384', 'sha512'];
  const nodeHash = (a, data) => nodeCrypto.createHash(a).update(data).digest();
  const r = rng(77);
  for (const alg of ALGS) {
    let bad = 0;
    for (let n = 0; n <= 300; n++) {
      const d = randomBytes(n, n + 1);
      if (!same(C.createHash(alg).update(d).digest(), nodeHash(alg, d))) bad++;
    }
    ok(bad === 0, alg + ' equals node for every input length 0..300', bad);
    let bad2 = 0;
    for (const n of [511, 512, 513, 1023, 1024, 4095, 4096, 65535, 65536, 65537, 300000]) {
      const d = randomBytes(n, n);
      if (!same(C.createHash(alg).update(d).digest(), nodeHash(alg, d))) bad2++;
    }
    ok(bad2 === 0, alg + ' equals node for larger inputs', bad2);
    const big = randomBytes(5 << 20, 9);
    ok(same(C.createHash(alg).update(big).digest(), nodeHash(alg, big)), alg + ' equals node for 5 MB');
    // chunked updates with random split points (and empty chunks)
    let bad3 = 0;
    for (let t = 0; t < 40; t++) {
      const d = randomBytes(((r() * 2000) | 0), 500 + t), h = C.createHash(alg), nh = nodeCrypto.createHash(alg);
      let p = 0;
      while (p < d.length) { const k = Math.floor(r() * 150); h.update(d.subarray(p, p + k)); nh.update(d.subarray(p, p + k)); p += k; }
      if (!same(h.digest(), nh.digest())) bad3++;
    }
    ok(bad3 === 0, alg + ' chunked updates equal node', bad3);
    // encodings in and out, input types
    const s = 'héllo 한글 ✓';
    for (const enc of ['hex', 'base64', 'latin1', 'binary', 'base64url']) eq(C.createHash(alg).update(s).digest(enc), nodeCrypto.createHash(alg).update(s).digest(enc), alg + ' digest(' + enc + ')');
    eq(C.createHash(alg).update('68656c6c6f', 'hex').digest('hex'), nodeCrypto.createHash(alg).update('68656c6c6f', 'hex').digest('hex'), alg + ' update(hex string)');
    eq(C.createHash(alg).update('aGVsbG8=', 'base64').digest('hex'), nodeCrypto.createHash(alg).update('aGVsbG8=', 'base64').digest('hex'), alg + ' update(base64 string)');
    eq(C.createHash(alg).update('héllo', 'latin1').digest('hex'), nodeCrypto.createHash(alg).update('héllo', 'latin1').digest('hex'), alg + ' update(latin1 string)');
    const bytes = Buffer.from(s);
    const want = nodeHash(alg, bytes).toString('hex');
    eq(C.createHash(alg).update(new Uint8Array(bytes)).digest('hex'), want, alg + ' update(Uint8Array)');
    eq(C.createHash(alg).update(new DataView(bytes.buffer, bytes.byteOffset, bytes.length)).digest('hex'), want, alg + ' update(DataView)');
    eq(C.createHash(alg).update(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.length)).digest('hex'), want, alg + ' update(ArrayBuffer)');
    eq(C.createHash(alg).update('héllo ').update('한글 ✓').digest('hex'), want, alg + ' update() is chainable');
    // copy(): independent states
    const h1 = C.createHash(alg).update('abc'), h2 = h1.copy();
    h1.update('def'); h2.update('xyz');
    eq(h1.digest('hex'), nodeHash(alg, 'abcdef').toString('hex'), alg + ' copy keeps the original going');
    eq(h2.digest('hex'), nodeHash(alg, 'abcxyz').toString('hex'), alg + ' copy continues on its own');
    ok(C.createHash(alg).digest() instanceof ShimBuffer, alg + ' digest() returns a Buffer');
    // names
    eq(C.createHash(alg.toUpperCase()).update('x').digest('hex'), nodeHash(alg, 'x').toString('hex'), alg + ' name is case-insensitive');
    // HMAC with keys around the block size
    const block = alg === 'sha384' || alg === 'sha512' ? 128 : 64;
    for (const klen of [0, 1, 20, block - 1, block, block + 1, 2 * block + 5]) {
      const key = randomBytes(klen, 900 + klen), msg = randomBytes(((r() * 700) | 0), 1500 + klen);
      ok(same(C.createHmac(alg, key).update(msg).digest(), nodeCrypto.createHmac(alg, key).update(msg).digest()), 'hmac-' + alg + ' with a ' + klen + ' byte key');
    }
    eq(C.createHmac(alg, 'secret').update('a').update('b').digest('hex'), nodeCrypto.createHmac(alg, 'secret').update('ab').digest('hex'), 'hmac-' + alg + ' string key, chained updates');
    // PBKDF2 (a zero-length key is skipped: node's OpenSSL 3 refuses it)
    eq(C.pbkdf2Sync('p', 's', 1, 0, alg).length, 0, 'pbkdf2-' + alg + ' with keylen 0 gives an empty buffer');
    for (const [iter, klen] of [[1, 20], [2, 33], [100, 64], [10, 100], [1, 1]]) {
      ok(same(C.pbkdf2Sync('password', 'salt', iter, klen, alg), nodeCrypto.pbkdf2Sync('password', 'salt', iter, klen, alg)), 'pbkdf2-' + alg + ' ' + iter + ' iterations, ' + klen + ' bytes');
    }
  }
  // names Node accepts as aliases
  for (const name of ['sha-256', 'SHA256', 'RSA-SHA256', 'sha-1', 'SHA-512', 'RSA-MD5', 'md5']) {
    let node = null; try { node = nodeCrypto.createHash(name).update('abc').digest('hex'); } catch (e) { /* not supported by this node */ }
    if (node !== null) eq(C.createHash(name).update('abc').digest('hex'), node, 'algorithm alias ' + name);
  }
  eq(C.createHash('md5').update('').digest('hex'), 'd41d8cd98f00b204e9800998ecf8427e', 'known md5 of the empty string');
  eq(C.createHash('sha1').update('abc').digest('hex'), 'a9993e364706816aba3e25717850c26c9cd0d89d', 'known sha1 of abc');
  eq(C.createHash('sha256').update('abc').digest('hex'), 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad', 'known sha256 of abc');
  // errors like Node's
  const errOf = (fn) => { try { fn(); return null; } catch (e) { return { name: e.name, code: e.code, msg: e.message }; } };
  for (const [label, fn, nfn] of [
    ['unknown digest', () => C.createHash('nope'), () => nodeCrypto.createHash('nope')],
    ['unknown hmac digest', () => C.createHmac('nope', 'k'), () => nodeCrypto.createHmac('nope', 'k')],
    ['update(number)', () => C.createHash('md5').update(123), () => nodeCrypto.createHash('md5').update(123)],
    ['update(undefined)', () => C.createHash('md5').update(), () => nodeCrypto.createHash('md5').update()],
    ['digest twice', () => { const h = C.createHash('md5'); h.digest(); h.digest(); }, () => { const h = nodeCrypto.createHash('md5'); h.digest(); h.digest(); }],
    ['update after digest', () => { const h = C.createHash('md5'); h.digest(); h.update('x'); }, () => { const h = nodeCrypto.createHash('md5'); h.digest(); h.update('x'); }],
    ['pbkdf2 unknown digest', () => C.pbkdf2Sync('a', 'b', 1, 8, 'nope'), () => nodeCrypto.pbkdf2Sync('a', 'b', 1, 8, 'nope')],
    ['pbkdf2 zero iterations', () => C.pbkdf2Sync('a', 'b', 0, 8, 'sha1'), () => nodeCrypto.pbkdf2Sync('a', 'b', 0, 8, 'sha1')],
    ['pbkdf2 no digest', () => C.pbkdf2Sync('a', 'b', 1, 8), () => nodeCrypto.pbkdf2Sync('a', 'b', 1, 8)]
  ]) {
    const a = errOf(nfn), b = errOf(fn);
    ok(a && b && a.name === b.name && a.code === b.code, 'error for ' + label + ' has the same type and code as node', { node: a, ours: b });
  }
  // random helpers
  const rb = C.randomBytes(16);
  ok(rb instanceof ShimBuffer && rb.length === 16, 'randomBytes(16) returns a 16 byte Buffer');
  ok(!same(C.randomBytes(32), C.randomBytes(32)), 'randomBytes differs between calls');
  eq(C.randomBytes(0).length, 0, 'randomBytes(0)');
  const bigRandom = C.randomBytes(300000);
  let distinct = new Set(); for (let k = 0; k < bigRandom.length; k++) distinct.add(bigRandom[k]);
  ok(bigRandom.length === 300000 && distinct.size === 256, 'randomBytes(300000) is filled completely (the 64 KiB limit of getRandomValues is handled)', distinct.size);
  let tail = 0; for (let k = 250000; k < 300000; k++) tail |= bigRandom[k]; ok(tail !== 0, 'the last chunk of a big randomBytes is random too');
  for (const bad of [-1, 1.5, 'x', NaN, undefined]) { const e = errOf(() => C.randomBytes(bad)); ok(e && /^ERR_(INVALID_ARG_TYPE|OUT_OF_RANGE)$/.test(e.code), 'randomBytes(' + String(bad) + ') throws', e); }
  {
    const seen = new Array(10).fill(0);
    for (let k = 0; k < 30000; k++) seen[C.randomInt(10)]++;
    ok(seen.every((c) => c > 2500 && c < 3500), 'randomInt(10) covers 0..9 evenly', seen);
    const seen2 = new Set(); for (let k = 0; k < 2000; k++) { const v = C.randomInt(5, 8); ok(v >= 5 && v < 8, 'randomInt(5, 8) stays in range'); seen2.add(v); }
    eq([...seen2].sort(), [5, 6, 7], 'randomInt(5, 8) produces every value');
    ok(C.randomInt(-3, -2) === -3, 'randomInt(-3, -2) has one possible value');
    for (const [a, b] of [[5, 5], [5, 4], [0, 0]]) { const e = errOf(() => C.randomInt(a, b)); ok(e && e.code === 'ERR_OUT_OF_RANGE', 'randomInt(' + a + ', ' + b + ') throws ERR_OUT_OF_RANGE', e); }
    const e2 = errOf(() => C.randomInt(1.5)); ok(e2 && e2.code === 'ERR_INVALID_ARG_TYPE', 'randomInt(1.5) throws ERR_INVALID_ARG_TYPE', e2);
    const big = C.randomInt(2 ** 47); ok(Number.isInteger(big) && big >= 0 && big < 2 ** 47, 'randomInt with a huge range');
  }
  {
    const buf = Buffer.alloc(40, 7), same1 = C.randomFillSync(buf, 10, 20);
    ok(same1 === buf && buf.subarray(0, 10).every((x) => x === 7) && buf.subarray(30).every((x) => x === 7), 'randomFillSync only touches the requested region');
    ok(buf.subarray(10, 30).some((x) => x !== 7), 'randomFillSync fills the region');
    const u32 = new Uint32Array(8); C.randomFillSync(u32); ok(u32.some((x) => x !== 0), 'randomFillSync accepts a Uint32Array');
    const e = errOf(() => C.randomFillSync(Buffer.alloc(4), 5)); ok(e && e.code === 'ERR_OUT_OF_RANGE', 'randomFillSync offset out of range', e);
  }
  {
    ok(C.timingSafeEqual(Buffer.from('abc'), Buffer.from('abc')) === true, 'timingSafeEqual equal');
    ok(C.timingSafeEqual(Buffer.from('abc'), Buffer.from('abd')) === false, 'timingSafeEqual different');
    const e = errOf(() => C.timingSafeEqual(Buffer.from('abc'), Buffer.from('ab'))), n = errOf(() => nodeCrypto.timingSafeEqual(Buffer.from('abc'), Buffer.from('ab')));
    ok(e && n && e.code === n.code && e.name === n.name, 'timingSafeEqual length mismatch error equals node', { e, n });
  }
  ok(ALGS.every((a) => C.getHashes().includes(a)), 'getHashes lists the supported digests');
  {
    const e = errOf(() => C.createCipheriv('aes-256-gcm', Buffer.alloc(32), Buffer.alloc(12)));
    ok(e && /not available/.test(e.msg) && logged.some((m) => /aes-256-gcm/.test(m)), 'a cipher that is not implemented throws a clear error and is logged', e);
    ok(errOf(() => C.createCipheriv('aes-256-cbc', Buffer.alloc(32), Buffer.alloc(16))) === null, 'aes-256-cbc is implemented (details: aes.test.js)');
    ok(typeof C.createSign === 'function' && errOf(() => C.createSign('sha256')) !== null, 'createSign throws');
  }
}
// callback flavours
async function cryptoCallbacks() {
  const p = (fn, ...a) => new Promise((res, rej) => fn(...a, (e, v) => e ? rej(e) : res(v)));
  const b = await p(C.randomBytes, 8); ok(b.length === 8, 'randomBytes with a callback');
  const i = await p(C.randomInt, 100); ok(i >= 0 && i < 100, 'randomInt(max, cb)');
  const i2 = await p(C.randomInt, 10, 12); ok(i2 >= 10 && i2 < 12, 'randomInt(min, max, cb)');
  const f = await p(C.randomFill, Buffer.alloc(16)); ok(f.length === 16 && f.some((x) => x !== 0), 'randomFill with a callback');
  const k = await p(C.pbkdf2, 'pw', 'salt', 5, 20, 'sha256'); ok(same(k, nodeCrypto.pbkdf2Sync('pw', 'salt', 5, 20, 'sha256')), 'pbkdf2 with a callback');
  const err = await new Promise((res) => C.pbkdf2('pw', 'salt', 5, 20, 'nope', (e) => res(e))); ok(err && err.code === 'ERR_CRYPTO_INVALID_DIGEST', 'pbkdf2 reports a bad digest through the callback');
}


main().then(cryptoCallbacks).then(() => {
  console.log('\n' + pass + ' passed, ' + fail + ' failed');
  process.exit(fail === 0 ? 0 : 1);
}).catch((e) => { console.log('TEST CRASHED: ' + (e && e.stack || e)); process.exit(1); });
