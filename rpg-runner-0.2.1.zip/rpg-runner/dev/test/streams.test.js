'use strict';
// Differential test: every scenario of stream-scenarios.js / fs-scenarios.js runs against REAL Node and against the shim's own
// stream / fs code (dev/shim-parts loaded into Node, see shim-node-harness.js); both logs must be identical.
// (shim.test.js runs the same scenarios once more inside the real shim in Chromium, on the real Java file bridge.)
//
//   usage: node dev/test/streams.test.js [filter]
const fs = require('fs');
const os = require('os');
const path = require('path');
const { loadShim } = require('./shim-node-harness');
const { sleep, show, bigData, nodeEnv, norm, withTimeout } = require('./scenario-env');

const filter = process.argv[2] || '';
const scenarios = Object.assign({}, require('./stream-scenarios'), require('./fs-scenarios'));

let pass = 0, fail = 0;
let currentLog = null;
process.on('uncaughtException', (e) => { if (currentLog) currentLog.push('UNCAUGHT ' + (e && e.code ? e.code + ' ' : '') + (e && e.message)); else throw e; });
process.on('unhandledRejection', (e) => { if (currentLog) currentLog.push('UNHANDLED REJECTION ' + (e && e.message)); else throw e; });

function shimEnv(log) {
  const T = fs.mkdtempSync(path.join(os.tmpdir(), 'rr-shim-'));
  const sh = loadShim(T);
  return {
    T,
    env: { stream: sh.streamMod, fs: sh.fs, zlib: sh.zlib, crypto: sh.crypto, StringDecoder: sh.StringDecoder, Buffer: sh.Buffer, T, log: (s) => log.push(String(s)), sleep, show, bigData: (n) => bigData(sh.Buffer, n) },
    finish: () => {
      sh.flush();
      const errs = sh.logs.filter((l) => /^E /.test(l));
      fs.rmSync(T, { recursive: true, force: true });
      return errs;
    },
  };
}

async function run(fn, makeEnv) {
  const log = [];
  currentLog = log;
  const e = makeEnv(log);
  try { await withTimeout(Promise.resolve(fn(e.env)), 5000, 'scenario'); } catch (err) { log.push('SCENARIO THREW ' + (err && err.code ? err.code + ' ' : '') + (err && err.message)); }
  await sleep(15);
  return { log: norm(log, e.T), extra: e.finish() || [] };
}

async function main() {
  const names = Object.keys(scenarios).filter((n) => n.indexOf(filter) >= 0);
  for (const name of names) {
    const a = await run(scenarios[name], nodeEnv);
    const b = await run(scenarios[name], shimEnv);
    const same = JSON.stringify(a.log) === JSON.stringify(b.log) && b.extra.length === 0;
    if (same) { pass++; continue; }
    fail++;
    console.log('FAIL: ' + name);
    const n = Math.max(a.log.length, b.log.length);
    for (let i = 0; i < n; i++) {
      const x = a.log[i] === undefined ? '' : a.log[i], y = b.log[i] === undefined ? '' : b.log[i];
      console.log((x === y ? '    ' : ' >> ') + 'node: ' + x + (x === y ? '' : '\n        shim: ' + y));
    }
    if (b.extra.length) console.log('    shim logged errors: ' + JSON.stringify(b.extra));
  }
  console.log('streams/fs differential: ' + pass + ' passed, ' + fail + ' failed (' + names.length + ' scenarios)');
  process.exit(fail ? 1 : 0);
}
main().catch((e) => { console.error(e); process.exit(2); });
