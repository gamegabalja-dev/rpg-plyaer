'use strict';
// Chromium integration test for the NW.js compatibility layer (shim.js) and the touch overlay (overlay.js).
// It runs the REAL Java GameServer (via DevServer) and a mock of the Android JS bridge (window.RRNative) that talks to
// the real NativeFs through a second HTTP port, so the page code is exercised exactly like inside the app's WebView.
//
//   usage: node dev/test/shim.test.js          (needs: compiled classes in $RR_CLASSES, playwright)
const { chromium } = require('playwright');
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const nodeZlib = require('zlib');
const nodeCrypto = require('crypto');
const buildMvFixture = require('./fixture-mv');
const { GAME_SPEC } = require('./bridge-spec');

const ROOT = path.resolve(__dirname, '..', '..');
const CLASSES = process.env.RR_CLASSES || path.join(ROOT, 'dev', '.build', 'classes');
const ASSETS = path.join(ROOT, 'app', 'src', 'main', 'assets');
const SHOTS = process.env.RR_SHOTS || path.join(ROOT, 'dev', '.build', 'shots');
// The WebView is told to look like desktop Chrome so MV picks WebGL + ogg like on a PC
const DESKTOP_UA = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';

let pass = 0, fail = 0;
function ok(cond, msg, extra) {
  if (cond) { pass++; } else { fail++; console.log('FAIL: ' + msg + (extra !== undefined ? '   -> ' + JSON.stringify(extra) : '')); }
}
function eq(got, want, msg) { ok(JSON.stringify(got) === JSON.stringify(want), msg, { got, want }); }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// ---------------------------------------------------------------------------------------------- dev server process
function startDevServer(gameDir, dataDir, extra, assetsDir) {
  return new Promise((resolve, reject) => {
    const args = ['-Dfile.encoding=UTF-8', '-Dsun.jnu.encoding=UTF-8', '-cp', CLASSES, 'app.rpgrunner.DevServer', gameDir, assetsDir || ASSETS, dataDir].concat(extra || []);
    const p = spawn('java', args, { stdio: ['pipe', 'pipe', 'inherit'], env: Object.assign({}, process.env, { LC_ALL: 'C.UTF-8', LANG: 'C.UTF-8' }) });
    const info = { proc: p, lines: [], port: 0, bridge: 0, url: '', id: '' };
    let buf = '';
    const timer = setTimeout(() => reject(new Error('DevServer did not start')), 20000);
    p.stdout.setEncoding('utf8');
    p.stdout.on('data', (d) => {
      buf += d;
      let i;
      while ((i = buf.indexOf('\n')) >= 0) {
        const line = buf.slice(0, i); buf = buf.slice(i + 1);
        info.lines.push(line);
        let m;
        if ((m = /^PORT (\d+)/.exec(line))) info.port = +m[1];
        else if ((m = /^BRIDGE (\d+)/.exec(line))) info.bridge = +m[1];
        else if ((m = /^URL (.*)/.exec(line))) info.url = m[1];
        else if ((m = /^ID (.*)/.exec(line))) { info.id = m[1]; clearTimeout(timer); resolve(info); }
        else if (/^ERR /.test(line)) { clearTimeout(timer); reject(new Error(line)); }
      }
    });
    p.on('exit', (c) => { if (!info.id) { clearTimeout(timer); reject(new Error('DevServer exited early: ' + c)); } });
    info.stop = () => { try { p.stdin.end(); } catch (e) { /* ignore */ } setTimeout(() => p.kill(), 1500).unref(); };
    info.logs = (prefix) => info.lines.filter((l) => l.startsWith(prefix));
  });
}

// ---------------------------------------------------------------------------------------------- window.RRNative mock
// Same method names/arity/types as the Java @JavascriptInterface methods of GameActivity; strict on purpose: the real
// bridge throws when a method is called with the wrong number of arguments.
function mockBridgeScript(bridgePort) {
  return `(function () {
  var BRIDGE = 'http://127.0.0.1:${bridgePort}/bridge';
  var SPEC = ${JSON.stringify(GAME_SPEC)};
  function call(name, args) {
    var spec = SPEC[name];
    if (args.length !== spec.length) throw new Error('Java method ' + name + ' with ' + args.length + ' argument(s) not found');
    var req = { m: name, a: '', b: '', f: false }, si = 0;
    for (var i = 0; i < spec.length; i++) {
      var v = args[i];
      if (spec.charAt(i) === 'b') { if (typeof v !== 'boolean') throw new Error('argument ' + i + ' of ' + name + ' must be boolean, got ' + typeof v); req.f = v; }
      else { if (typeof v !== 'string') throw new Error('argument ' + i + ' of ' + name + ' must be string, got ' + typeof v); if (si++ === 0) req.a = v; else req.b = v; }
    }
    var x = new XMLHttpRequest();
    x.open('POST', BRIDGE, false);
    x.setRequestHeader('Content-Type', 'text/plain');
    x.send(JSON.stringify(req));
    return x.responseText;
  }
  var N = {};
  Object.keys(SPEC).forEach(function (k) { N[k] = function () { return call(k, arguments); }; });
  window.RRNative = N;
})();`;
}

// ---------------------------------------------------------------------------------------------- helpers
function httpGet(port, p, headers, method) {
  return new Promise((resolve, reject) => {
    const req = http.request({ host: '127.0.0.1', port, path: p, method: method || 'GET', headers: headers || {} }, (res) => {
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }));
    });
    req.on('error', reject);
    req.end();
  });
}
const encPath = (p) => p.split('/').map(encodeURIComponent).join('/');

async function newGamePage(browser, srv, opts) {
  opts = opts || {};
  const context = await browser.newContext({
    viewport: { width: 915, height: 412 }, hasTouch: true, isMobile: false, deviceScaleFactor: 2, userAgent: DESKTOP_UA,
  });
  if (opts.bridge !== false) await context.addInitScript({ content: mockBridgeScript(srv.bridge) });
  const page = await context.newPage();
  const pageErrors = [];
  page.on('pageerror', (e) => pageErrors.push(String(e && e.message || e)));
  const consoleLines = [];
  page.on('console', (m) => consoleLines.push(m.type() + ': ' + m.text()));
  await page.goto(srv.url);
  await page.waitForFunction(() => window.__fixture && window.__fixture.booted === true, null, { timeout: 15000 });
  return { context, page, pageErrors, consoleLines };
}

async function main() {
  fs.mkdirSync(SHOTS, { recursive: true });
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'rr-shimtest-'));
  const gameDir = buildMvFixture(path.join(work, 'Games', 'Fixture 게임 MV'));
  const dataDir = path.join(work, 'data');
  const www = path.join(gameDir, 'www');

  const browser = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required'] });
  const srv = await startDevServer(gameDir, dataDir, []);
  console.log('dev server up: ' + srv.url);
  let g;
  try {
    g = await newGamePage(browser, srv);
    const { page } = g;

    // ---------------------------------------------------------------------------------------- bootstrap / environment
    const env = await page.evaluate(() => ({
      plugin: window.__fixture.plugin,
      isNwjs: Utils.isNwjs(), mobile: Utils.isMobileDevice(),
      moduleType: typeof module, exportsType: typeof exports, pixi: typeof PIXI, globalSelf: typeof global,
      platform: process.platform, mainFile: process.mainModule.filename, cwd: process.cwd(), home: process.env.HOME,
      nwv: process.versions.nw, nodeWebkit: process.versions['node-webkit'], argvLen: process.argv.length,
      uaHasAndroid: /Android/.test(navigator.userAgent), rrReady: !!(window.__RR && window.__RR.ready),
      title: document.title, viewport: (document.querySelector('meta[name=viewport]') || {}).content || null,
      rendererOpt: Utils.isOptionValid('canvas'), scripts: Array.from(document.scripts).map((s) => s.src || '(inline)').slice(0, 4),
    }));
    ok(env.rrReady, 'shim reports ready');
    ok(env.isNwjs === true, 'Utils.isNwjs() is true');
    ok(env.mobile === false, 'Utils.isMobileDevice() is false with the desktop UA (-> WebGL + ogg like on a PC)');
    eq(env.moduleType, 'undefined', 'no global "module" (pixi UMD must attach to window)');
    eq(env.exportsType, 'undefined', 'no global "exports"');
    eq(env.pixi, 'object', 'PIXI is defined');
    eq(env.plugin.pixi, 'fake-4.x', 'plugin ran after pixi');
    eq(env.globalSelf, 'object', 'global exists');
    eq(env.platform, 'linux', 'process.platform');
    eq(env.mainFile, www + '/index.html', 'process.mainModule.filename is the main html path');
    eq(env.cwd, gameDir, 'process.cwd() is the game folder');
    eq(env.home, dataDir, 'HOME points to the app data dir');
    ok(/^\d+\.\d+/.test(env.nwv) && env.nwv === env.nodeWebkit, 'process.versions.nw', env.nwv);
    eq(env.plugin.base, www, 'plugin: dirname(mainModule.filename) == www');
    eq(env.plugin.hasSystem, true, 'plugin: fs.existsSync finds data/System.json');
    eq(env.plugin.helper, { x: 1, dir: 'js/plugins', file: 'helper.js' }, 'plugin: relative require() with __dirname/__filename');
    eq(env.plugin.fakemod, { name: 'fakemod', file: 'fakemod/lib/main.js', requireType: 'function' }, 'plugin: bare require via node_modules + package.json main');
    eq(env.plugin.pkg, 'fixture-mv', 'plugin: require of a .json file');
    ok(/viewport-fit=cover/.test(env.viewport || '') && /user-scalable=no/.test(env.viewport || ''), 'viewport meta fixed up', env.viewport);
    eq(env.title, 'Fixture MV', 'document title untouched');
    eq(env.rendererOpt, 0, 'no ?canvas option by default (renderer auto)');

    // ---------------------------------------------------------------------------------------- MV save / load
    const sv = await page.evaluate(() => {
      const json = JSON.stringify({ gold: 123, name: '한글 ✓ "quote" \\ back', n: [1, 2, 3] });
      const out = {};
      out.existsBefore = StorageManager.exists(1);
      StorageManager.save(1, json);
      StorageManager.save(0, '{"global":true}');
      StorageManager.save(-1, '{"cfg":1}');
      out.existsAfter = StorageManager.exists(1);
      out.loaded = StorageManager.load(1);
      out.same = out.loaded === json;
      out.listing = require('fs').readdirSync(StorageManager.localFileDirectoryPath()).sort();
      StorageManager.remove(0);
      out.removed = !StorageManager.exists(0);
      return out;
    });
    eq(sv.existsBefore, false, 'save: file does not exist initially');
    eq(sv.existsAfter, true, 'save: exists after saving');
    eq(sv.same, true, 'save: load() returns exactly what save() stored (unicode, quotes, backslash)');
    eq(sv.listing, ['config.rpgsave', 'file1.rpgsave', 'global.rpgsave'], 'save: files land in www/save/');
    eq(sv.removed, true, 'save: remove() deletes the file');
    ok(fs.existsSync(path.join(www, 'save', 'file1.rpgsave')), 'save: file really exists on disk');
    const onDisk = fs.readFileSync(path.join(www, 'save', 'file1.rpgsave'), 'utf8');
    ok(Buffer.from(onDisk, 'base64').toString('utf8').indexOf('"gold":123') > 0, 'save: on-disk content is the MV save format');
    ok(!fs.existsSync(path.join(www, 'save', 'global.rpgsave')), 'save: removed file is gone on disk');

    // ---------------------------------------------------------------------------------------- fs API
    const fsr = await page.evaluate(async () => {
      const fs = require('fs'), path = require('path');
      const T = path.join(path.dirname(process.mainModule.filename), 'tmp-test');
      const o = {};
      const t = (f) => { try { return { v: f() }; } catch (e) { return { code: e.code, errno: e.errno, syscall: e.syscall, msg: e.message, isErr: e instanceof Error }; } };
      o.mkdirRec = t(() => fs.mkdirSync(T + '/a/b/c', { recursive: true }));
      o.mkdirEexist = t(() => fs.mkdirSync(T + '/a'));
      o.exists = [fs.existsSync(T), fs.existsSync(T + '/a/b/c'), fs.existsSync(T + '/nope'), fs.existsSync(T + '/')];
      fs.writeFileSync(T + '/t.txt', 'héllo 한글 ✓');
      o.utf8 = fs.readFileSync(T + '/t.txt', 'utf8');
      o.utf8b = fs.readFileSync(T + '/t.txt', { encoding: 'utf8' });
      const buf = fs.readFileSync(T + '/t.txt');
      o.bufIsBuffer = Buffer.isBuffer(buf); o.bufLen = buf.length; o.bufByteLength = Buffer.byteLength('héllo 한글 ✓');
      o.stat = t(() => { const s = fs.statSync(T + '/t.txt'); return { size: s.size, file: s.isFile(), dir: s.isDirectory(), mtime: s.mtime instanceof Date, mtimeMs: typeof s.mtimeMs }; });
      o.statDir = t(() => fs.statSync(T + '/a').isDirectory());
      o.statMissing = t(() => fs.statSync(T + '/nope'));
      o.statNoThrow = t(() => fs.statSync(T + '/nope', { throwIfNoEntry: false }));
      const all = Buffer.alloc(256); for (let i = 0; i < 256; i++) all[i] = i;
      fs.writeFileSync(T + '/bin.dat', all);
      const back = fs.readFileSync(T + '/bin.dat');
      o.binOk = back.length === 256 && back.every((v, i) => v === i);
      o.binB64 = fs.readFileSync(T + '/bin.dat', 'base64') === all.toString('base64');
      o.binHex = fs.readFileSync(T + '/bin.dat', 'hex').slice(0, 12);
      o.binLatin1 = fs.readFileSync(T + '/bin.dat', 'latin1').charCodeAt(200);
      fs.writeFileSync(T + '/u8.dat', new Uint8Array([1, 2, 3, 250, 251]));
      o.u8 = Array.from(fs.readFileSync(T + '/u8.dat'));
      fs.writeFileSync(T + '/ab.dat', new Uint8Array([9, 8, 7]).buffer);
      o.ab = Array.from(fs.readFileSync(T + '/ab.dat'));
      fs.writeFileSync(T + '/hex.dat', 'cafebabe', 'hex');
      o.hexWrite = Array.from(fs.readFileSync(T + '/hex.dat'));
      fs.appendFileSync(T + '/t.txt', '+more');
      o.appended = fs.readFileSync(T + '/t.txt', 'utf8');
      fs.writeFileSync(T + '/t.txt', 'x', { flag: 'a' });
      o.flagA = fs.readFileSync(T + '/t.txt', 'utf8').slice(-6);
      o.readdir = fs.readdirSync(T).sort();
      o.dirent = fs.readdirSync(T, { withFileTypes: true }).filter((d) => d.name === 'a' || d.name === 't.txt').map((d) => [d.name, d.isDirectory(), d.isFile()]).sort();
      fs.renameSync(T + '/t.txt', T + '/renamed.txt');
      o.renamed = [fs.existsSync(T + '/t.txt'), fs.existsSync(T + '/renamed.txt')];
      fs.copyFileSync(T + '/renamed.txt', T + '/copy.txt');
      o.copied = fs.readFileSync(T + '/copy.txt', 'utf8') === fs.readFileSync(T + '/renamed.txt', 'utf8');
      fs.unlinkSync(T + '/copy.txt');
      o.unlinked = !fs.existsSync(T + '/copy.txt');
      o.readMissing = t(() => fs.readFileSync(T + '/nope.txt'));
      o.readMissingUtf8 = t(() => fs.readFileSync(T + '/nope.txt', 'utf8'));
      o.unlinkMissing = t(() => fs.unlinkSync(T + '/nope.txt'));
      o.readdirMissing = t(() => fs.readdirSync(T + '/nope'));
      o.rmdirNonEmpty = t(() => fs.rmdirSync(T + '/a'));
      o.readDir = t(() => fs.readFileSync(T + '/a'));
      o.badArg = t(() => fs.readFileSync(undefined));
      o.outside = t(() => fs.writeFileSync('/etc/rr-should-not-exist', 'x'));
      o.outsideRead = t(() => fs.readFileSync('/etc/hostname', 'utf8'));
      o.relative = t(() => { fs.writeFileSync('rel-test.txt', 'rel'); return fs.existsSync(process.cwd() + '/rel-test.txt'); });
      const uni = T + '/한글 파일 #1?%25&.txt';
      fs.writeFileSync(uni, 'unicode path');
      o.unicodePath = t(() => fs.readFileSync(uni, 'utf8'));
      o.unicodeList = fs.readdirSync(T).includes('한글 파일 #1?%25&.txt');
      // 3 MB round trip
      const big = Buffer.alloc(3 * 1024 * 1024); for (let i = 0; i < big.length; i += 4099) big[i] = (i / 4099) & 255;
      const t0 = performance.now();
      fs.writeFileSync(T + '/big.dat', big);
      const bigBack = fs.readFileSync(T + '/big.dat');
      o.bigMs = Math.round(performance.now() - t0);
      o.bigOk = bigBack.length === big.length && Buffer.compare(big, bigBack) === 0;
      o.realpath = t(() => fs.realpathSync(T + '/a/../renamed.txt'));
      // promises + callbacks
      o.promise = await fs.promises.readFile(T + '/renamed.txt', 'utf8').then((s) => s.length, (e) => 'ERR ' + e.code);
      o.promiseErr = await fs.promises.readFile(T + '/nope.txt').then(() => 'resolved', (e) => e.code);
      o.promiseWrite = await fs.promises.writeFile(T + '/p.txt', 'p').then(() => fs.readFileSync(T + '/p.txt', 'utf8'));
      o.cb = await new Promise((res) => fs.readFile(T + '/renamed.txt', 'utf8', (err, d) => res([err, typeof d])));
      o.cbErr = await new Promise((res) => fs.readFile(T + '/nope', (err, d) => res([err && err.code, d])));
      o.cbExists = await new Promise((res) => fs.exists(T + '/renamed.txt', (b) => res(b)));
      o.cbStat = await new Promise((res) => fs.stat(T + '/a', (err, s) => res([err, s.isDirectory()])));
      o.cbMkdir = await new Promise((res) => fs.mkdir(T + '/cbdir', (err) => res(err)));
      o.cbReaddir = await new Promise((res) => fs.readdir(T + '/cbdir', (err, l) => res([err, l])));
      o.cbWrite = await new Promise((res) => fs.writeFile(T + '/cb.txt', 'cb', (err) => res(err)));
      const util = require('util');
      o.promisified = await util.promisify(fs.readFile)(T + '/cb.txt', 'utf8');
      o.rmRec = t(() => fs.rmSync(T, { recursive: true, force: true }));
      o.afterRm = fs.existsSync(T);
      o.rmForce = t(() => fs.rmSync(T + '/gone', { force: true }));
      return o;
    });
    ok(fsr.mkdirRec.code === undefined, 'fs: mkdirSync recursive ok', fsr.mkdirRec);
    eq(fsr.mkdirEexist.code, 'EEXIST', 'fs: mkdirSync on existing dir -> EEXIST');
    eq(fsr.exists, [true, true, false, true], 'fs: existsSync (incl. trailing slash)');
    eq(fsr.utf8, 'héllo 한글 ✓', 'fs: utf8 round trip');
    eq(fsr.utf8b, 'héllo 한글 ✓', 'fs: {encoding:"utf8"} form');
    ok(fsr.bufIsBuffer && fsr.bufLen === fsr.bufByteLength, 'fs: no-encoding read returns a Buffer with the right length', [fsr.bufLen, fsr.bufByteLength]);
    eq(fsr.stat.v, { size: fsr.bufLen, file: true, dir: false, mtime: true, mtimeMs: 'number' }, 'fs: statSync file');
    eq(fsr.statDir.v, true, 'fs: statSync dir');
    eq(fsr.statMissing.code, 'ENOENT', 'fs: statSync missing -> ENOENT');
    eq(fsr.statNoThrow.v, undefined, 'fs: statSync throwIfNoEntry:false');
    eq(fsr.binOk, true, 'fs: all 256 byte values survive a binary round trip');
    eq(fsr.binB64, true, 'fs: base64 read matches Buffer.toString("base64")');
    eq(fsr.binHex, '000102030405', 'fs: hex read');
    eq(fsr.binLatin1, 200, 'fs: latin1 read');
    eq(fsr.u8, [1, 2, 3, 250, 251], 'fs: write Uint8Array');
    eq(fsr.ab, [9, 8, 7], 'fs: write ArrayBuffer');
    eq(fsr.hexWrite, [0xca, 0xfe, 0xba, 0xbe], 'fs: write with hex encoding');
    eq(fsr.appended, 'héllo 한글 ✓+more', 'fs: appendFileSync');
    ok(fsr.flagA.endsWith('ex'), 'fs: writeFileSync flag "a" appends', fsr.flagA);
    ok(['a', 'bin.dat', 't.txt', 'u8.dat'].every((n) => fsr.readdir.includes(n)), 'fs: readdirSync', fsr.readdir);
    eq(fsr.dirent, [['a', true, false], ['t.txt', false, true]], 'fs: readdirSync withFileTypes');
    eq(fsr.renamed, [false, true], 'fs: renameSync');
    eq(fsr.copied, true, 'fs: copyFileSync');
    eq(fsr.unlinked, true, 'fs: unlinkSync');
    eq(fsr.readMissing.code, 'ENOENT', 'fs: readFileSync missing -> ENOENT');
    eq(fsr.readMissing.errno, -2, 'fs: errno -2');
    eq(fsr.readMissing.syscall, 'open', 'fs: syscall open');
    ok(fsr.readMissing.isErr && /^ENOENT: no such file or directory, open '.*nope\.txt'$/.test(fsr.readMissing.msg), 'fs: Node-style error message', fsr.readMissing.msg);
    eq(fsr.readMissingUtf8.code, 'ENOENT', 'fs: readFileSync(utf8) missing -> ENOENT');
    eq(fsr.unlinkMissing.code, 'ENOENT', 'fs: unlinkSync missing -> ENOENT');
    eq(fsr.readdirMissing.code, 'ENOENT', 'fs: readdirSync missing -> ENOENT');
    eq(fsr.rmdirNonEmpty.code, 'ENOTEMPTY', 'fs: rmdirSync non-empty -> ENOTEMPTY');
    ok(fsr.readDir.code === 'EISDIR' || fsr.readDir.code === 'ENOENT', 'fs: reading a directory fails with EISDIR/ENOENT', fsr.readDir);
    eq(fsr.badArg.code, 'ERR_INVALID_ARG_TYPE', 'fs: non-string path -> ERR_INVALID_ARG_TYPE');
    ok(fsr.outside.code === 'EACCES', 'fs: writing outside the game/data folders is refused (EACCES)', fsr.outside);
    ok(fsr.outsideRead.code !== undefined, 'fs: reading outside the game/data folders is refused', fsr.outsideRead);
    ok(!fs.existsSync('/etc/rr-should-not-exist'), 'fs: nothing was written outside');
    eq(fsr.relative.v, true, 'fs: relative paths resolve against process.cwd()');
    eq(fsr.unicodePath.v, 'unicode path', 'fs: path with Korean, space, #, ?, %, & round-trips');
    eq(fsr.unicodeList, true, 'fs: readdirSync lists the unicode name');
    eq(fsr.bigOk, true, 'fs: 3 MB binary round trip');
    ok(fsr.bigMs < 5000, 'fs: 3 MB round trip is fast enough (' + fsr.bigMs + ' ms)');
    ok(fsr.realpath.v && fsr.realpath.v.endsWith('/tmp-test/renamed.txt'), 'fs: realpathSync normalizes', fsr.realpath);
    eq(fsr.promise, 'héllo 한글 ✓+morex'.length, 'fs.promises.readFile');
    eq(fsr.promiseErr, 'ENOENT', 'fs.promises rejects with ENOENT');
    eq(fsr.promiseWrite, 'p', 'fs.promises.writeFile');
    eq(fsr.cb, [null, 'string'], 'fs.readFile callback');
    eq(fsr.cbErr, ['ENOENT', undefined], 'fs.readFile callback error');
    eq(fsr.cbExists, true, 'fs.exists callback');
    eq(fsr.cbStat, [null, true], 'fs.stat callback');
    eq(fsr.cbMkdir, null, 'fs.mkdir callback');
    eq(fsr.cbReaddir, [null, []], 'fs.readdir callback');
    eq(fsr.cbWrite, null, 'fs.writeFile callback');
    eq(fsr.promisified, 'cb', 'util.promisify(fs.readFile)');
    ok(fsr.rmRec.code === undefined && fsr.afterRm === false, 'fs: rmSync recursive removes the tree', fsr);
    ok(fsr.rmForce.code === undefined, 'fs: rmSync force on a missing path does not throw');
    ok(!fs.existsSync(path.join(www, 'tmp-test')), 'fs: test tree really gone from disk');
    ok(fs.existsSync(path.join(gameDir, 'rel-test.txt')), 'fs: relative write landed in the game folder (cwd)');

    // ---------------------------------------------------------------------------------------- require / nw / process / Buffer
    const req = await page.evaluate(async () => {
      const o = {};
      const t = (f) => { try { return { v: f() }; } catch (e) { return { code: e.code, msg: e.message }; } };
      o.builtins = [typeof require('fs').readFileSync, require('path').sep, require('os').platform(), require('util').format('%s-%d-%j', 'a', 5, { b: 1 }), require('events') === require('events').EventEmitter, typeof require('crypto').randomBytes(4).length, require('node:path') === require('path')];
      o.missing = t(() => require('does-not-exist'));
      o.missingRel = t(() => require('./nope/nothing'));
      o.http = t(() => typeof require('http'));
      o.httpUse = t(() => require('http').get('http://x'));
      o.greenworks = t(() => { const g = require('greenworks'); return [typeof g.init, g.init(), g.isGreenworksSupported()]; });
      o.greenworksPath = t(() => typeof require('./js/libs/greenworks'));
      o.nodeFile = t(() => typeof require('./js/libs/steam_api64.node'));
      o.nwgui = t(() => [typeof require('nw.gui').Window.get, require('nw.gui') === nw]);
      o.resolve = t(() => require.resolve('fakemod').split('/').slice(-3).join('/'));
      o.cacheSame = require('./js/plugins/helper.js') === require('./js/plugins/helper.js');
      const ee = new (require('events'))();
      let got = [];
      ee.on('x', (a) => got.push('on' + a)); ee.once('x', (a) => got.push('once' + a));
      ee.emit('x', 1); ee.emit('x', 2);
      o.events = got;
      const w = nw.Window.get();
      let closeSeen = 0;
      w.on('close', function () { closeSeen++; });
      w.close();
      o.winCloseEvent = closeSeen;
      o.win = { fs: w.isFullscreen, w: w.width === innerWidth, h: w.height === innerHeight, getSame: nw.Window.get() === w, titleSet: (w.title = 'T2', document.title) };
      document.title = 'Fixture MV';
      o.winUnknown = typeof w.someUnknownThing;
      o.app = { name: nw.App.manifest.name, mainOk: nw.App.manifest.main, data: nw.App.dataPath, argv: nw.App.argv };
      o.clip = nw.Clipboard.get().get('text');
      o.screens = nw.Screen.screens.length;
      o.hr = process.hrtime().length;
      o.tick = await new Promise((res) => process.nextTick((a) => res(a), 'tick'));
      o.uptime = typeof process.uptime();
      o.memory = typeof process.memoryUsage().heapUsed;
      // Buffer
      const b = Buffer.from('héllo');
      o.buf = {
        len: b.length, hex: b.toString('hex'), b64: b.toString('base64'), fromHex: Buffer.from('cafe', 'hex').toString('base64'),
        concat: Buffer.concat([Buffer.from('ab'), Buffer.from('cd')]).toString(), slice: b.slice(1, 3).toString('hex'), idx: b.indexOf('l'), eq: b.equals(Buffer.from('héllo')),
        alloc: Array.from(Buffer.alloc(3, 7)), json: JSON.stringify(Buffer.from([1, 2])), isBuf: [Buffer.isBuffer(b), Buffer.isBuffer(new Uint8Array(1))],
        rw: (() => { const x = Buffer.alloc(8); x.writeUInt32LE(0xdeadbeef, 0); x.writeUInt16BE(0x1234, 4); return [x.readUInt32LE(0), x.readUInt16BE(4), x.readInt8(0), x.readUInt8(3)]; })(),
        fromArr: Array.from(Buffer.from([1, 2, 300])), fromAb: Buffer.from(new Uint8Array([5, 6]).buffer).length, sliceIsBuf: Buffer.isBuffer(b.slice(0, 1)),
        str: b.toString('utf8', 0, 3), ascii: Buffer.from('abc').toString('ascii'), copy: (() => { const d = Buffer.alloc(4); Buffer.from('xy').copy(d, 1); return Array.from(d); })(),
      };
      o.nw = typeof nw.Window.open('http://x');
      o.exitFn = typeof process.exit;
      return o;
    });
    eq(req.builtins, ['function', '/', 'linux', "a-5-{\"b\":1}", true, 'number', true], 'require: builtin modules (fs, path, os, util, events, crypto, node: prefix)');
    eq(req.missing.code, 'MODULE_NOT_FOUND', 'require: missing module -> MODULE_NOT_FOUND');
    ok(/Cannot find module 'does-not-exist'/.test(req.missing.msg), 'require: Node-style message');
    eq(req.missingRel.code, 'MODULE_NOT_FOUND', 'require: missing relative module');
    ok(req.http.code === undefined, 'require("http") itself does not throw');
    ok(req.httpUse.code === undefined && /not available/.test(req.httpUse.msg || ''), 'require("http").get() throws a clear error', req.httpUse);
    eq(req.greenworks.v, ['function', undefined, undefined], 'require("greenworks") is a harmless stub');
    eq(req.greenworksPath.v, 'function', 'require("./js/libs/greenworks") is a stub');
    eq(req.nodeFile.v, 'function', 'require of a .node addon is a stub');
    eq(req.nwgui.v, ['function', true], 'require("nw.gui") is nw');
    eq(req.resolve.v, 'fakemod/lib/main.js', 'require.resolve');
    eq(req.cacheSame, true, 'require: module cache');
    eq(req.events, ['on1', 'once1', 'on2'], 'EventEmitter on/once');
    eq(req.winCloseEvent, 1, 'nw.Window.close() with a close handler only emits "close"');
    eq(req.win, { fs: true, w: true, h: true, getSame: true, titleSet: 'T2' }, 'nw.Window basics');
    eq(req.winUnknown, 'function', 'nw.Window unknown members are harmless no-ops');
    eq(req.app, { name: 'fixture-mv', mainOk: 'www/index.html', data: dataDir, argv: [] }, 'nw.App');
    eq(req.clip, '', 'nw.Clipboard');
    eq(req.screens, 1, 'nw.Screen');
    eq(req.hr, 2, 'process.hrtime');
    eq(req.tick, 'tick', 'process.nextTick');
    eq(req.uptime, 'number', 'process.uptime');
    eq(req.memory, 'number', 'process.memoryUsage');
    eq(req.buf.len, 6, 'Buffer.from(utf8).length');
    eq(req.buf.hex, '68c3a96c6c6f', 'Buffer hex');
    eq(req.buf.b64, 'aMOpbGxv', 'Buffer base64');
    eq(req.buf.fromHex, 'yv4=', 'Buffer.from(hex)');
    eq(req.buf.concat, 'abcd', 'Buffer.concat');
    eq(req.buf.slice, 'c3a9', 'Buffer.slice');
    eq(req.buf.idx, 3, 'Buffer.indexOf');
    eq(req.buf.eq, true, 'Buffer.equals');
    eq(req.buf.alloc, [7, 7, 7], 'Buffer.alloc fill');
    eq(req.buf.json, '{"type":"Buffer","data":[1,2]}', 'Buffer JSON');
    eq(req.buf.isBuf, [true, false], 'Buffer.isBuffer');
    eq(req.buf.rw, [0xdeadbeef, 0x1234, -17, 0xde], 'Buffer read/write ints');
    eq(req.buf.fromArr, [1, 2, 44], 'Buffer.from(array) masks to bytes');
    eq(req.buf.fromAb, 2, 'Buffer.from(ArrayBuffer)');
    eq(req.buf.sliceIsBuf, true, 'Buffer.slice returns a Buffer');
    eq(req.buf.str, 'hé', 'Buffer.toString(utf8, start, end)');
    eq(req.buf.ascii, 'abc', 'Buffer ascii');
    eq(req.buf.copy, [0, 120, 121, 0], 'Buffer.copy');

    // ---------------------------------------------------------------------------------------- log / bridge side effects
    await page.evaluate(() => { nw.Shell.openExternal('https://example.com/x?y=1'); nw.Window.get().close(true); });
    await sleep(300);
    ok(srv.logs('JS I shim').length === 1, 'bridge: shim logged its start line', srv.logs('JS I shim'));
    ok(srv.logs('JS I UA ').length === 1 && /dpr=2 915x412/.test(srv.logs('JS I UA ')[0]), 'bridge: UA/viewport line logged', srv.logs('JS I UA '));
    ok(srv.lines.some((l) => l === 'JS OPENURL https://example.com/x?y=1'), 'bridge: nw.Shell.openExternal -> openUrl');
    ok(srv.lines.some((l) => l === 'JS EXIT'), 'bridge: nw.Window.close(true) -> exit');
    ok(srv.logs('JS W').some((l) => /require\("does-not-exist"\)/.test(l)), 'bridge: failed require() is logged as a warning');
    ok(srv.logs('JS W').some((l) => /greenworks/.test(l)), 'bridge: stub module use is logged once');

    // ---------------------------------------------------------------------------------------- zlib / crypto / fs diagnostics
    {
      const sample = Buffer.concat([Buffer.from('{"language":"한국어","items":[1,2,3]}'.repeat(300)), Buffer.from(Array.from({ length: 5000 }, (_, i) => (i * 7919) & 255))]);
      const zin = {
        raw: sample.toString('base64'), gz: nodeZlib.gzipSync(sample).toString('base64'),
        zl: nodeZlib.deflateSync(sample, { level: 9 }).toString('base64'), rw: nodeZlib.deflateRawSync(sample, { level: 1 }).toString('base64')
      };
      const zc = await page.evaluate(async (a) => {
        const zlib = require('zlib'), crypto = require('crypto');
        const b = (s) => Buffer.from(s, 'base64'), s64 = (x) => Buffer.from(x).toString('base64');
        const o = {}, raw = b(a.raw);
        o.gunzipOk = zlib.gunzipSync(b(a.gz)).equals(raw);
        o.inflateOk = zlib.inflateSync(b(a.zl)).equals(raw);
        o.rawOk = zlib.inflateRawSync(b(a.rw)).equals(raw);
        o.unzipOk = zlib.unzipSync(b(a.gz)).equals(raw) && zlib.unzipSync(b(a.zl)).equals(raw);
        o.ourGzip = s64(zlib.gzipSync(raw)); o.ourDeflate = s64(zlib.deflateSync(raw)); o.ourRaw = s64(zlib.deflateRawSync(raw));
        o.isBuffer = Buffer.isBuffer(zlib.gzipSync(raw)) && Buffer.isBuffer(zlib.inflateSync(b(a.zl)));
        o.err = (() => { try { zlib.inflateSync(Buffer.from('definitely not zlib')); } catch (e) { return [e.code, e.errno, e.message]; } return null; })();
        o.crc = zlib.crc32(raw);
        o.hashes = {};
        ['md5', 'sha1', 'sha224', 'sha256', 'sha384', 'sha512'].forEach((h) => { o.hashes[h] = crypto.createHash(h).update(raw).digest('hex'); });
        o.hmac = crypto.createHmac('sha256', 'secret').update(raw).digest('base64');
        o.pbkdf2 = crypto.pbkdf2Sync('pw', 'salt', 10, 24, 'sha1').toString('hex');
        o.rnd = [crypto.randomBytes(300000).length, crypto.randomInt(5, 6), typeof crypto.randomUUID()];
        o.cb = await new Promise((res) => zlib.gzip(raw, (e, v) => res(e ? 'err' : s64(v))));
        o.stream = await new Promise((res) => { const g = zlib.createGzip(), chunks = []; g.on('data', (c) => chunks.push(Buffer.from(c))); g.on('end', () => res(s64(Buffer.concat(chunks)))); g.end(raw); });
        o.cipher = (() => { const c = crypto.createCipheriv('aes-256-cbc', Buffer.alloc(32, 1), Buffer.alloc(16, 2)); return s64(Buffer.concat([c.update(raw), c.final()])); })();
        o.ctr = (() => { const c = crypto.createCipheriv('aes-256-ctr', Buffer.alloc(32, 3), Buffer.alloc(16, 4)); const e = Buffer.concat([c.update(raw), c.final()]); const d = crypto.createDecipheriv('aes-256-ctr', Buffer.alloc(32, 3), Buffer.alloc(16, 4)); return [s64(e), Buffer.concat([d.update(e), d.final()]).equals(raw)]; })();
        o.gcm = (() => { try { crypto.createCipheriv('aes-256-gcm', Buffer.alloc(32), Buffer.alloc(12)); } catch (e) { return e.message; } return null; })();
        return o;
      }, zin);
      ok(zc.gunzipOk && zc.inflateOk && zc.rawOk && zc.unzipOk, 'zlib in the page reads gzip / zlib / raw data made by Node');
      for (const [k, reader] of [['ourGzip', 'gunzipSync'], ['ourDeflate', 'inflateSync'], ['ourRaw', 'inflateRawSync'], ['cb', 'gunzipSync'], ['stream', 'gunzipSync']]) {
        ok(nodeZlib[reader](Buffer.from(zc[k], 'base64')).equals(sample), 'zlib in the page: ' + k + ' is read back by Node');
      }
      ok(zc.isBuffer, 'zlib results are Buffers');
      eq(zc.err, ['Z_DATA_ERROR', -3, 'incorrect header check'], 'zlib in the page: bad data gives node\'s error');
      eq(zc.crc, nodeZlib.crc32(sample), 'zlib.crc32 in the page equals node');
      for (const h of Object.keys(zc.hashes)) eq(zc.hashes[h], nodeCrypto.createHash(h).update(sample).digest('hex'), 'crypto.createHash(' + h + ') in the page equals node');
      eq(zc.hmac, nodeCrypto.createHmac('sha256', 'secret').update(sample).digest('base64'), 'crypto.createHmac in the page equals node');
      eq(zc.pbkdf2, nodeCrypto.pbkdf2Sync('pw', 'salt', 10, 24, 'sha1').toString('hex'), 'crypto.pbkdf2Sync in the page equals node');
      eq(zc.rnd, [300000, 5, 'string'], 'crypto.randomBytes (big), randomInt, randomUUID in the page');
      {
        const aesNode = (alg, k, v) => { const c = nodeCrypto.createCipheriv(alg, Buffer.alloc(32, k), Buffer.alloc(16, v)); return Buffer.concat([c.update(sample), c.final()]).toString('base64'); };
        eq(zc.cipher, aesNode('aes-256-cbc', 1, 2), 'crypto.createCipheriv(aes-256-cbc) in the page equals node');
        eq(zc.ctr, [aesNode('aes-256-ctr', 3, 4), true], 'crypto aes-256-ctr in the page equals node and decrypts back');
        ok(/aes-256-gcm.*not available/.test(zc.gcm || ''), 'a cipher that is not implemented fails with a clear message', zc.gcm);
      }

      srv.lines.length = 0;
      await page.evaluate(() => {
        const fs = require('fs'), cwd = process.cwd();
        for (let i = 0; i < 100; i++) fs.existsSync(cwd + '/probe-missing-' + i);
        for (let i = 0; i < 3; i++) { try { fs.readFileSync(cwd + '/www/languages/en.cld'); } catch (e) { /* expected */ } }
        try { fs.readdirSync(cwd + '/www/languages-missing'); } catch (e) { /* expected */ }
        try { require('https').request('http://x'); } catch (e) { /* expected */ }
        try { require('vm').runInThisContext('1'); } catch (e) { /* expected */ }
      });
      await sleep(300);
      const probes = srv.logs('JS I fs exists false');
      ok(probes.length > 0 && probes.length <= 40, 'log: missing-path probes are logged, capped at 40', probes.length);
      ok(probes.some((l) => /further missing-path probes are not logged/.test(l)), 'log: the cap is announced once');
      eq(srv.logs('JS W fs open ENOENT: ' + gameDir + '/www/languages/en.cld').length, 1, 'log: a failing readFileSync names the path (once, however often it is retried)');
      ok(srv.logs('JS W fs scandir ENOENT: ' + gameDir + '/www/languages-missing').length === 1, 'log: a failing readdirSync names the path');
      ok(srv.logs('JS W').some((l) => /require\("vm"\): this Node module is not available/.test(l)), 'log: requiring an unavailable module is logged');
      ok(srv.logs('JS W').some((l) => /Node module "https" was used \(request\)/.test(l)), 'log: using an unavailable module is logged with the member name');
    }

    // ---------------------------------------------------------------------------------------- streams / file descriptors / file streams vs real Node
    // the very scenarios of streams.test.js, run once in real Node and once in the real shim (Chromium + the real Java file bridge)
    {
      const scen = Object.assign({}, require('./stream-scenarios'), require('./fs-scenarios'));
      const { nodeEnv, norm, show: showFn, bigData: bigDataFn, sleep: sleepFn, withTimeout } = require('./scenario-env');
      const names = Object.keys(scen);
      let idx = 0, bad = 0;
      for (const name of names) {
        const nlog = [];
        const ne = nodeEnv(nlog);
        try { await withTimeout(Promise.resolve(scen[name](ne.env)), 5000, 'node scenario'); } catch (e) { nlog.push('SCENARIO THREW ' + (e && e.code ? e.code + ' ' : '') + (e && e.message)); }
        await sleepFn(15);
        ne.finish();
        const T = path.join(www, 'tmp-sc', String(++idx));
        const plog = await page.evaluate(async (a) => {
          const log = [];
          const env = { stream: require('stream'), fs: require('fs'), zlib: require('zlib'), crypto: require('crypto'), StringDecoder: require('string_decoder').StringDecoder,
            Buffer, T: a.T, log: (s) => log.push(String(s)), sleep: (ms) => new Promise((r) => setTimeout(r, ms)), show: (0, eval)('(' + a.show + ')'), bigData: (n) => (0, eval)('(' + a.bigData + ')')(Buffer, n) };
          env.fs.mkdirSync(a.T, { recursive: true });
          try {
            await Promise.race([(0, eval)('(' + a.src + ')')(env), new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 8000))]);
          } catch (e) { log.push('SCENARIO THREW ' + (e && e.code ? e.code + ' ' : '') + (e && e.message)); }
          await env.sleep(20);
          return log;
        }, { src: scen[name].toString(), show: showFn.toString(), bigData: bigDataFn.toString(), T });
        const same = JSON.stringify(norm(nlog, ne.T)) === JSON.stringify(norm(plog, T));
        if (!same) {
          bad++;
          const a = norm(nlog, ne.T), b = norm(plog, T);
          for (let i = 0; i < Math.max(a.length, b.length) && i < 400; i++) if (a[i] !== b[i]) { console.log('  [' + name + '] line ' + i + '\n     node: ' + a[i] + '\n     page: ' + b[i]); break; }
        }
        ok(same, 'page vs node: ' + name);
      }
      ok(names.length >= 40 && bad === 0, 'streams / fd / file streams: ' + names.length + ' scenarios identical in real Node and in the shim', bad);
    }

    // ---------------------------------------------------------------------------------------- uncaught errors -> log + banner
    srv.lines.length = 0;
    await page.evaluate(() => { setTimeout(() => { throw new Error('boom-test'); }, 0); });
    await page.waitForFunction(() => Array.from(document.querySelectorAll('div')).some((d) => /boom-test/.test(d.textContent) && d.style.position === 'fixed'), null, { timeout: 5000 }).catch(() => {});
    await sleep(200);
    ok(srv.logs('JS E uncaught').some((l) => /boom-test/.test(l)), 'errors: uncaught exception reaches the log file', srv.lines.slice(-3));
    const banner = await page.evaluate(() => { const d = Array.from(document.querySelectorAll('div')).find((x) => x.style.position === 'fixed' && /boom-test/.test(x.textContent)); return d ? { text: d.textContent, shown: getComputedStyle(d).display } : null; });
    ok(banner && banner.shown === 'block', 'errors: on-screen banner shown in debug mode', banner);
    await page.evaluate(() => { Promise.reject(new Error('rej-test')); });
    await sleep(200);
    ok(srv.logs('JS E unhandled rejection').some((l) => /rej-test/.test(l)), 'errors: unhandled rejection logged');
    await page.evaluate(() => { const s = document.createElement('script'); s.src = 'js/missing-plugin.js'; document.body.appendChild(s); });
    await sleep(400);
    ok(srv.logs('JS W resource failed').some((l) => /missing-plugin\.js/.test(l)), 'errors: failed <script> load is logged');
    ok(srv.logs('SRV').some((l) => /404/.test(l) && /missing-plugin\.js/.test(l)), 'server: 404 for the missing plugin is logged', srv.logs('SRV').slice(-4));

    // ---------------------------------------------------------------------------------------- audio: unlock / pause
    const au = await page.evaluate(async () => {
      const o = {};
      const ctx = WebAudio._context;
      o.hasCtx = !!ctx; o.sameClass = ctx instanceof AudioContext && ctx instanceof (window.webkitAudioContext || AudioContext);
      o.tracked = __RR.audioContexts.includes(ctx);
      await ctx.resume();
      o.running = ctx.state;
      __RR.setPaused(true);
      await new Promise((r) => setTimeout(r, 250));
      o.paused = ctx.state;
      __RR.setPaused(false);
      await new Promise((r) => setTimeout(r, 250));
      o.resumed = ctx.state;
      return o;
    });
    ok(au.hasCtx && au.sameClass && au.tracked, 'audio: AudioContext subclass is tracked', au);
    eq(au.running, 'running', 'audio: context running');
    eq(au.paused, 'suspended', 'audio: setPaused(true) suspends all contexts');
    eq(au.resumed, 'running', 'audio: setPaused(false) resumes them');

    // ---------------------------------------------------------------------------------------- server behaviour (plain HTTP)
    const base = '/' + encPath(www.slice(1));
    let r = await httpGet(srv.port, base + '/audio/bgm/Theme.ogg', { Range: 'bytes=10-19' });
    eq(r.status, 206, 'server: Range request -> 206');
    eq(r.headers['content-range'], 'bytes 10-19/4096', 'server: Content-Range');
    eq(Array.from(r.body), Array.from({ length: 10 }, (_, i) => ((i + 10) * 7) & 255), 'server: Range body bytes');
    r = await httpGet(srv.port, base + '/audio/bgm/Theme.ogg', { Range: 'bytes=4090-' });
    eq([r.status, r.body.length], [206, 6], 'server: open-ended Range');
    r = await httpGet(srv.port, base + '/audio/bgm/Theme.ogg', { Range: 'bytes=9999-' });
    eq(r.status, 416, 'server: unsatisfiable Range -> 416');
    r = await httpGet(srv.port, base + '/audio/bgm/Theme.ogg', {}, 'HEAD');
    eq([r.status, r.headers['content-length'], r.body.length], [200, '4096', 0], 'server: HEAD');
    ok(/audio\/ogg/.test(r.headers['content-type'] || ''), 'server: .ogg content type', r.headers['content-type']);
    r = await httpGet(srv.port, base.replace('/www', '/WWW') + '/JS/RPG_CORE.JS');
    eq(r.status, 200, 'server: case-insensitive lookup (Android file names are case-sensitive, Windows games are not)');
    r = await httpGet(srv.port, base + '/img/pictures/' + encodeURIComponent('Ünï 그림 #1.txt'));
    eq([r.status, r.body.toString()], [200, 'unicode name ok'], 'server: unicode file name');
    r = await httpGet(srv.port, base + '/index.html');
    const html = r.body.toString();
    ok(r.status === 200 && /text\/html/.test(r.headers['content-type']), 'server: index.html');
    ok(html.indexOf('/__rr/config.js') > 0 && html.indexOf('/__rr/shim.js') > html.indexOf('/__rr/config.js') && html.indexOf('/__rr/shim.js') < html.indexOf('js/libs/pixi.js'), 'server: shim is injected before the game scripts', html.slice(0, 400));
    ok((html.match(/__rr\/shim\.js/g) || []).length === 1, 'server: shim injected exactly once');
    ok(/overlay\.js/.test(html), 'server: overlay injected');
    r = await httpGet(srv.port, base + '/js/rpg_core.js');
    ok(r.body.toString().indexOf('__rr') < 0, 'server: non-html files are not modified');
    r = await httpGet(srv.port, base + '/../../../../etc/passwd');
    ok(r.status === 403 || r.status === 404 || r.status === 400, 'server: ".." traversal refused', r.status);
    r = await httpGet(srv.port, base + '/%2e%2e/%2e%2e/%2e%2e/%2e%2e/etc/passwd');
    ok(r.status === 403 || r.status === 404 || r.status === 400, 'server: encoded ".." traversal refused', r.status);
    r = await httpGet(srv.port, '/etc/passwd');
    ok(r.status === 403 || r.status === 404, 'server: files outside the game/data folders are refused', r.status);
    r = await httpGet(srv.port, base + '/index.html', { Host: 'evil.example.com' });
    ok(r.status === 403 || r.status === 400 || r.status === 421, 'server: foreign Host header refused (DNS rebinding guard)', r.status);
    r = await httpGet(srv.port, '/__rr/ping');
    eq(r.status, 200, 'server: ping');
    r = await httpGet(srv.port, '/__rr/shim.js');
    ok(r.status === 200 && /javascript/.test(r.headers['content-type']), 'server: shim.js served', r.headers['content-type']);
    ok(/no-store/.test(r.headers['cache-control'] || ''), 'server: no-store caching');
    r = await httpGet(srv.port, '/__rr/config.js');
    ok(/window\.__RR_CONFIG=\{/.test(r.body.toString()) && /"debug":true/.test(r.body.toString()), 'server: config.js');

    // ---------------------------------------------------------------------------------------- overlay
    const geo = await page.evaluate(() => {
      const rect = (sel) => { const e = document.querySelector(sel); if (!e) return null; const r = e.getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height, cx: r.left + r.width / 2, cy: r.top + r.height / 2, disp: getComputedStyle(e).display }; };
      return { dpad: rect('#rr-ui .rr-dpad'), a: rect('#rr-ui .rr-a'), b: rect('#rr-ui .rr-b'), dash: rect('#rr-ui .rr-dash'), q: rect('#rr-ui .rr-q'), w: rect('#rr-ui .rr-w'), menu: rect('#rr-ui .rr-menu'), vw: innerWidth, vh: innerHeight, ui: !!window.__RR_UI };
    });
    ok(geo.ui && geo.dpad && geo.a && geo.b && geo.dash && geo.q && geo.w && geo.menu, 'overlay: all controls exist', geo);
    ok(geo.dpad.x >= 0 && geo.dpad.y + geo.dpad.h <= geo.vh + 1 && geo.a.x + geo.a.w <= geo.vw + 1 && geo.a.y + geo.a.h <= geo.vh + 1, 'overlay: pad and buttons are inside the viewport', geo);
    ok(geo.dpad.cx < geo.vw / 2 && geo.a.cx > geo.vw / 2 && geo.b.cx > geo.vw / 2, 'overlay: d-pad left, action buttons right');
    function overlap(p, q) { return !(p.x + p.w <= q.x || q.x + q.w <= p.x || p.y + p.h <= q.y || q.y + q.h <= p.y); }
    ok(!overlap(geo.a, geo.b) && !overlap(geo.a, geo.dash) && !overlap(geo.b, geo.dash), 'overlay: A / B / Dash do not overlap', geo);
    ok(!overlap(geo.menu, geo.w) && !overlap(geo.menu, geo.q), 'overlay: menu button does not overlap Q / W');

    const cdp = await g.context.newCDPSession(page);
    async function touch(type, pts) { await cdp.send('Input.dispatchTouchEvent', { type, touchPoints: pts.map((p) => ({ x: p.x, y: p.y, id: p.id === undefined ? 0 : p.id })) }); }
    const pressed = () => page.evaluate(() => Input.pressed());
    const seen = () => page.evaluate(() => TouchInput.events.slice());
    const D = geo.dpad, rad = D.w / 2;

    await page.evaluate(() => { TouchInput.events.length = 0; });
    await touch('touchStart', [{ x: D.cx + rad * 0.7, y: D.cy, id: 1 }]);
    eq(await pressed(), ['right'], 'overlay: touch right of the d-pad centre -> right');
    await touch('touchMove', [{ x: D.cx, y: D.cy - rad * 0.7, id: 1 }]);
    eq(await pressed(), ['up'], 'overlay: sliding to the top -> up only (right released)');
    await touch('touchMove', [{ x: D.cx - rad * 0.55, y: D.cy + rad * 0.55, id: 1 }]);
    eq(await pressed(), ['down', 'left'], 'overlay: bottom-left -> diagonal (down + left)');
    await touch('touchMove', [{ x: D.cx + rad * 0.05, y: D.cy + rad * 0.05, id: 1 }]);
    eq(await pressed(), [], 'overlay: dead zone in the middle -> nothing pressed');
    await touch('touchMove', [{ x: D.cx + rad * 0.9, y: D.cy + rad * 0.25, id: 1 }]);
    eq(await pressed(), ['right'], 'overlay: shallow angle stays a pure cardinal direction');
    // second finger on OK while the first holds the d-pad
    const A = geo.a;
    await touch('touchStart', [{ x: D.cx + rad * 0.9, y: D.cy + rad * 0.25, id: 1 }, { x: A.cx, y: A.cy, id: 2 }]);
    eq(await pressed(), ['ok', 'right'], 'overlay: multi-touch d-pad + OK');
    const dpadClass = await page.evaluate(() => document.querySelector('#rr-ui .rr-dpad').className);
    ok(/\br\b/.test(dpadClass), 'overlay: d-pad highlights the active direction', dpadClass);
    await touch('touchEnd', [{ x: A.cx, y: A.cy, id: 2 }]); // lift only the OK finger
    eq(await pressed(), ['right'], 'overlay: releasing OK keeps the d-pad direction');
    await touch('touchEnd', []);
    eq(await pressed(), [], 'overlay: releasing everything clears all keys');
    // button mapping
    const map = [['b', 'escape'], ['dash', 'shift'], ['q', 'pageup'], ['w', 'pagedown']];
    for (const [k, name] of map) {
      const R = geo[k];
      await touch('touchStart', [{ x: R.cx, y: R.cy, id: 5 }]);
      eq(await pressed(), [name], 'overlay: button ' + k + ' -> ' + name);
      await touch('touchEnd', []);
    }
    eq(await seen(), [], 'overlay: the game never saw a touch/mouse event that happened on the overlay', await seen());
    // touching the empty game area is NOT swallowed
    await touch('touchStart', [{ x: geo.vw / 2, y: geo.vh / 2, id: 9 }]);
    await touch('touchEnd', []);
    await sleep(100);
    ok((await seen()).some((e) => /^touchstart:/.test(e)), 'overlay: touches on the game area still reach the game', await seen());
    // cancel releases keys
    await touch('touchStart', [{ x: A.cx, y: A.cy, id: 6 }]);
    eq(await pressed(), ['ok'], 'overlay: OK down');
    await touch('touchCancel', []);
    eq(await pressed(), [], 'overlay: touchcancel releases the key');
    // window blur releases everything (MV itself clears its state on blur, the overlay must agree)
    await touch('touchStart', [{ x: A.cx, y: A.cy, id: 7 }]);
    await page.evaluate(() => window.dispatchEvent(new Event('blur')));
    eq(await page.evaluate(() => __RR_UI.held()), [], 'overlay: blur releases held keys');
    await touch('touchEnd', []);
    // keyboard events carry keyCode/which like real ones
    const kev = await page.evaluate(() => new Promise((res) => {
      const h = (e) => { document.removeEventListener('keydown', h); res({ key: e.key, code: e.code, keyCode: e.keyCode, which: e.which, bubbles: e.bubbles, trusted: e.isTrusted }); };
      document.addEventListener('keydown', h);
      __RR_UI.key('ok', true); __RR_UI.key('ok', false);
    }));
    eq([kev.key, kev.code, kev.keyCode, kev.which], ['z', 'KeyZ', 90, 90], 'overlay: synthetic KeyboardEvent has key/code/keyCode/which');
    // menu button -> native menu
    const M = geo.menu;
    srv.lines.length = 0;
    await touch('touchStart', [{ x: M.cx, y: M.cy, id: 3 }]);
    await touch('touchEnd', []);
    await sleep(150);
    ok(srv.lines.some((l) => l === 'JS MENU'), 'overlay: menu button calls RRNative.showMenu()', srv.lines);
    // pad hide / show
    await page.evaluate(() => __RR_UI.setPad(false));
    eq(await page.evaluate(() => getComputedStyle(document.querySelector('#rr-ui .rr-dpad')).display), 'none', 'overlay: setPad(false) hides the pad');
    eq(await page.evaluate(() => getComputedStyle(document.querySelector('#rr-ui .rr-menu')).display) !== 'none', true, 'overlay: ...but the menu button stays');
    await page.evaluate(() => __RR_UI.setPad(true));
    // gamepad connected hides the on-screen pad
    await page.evaluate(() => window.dispatchEvent(new Event('gamepadconnected')));
    eq(await page.evaluate(() => getComputedStyle(document.querySelector('#rr-ui .rr-dpad')).display), 'none', 'overlay: a connected gamepad hides the pad');
    await page.evaluate(() => window.dispatchEvent(new Event('gamepaddisconnected')));
    eq(await page.evaluate(() => getComputedStyle(document.querySelector('#rr-ui .rr-dpad')).display) !== 'none', true, 'overlay: pad returns after the gamepad is gone');
    await page.evaluate(() => { window.__fixture.errors = []; });

    // screenshot: pad + character moving
    await touch('touchStart', [{ x: D.cx + rad * 0.7, y: D.cy - rad * 0.2, id: 1 }, { x: A.cx, y: A.cy, id: 2 }]);
    await sleep(400);
    await page.screenshot({ path: path.join(SHOTS, 'game-landscape.png') });
    await touch('touchEnd', []);

    // fallback menu when there is no native bridge is covered in the second scenario below
    ok(g.pageErrors.filter((e) => !/boom-test/.test(e) && !/rej-test/.test(e)).length === 0, 'no unexpected page errors', g.pageErrors);
    await g.context.close();
    g = null;

    // ---------------------------------------------------------------------------------------- scenario 2: no bridge, pad off, canvas renderer
    srv.stop();
    await sleep(300);
    const srv2 = await startDevServer(gameDir, dataDir, ['--pad=false', '--renderer=canvas']);
    ok(/\/index\.html\?canvas$/.test(srv2.url), 'page url carries ?canvas for the canvas renderer', srv2.url);
    let g2 = await newGamePage(browser, srv2, { bridge: false });
    const s2 = await g2.page.evaluate(() => ({
      opt: Utils.isOptionValid('canvas'), nopad: document.getElementById('rr-ui').classList.contains('nopad'),
      dpadDisp: getComputedStyle(document.querySelector('#rr-ui .rr-dpad')).display, menuDisp: getComputedStyle(document.querySelector('#rr-ui .rr-menu')).display,
      ready: __RR.ready, noNative: !window.RRNative, save: (StorageManager.exists(1), 'ok'),
    }));
    eq(s2.opt, 1, 'renderer: MV sees the canvas option');
    eq(s2.nopad, true, 'config: pad=false starts hidden');
    eq(s2.dpadDisp, 'none', 'config: hidden pad is display:none');
    ok(s2.menuDisp !== 'none', 'config: menu button stays when the pad is off');
    eq(s2.ready, true, 'shim still starts without the native bridge');
    const noBridge = await g2.page.evaluate(() => { try { require('fs').writeFileSync(process.cwd() + '/x.txt', 'x'); return 'wrote'; } catch (e) { return e.code; } });
    eq(noBridge, 'ENOSYS', 'fs writes without a bridge fail with ENOSYS instead of crashing');
    const rd = await g2.page.evaluate(() => require('fs').readFileSync(process.cwd() + '/package.json', 'utf8').length > 10);
    eq(rd, true, 'fs reads work without a bridge (plain HTTP)');
    const M2 = await g2.page.evaluate(() => { const r = document.querySelector('#rr-ui .rr-menu').getBoundingClientRect(); return { x: r.left + r.width / 2, y: r.top + r.height / 2 }; });
    await g2.page.touchscreen.tap(M2.x, M2.y);
    await sleep(200);
    eq(await g2.page.evaluate(() => { const p = document.querySelector('#rr-ui .rr-panel'); return p ? getComputedStyle(p).display : null; }), 'flex', 'overlay: fallback menu panel appears without the bridge');
    await g2.page.screenshot({ path: path.join(SHOTS, 'fallback-menu.png') });
    await g2.context.close();
    srv2.stop();
    await sleep(300);

    // ---------------------------------------------------------------------------------------- scenario 3: frame limiter
    const srv3 = await startDevServer(gameDir, dataDir, ['--fps=30']);
    const g3 = await newGamePage(browser, srv3);
    const fpsOf = async (pg) => { const a = await pg.evaluate(() => Graphics.frames); await sleep(2000); const b = await pg.evaluate(() => Graphics.frames); return (b - a) / 2; };
    const fps30 = await fpsOf(g3.page);
    ok(fps30 > 22 && fps30 < 38, 'frame limiter: --fps=30 gives ~30 fps (measured ' + fps30 + ')');
    ok(srv3.logs('JS I frame limiter active: 30').length === 1, 'frame limiter: logged');
    await g3.context.close();
    srv3.stop();
    await sleep(300);
    const srv4 = await startDevServer(gameDir, dataDir, []);
    const g4 = await newGamePage(browser, srv4);
    const fpsFree = await fpsOf(g4.page);
    ok(fpsFree > 45, 'frame limiter: unlimited game runs at full rate (measured ' + fpsFree + ')');
    await g4.context.close();
    srv4.stop();
    await sleep(300);

    // ---------------------------------------------------------------------------------------- scenario 5: RPG Maker 2000/2003 (EasyRPG player page stand-in)
    // The real player (index.js/index.wasm) is downloaded at build time; here a tiny page plays its part: a #canvas, the stock
    // on-screen buttons (#apad) and window-level key listeners that record what an SDL-based player would receive.
    const ynDir = path.join(work, 'Games', 'Yume Nikki');
    fs.mkdirSync(ynDir, { recursive: true });
    fs.writeFileSync(path.join(ynDir, 'RPG_RT.ldb'), 'x');
    fs.writeFileSync(path.join(ynDir, 'RPG_RT.ini'), '[RPG_RT]\r\nGameTitle=Yume Nikki\r\n');
    const assets5 = path.join(work, 'assets-rm2k');
    fs.mkdirSync(path.join(assets5, 'shim'), { recursive: true });
    fs.mkdirSync(path.join(assets5, 'easyrpg'), { recursive: true });
    for (const f of ['shim.js', 'overlay.js']) fs.copyFileSync(path.join(ASSETS, 'shim', f), path.join(assets5, 'shim', f));
    fs.writeFileSync(path.join(assets5, 'easyrpg', 'rr-player.html'),
      '<!doctype html><html><head><meta charset="utf-8"><title>player</title></head><body style="margin:0;background:#000">' +
      '<div id="apad" style="position:fixed;left:0;bottom:0;width:90px;height:90px;background:#c00">stock buttons</div>' +
      '<canvas id="canvas" width="320" height="240" tabindex="-1" style="display:block;width:100vw;height:100vh"></canvas>' +
      '<script>window.__keys=[];function rec(e){window.__keys.push({t:e.type,key:e.key,code:e.code,kc:e.keyCode,which:e.which,target:e.target.id||e.target.tagName});}' +
      'window.addEventListener("keydown",rec);window.addEventListener("keyup",rec);' +
      'window.__ev=[];["touchstart","mousedown","click"].forEach(function(t){document.addEventListener(t,function(){window.__ev.push(t);});});</script></body></html>');
    const srv5 = await startDevServer(ynDir, path.join(work, 'data5'), [], assets5);
    ok(/\/__rr\/easyrpg\/rr-player\.html\?game=/.test(srv5.url), 'rm2k: page url points at the EasyRPG player page', srv5.url);
    const ctx5 = await browser.newContext({ viewport: { width: 915, height: 412 }, hasTouch: true, isMobile: false, deviceScaleFactor: 2, userAgent: DESKTOP_UA });
    await ctx5.addInitScript({ content: mockBridgeScript(srv5.bridge) });
    const p5 = await ctx5.newPage();
    const errors5 = [];
    p5.on('pageerror', (e) => errors5.push(String(e && e.message || e)));
    await p5.goto(srv5.url);
    await p5.waitForSelector('#rr-ui .rr-menu', { state: 'attached', timeout: 10000 });
    const rm = await p5.evaluate(() => {
      const rect = (sel) => { const e = document.querySelector(sel); if (!e) return null; const r = e.getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height, cx: r.left + r.width / 2, cy: r.top + r.height / 2 }; };
      return {
        engine: window.__RR_CONFIG && window.__RR_CONFIG.engine, shimLoaded: typeof window.__RR === 'object' && typeof window.require === 'function', apad: getComputedStyle(document.getElementById('apad')).display,
        dpad: rect('#rr-ui .rr-dpad'), a: rect('#rr-ui .rr-a'), b: rect('#rr-ui .rr-b'), dash: rect('#rr-ui .rr-dash'), menu: rect('#rr-ui .rr-menu'),
        n: Array.from(document.querySelectorAll('#rr-ui .rr-n')).map((e) => { const r = e.getBoundingClientRect(); return { t: e.textContent, x: r.left, y: r.top, w: r.width, h: r.height, cx: r.left + r.width / 2, cy: r.top + r.height / 2 }; }),
        q: !!document.querySelector('#rr-ui .rr-q'), w: !!document.querySelector('#rr-ui .rr-w'), vw: innerWidth, vh: innerHeight,
      };
    });
    eq(rm.engine, 'rm2k', 'rm2k: config says engine rm2k');
    eq(rm.shimLoaded, false, 'rm2k: the Node/NW.js shim is not loaded on the player page');
    eq(rm.apad, 'none', 'rm2k: the stock on-screen buttons (#apad) are hidden');
    ok(rm.dpad && rm.a && rm.b && rm.dash && rm.menu, 'rm2k: d-pad, OK, Cancel, Dash and menu button exist', rm);
    eq(rm.n.map((x) => x.t), ['1', '3', '5', '9'], 'rm2k: four number buttons 1 3 5 9');
    eq([rm.q, rm.w], [false, false], 'rm2k: no Q / W buttons');
    const ov = (p, q) => !(p.x + p.w <= q.x + 0.5 || q.x + q.w <= p.x + 0.5 || p.y + p.h <= q.y + 0.5 || q.y + q.h <= p.y + 0.5);
    let clash = false;
    rm.n.forEach((p, i) => { if (p.x < 0 || p.y < 0 || p.x + p.w > rm.vw || p.y + p.h > rm.vh || ov(p, rm.menu) || ov(p, rm.dpad) || ov(p, rm.a) || ov(p, rm.b)) clash = true; rm.n.forEach((q, j) => { if (i < j && ov(p, q)) clash = true; }); });
    ok(!clash, 'rm2k: number buttons fit on screen and overlap nothing', rm);
    ok(rm.n.every((p, i) => i === 0 || p.x > rm.n[i - 1].x), 'rm2k: number buttons are in order left to right');
    const cdp5 = await ctx5.newCDPSession(p5);
    const touch5 = (type, pts) => cdp5.send('Input.dispatchTouchEvent', { type, touchPoints: pts.map((p) => ({ x: p.x, y: p.y, id: p.id === undefined ? 0 : p.id })) });
    const keys5 = () => p5.evaluate(() => window.__keys.splice(0));
    const expectCodes = { '1': ['Numpad1', 97], '3': ['Numpad3', 99], '5': ['Numpad5', 101], '9': ['Numpad9', 105] };
    for (const b of rm.n) {
      await touch5('touchStart', [{ x: b.cx, y: b.cy, id: 4 }]);
      await touch5('touchEnd', []);
      const ks = await keys5();
      eq(ks.map((k) => [k.t, k.key, k.code, k.kc, k.which, k.target]), [['keydown', b.t, expectCodes[b.t][0], expectCodes[b.t][1], expectCodes[b.t][1], 'canvas'], ['keyup', b.t, expectCodes[b.t][0], expectCodes[b.t][1], expectCodes[b.t][1], 'canvas']],
        'rm2k: button ' + b.t + ' sends keypad ' + b.t + ' down+up to the canvas (bubbles to window)');
    }
    await touch5('touchStart', [{ x: rm.dpad.cx + rm.dpad.w * 0.35, y: rm.dpad.cy, id: 1 }, { x: rm.a.cx, y: rm.a.cy, id: 2 }]);
    eq((await keys5()).map((k) => k.t + ':' + k.code + ':' + k.target), ['keydown:ArrowRight:canvas', 'keydown:KeyZ:canvas'], 'rm2k: d-pad and OK reach the canvas too');
    await touch5('touchEnd', []);
    eq((await keys5()).map((k) => k.t + ':' + k.code), ['keyup:ArrowRight', 'keyup:KeyZ'], 'rm2k: releasing sends keyup for everything');
    eq(await p5.evaluate(() => window.__ev), [], 'rm2k: the player never saw a touch/mouse event from the overlay');
    // 160% scale still fits (the number buttons grow with the pad size)
    await p5.evaluate(() => document.getElementById('rr-ui').style.setProperty('--s', '1.6'));
    const boxes = (sel) => p5.evaluate((s) => Array.from(document.querySelectorAll(s)).map((e) => { const r = e.getBoundingClientRect(); return { x: r.left, y: r.top, w: r.width, h: r.height }; }), sel);
    const big = await boxes('#rr-ui .rr-n');
    const bigMenu = (await boxes('#rr-ui .rr-menu'))[0];
    const bigClash = big.some((p, i) => p.x + p.w > rm.vw || ov(p, bigMenu) || big.some((q, j) => i < j && ov(p, q)));
    ok(big.length === 4 && !bigClash, 'rm2k: at 160% pad size the number buttons still do not collide with each other or the menu button', { big, bigMenu });
    await p5.evaluate(() => document.getElementById('rr-ui').style.setProperty('--s', '1'));
    // pad off hides the number buttons as well, the menu button stays
    await p5.evaluate(() => __RR_UI.setPad(false));
    eq(await p5.evaluate(() => Array.from(document.querySelectorAll('#rr-ui .rr-n')).map((e) => getComputedStyle(e).display)), ['none', 'none', 'none', 'none'], 'rm2k: pad off hides the number buttons');
    ok(await p5.evaluate(() => getComputedStyle(document.querySelector('#rr-ui .rr-menu')).display !== 'none'), 'rm2k: menu button stays with the pad off');
    await p5.evaluate(() => __RR_UI.setPad(true));
    await p5.screenshot({ path: path.join(SHOTS, 'rm2k-pad.png') });
    ok(errors5.length === 0, 'rm2k: no page errors', errors5);
    await ctx5.close();
    srv5.stop();
  } finally {
    if (g) await g.context.close().catch(() => {});
    await browser.close().catch(() => {});
    srv.stop();
  }
  console.log('\n' + pass + ' passed, ' + fail + ' failed');
  process.exit(fail === 0 ? 0 : 1);
}

main().catch((e) => { console.error('TEST CRASH', e); process.exit(2); });
