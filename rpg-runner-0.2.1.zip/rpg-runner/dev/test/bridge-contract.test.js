'use strict';
// Static check that the Java @JavascriptInterface methods, the JavaScript that calls them and the test mocks agree
// (names, argument count, argument types). The Android code cannot be run in the sandbox, so drift must be caught here.
const fs = require('fs');
const path = require('path');
const { GAME_SPEC, LAUNCHER_SPEC } = require('./bridge-spec');

const ROOT = path.resolve(__dirname, '..', '..');
const read = (p) => fs.readFileSync(path.join(ROOT, p), 'utf8');

let pass = 0, fail = 0;
function ok(cond, msg, extra) { if (cond) pass++; else { fail++; console.log('FAIL: ' + msg + (extra !== undefined ? '   -> ' + JSON.stringify(extra) : '')); } }
function eq(got, want, msg) { ok(JSON.stringify(got) === JSON.stringify(want), msg, { got, want }); }

const TYPE = { String: 's', boolean: 'b' };

/** @JavascriptInterface public <ret> name(<params>) -> { name: { sig: 'ss', ret: 'String' } } */
function javaInterface(file) {
  const src = read(file);
  const out = {};
  const re = /@JavascriptInterface\s+public\s+(\w+)\s+(\w+)\s*\(([^)]*)\)/g;
  let m;
  while ((m = re.exec(src))) {
    const params = m[3].trim() === '' ? [] : m[3].split(',').map((p) => p.trim().replace(/^final\s+/, '').split(/\s+/)[0]);
    out[m[2]] = { sig: params.map((t) => TYPE[t] || '?' + t).join(''), ret: m[1] };
  }
  return out;
}

function compare(label, javaFile, spec) {
  const java = javaInterface(javaFile);
  eq(Object.keys(java).sort(), Object.keys(spec).sort(), label + ': Java methods == expected method names');
  for (const name of Object.keys(spec)) {
    ok(java[name] && java[name].sig === spec[name], label + ': ' + name + ' signature (' + (java[name] ? java[name].sig : 'missing') + ' vs ' + spec[name] + ')');
  }
  return java;
}

const gameJava = compare('RRNative', 'app/src/main/java/app/rpgrunner/GameActivity.java', GAME_SPEC);
const launcherJava = compare('Launcher', 'app/src/main/java/app/rpgrunner/LauncherActivity.java', LAUNCHER_SPEC);

// file operations return a String ("" / data / "!ECODE"); the shim relies on that
['exists', 'stat', 'readdir', 'readBase64', 'writeBase64', 'mkdir', 'unlink', 'rmdir', 'rename', 'copy'].forEach((n) => eq(gameJava[n].ret, 'String', 'RRNative.' + n + ' returns String'));
['log', 'exit', 'showMenu', 'openUrl'].forEach((n) => eq(gameJava[n].ret, 'void', 'RRNative.' + n + ' returns void'));
['getState', 'addGamePath', 'readLog'].forEach((n) => eq(launcherJava[n].ret, 'String', 'Launcher.' + n + ' returns String'));

// ---- call sites in the page scripts must use known methods with the right number of arguments
const shim = read('app/src/main/assets/shim/shim.js') + '\n' + read('app/src/main/assets/shim/overlay.js') + '\n' + read('app/src/main/assets/shim/perf.js');
// nativeCall('name', 'syscall', path[, a[, b]]) -> 1 + extras arguments
const nativeCalls = [...shim.matchAll(/nativeCall\('(\w+)',\s*'[\w]+',\s*([^;]*?)\)(?=[;)\s,}]|$)/g)];
ok(nativeCalls.length >= 12, 'found the fs call sites in shim.js', nativeCalls.length);
for (const m of nativeCalls) {
  ok(m[1] in GAME_SPEC, 'shim calls a known native method: ' + m[1]);
}
// direct N.xxx( calls
for (const m of shim.matchAll(/\bN\.(\w+)\(([^)]*)\)/g)) {
  if (['log', 'exit', 'showMenu', 'openUrl'].includes(m[1])) {
    const argc = m[2].trim() === '' ? 0 : m[2].split(',').length;
    eq(argc, GAME_SPEC[m[1]].length, 'N.' + m[1] + '(...) passes ' + GAME_SPEC[m[1]].length + ' argument(s)');
  }
}
for (const m of shim.matchAll(/typeof N\.(\w+)\s*===\s*'function'/g)) ok(m[1] in GAME_SPEC, 'shim feature-tests a known native method: ' + m[1]);

const launcherHtml = read('app/src/main/assets/launcher/index.html');
const used = new Set([...launcherHtml.matchAll(/call\('(\w+)'/g)].map((m) => m[1]));
ok(used.size >= 8, 'found the launcher call sites', [...used]);
for (const n of used) ok(n in LAUNCHER_SPEC, 'launcher page calls a known Launcher method: ' + n);
// every Java-side event name the page handles
const emitted = new Set([...read('app/src/main/java/app/rpgrunner/LauncherActivity.java').matchAll(/emit\("(\w+)"/g)].map((m) => m[1]));
for (const n of emitted) ok(new RegExp("name === '" + n + "'").test(launcherHtml), 'launcher page handles the "' + n + '" event');

// ---- manifest sanity
const manifest = read('app/src/main/AndroidManifest.xml');
['.App', '.LauncherActivity', '.GameActivity'].forEach((c) => ok(manifest.includes('android:name="' + c + '"'), 'manifest declares ' + c));
ok(/android:process=":game"/.test(manifest), 'game runs in its own process');
['INTERNET', 'MANAGE_EXTERNAL_STORAGE'].forEach((p) => ok(manifest.includes('android.permission.' + p), 'manifest requests ' + p));
for (const cls of ['App', 'LauncherActivity', 'GameActivity']) ok(fs.existsSync(path.join(ROOT, 'app/src/main/java/app/rpgrunner/' + cls + '.java')), cls + '.java exists');
ok(fs.existsSync(path.join(ROOT, 'app/src/main/assets/launcher/index.html')), 'launcher page is in assets');
ok(fs.existsSync(path.join(ROOT, 'app/src/main/assets/shim/shim.js')) && fs.existsSync(path.join(ROOT, 'app/src/main/assets/shim/overlay.js')), 'shim assets are in place');
// every script the server injects must exist as an asset (config.js is generated by the server)
const injected = [...new Set([...read('app/src/main/java/app/rpgrunner/GameServer.java').matchAll(/\/__rr\/([A-Za-z0-9_.-]+\.js)/g)].map((m) => m[1]))].filter((n) => n !== 'config.js');
ok(injected.length >= 3, 'found the injected scripts', injected);
for (const n of injected) ok(fs.existsSync(path.join(ROOT, 'app/src/main/assets/shim', n)), 'injected script exists in assets/shim: ' + n);

// shim.js in assets must be the build of dev/shim-parts
const parts = fs.readdirSync(path.join(ROOT, 'dev', 'shim-parts')).filter((f) => /\.js$/.test(f)).sort().map((f) => read('dev/shim-parts/' + f)).join('');
ok(parts === read('app/src/main/assets/shim/shim.js'), 'assets/shim/shim.js is up to date with dev/shim-parts (run dev/build-shim.sh)');

console.log('\n' + pass + ' passed, ' + fail + ' failed');
process.exit(fail === 0 ? 0 : 1);
