'use strict';
// Shared by streams.test.js (shim parts inside Node) and shim.test.js (the real shim in Chromium): the environment the scenarios of
// stream-scenarios.js / fs-scenarios.js run in when they run against REAL Node, plus the log normalisation.
const fs = require('fs');
const os = require('os');
const path = require('path');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** One-line outcome of a call: its (JSON) result, or its error code and message. */
const show = (f) => {
  try {
    const r = f();
    return 'ok ' + (r !== null && typeof r === 'object' ? JSON.stringify(r) : String(r));
  } catch (e) { return 'ERR ' + (e.code || e.name) + ' | ' + e.message; }
};

/** Deterministic test data of n bytes (the same in every environment). */
const bigData = (Buffer, n) => {
  const b = Buffer.alloc(n);
  for (let i = 0; i < n; i++) b[i] = (i * 31 + (i >> 7)) & 255;
  return b;
};

/** Environment of real Node: { env, T, finish() }. */
function nodeEnv(log) {
  const T = fs.mkdtempSync(path.join(os.tmpdir(), 'rr-node-'));
  return {
    T,
    env: { stream: require('stream'), fs, zlib: require('zlib'), crypto: require('crypto'), StringDecoder: require('string_decoder').StringDecoder,
      Buffer, T, log: (s) => log.push(String(s)), sleep, show, bigData: (n) => bigData(Buffer, n) },
    finish: () => { fs.rmSync(T, { recursive: true, force: true }); },
  };
}

/** Makes the logs of two runs comparable: the (different) temp folder becomes <T>. */
const norm = (lines, T) => lines.map((l) => (T ? l.split(T).join('<T>') : l));

function withTimeout(p, ms, what) {
  let t;
  return Promise.race([p, new Promise((_, rej) => { t = setTimeout(() => rej(new Error('timeout after ' + ms + ' ms (' + what + ')')), ms); })]).finally(() => clearTimeout(t));
}

module.exports = { sleep, show, bigData, nodeEnv, norm, withTimeout };
