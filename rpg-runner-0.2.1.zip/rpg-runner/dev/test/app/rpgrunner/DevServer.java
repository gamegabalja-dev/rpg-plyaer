package app.rpgrunner;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.Charset;
import java.util.Map;

/**
 * Desktop stand-in for GameActivity, used by the Chromium tests (dev/test/shim.test.js).
 * It starts the real GameServer and, on a second port, exposes the NativeFs methods the Android JS bridge
 * (window.RRNative) would offer, so the test page can emulate that bridge with synchronous XHR.
 *
 * usage: DevServer GAME_DIR ASSETS_DIR DATA_DIR [--fps=30] [--pad=false] [--renderer=canvas]
 * prints: PORT n / BRIDGE n / URL ... / then "SRV level message" and "JS level message" lines for logs.
 */
public final class DevServer {
    private static final Charset UTF8 = Charset.forName("UTF-8");

    public static void main(String[] args) throws Exception {
        final File game = new File(args[0]).getCanonicalFile();
        final File assets = new File(args[1]);
        final File data = new File(args[2]).getCanonicalFile();
        data.mkdirs();
        File tmp = new File(data, "tmp");
        tmp.mkdirs();
        int fps = 0;
        boolean pad = true;
        String renderer = "auto";
        for (int i = 3; i < args.length; i++) {
            if (args[i].startsWith("--fps=")) fps = Integer.parseInt(args[i].substring(6));
            else if (args[i].startsWith("--pad=")) pad = Boolean.parseBoolean(args[i].substring(6));
            else if (args[i].startsWith("--renderer=")) renderer = args[i].substring(11);
        }
        GameEntry g = GameDetector.detect(game);
        if (g == null) {
            System.out.println("ERR not a game folder: " + game);
            System.exit(2);
        }
        g.fpsLimit = fps;
        g.pad = pad;
        g.renderer = renderer;

        final NativeFs fs = new NativeFs(game, data);
        String cfg = ConfigJs.build(g, data.getPath(), tmp.getPath(), true);
        GameServer srv = new GameServer(fs, new GameServer.AssetSource() {
            public InputStream open(String name) throws IOException {
                File f = new File(assets, name);
                return f.isFile() ? new FileInputStream(f) : null;
            }
        }, cfg, new GameServer.Listener() {
            public void onLog(String level, String message) {
                System.out.println("SRV " + level + " " + message.replace('\n', ' '));
            }
        });
        if (g.isRm2k()) srv.registerEasyRpgGame(g.id, game);
        int port = srv.start(0);

        HttpServer bridge = HttpServer.create(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), 0), 0);
        bridge.createContext("/bridge", new HttpHandler() {
            public void handle(HttpExchange ex) throws IOException {
                ex.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
                ex.getResponseHeaders().add("Access-Control-Allow-Headers", "*");
                if ("OPTIONS".equals(ex.getRequestMethod())) {
                    ex.sendResponseHeaders(204, -1);
                    ex.close();
                    return;
                }
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                InputStream in = ex.getRequestBody();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
                Map<String, Object> req = MiniJson.asMap(MiniJson.tryParse(new String(bos.toByteArray(), UTF8)));
                String out = call(fs, req);
                byte[] body = out.getBytes(UTF8);
                ex.getResponseHeaders().add("Content-Type", "text/plain; charset=utf-8");
                ex.sendResponseHeaders(200, body.length);
                OutputStream os = ex.getResponseBody();
                os.write(body);
                os.close();
            }
        });
        bridge.start();

        System.out.println("PORT " + port);
        System.out.println("BRIDGE " + bridge.getAddress().getPort());
        System.out.println("URL " + PageUrl.forGame(port, g));
        System.out.println("ID " + g.id);
        System.out.flush();
        // run until the parent closes our stdin or kills us
        while (System.in.read() >= 0) {
            // ignore input
        }
        srv.stop();
        bridge.stop(0);
    }

    private static String call(NativeFs fs, Map<String, Object> r) {
        if (r == null) return "!EINVAL";
        String m = MiniJson.str(r.get("m"), "");
        String a = MiniJson.str(r.get("a"), "");
        String b = MiniJson.str(r.get("b"), "");
        boolean flag = MiniJson.bool(r.get("f"), false);
        if (m.equals("exists")) return fs.exists(a);
        if (m.equals("stat")) return fs.stat(a);
        if (m.equals("readdir")) return fs.readdir(a);
        if (m.equals("readBase64")) return fs.readBase64(a);
        if (m.equals("writeBase64")) return fs.writeBase64(a, b, flag);
        if (m.equals("mkdir")) return fs.mkdir(a, flag);
        if (m.equals("unlink")) return fs.unlink(a);
        if (m.equals("rmdir")) return fs.rmdir(a, flag);
        if (m.equals("rename")) return fs.rename(a, b);
        if (m.equals("copy")) return fs.copy(a, b);
        if (m.equals("log")) {
            System.out.println("JS " + a + " " + b.replace('\n', ' '));
            System.out.flush();
            return "";
        }
        if (m.equals("exit")) {
            System.out.println("JS EXIT");
            System.out.flush();
            return "";
        }
        if (m.equals("showMenu")) {
            System.out.println("JS MENU");
            System.out.flush();
            return "";
        }
        if (m.equals("openUrl")) {
            System.out.println("JS OPENURL " + a);
            System.out.flush();
            return "";
        }
        return "!ENOSYS";
    }
}
