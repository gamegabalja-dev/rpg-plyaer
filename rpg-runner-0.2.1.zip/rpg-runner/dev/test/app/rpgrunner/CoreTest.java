package app.rpgrunner;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.Socket;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/** Desktop-JVM tests for the pure-Java half of the app (no JUnit so it runs with just javac + java). */
public class CoreTest {
    static int passed = 0;
    static int failed = 0;
    static final Charset UTF8 = Charset.forName("UTF-8");

    static void check(boolean ok, String what) {
        if (ok) {
            passed++;
        } else {
            failed++;
            System.out.println("FAIL: " + what);
        }
    }

    static void eq(Object a, Object b, String what) {
        boolean ok = (a == null) ? b == null : a.equals(b);
        if (!ok) System.out.println("   expected <" + b + "> got <" + a + ">");
        check(ok, what);
    }

    static File tmp(String name) throws IOException {
        File d = File.createTempFile("rrtest-" + name, "");
        d.delete();
        d.mkdirs();
        return d.getCanonicalFile();
    }

    static void write(File f, String text) throws IOException {
        f.getParentFile().mkdirs();
        FileOutputStream o = new FileOutputStream(f);
        o.write(text.getBytes(UTF8));
        o.close();
    }

    static void writeBytes(File f, byte[] b) throws IOException {
        f.getParentFile().mkdirs();
        FileOutputStream o = new FileOutputStream(f);
        o.write(b);
        o.close();
    }

    public static void main(String[] args) throws Exception {
        testJson();
        testBase64();
        testPathUtil();
        testNativeFs();
        testDetector();
        testLogStore();
        testCoverStore();
        testLayoutProbe();
        testRequestStats();
        testServer();
        testEasyRpg();
        testConfigJs();
        testPageUrl();
        testGameStore();
        testStorageAccess();
        System.out.println("\n" + passed + " passed, " + failed + " failed");
        System.exit(failed == 0 ? 0 : 1);
    }

    // ------------------------------------------------------------------ MiniJson

    static void testJson() {
        Object o = MiniJson.parse("{\"a\":1,\"b\":[true,false,null,\"x\\n\\u00e9\"],\"c\":{\"d\":-2.5e1},\"big\":12345678901234567890}");
        Map<String, Object> m = MiniJson.asMap(o);
        eq(m.get("a"), Long.valueOf(1), "json int");
        eq(MiniJson.asList(m.get("b")).get(3), "x\n\u00e9", "json string escapes");
        eq(MiniJson.asMap(m.get("c")).get("d"), Double.valueOf(-25.0), "json double");
        check(m.get("big") instanceof Double, "json huge int falls back to double");
        eq(MiniJson.stringify(MiniJson.parse("[1,2.0,\"a\\\"b\"]")), "[1,2,\"a\\\"b\"]", "json roundtrip");
        eq(MiniJson.stringify("</script>"), "\"\\u003c/script\\u003e\"", "json escapes script end");
        eq(MiniJson.parse("\uFEFF{\"x\":1}") instanceof Map, true, "json BOM");
        check(MiniJson.tryParse("{\"a\":1} x") == null, "json trailing garbage rejected");
        check(MiniJson.tryParse("{\"a\":}") == null, "json bad value rejected");
        check(MiniJson.tryParse("[1,2") == null, "json unterminated rejected");
        StringBuilder deep = new StringBuilder();
        for (int i = 0; i < 1000; i++) deep.append('[');
        check(MiniJson.tryParse(deep.toString()) == null, "json depth limit");
        Map<String, Object> out = new LinkedHashMap<String, Object>();
        out.put("k", Arrays.asList("a", Integer.valueOf(2), Boolean.TRUE));
        out.put("n", null);
        eq(MiniJson.stringify(out), "{\"k\":[\"a\",2,true],\"n\":null}", "json stringify map");
    }

    // ------------------------------------------------------------------ Base64

    static void testBase64() {
        Random r = new Random(7);
        boolean ok = true;
        for (int len = 0; len < 200; len++) {
            byte[] b = new byte[len];
            r.nextBytes(b);
            String enc = Base64Lite.encode(b);
            String ref = java.util.Base64.getEncoder().encodeToString(b);
            if (!enc.equals(ref)) ok = false;
            if (!Arrays.equals(Base64Lite.decode(enc), b)) ok = false;
            if (!Arrays.equals(Base64Lite.decode(ref.replace("=", "")), b)) ok = false;
        }
        check(ok, "base64 matches java.util.Base64 for lengths 0..199");
        check(Base64Lite.decode("***") == null, "base64 rejects garbage");
        check(Arrays.equals(Base64Lite.decode("aG\nk ="), new byte[] {'h', 'i'}), "base64 whitespace tolerant");
    }

    // ------------------------------------------------------------------ PathUtil

    static void testPathUtil() {
        eq(PathUtil.normalize("/a/b/../c"), "/a/c", "normalize ..");
        eq(PathUtil.normalize("/../../x"), "/x", "normalize cannot climb above root");
        eq(PathUtil.normalize("//a///b/"), "/a/b", "normalize slashes");
        eq(PathUtil.normalize("/a\\b\\c"), "/a/b/c", "normalize backslashes");
        eq(PathUtil.normalize("/"), "/", "normalize root");
        eq(PathUtil.storageKind("/storage/emulated/0/Games/x"), "internal storage", "storage kind: emulated");
        eq(PathUtil.storageKind("/sdcard/Games"), "internal storage", "storage kind: /sdcard");
        eq(PathUtil.storageKind("/data/user/0/app.rpgrunner/files"), "internal storage", "storage kind: app data");
        eq(PathUtil.storageKind("/storage/399D-D78B/GAMES/project"), "removable volume 399D-D78B (SD card / USB)", "storage kind: SD card");
        eq(PathUtil.storageKind("/storage/399D-D78B"), "removable volume 399D-D78B (SD card / USB)", "storage kind: SD card root");
        eq(PathUtil.storageKind("/storage/emulated"), "unknown", "storage kind: emulated root alone");
        eq(PathUtil.storageKind("relative/path"), "unknown", "storage kind: relative path");
        eq(PathUtil.storageKind(null), "unknown", "storage kind: null");
        eq(PathUtil.normalize("a/b"), null, "normalize relative -> null");
        eq(PathUtil.normalize("/a\0b"), null, "normalize NUL -> null");
        eq(PathUtil.normalize("/a/./b/."), "/a/b", "normalize dots");
    }

    // ------------------------------------------------------------------ NativeFs

    static void testNativeFs() throws Exception {
        File root = tmp("fs-root");
        File data = tmp("fs-data");
        File outside = tmp("fs-outside");
        write(new File(root, "www/Audio/BGM/Theme.OGG"), "ogg");
        write(new File(root, "www/js/main.js"), "console.log(1)");
        write(new File(outside, "secret.txt"), "top secret");
        NativeFs fs = new NativeFs(root, data);
        String r = root.getPath();

        eq(fs.exists(r + "/www/js/main.js"), "1", "fs exists exact");
        eq(fs.exists(r + "/WWW/JS/MAIN.JS"), "1", "fs exists case-insensitive");
        eq(fs.exists(r + "/www/audio/bgm/theme.ogg"), "1", "fs deep case-insensitive");
        eq(fs.exists(r + "/www/nope.js"), "0", "fs missing");
        eq(fs.exists(outside.getPath() + "/secret.txt"), "0", "fs outside sandbox denied");
        eq(fs.exists(r + "/../" + outside.getName() + "/secret.txt"), "0", "fs traversal denied");
        eq(fs.exists(r + "/www/../../../etc/passwd"), "0", "fs traversal to /etc/passwd denied");

        // symlink pointing out of the sandbox
        try {
            java.nio.file.Files.createSymbolicLink(new File(root, "escape").toPath(), outside.toPath());
            eq(fs.exists(r + "/escape/secret.txt"), "0", "fs symlink escape denied");
            eq(fs.readBase64(r + "/escape/secret.txt"), "!ENOENT", "fs symlink escape read denied");
        } catch (UnsupportedOperationException e) {
            System.out.println("   (symlinks unsupported, skipped)");
        }

        eq(fs.stat(r + "/www/js/main.js").contains("\"f\":1"), true, "fs stat file");
        eq(fs.stat(r + "/www").contains("\"d\":1"), true, "fs stat dir");
        eq(fs.stat(r + "/zzz"), "!ENOENT", "fs stat missing");
        eq(fs.readdir(r + "/www"), "[\"Audio\",\"js\"]", "fs readdir sorted");
        eq(fs.readdir(r + "/www/js/main.js"), "!ENOTDIR", "fs readdir on file");

        // writes
        String save = r + "/www/save";
        eq(fs.writeBase64(save + "/file1.rpgsave", "aGVsbG8=", false), "!ENOENT", "fs write needs parent dir");
        eq(fs.mkdir(save, false), "", "fs mkdir");
        eq(fs.mkdir(save, false), "!EEXIST", "fs mkdir twice");
        eq(fs.mkdir(r + "/a/b/c", true), "", "fs mkdir -p");
        eq(fs.writeBase64(save + "/file1.rpgsave", "aGVsbG8=", false), "", "fs write");
        eq(fs.readBase64(save + "/file1.rpgsave"), "aGVsbG8=", "fs read back");
        eq(fs.writeBase64(save + "/file1.rpgsave", "d29ybGQ=", true), "", "fs append");
        eq(new String(Base64Lite.decode(fs.readBase64(save + "/file1.rpgsave")), UTF8), "helloworld", "fs appended content");
        eq(fs.writeBase64(save + "/FILE1.RPGSAVE", "eA==", false), "", "fs overwrite via other case");
        eq(new File(save).list().length, 1, "fs overwrite via other case keeps one file (no .rr-tmp left)");
        eq(fs.writeBase64(save + "/x", "***", false), "!EINVAL", "fs write bad base64");
        eq(fs.writeBase64("/tmp/rr-should-not-exist", "eA==", false), "!EACCES", "fs write outside sandbox denied");
        eq(fs.copy(save + "/file1.rpgsave", save + "/copy.bin"), "", "fs copy");
        eq(fs.rename(save + "/copy.bin", save + "/moved.bin"), "", "fs rename");
        eq(fs.exists(save + "/copy.bin"), "0", "fs rename removed source");
        eq(fs.unlink(save + "/moved.bin"), "", "fs unlink");
        eq(fs.unlink(save + "/moved.bin"), "!ENOENT", "fs unlink twice");
        eq(fs.rmdir(save, false), "!ENOTEMPTY", "fs rmdir non-empty");
        eq(fs.rmdir(save, true), "", "fs rmdir -r");
        eq(fs.rmdir(r, true), "!EACCES", "fs never deletes sandbox root");
        eq(fs.writeBase64(data.getPath() + "/cfg.json", "e30=", false), "", "fs second root writable");
    }

    // ------------------------------------------------------------------ GameDetector

    static void testDetector() throws Exception {
        File parent = tmp("detect");
        // MV, Windows deployment layout with a ?canvas main and a real title in System.json
        File mv = new File(parent, "Witch House");
        write(new File(mv, "package.json"), "{\"name\":\"Project1\",\"main\":\"www/index.html?canvas\",\"window\":{\"title\":\"pkg title\"}}");
        write(new File(mv, "www/index.html"), "<html><head></head><body></body></html>");
        write(new File(mv, "www/js/rpg_core.js"), "//");
        write(new File(mv, "www/data/System.json"), "{\"gameTitle\":\"The Witch's House MV\"}");
        GameEntry g = GameDetector.detect(mv);
        check(g != null, "detect MV");
        eq(g.engine, "mv", "mv engine");
        eq(g.name, "The Witch's House MV", "mv title from System.json");
        eq(g.mainQuery, "canvas", "mv main query");
        check(g.mainHtml.endsWith("/Witch House/www/index.html"), "mv main html path " + g.mainHtml);

        // MV with unusual case and no System.json (OMORI-like: encrypted data)
        File omori = new File(parent, "OMORI");
        write(new File(omori, "package.json"), "{\"main\":\"WWW/Index.html\",\"window\":{\"title\":\"OMORI\"}}");
        write(new File(omori, "www/index.html"), "<html></html>");
        write(new File(omori, "www/js/rpg_core.js"), "//");
        GameEntry o = GameDetector.detect(omori);
        check(o != null && o.engine.equals("mv"), "detect case-insensitive main");
        eq(o.name, "OMORI", "title from package.json window.title");

        // MZ: everything in the root
        File mz = new File(parent, "MZGame");
        write(new File(mz, "package.json"), "{\"name\":\"mz\",\"main\":\"index.html\"}");
        write(new File(mz, "index.html"), "<html></html>");
        write(new File(mz, "js/rmmz_core.js"), "//");
        GameEntry z = GameDetector.detect(mz);
        eq(z.engine, "mz", "detect MZ");
        eq(z.name, "MZGame", "MZ falls back to folder name");

        // no package.json at all
        File bare = new File(parent, "Bare");
        write(new File(bare, "www/index.html"), "<html></html>");
        write(new File(bare, "www/js/rpg_core.js"), "//");
        eq(GameDetector.detect(bare).engine, "mv", "detect without package.json");

        // RPG Maker 2003
        File yn = new File(parent, "YumeNikki");
        write(new File(yn, "RPG_RT.ldb"), "x");
        write(new File(yn, "RPG_RT.ini"), "[RPG_RT]\r\nGameTitle=Yume Nikki\r\n");
        GameEntry y = GameDetector.detect(yn);
        eq(y.engine, "rm2k", "detect RM2k");
        eq(y.name, "Yume Nikki", "RM2k title from ini");

        write(new File(parent, "NotAGame/readme.txt"), "x");
        List<GameEntry> found = GameDetector.scan(parent, 2);
        eq(found.size(), 5, "scan finds all five games, ignores others");
        eq(GameDetector.scan(mv, 2).size(), 1, "scan of a game folder returns just it");
        check(GameDetector.detect(new File(parent, "NotAGame")) == null, "non-game is null");
        eq(GameDetector.idFor("/a/b"), GameDetector.idFor("/a/b"), "id is stable");
        check(!GameDetector.idFor("/a/b").equals(GameDetector.idFor("/a/c")), "ids differ");

        // GameEntry settings round trip + validation
        GameEntry e = GameEntry.fromMap(MiniJson.asMap(MiniJson.parse(MiniJson.stringify(g.toMap()))));
        eq(e.id, g.id, "entry roundtrip id");
        Map<String, Object> upd = new LinkedHashMap<String, Object>();
        upd.put("renderer", "bogus");
        upd.put("padOpacity", Long.valueOf(500));
        upd.put("fpsLimit", Long.valueOf(37));
        upd.put("padScale", Long.valueOf(10));
        e.applySettings(upd);
        eq(e.renderer, "auto", "renderer validated");
        eq(e.padOpacity, 100, "opacity clamped");
        eq(e.fpsLimit, 0, "fps limit validated");
        eq(e.padScale, 50, "scale clamped");
    }

    // ------------------------------------------------------------------ LogStore

    static void testLogStore() throws Exception {
        File dir = tmp("log");
        LogStore ls = LogStore.create(dir, "My Game: 한글/x", "0123456789ab");
        ls.log("I", "hello");
        ls.log("I", "same");
        ls.log("I", "same");
        ls.log("I", "same");
        ls.log("W", "other");
        ls.close();
        String text = LogStore.tail(ls.file(), 100000);
        check(text.contains("hello") && text.contains("other"), "log contains lines");
        check(text.contains("repeated 2 more times"), "log folds repeats");
        check(ls.file().getName().startsWith("My_Game_x-0123456789ab-"), "log file name: sanitized game name + game id: " + ls.file().getName());
        check(ls.file().getName().matches("My_Game_x-0123456789ab-\\d{8}-\\d{6}\\.log"), "log file name shape: " + ls.file().getName());
        String t2 = LogStore.tail(ls.file(), 30);
        check(t2.startsWith("... (earlier lines omitted)"), "tail truncates");
        eq(LogStore.list(dir).size(), 1, "list logs");

        // finding the newest log of one game
        File older = new File(dir, "Renamed-0123456789ab-20200101-010101.log");
        File other = new File(dir, "Other-ffffffffffff-20300101-010101.log");
        File noId = new File(dir, "Plain-20300101-010101.log");
        write(older, "old");
        write(other, "other game");
        write(noId, "no id");
        ls.file().setLastModified(3000000000000L);
        older.setLastModified(1000000000000L);
        other.setLastModified(4000000000000L);
        noId.setLastModified(5000000000000L);
        List<File> all = LogStore.list(dir);
        eq(all.size(), 4, "list: all four logs");
        eq(all.get(0).getName(), noId.getName(), "list: newest first");
        eq(LogStore.latestFor(all, "0123456789ab").getName(), ls.file().getName(), "latestFor: the newest log of that game wins");
        eq(LogStore.latestFor(all, "ffffffffffff").getName(), other.getName(), "latestFor: other game");
        check(LogStore.latestFor(all, "0123456789a") == null, "latestFor: a prefix of an id is not that id");
        check(LogStore.latestFor(all, "") == null && LogStore.latestFor(all, null) == null && LogStore.latestFor(null, "x") == null, "latestFor: empty / null arguments");
        check(LogStore.latestFor(all, "aaaaaaaaaaaa") == null, "latestFor: a game without logs");
        ls.file().delete();
        eq(LogStore.latestFor(LogStore.list(dir), "0123456789ab").getName(), older.getName(), "latestFor: falls back to the older log of the same id (even under another name)");
        LogStore plain = LogStore.create(dir, "한글", "");
        plain.close();
        check(plain.file().getName().matches("_-\\d{8}-\\d{6}\\.log"), "log name without id: " + plain.file().getName());
        eq(LogStore.safeName(null), "game", "safeName: null");
        eq(LogStore.safeName(""), "game", "safeName: empty");
        eq(LogStore.safeName("a b/c").length(), 5, "safeName: separators collapse");
        eq(LogStore.safeName("xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx").length(), 40, "safeName: limited to 40 characters");
        LogStore.prune(dir, 0);
        eq(LogStore.list(dir).size(), 0, "prune logs");
    }

    // ------------------------------------------------------------------ CoverStore

    static final byte[] JPG = {(byte) 0xff, (byte) 0xd8, (byte) 0xff, (byte) 0xe0, 0, 16, 'J', 'F', 'I', 'F', 0, 1};
    static final byte[] PNG = {(byte) 0x89, 'P', 'N', 'G', 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 13, 'I', 'H', 'D', 'R'};

    /** Where the stored pixel (x, y) of a w x h picture ends up after the EXIF fix-up {degrees clockwise, mirror}; the displayed picture is returned as {x, y, displayedWidth}. */
    static int[] exifPlace(int[] ops, int w, int h, int x, int y) {
        int nx = x, ny = y, nw = w;
        switch (ops[0]) {
            case 90: nx = h - 1 - y; ny = x; nw = h; break;
            case 180: nx = w - 1 - x; ny = h - 1 - y; break;
            case 270: nx = y; ny = w - 1 - x; nw = h; break;
            default: break;
        }
        if (ops[1] == 1) nx = nw - 1 - nx;
        return new int[] {nx, ny, nw};
    }

    static void testCoverStore() throws Exception {
        File root = tmp("cover");
        File dir = new File(root, "covers/nested");
        CoverStore cs = new CoverStore(dir);
        String id = "0123456789ab";

        check(CoverStore.validId(id) && CoverStore.validId("ABC_def-1") && CoverStore.validId("a"), "cover: plain tokens are valid ids");
        check(!CoverStore.validId(null) && !CoverStore.validId("") && !CoverStore.validId("../x") && !CoverStore.validId("a/b") && !CoverStore.validId("a.b")
                && !CoverStore.validId("a b") && !CoverStore.validId("a\\b") && !CoverStore.validId("한글"), "cover: path-like ids are rejected");
        check(CoverStore.validId(String.valueOf(new char[64]).replace('\0', 'a')) && !CoverStore.validId(String.valueOf(new char[65]).replace('\0', 'a')), "cover: id length limit is 64");

        eq(CoverStore.sniff(JPG), "jpg", "cover: jpeg signature");
        eq(CoverStore.sniff(PNG), "png", "cover: png signature");
        check(CoverStore.sniff("GIF89a......".getBytes(UTF8)) == null && CoverStore.sniff("hello".getBytes(UTF8)) == null && CoverStore.sniff(new byte[0]) == null && CoverStore.sniff(null) == null, "cover: other data is not a cover");
        check(CoverStore.sniff(Arrays.copyOf(PNG, 7)) == null && CoverStore.sniff(new byte[] {(byte) 0xff, (byte) 0xd8}) == null, "cover: truncated signatures are rejected");

        check(cs.find(id) == null && "0".equals(cs.version(id)), "cover: none yet");
        File f = cs.write(id, JPG);
        eq(f.getName(), id + ".jpg", "cover: jpeg is stored as <id>.jpg");
        check(f.isFile() && f.getParentFile().equals(dir), "cover: folder is created on demand");
        check(Arrays.equals(java.nio.file.Files.readAllBytes(f.toPath()), JPG), "cover: bytes stored unchanged");
        eq(cs.find(id), f, "cover: find");
        eq(CoverStore.mimeOf(f), "image/jpeg", "cover: jpeg mime");
        String v1 = cs.version(id);
        check(!"0".equals(v1) && v1.equals(cs.version(id)), "cover: version is stable while the file is unchanged");
        check(!new File(dir, id + ".tmp").exists(), "cover: no temp file left behind");

        byte[] jpg2 = Arrays.copyOf(JPG, JPG.length + 40);
        cs.write(id, jpg2);
        check(!cs.version(id).equals(v1), "cover: version changes when the picture is replaced");
        eq(cs.find(id).length(), (long) jpg2.length, "cover: replaced content");

        File p = cs.write(id, PNG);
        eq(p.getName(), id + ".png", "cover: png is stored as <id>.png");
        check(!new File(dir, id + ".jpg").exists(), "cover: the other format is removed");
        eq(cs.find(id), p, "cover: find returns the png");
        eq(CoverStore.mimeOf(p), "image/png", "cover: png mime");

        boolean threw = false;
        try {
            cs.write(id, "not an image".getBytes(UTF8));
        } catch (IOException e) {
            threw = true;
        }
        check(threw, "cover: data that is not PNG/JPEG is refused");
        eq(cs.find(id), p, "cover: a refused write keeps the old cover");
        threw = false;
        try {
            cs.write("../evil", JPG);
        } catch (IOException e) {
            threw = true;
        }
        check(threw && !new File(dir.getParentFile(), "evil.jpg").exists() && !new File(dir, "../evil.jpg").exists(), "cover: a path-like id is refused and nothing is written outside");

        // empty files do not count as covers
        writeBytes(new File(dir, "bbbbbbbbbbbb.jpg"), new byte[0]);
        check(cs.find("bbbbbbbbbbbb") == null, "cover: an empty file is no cover");
        check(cs.find("../" + id) == null && cs.find(null) == null, "cover: find with a bad id");

        check(cs.delete(id), "cover: delete reports that there was one");
        check(!cs.delete(id) && cs.find(id) == null, "cover: nothing left after delete");
        check(!cs.delete("../x") && !cs.delete(null), "cover: delete with a bad id does nothing");
        writeBytes(new File(dir, "cccccccccccc.jpg"), JPG);
        writeBytes(new File(dir, "cccccccccccc.png"), PNG);
        writeBytes(new File(dir, "cccccccccccc.tmp"), JPG);
        check(cs.delete("cccccccccccc") && cs.find("cccccccccccc") == null && !new File(dir, "cccccccccccc.tmp").exists(), "cover: delete removes every variant");

        // both formats present (should not happen): the newer one wins
        File j = new File(dir, "dddddddddddd.jpg");
        File q = new File(dir, "dddddddddddd.png");
        writeBytes(j, JPG);
        writeBytes(q, PNG);
        j.setLastModified(2000000000000L);
        q.setLastModified(1000000000000L);
        eq(cs.find("dddddddddddd"), j, "cover: with both formats present the newer wins");

        // picture arithmetic
        eq(CoverStore.sampleSize(4000, 3000, 1280), 2, "sample size 4000x3000");
        eq(CoverStore.sampleSize(1000, 800, 1280), 1, "sample size small picture");
        eq(CoverStore.sampleSize(2560, 1000, 1280), 2, "sample size exactly 2x");
        eq(CoverStore.sampleSize(2559, 1000, 1280), 1, "sample size just below 2x");
        eq(CoverStore.sampleSize(12000, 9000, 1280), 8, "sample size 12000 wide");
        eq(CoverStore.sampleSize(3000, 4000, 1280), 2, "sample size portrait");
        check(CoverStore.sampleSize(0, 0, 1280) == 1 && CoverStore.sampleSize(5000, 5000, 0) == 1, "sample size degenerate input");
        check(Arrays.equals(CoverStore.fit(4000, 3000, 1280), new int[] {1280, 960}), "fit landscape");
        check(Arrays.equals(CoverStore.fit(3000, 4000, 1280), new int[] {960, 1280}), "fit portrait");
        check(Arrays.equals(CoverStore.fit(1000, 500, 1280), new int[] {1000, 500}), "fit never enlarges");
        check(Arrays.equals(CoverStore.fit(1280, 1280, 1280), new int[] {1280, 1280}), "fit exact");
        check(Arrays.equals(CoverStore.fit(20000, 1, 1280), new int[] {1280, 1}), "fit keeps at least 1 pixel");
        check(Arrays.equals(CoverStore.fit(0, 0, 1280), new int[] {1, 1}), "fit degenerate input");

        // EXIF orientation: where the stored top-left / top-right / bottom-left pixel of a 4x3 picture ends up (EXIF spec, orientation 1..8)
        int[][][] expect = {
            /* 1 */ {{0, 0}, {3, 0}, {0, 2}},
            /* 2 */ {{3, 0}, {0, 0}, {3, 2}},
            /* 3 */ {{3, 2}, {0, 2}, {3, 0}},
            /* 4 */ {{0, 2}, {3, 2}, {0, 0}},
            /* 5 */ {{0, 0}, {0, 3}, {2, 0}},
            /* 6 */ {{2, 0}, {2, 3}, {0, 0}},
            /* 7 */ {{2, 3}, {2, 0}, {0, 3}},
            /* 8 */ {{0, 3}, {0, 0}, {2, 3}},
        };
        for (int o = 1; o <= 8; o++) {
            int[] ops = CoverStore.exifOps(o);
            int[] tl = exifPlace(ops, 4, 3, 0, 0);
            int[] tr = exifPlace(ops, 4, 3, 3, 0);
            int[] bl = exifPlace(ops, 4, 3, 0, 2);
            boolean good = tl[0] == expect[o - 1][0][0] && tl[1] == expect[o - 1][0][1]
                    && tr[0] == expect[o - 1][1][0] && tr[1] == expect[o - 1][1][1]
                    && bl[0] == expect[o - 1][2][0] && bl[1] == expect[o - 1][2][1];
            check(good, "exif orientation " + o + " puts the corners where the EXIF spec says: " + Arrays.toString(tl) + Arrays.toString(tr) + Arrays.toString(bl));
        }
        check(Arrays.equals(CoverStore.exifOps(0), new int[] {0, 0}) && Arrays.equals(CoverStore.exifOps(9), new int[] {0, 0}) && Arrays.equals(CoverStore.exifOps(-3), new int[] {0, 0}), "exif: unknown orientation values mean as stored");
    }

    // ------------------------------------------------------------------ GameServer

    static class Resp {
        int code;
        byte[] body;
        Map<String, String> headers = new LinkedHashMap<String, String>();
    }

    // ------------------------------------------------------------------ LayoutProbe

    static String joinLines(List<String> lines) {
        StringBuilder sb = new StringBuilder();
        for (String l : lines) sb.append(l).append('\n');
        return sb.toString();
    }

    static boolean anyStartsWith(List<String> lines, String prefix) {
        for (String l : lines) if (l.startsWith(prefix)) return true;
        return false;
    }

    static void testLayoutProbe() throws Exception {
        File root = tmp("probe");
        File www = new File(root, "www");
        write(new File(root, "package.json"), "{\"name\":\"tcoaal\",\"main\":\"www/index.html\",\"window\":{\"title\":\"The Coffin\"}}");
        write(new File(root, "en.cld"), "abc");
        write(new File(www, "index.html"), "<html></html>");
        write(new File(www, "js/plugins.js"), "var $plugins = [\n{\"name\":\"Alpha\",\"status\":true,\"description\":\"\",\"parameters\":{}},\n"
                + "{\"name\":\"Beta\",\"status\":false,\"description\":\"x\",\"parameters\":{\"a\":\"b\"}},\n{\"name\":\"Gamma\",\"status\":true,\"description\":\"\",\"parameters\":{}}\n];");
        write(new File(www, "js/rpg_core.js"), "x");
        write(new File(www, "languages/en.cld"), "abc");
        write(new File(www, "languages/ko/ui.json"), "{}");
        write(new File(www, "languages/한국어/a.txt"), "z");
        write(new File(www, "img/lang/x.png"), "png"); // inside a picture folder: never searched
        write(new File(www, "data/System.json"), "{}");

        List<String> lines = LayoutProbe.describe(root, new File(www, "index.html").getPath());
        String all = joinLines(lines);
        check(lines.size() > 8 && lines.size() <= 61, "probe: a normal game gives a handful of lines (" + lines.size() + ")");
        check(lines.get(0).startsWith("/ (3 entries) en.cld 3 B, package.json") && lines.get(0).contains("www/"), "probe: the game folder is listed first: " + lines.get(0));
        check(anyStartsWith(lines, "www/ (") && all.contains("index.html") && all.contains("js/") && all.contains("languages/") && all.contains("data/"), "probe: the web folder is listed");
        check(all.contains("package.json: name=tcoaal main=www/index.html window.title=The Coffin"), "probe: package.json summary");
        check(anyStartsWith(lines, "www/languages/ (3 entries) en.cld 3 B, ko/, 한국어/"), "probe: the language folder is listed with its entries: " + all);
        check(anyStartsWith(lines, "www/languages/ko/ (1 entry) ui.json 2 B") && anyStartsWith(lines, "www/languages/한국어/ (1 entry) a.txt 1 B"), "probe: sub folders of the language folder are listed");
        check(all.contains("language packs (*.cld): en.cld (3 B)"), "probe: *.cld files outside language folders are listed");
        check(!anyStartsWith(lines, "www/img/lang"), "probe: picture folders are not searched");
        check(all.contains("js/plugins.js: 3 plugins, 2 enabled: Alpha, Gamma") && all.contains("js/plugins.js disabled: Beta"), "probe: plugin list: " + all);
        check(all.contains("most recently changed:") && all.contains("www/languages/en.cld (") && all.contains("www/js/plugins.js ("), "probe: recently changed files");

        // no language folder at all
        File plain = tmp("probe-plain");
        write(new File(plain, "RPG_RT.ldb"), "x");
        write(new File(plain, "Music/a.mid"), "x");
        List<String> plainLines = LayoutProbe.describe(plain, "");
        check(plainLines.get(0).startsWith("/ (2 entries) Music/, RPG_RT.ldb 1 B") || plainLines.get(0).startsWith("/ (2 entries) Music/"), "probe: RPG Maker 2000/2003 folder is listed: " + plainLines.get(0));
        check(joinLines(plainLines).contains("no language / translation folder or *.cld file found"), "probe: says so when there is no language folder");
        check(!anyStartsWith(plainLines, "www/"), "probe: no web folder without a main page");

        // web folder == game folder: not listed twice
        File flat = tmp("probe-flat");
        write(new File(flat, "index.html"), "<html></html>");
        write(new File(flat, "js/plugins.js"), "var $plugins = [];");
        List<String> flatLines = LayoutProbe.describe(flat, new File(flat, "index.html").getPath());
        int listings = 0;
        for (String l : flatLines) if (l.startsWith("/ (") || l.startsWith("./ (")) listings++;
        eq(Integer.valueOf(listings), Integer.valueOf(1), "probe: a game without www is listed once");
        check(joinLines(flatLines).contains("js/plugins.js: 0 plugins, 0 enabled:"), "probe: empty plugin list");

        // big folders stay short
        File big = tmp("probe-big");
        for (int i = 0; i < 200; i++) write(new File(big, String.format("file%03d.txt", i)), "x");
        for (int i = 0; i < 20; i++) write(new File(big, "www/lang" + i + "/a.txt"), "x");
        List<String> bigLines = LayoutProbe.describe(big, new File(big, "www/index.html").getPath());
        check(bigLines.get(0).startsWith("/ (201 entries) file000.txt 1 B") && bigLines.get(0).contains("... and 141 more"), "probe: long listings are cut: " + bigLines.get(0).substring(0, Math.min(80, bigLines.get(0).length())));
        check(bigLines.size() <= 61, "probe: the number of lines is bounded (" + bigLines.size() + ")");
        check(joinLines(bigLines).contains("more language folder(s)"), "probe: many language folders are summarised");
        for (String l : bigLines) check(l.length() <= 1810, "probe: every line is short enough (" + l.length() + ")");

        // plugins.js that is too big to read, an unreadable game folder, nulls
        File huge = tmp("probe-huge");
        byte[] filler = new byte[1024 * 1024 + 10];
        Arrays.fill(filler, (byte) ' ');
        writeBytes(new File(huge, "www/js/plugins.js"), filler);
        write(new File(huge, "www/index.html"), "x");
        check(joinLines(LayoutProbe.describe(huge, new File(huge, "www/index.html").getPath())).contains("js/plugins.js: not readable"), "probe: a huge plugins.js is skipped");
        check(joinLines(LayoutProbe.describe(new File(root, "does-not-exist"), "")).contains("not a readable directory"), "probe: a missing folder is reported");
        check(joinLines(LayoutProbe.describe(null, null)).contains("not a readable directory"), "probe: null does not throw");
        write(new File(huge, "package.json"), "{ not json");
        check(joinLines(LayoutProbe.describe(huge, "")).contains("package.json: not readable as JSON"), "probe: broken package.json is reported");

        // a decrypted source dump of OMORI (what OmoriSource contains) is recognised; a real install is not
        File dump = tmp("probe-omori-dump");
        write(new File(dump, "package.json"), "{\"name\":\"OMORI\",\"main\":\"index.html\"}");
        write(new File(dump, "index.html"), "<html></html>");
        write(new File(dump, "Game.rpgproject"), "RPGMV 1.6.2");
        write(new File(dump, "data/System.json"), "{}");
        write(new File(dump, "data/Map001.json"), "{}");
        write(new File(dump, "languages/en/01_a.yaml"), "x: y");
        String dumpPath = new File(dump, "index.html").getPath();
        eq(LayoutProbe.sourceDumpKind(dump, dumpPath), LayoutProbe.DUMP_OMORI_DECRYPTED, "probe: OMORI source dump is recognised");
        List<String> dumpLines = LayoutProbe.describe(dump, dumpPath);
        check(anyStartsWith(dumpLines, "WARNING: this OMORI folder has plain data") && joinLines(dumpLines).contains("decrypted source project"), "probe: the dump is explained in the log: " + joinLines(dumpLines));
        check(!joinLines(dumpLines).contains("NOTE: this folder contains an RPG Maker editor project"), "probe: only one of the two hints is given");
        File real = tmp("probe-omori-real");
        write(new File(real, "package.json"), "{\"name\":\"OMORI\",\"main\":\"index.html\"}");
        write(new File(real, "index.html"), "<html></html>");
        write(new File(real, "data/Map001.KEL"), "enc");
        write(new File(real, "data/System.KEL"), "enc");
        write(new File(real, "data/Atlas.json"), "{}");
        check(LayoutProbe.sourceDumpKind(real, new File(real, "index.html").getPath()) == null, "probe: an installed OMORI (with *.KEL files) is not flagged");
        check(!joinLines(LayoutProbe.describe(real, new File(real, "index.html").getPath())).contains("WARNING"), "probe: no warning for an installed OMORI");
        // another game with an editor project file: a note, not a warning
        File proj = tmp("probe-project");
        write(new File(proj, "package.json"), "{\"name\":\"Some Game\",\"main\":\"www/index.html\"}");
        write(new File(proj, "www/index.html"), "<html></html>");
        write(new File(proj, "www/Game.rpgproject"), "RPGMV 1.6.1");
        write(new File(proj, "www/data/Map001.json"), "{}");
        eq(LayoutProbe.sourceDumpKind(proj, new File(proj, "www/index.html").getPath()), LayoutProbe.DUMP_EDITOR_PROJECT, "probe: an editor project file is noticed in the web folder");
        List<String> projLines = LayoutProbe.describe(proj, new File(proj, "www/index.html").getPath());
        check(anyStartsWith(projLines, "NOTE: this folder contains an RPG Maker editor project file") && !joinLines(projLines).contains("WARNING"), "probe: an editor project only gets a note");
        File mz = tmp("probe-mz");
        write(new File(mz, "index.html"), "x");
        write(new File(mz, "game.RMMZPROJECT"), "x");
        eq(LayoutProbe.sourceDumpKind(mz, new File(mz, "index.html").getPath()), LayoutProbe.DUMP_EDITOR_PROJECT, "probe: *.rmmzproject counts too (any letter case)");
        // ordinary games, odd input
        check(LayoutProbe.sourceDumpKind(root, new File(www, "index.html").getPath()) == null, "probe: an ordinary game is not flagged");
        check(LayoutProbe.sourceDumpKind(plain, "") == null && LayoutProbe.sourceDumpKind(null, null) == null && LayoutProbe.sourceDumpKind(new File(root, "nope"), "") == null, "probe: nulls, missing folders and RPG Maker 2000/2003 folders are not flagged");
        write(new File(huge, "package.json"), "{ not json");
        check(LayoutProbe.sourceDumpKind(huge, "") == null, "probe: a broken package.json does not trigger the hint");
    }

    // new URL(String) on purpose: some tests send deliberately malformed paths (e.g. "%zz"), which java.net.URI refuses to parse
    @SuppressWarnings("deprecation")
    static Resp http(int port, String method, String path, String... hdr) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL("http://127.0.0.1:" + port + path).openConnection();
        c.setRequestMethod(method);
        for (int i = 0; i + 1 < hdr.length; i += 2) c.setRequestProperty(hdr[i], hdr[i + 1]);
        Resp r = new Resp();
        r.code = c.getResponseCode();
        for (Map.Entry<String, List<String>> e : c.getHeaderFields().entrySet()) {
            if (e.getKey() != null) r.headers.put(e.getKey().toLowerCase(), e.getValue().get(0));
        }
        InputStream in = r.code >= 400 ? c.getErrorStream() : c.getInputStream();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        if (in != null) {
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            in.close();
        }
        r.body = bos.toByteArray();
        return r;
    }

    static String enc(String path) throws Exception {
        StringBuilder sb = new StringBuilder();
        for (byte b : path.getBytes(UTF8)) {
            int c = b & 0xFF;
            if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || "/-_.~".indexOf(c) >= 0) sb.append((char) c);
            else sb.append(String.format("%%%02X", c));
        }
        return sb.toString();
    }

    static void testServer() throws Exception {
        File root = tmp("srv-root");
        File data = tmp("srv-data");
        File assets = tmp("srv-assets");
        write(new File(assets, "shim/shim.js"), "window.__shim=1;");
        write(new File(assets, "shim/overlay.js"), "window.__overlay=1;");
        write(new File(assets, "shim/perf.js"), "window.__perf=1;");
        write(new File(root, "www/index.html"),
                "<!DOCTYPE html>\n<html>\n<head>\n<meta charset=\"UTF-8\"><title>t</title></head><body><header>hi</header></body></html>");
        write(new File(root, "www/NoHead.html"), "<body>x</body>");
        byte[] big = new byte[1_500_000];
        new Random(1).nextBytes(big);
        writeBytes(new File(root, "www/audio/bgm/Theme.ogg"), big);
        write(new File(root, "www/데이터/마녀의 집 #1.json"), "{\"ok\":true}");
        write(new File(root, "www/empty.bin"), "");

        NativeFs fs = new NativeFs(root, data);
        final List<String> logs = new ArrayList<String>();
        GameServer srv = new GameServer(fs, new GameServer.AssetSource() {
            public InputStream open(String name) throws IOException {
                File f = new File(new File(assets, "dummy").getParentFile(), name);
                if (!f.isFile()) throw new IOException("no asset " + name);
                return new java.io.FileInputStream(f);
            }
        }, "window.__RR_CONFIG={\"x\":1};", new GameServer.Listener() {
            public void onLog(String level, String message) {
                synchronized (logs) {
                    logs.add(level + " " + message);
                }
            }
        });
        int port = srv.start();
        String base = root.getPath();

        Resp r = http(port, "GET", enc(base + "/www/index.html"));
        eq(r.code, 200, "GET index.html");
        String html = new String(r.body, UTF8);
        check(html.contains("<head><script src=\"/__rr/config.js\"></script><script src=\"/__rr/shim.js\"></script>"), "shim injected right after <head>");
        check(html.indexOf("/__rr/shim.js") < html.indexOf("<meta charset"), "shim comes before the page's own tags");
        check(html.contains("<script src=\"/__rr/overlay.js\" defer></script>"), "overlay script injected (deferred)");
        check(html.indexOf("/__rr/shim.js") < html.indexOf("/__rr/perf.js") && html.indexOf("/__rr/perf.js") < html.indexOf("/__rr/overlay.js")
                && html.contains("<script src=\"/__rr/perf.js\"></script>"), "lag diagnostics injected after the shim, before the overlay");
        check(html.contains("<header>hi</header>"), "<header> not mistaken for <head>");
        eq(r.headers.get("content-length"), String.valueOf(r.body.length), "html content-length matches injected body");
        eq(r.headers.get("content-type"), "text/html", "html content-type (charset declared in page)");
        check(!r.headers.containsKey("access-control-allow-origin"), "no CORS header");

        r = http(port, "GET", enc(base + "/WWW/nohead.HTML"));
        eq(r.code, 200, "GET case-insensitive html");
        check(new String(r.body, UTF8).startsWith("<script src=\"/__rr/config.js\">"), "inject at start when no <head>/<html>/doctype");

        r = http(port, "GET", enc(base + "/www/audio/bgm/theme.OGG"));
        eq(r.code, 200, "GET ogg case-insensitive");
        check(Arrays.equals(r.body, big), "ogg bytes identical");
        eq(r.headers.get("content-type"), "audio/ogg", "ogg mime");
        eq(r.headers.get("accept-ranges"), "bytes", "accept-ranges");

        r = http(port, "GET", enc(base + "/www/audio/bgm/Theme.ogg"), "Range", "bytes=10-19");
        eq(r.code, 206, "range 206");
        check(Arrays.equals(r.body, Arrays.copyOfRange(big, 10, 20)), "range bytes");
        eq(r.headers.get("content-range"), "bytes 10-19/" + big.length, "content-range");
        r = http(port, "GET", enc(base + "/www/audio/bgm/Theme.ogg"), "Range", "bytes=-5");
        check(r.code == 206 && Arrays.equals(r.body, Arrays.copyOfRange(big, big.length - 5, big.length)), "suffix range");
        r = http(port, "GET", enc(base + "/www/audio/bgm/Theme.ogg"), "Range", "bytes=1499990-");
        check(r.code == 206 && r.body.length == 10, "open-ended range");
        r = http(port, "GET", enc(base + "/www/audio/bgm/Theme.ogg"), "Range", "bytes=0-99999999");
        check(r.code == 206 && r.body.length == big.length, "range end clamped");
        r = http(port, "GET", enc(base + "/www/audio/bgm/Theme.ogg"), "Range", "bytes=9999999-");
        eq(r.code, 416, "unsatisfiable range 416");
        r = http(port, "GET", enc(base + "/www/audio/bgm/Theme.ogg"), "Range", "bytes=abc");
        check(r.code == 200 && r.body.length == big.length, "garbage range ignored");
        r = http(port, "HEAD", enc(base + "/www/audio/bgm/Theme.ogg"));
        check(r.code == 200 && r.body.length == 0 && r.headers.get("content-length").equals(String.valueOf(big.length)), "HEAD");
        r = http(port, "GET", enc(base + "/www/empty.bin"));
        check(r.code == 200 && r.body.length == 0, "empty file");

        r = http(port, "GET", enc(base + "/www/데이터/마녀의 집 #1.json"));
        check(r.code == 200 && new String(r.body, UTF8).equals("{\"ok\":true}"), "unicode + space + # in path");
        eq(r.headers.get("content-type"), "application/json; charset=utf-8", "json mime");

        r = http(port, "GET", enc(base + "/www/missing.png"));
        eq(r.code, 404, "404 missing");
        r = http(port, "GET", "/etc/passwd");
        eq(r.code, 404, "404 outside sandbox");
        r = http(port, "GET", enc(base) + "/www/../../../../etc/passwd");
        eq(r.code, 404, "404 traversal");
        r = http(port, "GET", enc(base) + "/www/%2e%2e/%2e%2e/%2e%2e/etc/passwd");
        eq(r.code, 404, "404 encoded traversal");
        r = http(port, "GET", enc(base + "/www/") + "%zz");
        eq(r.code, 400, "400 bad percent-escape");
        r = http(port, "GET", enc(base + "/www/%zz"));
        eq(r.code, 404, "a literal % in a file name is just a missing file");
        r = http(port, "POST", enc(base + "/www/index.html"));
        eq(r.code, 405, "405 for POST");
        r = http(port, "GET", enc(base + "/www"));
        eq(r.code, 200, "directory serves index.html");

        r = http(port, "GET", "/__rr/config.js");
        check(r.code == 200 && new String(r.body, UTF8).startsWith("window.__RR_CONFIG"), "config.js");
        r = http(port, "GET", "/__rr/shim.js");
        check(r.code == 200 && new String(r.body, UTF8).equals("window.__shim=1;"), "shim.js from assets");
        r = http(port, "GET", "/__rr/perf.js");
        check(r.code == 200 && new String(r.body, UTF8).equals("window.__perf=1;") && r.headers.get("content-type").startsWith("application/javascript"), "perf.js from assets");
        r = http(port, "GET", "/__rr/../../etc/passwd");
        eq(r.code, 404, "rr path traversal");
        r = http(port, "GET", "/__rr/nope.js");
        eq(r.code, 404, "unknown rr asset");
        r = http(port, "GET", "/__rr/ping");
        eq(new String(r.body, UTF8), "ok", "ping");

        // Host header (DNS rebinding guard)
        Socket s = new Socket("127.0.0.1", port);
        s.getOutputStream().write(("GET /__rr/ping HTTP/1.1\r\nHost: evil.example:" + port + "\r\nConnection: close\r\n\r\n").getBytes(UTF8));
        String raw = readAll(s.getInputStream());
        s.close();
        check(raw.startsWith("HTTP/1.1 403"), "foreign Host header rejected");

        // keep-alive: two requests on one connection
        s = new Socket("127.0.0.1", port);
        OutputStream os = s.getOutputStream();
        os.write(("GET /__rr/ping HTTP/1.1\r\nHost: 127.0.0.1:" + port + "\r\n\r\n").getBytes(UTF8));
        os.write(("GET /__rr/ping HTTP/1.1\r\nHost: 127.0.0.1:" + port + "\r\nConnection: close\r\n\r\n").getBytes(UTF8));
        os.flush();
        raw = readAll(s.getInputStream());
        s.close();
        int count = raw.split("HTTP/1.1 200 OK", -1).length - 1;
        eq(count, 2, "keep-alive serves two requests on one socket");

        // concurrency
        ExecutorService ex = Executors.newFixedThreadPool(16);
        List<Future<Boolean>> fut = new ArrayList<Future<Boolean>>();
        final int fport = port;
        final String fpath = enc(base + "/www/audio/bgm/Theme.ogg");
        final byte[] fbig = big;
        for (int i = 0; i < 64; i++) {
            fut.add(ex.submit(new Callable<Boolean>() {
                public Boolean call() throws Exception {
                    Resp rr = http(fport, "GET", fpath);
                    return Boolean.valueOf(rr.code == 200 && Arrays.equals(rr.body, fbig));
                }
            }));
        }
        boolean allOk = true;
        for (Future<Boolean> f : fut) allOk &= f.get().booleanValue();
        ex.shutdown();
        check(allOk, "64 concurrent 1.5MB downloads are byte-identical");

        synchronized (logs) {
            check(logs.contains("W 404 " + base + "/www/missing.png"), "404 is logged once: " + logs);
            for (String l : logs) check(!l.startsWith("I slow request"), "fast requests are not listed as slow: " + l);
        }
        // timing log: with the threshold at 0 every request is listed, with its path, size and the read / write split
        srv.setSlowRequestMs(0);
        r = http(port, "GET", enc(base + "/www/audio/bgm/Theme.ogg"));
        eq(r.code, 200, "download for the timing log");
        r = http(port, "GET", enc(base + "/www/데이터/마녀의 집 #1.json"));
        eq(r.code, 200, "download of a non-ASCII path for the timing log");
        Thread.sleep(50);
        synchronized (logs) {
            String ogg = null;
            String json = null;
            for (String l : logs) {
                if (l.startsWith("I slow request: GET audio/bgm/Theme.ogg ")) ogg = l;
                if (l.startsWith("I slow request: GET www/데이터/마녀의 집 #1.json ")) json = l;
            }
            check(ogg != null && ogg.contains("1.4 MB took ") && ogg.contains(" ms (read ") && ogg.contains(", write ") && ogg.contains(", other "), "timing log line for a big file: " + ogg);
            check(json != null, "timing log shows decoded non-ASCII paths: " + logs);
        }
        srv.stop();
        synchronized (logs) {
            String total = null;
            for (String l : logs) if (l.startsWith("I requests in this session (")) total = l;
            check(total != null && total.contains("ogg ") && total.contains("json ") && total.contains("slowest "), "the session summary is written when the server stops: " + total);
        }
        try {
            http(port, "GET", "/__rr/ping");
            check(false, "server stopped");
        } catch (IOException expected) {
            check(true, "server stopped");
        }
    }

    // ------------------------------------------------------------------ RequestStats (timing of the page's requests)

    static void testRequestStats() {
        final List<String> out = new ArrayList<String>();
        RequestStats st = new RequestStats(new RequestStats.Sink() {
            public void log(String level, String message) {
                out.add(level + " " + message);
            }
        });
        // helpers
        eq(RequestStats.typeOf("/a/b/Tile.PNG"), "png", "type: extension in lower case");
        eq(RequestStats.typeOf("/a/b/noext"), "none", "type: no extension");
        eq(RequestStats.typeOf("/a/b/x."), "none", "type: trailing dot");
        eq(RequestStats.typeOf("/a.b/c"), "none", "type: dot in a folder name only");
        eq(RequestStats.typeOf("/a/file.verylongext"), "other", "type: too long");
        eq(RequestStats.typeOf("/a/file.p-g"), "other", "type: odd characters");
        eq(RequestStats.typeOf(null), "other", "type: null");
        eq(RequestStats.shortPath("/storage/399D-D78B/GAMES/WH/img/tilesets/Outside_A2.png"), "img/tilesets/Outside_A2.png", "shortPath keeps three segments");
        eq(RequestStats.shortPath("/a/b"), "a/b", "shortPath of a short path");
        eq(RequestStats.shortPath("/a/b/c/d"), "b/c/d", "shortPath of a longer path");
        eq(RequestStats.shortPath("x.png"), "x.png", "shortPath without folders");
        eq(RequestStats.fmtBytes(12), "12 B", "bytes");
        eq(RequestStats.fmtBytes(2048), "2 KB", "KB");
        eq(RequestStats.fmtBytes(3 * 1024 * 1024 + 512 * 1024), "3.5 MB", "MB");

        // fast requests: nothing logged until the 30 s summary
        long t = 1000;
        for (int i = 0; i < 20; i++) st.record("GET", "/g/img/pictures/p" + i + ".png", 40000, 5, 3, 1, t + i * 100);
        st.record("GET", "/g/audio/bgm/a.ogg", 3000000, 80, 60, 15, t + 2500);
        eq(Integer.valueOf(out.size()), Integer.valueOf(0), "stats: fast requests are not logged one by one");
        // a slow one
        st.record("GET", "/g/img/tilesets/Big.png", 2500000, 420, 395, 22, t + 3000);
        eq(Integer.valueOf(out.size()), Integer.valueOf(1), "stats: one slow request, one line");
        eq(out.get(0), "I slow request: GET img/tilesets/Big.png 2.4 MB took 420 ms (read 395, write 22, other 3)", "stats: slow request line");
        // 30 s later the summary comes with the next request
        st.record("GET", "/g/data/Map001.json", 9000, 2, 1, 0, t + RequestStats.SUMMARY_EVERY_MS + 5);
        eq(Integer.valueOf(out.size()), Integer.valueOf(2), "stats: a summary after 30 s");
        String sum = out.get(1);
        check(sum.startsWith("I requests in the last 30 s: 23, ") && sum.contains("slow 1") && sum.contains(" | png 21 (") && sum.contains(" | ogg 1 (") && sum.contains(" | json 1 ("), "stats: summary content: " + sum);
        check(sum.indexOf(" | png ") < sum.indexOf(" | ogg "), "stats: the type that took longest comes first: " + sum);
        // nothing new -> no second summary until 30 s more have passed
        st.record("GET", "/g/x.png", 1, 1, 0, 0, t + RequestStats.SUMMARY_EVERY_MS + 100);
        eq(Integer.valueOf(out.size()), Integer.valueOf(2), "stats: no summary before the next period ends");

        // the number of one-by-one lines is bounded
        out.clear();
        st = new RequestStats(new RequestStats.Sink() {
            public void log(String level, String message) {
                out.add(level + " " + message);
            }
        });
        for (int i = 0; i < RequestStats.MAX_SLOW_LINES + 40; i++) st.record("GET", "/g/s" + i + ".png", 10, 500, 400, 50, t + 70000 + i);
        int slowLines = 0;
        for (String l : out) if (l.startsWith("I slow request")) slowLines++;
        eq(Integer.valueOf(slowLines), Integer.valueOf(RequestStats.MAX_SLOW_LINES), "stats: at most MAX_SLOW_LINES slow lines");
        check(out.get(RequestStats.MAX_SLOW_LINES - 1).contains("no more slow requests are listed"), "stats: the last slow line says that no more follow");

        // many types: only the top ones are shown
        out.clear();
        RequestStats many = new RequestStats(new RequestStats.Sink() {
            public void log(String level, String message) {
                out.add(message);
            }
        });
        String[] exts = {"png", "ogg", "json", "js", "m4a", "css", "woff", "txt", "html"};
        for (int i = 0; i < exts.length; i++) many.record("GET", "/g/f." + exts[i], 100, 10 + i, 5, 1, 5000);
        many.finish(5000 + 12000);
        check(out.size() == 1 && out.get(0).startsWith("requests in this session (12 s): 9, ") && out.get(0).contains("... 3 more type(s)"), "stats: summary of many types is cut: " + out);
        // finish() with nothing recorded, and a second finish()
        out.clear();
        many.finish(99999);
        eq(Integer.valueOf(out.size()), Integer.valueOf(0), "stats: finish() twice writes nothing the second time");
        // finish(): the end of the last period and the whole session, with the not-listed slow requests
        out.clear();
        RequestStats two = new RequestStats(new RequestStats.Sink() {
            public void log(String level, String message) {
                out.add(message);
            }
        });
        two.setSlowMs(100);
        two.record("GET", "/g/a.png", 10, 200, 100, 10, 0);
        two.record("GET", "/g/b.png", 10, 1, 0, 0, RequestStats.SUMMARY_EVERY_MS + 1);
        two.record("GET", "/g/c.png", 10, 1, 0, 0, RequestStats.SUMMARY_EVERY_MS + 500);
        two.finish(RequestStats.SUMMARY_EVERY_MS + 2000);
        check(out.size() == 4 && out.get(0).startsWith("slow request: GET g/a.png") && out.get(1).startsWith("requests in the last 30 s: 2") && out.get(2).startsWith("requests since the last summary: 1")
                && out.get(3).startsWith("requests in this session (32 s): 3"), "stats: periodic summary, rest of the period and session total: " + out);
        // a sink that throws must not disturb the caller
        RequestStats bad = new RequestStats(new RequestStats.Sink() {
            public void log(String level, String message) {
                throw new IllegalStateException("boom");
            }
        });
        bad.setSlowMs(0);
        bad.record("GET", "/x.png", 1, 1, 0, 0, 0);
        bad.finish(10);
        check(true, "stats: a failing log sink does not throw");
    }

    static String readAll(InputStream in) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[4096];
        int n;
        while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
        return new String(bos.toByteArray(), UTF8);
    }

    // ------------------------------------------------------------------ EasyRPG web player support

    /** The engine's own index.json v2 reader (AsyncHandler::CreateRequestMapping), re-implemented to check our output. */
    @SuppressWarnings("unchecked")
    static void engineParse(Map<String, Object> obj, String path, Map<String, String> out) {
        String dirname = obj.get("_dirname") instanceof String ? (String) obj.get("_dirname") : "";
        dirname = path.length() == 0 ? dirname : (dirname.length() == 0 ? path : path + "/" + dirname);
        for (Map.Entry<String, Object> e : obj.entrySet()) {
            if (e.getValue() instanceof Map) {
                engineParse((Map<String, Object>) e.getValue(), dirname, out);
            } else if (e.getValue() instanceof String) {
                String key = dirname.length() == 0 ? e.getKey() : dirname.toLowerCase() + "/" + e.getKey();
                String val = dirname.length() == 0 ? (String) e.getValue() : dirname + "/" + e.getValue();
                if (!e.getKey().equals("_dirname")) out.put(key, val);
            }
        }
    }

    static void testEasyRpg() throws Exception {
        File root = tmp("erpg-game");
        File data = tmp("erpg-data");
        File assets = tmp("erpg-assets");
        write(new File(root, "RPG_RT.ldb"), "ldb");
        write(new File(root, "RPG_RT.INI"), "[RPG_RT]\nGameTitle=Test\n");
        write(new File(root, "Map0001.lmu"), "map");
        write(new File(root, "Music/Dream.MID"), "mid");
        write(new File(root, "Music/Dream.ogg"), "ogg");
        write(new File(root, "Music/loop.wav"), "wav");
        write(new File(root, "CharSet/Madotsuki.png"), "png");
        write(new File(root, "CharSet/한글.PNG"), "png");
        write(new File(root, "Save/Save01.lsd"), "ignored? no, saves are files too");
        write(new File(root, ".hidden/x.png"), "x");
        write(new File(root, "Thumbs.db"), "x");
        write(new File(assets, "easyrpg/rr-player.html"), "<!doctype html><html><head><title>p</title></head><body><canvas id=\"canvas\"></canvas></body></html>");
        write(new File(assets, "easyrpg/index.js"), "var createEasyRpgPlayer=1;");
        writeBytes(new File(assets, "easyrpg/index.wasm"), new byte[] {0, 'a', 's', 'm', 1, 0, 0, 0});
        write(new File(assets, "shim/overlay.js"), "1");
        write(new File(assets, "shim/perf.js"), "1");

        // ---- index.json content, checked against the engine's own parsing rules
        Map<String, Object> idx = MiniJson.asMap(MiniJson.parse(EasyRpgIndex.build(root)));
        eq(MiniJson.asMap(idx.get("metadata")).get("version"), Long.valueOf(2), "index.json version 2");
        Map<String, String> mapping = new java.util.HashMap<String, String>();
        engineParse(MiniJson.asMap(idx.get("cache")), "", mapping);
        eq(mapping.get("rpg_rt.ldb"), "RPG_RT.ldb", "root file keyed lower-case WITH extension");
        eq(mapping.get("rpg_rt.ini"), "RPG_RT.INI", "root file real spelling kept");
        eq(mapping.get("map0001.lmu"), "Map0001.lmu", "map file");
        eq(mapping.get("music/dream"), "Music/Dream.ogg", "sub folder keyed WITHOUT extension, ogg preferred over mid");
        eq(mapping.get("music/loop"), "Music/loop.wav", "wav entry");
        eq(mapping.get("charset/madotsuki"), "CharSet/Madotsuki.png", "charset entry");
        eq(mapping.get("charset/한글"), "CharSet/한글.PNG", "non-ASCII name keeps its characters");
        eq(mapping.get("save/save01"), "Save/Save01.lsd", "Save folder is listed too");
        check(!mapping.containsKey("thumbs.db") && !mapping.containsKey(".hidden/x"), "hidden / junk files skipped");
        eq(mapping, EasyRpgIndex.flatten(root), "build() and flatten() agree");
        eq(EasyRpgIndex.lowerAscii("ÄBc"), "Äbc", "lowerAscii only touches ASCII");

        // ---- routes
        NativeFs fs = new NativeFs(root, data);
        final File assetRoot = assets;
        GameServer srv = new GameServer(fs, new GameServer.AssetSource() {
            public InputStream open(String name) throws IOException {
                File f = new File(assetRoot, name);
                if (!f.isFile()) throw new IOException("no asset " + name);
                return new java.io.FileInputStream(f);
            }
        }, "window.__RR_CONFIG={};", null);
        srv.registerEasyRpgGame("g1234", root);
        int port = srv.start();
        String b = "/__rr/easyrpg/";

        Resp r = http(port, "GET", b + "rr-player.html?game=g1234");
        eq(r.code, 200, "player page served");
        String page = new String(r.body, UTF8);
        check(page.contains("/__rr/overlay.js") && page.contains("/__rr/config.js"), "overlay + config injected into the player page");
        check(!page.contains("shim.js"), "NW.js shim is NOT injected into the player page");
        check(page.contains("/__rr/perf.js") && page.indexOf("/__rr/config.js") < page.indexOf("/__rr/perf.js"), "lag diagnostics are injected into the player page after the config");
        check(page.contains("#apad{display:none!important}"), "the stock on-screen buttons are hidden on the player page");
        check(page.indexOf("/__rr/config.js") < page.indexOf("/__rr/overlay.js"), "config is injected before the overlay");
        check(r.headers.get("content-type").startsWith("text/html"), "player page content type");
        r = http(port, "GET", b + "index.js");
        check(r.code == 200 && r.headers.get("content-type").startsWith("application/javascript"), "player js served as javascript");
        r = http(port, "GET", b + "index.wasm");
        check(r.code == 200 && "application/wasm".equals(r.headers.get("content-type")) && r.body.length == 8, "wasm mime + bytes");
        r = http(port, "GET", b + "missing.wasm");
        eq(r.code, 404, "missing player asset -> 404");
        r = http(port, "GET", b + "..%2f..%2fetc%2fpasswd");
        eq(r.code, 404, "player asset traversal -> 404");

        r = http(port, "GET", b + "games/g1234/index.json");
        check(r.code == 200 && r.headers.get("content-type").startsWith("application/json"), "index.json served");
        check(MiniJson.tryParse(new String(r.body, UTF8)) != null, "index.json is valid JSON");
        r = http(port, "GET", b + "games/g1234/INDEX.JSON");
        eq(r.code, 200, "index.json case-insensitive");
        r = http(port, "GET", b + "games/g1234/RPG_RT.ldb");
        check(r.code == 200 && new String(r.body, UTF8).equals("ldb"), "game file via games/<key>/");
        r = http(port, "GET", b + "games/g1234/music/dream.OGG");
        check(r.code == 200 && new String(r.body, UTF8).equals("ogg"), "game file, case-insensitive");
        r = http(port, "GET", b + "games/g1234/" + enc("CharSet/한글.PNG"));
        eq(r.code, 200, "unicode file name");
        r = http(port, "GET", b + "games/g1234/Music/loop.wav", "Range", "bytes=1-2");
        check(r.code == 206 && new String(r.body, UTF8).equals("av"), "range on game file");
        r = http(port, "GET", b + "games/nope/RPG_RT.ldb");
        eq(r.code, 404, "unknown game key");
        r = http(port, "GET", b + "games/g1234/");
        eq(r.code, 404, "games/<key>/ without a file");
        r = http(port, "GET", b + "games/g1234/..%2f..%2f..%2fetc%2fpasswd");
        eq(r.code, 404, "traversal out of the game folder");
        r = http(port, "GET", b + "games/g1234/%2e%2e/%2e%2e/etc/passwd");
        eq(r.code, 404, "encoded traversal out of the game folder");
        srv.stop();

        // ---- stable port: reuse it next time, fall back to a random one when it is taken
        java.net.ServerSocket probe = new java.net.ServerSocket(0, 1, java.net.InetAddress.getByName("127.0.0.1"));
        int free = probe.getLocalPort();
        probe.close();
        GameServer s1 = new GameServer(fs, null, "", null);
        eq(s1.start(free), free, "server binds the preferred port");
        GameServer s2 = new GameServer(fs, null, "", null);
        int p2 = s2.start(free);
        check(p2 != free && p2 > 0, "second server falls back to a random port (" + p2 + ")");
        s1.stop();
        s2.stop();
        GameServer s3 = new GameServer(fs, null, "", null);
        eq(s3.start(free), free, "preferred port can be re-bound right after stop()");
        s3.stop();
    }

    static void testConfigJs() {
        GameEntry g = new GameEntry();
        g.id = "abc123";
        g.name = "</script>\"quoted\"";
        g.path = "/sdcard/Games/X";
        g.mainHtml = "/sdcard/Games/X/www/index.html";
        g.engine = "mv";
        g.renderer = "canvas";
        g.fpsLimit = 30;
        String js = ConfigJs.build(g, "/data/x", "/tmp/x", true);
        check(js.startsWith("window.__RR_CONFIG={") && js.endsWith(";\n"), "config.js shape");
        check(!js.contains("</script>"), "config.js cannot break out of a script tag");
        Map<String, Object> m = MiniJson.asMap(MiniJson.parse(js.substring("window.__RR_CONFIG=".length(), js.length() - 2)));
        eq(m.get("name"), "</script>\"quoted\"", "config.js name round-trips");
        eq(m.get("renderer"), "canvas", "config.js renderer");
        eq(m.get("fpsLimit"), Long.valueOf(30), "config.js fps");
        eq(m.get("dataDir"), "/data/x", "config.js dataDir");
        eq(m.get("debug"), Boolean.TRUE, "config.js debug flag");
    }

    static void testGameStore() throws Exception {
        File dir = tmp("store");
        File f = new File(dir, "sub/games.json");
        GameStore s = new GameStore(f);
        eq(s.list().size(), 0, "store: missing file -> empty list");
        GameEntry a = new GameEntry();
        a.id = "aaaaaaaaaaaa";
        a.name = "한글 게임 \"A\"";
        a.path = "/storage/emulated/0/Games/A";
        a.engine = GameEntry.ENGINE_MV;
        a.mainHtml = a.path + "/www/index.html";
        a.addedAt = 1000;
        a.padOpacity = 33;
        check(s.upsert(a), "store: upsert of a new game returns true");
        GameEntry b = new GameEntry();
        b.id = "bbbbbbbbbbbb";
        b.name = "B";
        b.path = "/storage/1234-ABCD/B";
        b.engine = GameEntry.ENGINE_RM2K;
        b.encoding = "949";
        check(s.upsert(b), "store: second game");
        eq(s.list().size(), 2, "store: two games listed");
        GameEntry back = s.find("aaaaaaaaaaaa");
        check(back != null && back.name.equals(a.name) && back.padOpacity == 33 && back.mainHtml.equals(a.mainHtml) && back.addedAt == 1000, "store: fields round-trip (unicode, quotes, settings)");
        eq(s.find("bbbbbbbbbbbb").encoding, "949", "store: rm2k encoding round-trips");
        check(s.find("nope") == null && s.find(null) == null, "store: unknown id -> null");
        GameEntry a2 = s.find("aaaaaaaaaaaa");
        a2.fpsLimit = 30;
        a2.addedAt = 5;
        check(!s.upsert(a2), "store: upsert of an existing id returns false");
        eq(s.list().size(), 2, "store: upsert does not duplicate");
        eq(s.find("aaaaaaaaaaaa").fpsLimit, 30, "store: upsert replaced the entry");
        eq(s.find("aaaaaaaaaaaa").addedAt, 1000L, "store: upsert keeps the original addedAt");
        check(s.remove("aaaaaaaaaaaa") && !s.remove("aaaaaaaaaaaa"), "store: remove reports whether something was removed");
        eq(s.list().size(), 1, "store: one game left");
        check(!new File(f.getPath() + ".tmp").exists(), "store: no temp file left behind");
        // another process / instance sees the same data
        eq(new GameStore(f).list().size(), 1, "store: a second instance reads the same file");
        // corrupt file: recovered, old copy kept
        write(f, "{not json");
        eq(s.list().size(), 0, "store: corrupt file -> empty list instead of an exception");
        check(new File(f.getPath() + ".bad").isFile(), "store: corrupt file is kept as .bad");
        check(s.upsert(b), "store: usable again after corruption");
        // entries without id/path are ignored
        write(f, "{\"version\":1,\"games\":[{\"name\":\"x\"},{\"id\":\"c\",\"path\":\"/p\"}, 5, null]}");
        eq(s.list().size(), 1, "store: incomplete entries are skipped");
    }

    static void testStorageAccess() {
        String p = "/storage/emulated/0";
        String ext = "com.android.externalstorage.documents";
        eq(StorageAccess.pathFromTreeDocId(ext, "primary:Games/OMORI", p), "/storage/emulated/0/Games/OMORI", "tree: primary volume");
        eq(StorageAccess.pathFromTreeDocId(ext, "primary:", p), "/storage/emulated/0", "tree: primary root");
        eq(StorageAccess.pathFromTreeDocId(ext, "1A2B-3C4D:RPG/Fear & Hunger", p), "/storage/1A2B-3C4D/RPG/Fear & Hunger", "tree: SD card with spaces and &");
        eq(StorageAccess.pathFromTreeDocId(ext, "home:RPG", p), "/storage/emulated/0/Documents/RPG", "tree: Documents (home) volume");
        eq(StorageAccess.pathFromTreeDocId(ext, "primary:Games/OMORI/", p), "/storage/emulated/0/Games/OMORI", "tree: trailing slash removed");
        eq(StorageAccess.pathFromTreeDocId(ext, "primary:../../etc", p), null, "tree: .. rejected");
        eq(StorageAccess.pathFromTreeDocId(ext, "nocolon", p), null, "tree: malformed id");
        eq(StorageAccess.pathFromTreeDocId(ext, "bad volume:x", p), null, "tree: weird volume name");
        eq(StorageAccess.pathFromTreeDocId("com.google.android.apps.docs.storage", "abc", p), null, "tree: cloud provider unsupported");
        eq(StorageAccess.pathFromTreeDocId("com.android.providers.downloads.documents", "raw:/storage/emulated/0/Download/Games", p), "/storage/emulated/0/Download/Games", "tree: downloads raw path");
        eq(StorageAccess.pathFromTreeDocId("com.android.providers.downloads.documents", "msf:1234", p), null, "tree: downloads media id unsupported");
        eq(StorageAccess.pathFromTreeDocId(ext, null, p), null, "tree: null id");
        check(StorageAccess.isSharedStorage("/storage/emulated/0/Games/X", "app.rpgrunner"), "shared storage: /storage/emulated/0");
        check(StorageAccess.isSharedStorage("/storage/1234-ABCD/X", "app.rpgrunner"), "shared storage: SD card");
        check(StorageAccess.isSharedStorage("/sdcard/Games", "app.rpgrunner"), "shared storage: /sdcard");
        check(!StorageAccess.isSharedStorage("/storage/emulated/0/Android/data/app.rpgrunner/files/Games/X", "app.rpgrunner"), "own app folder needs no permission");
        check(StorageAccess.isSharedStorage("/storage/emulated/0/Android/data/other.app/files", "app.rpgrunner"), "another app's folder is not ours");
        check(!StorageAccess.isSharedStorage("/data/user/0/app.rpgrunner/files/g", "app.rpgrunner"), "internal app storage needs no permission");
    }

    static void testPageUrl() {
        GameEntry g = new GameEntry();
        g.id = "0123456789ab";
        g.engine = GameEntry.ENGINE_MV;
        g.mainHtml = "/storage/emulated/0/Games/The Witch's House MV/www/index.html";
        g.renderer = "auto";
        eq(PageUrl.forGame(8123, g), "http://127.0.0.1:8123/storage/emulated/0/Games/The%20Witch's%20House%20MV/www/index.html",
                "page url: spaces are percent-encoded, apostrophe is kept");

        g.renderer = "canvas";
        check(PageUrl.forGame(8123, g).endsWith("/index.html?canvas"), "page url: canvas renderer adds ?canvas");
        g.renderer = "webgl";
        check(PageUrl.forGame(8123, g).endsWith("/index.html?webgl"), "page url: webgl renderer adds ?webgl");

        g.renderer = "canvas";
        g.mainQuery = "test&webgl";
        eq(PageUrl.forGame(1, g).substring(PageUrl.forGame(1, g).indexOf('?')), "?test&webgl", "page url: an existing renderer token in package.json wins");
        g.mainQuery = "foo=1";
        check(PageUrl.forGame(1, g).endsWith("/index.html?foo=1&canvas"), "page url: renderer token is appended to an existing query");

        g.mainQuery = "";
        g.renderer = "auto";
        g.mainHtml = "/sdcard/게임/오모리/www/index.html";
        String u = PageUrl.forGame(5, g);
        check(u.contains("%EC%98%A4%EB%AA%A8%EB%A6%AC") && !u.contains("오"), "page url: non-ASCII path is UTF-8 percent-encoded");
        g.mainHtml = "/sdcard/a#b?c%d/index.html";
        u = PageUrl.forGame(5, g);
        check(u.endsWith("/sdcard/a%23b%3Fc%25d/index.html"), "page url: # ? % in a folder name are escaped (" + u + ")");

        GameEntry y = new GameEntry();
        y.id = "ffeeddccbbaa";
        y.engine = GameEntry.ENGINE_RM2K;
        y.encoding = "";
        eq(PageUrl.forGame(9, y), "http://127.0.0.1:9/__rr/easyrpg/rr-player.html?game=ffeeddccbbaa", "page url: rm2k without encoding");
        y.encoding = "ko_KR.949";
        check(!PageUrl.forGame(9, y).contains("encoding"), "page url: an invalid encoding value is dropped");
        y.encoding = "949";
        eq(PageUrl.forGame(9, y), "http://127.0.0.1:9/__rr/easyrpg/rr-player.html?game=ffeeddccbbaa&encoding=949", "page url: rm2k with encoding");
    }
}
