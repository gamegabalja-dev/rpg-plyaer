'use strict';
// The JavaScript <-> Java contracts. Letters: s = String, b = boolean (argument types), in call order.
// Keep in sync with GameActivity.Bridge and LauncherActivity.LauncherBridge: bridge-contract.test.js compares them with the Java sources.

/** window.RRNative (GameActivity.Bridge) used by shim.js / overlay.js. */
const GAME_SPEC = {
  exists: 's', stat: 's', readdir: 's', readBase64: 's', writeBase64: 'ssb', mkdir: 'sb', unlink: 's', rmdir: 'sb', rename: 'ss', copy: 'ss',
  log: 'ss', exit: '', showMenu: '', openUrl: 's',
};

/** window.Launcher (LauncherActivity.LauncherBridge) used by the launcher page. */
const LAUNCHER_SPEC = {
  getState: '', addGameFolder: '', addGamePath: 's', removeGame: 's', saveSettings: 'ss', play: 's', pickCover: 's', removeCover: 's', openPermissionSettings: '',
  readLog: 's', copyLog: 's', shareLog: 's', copyText: 's', openEasyRpgApp: '', toast: 's',
};

module.exports = { GAME_SPEC, LAUNCHER_SPEC };
