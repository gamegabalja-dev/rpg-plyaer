'use strict';
// Differential test of the AES ciphers of the NW.js compatibility layer (dev/shim-parts/27-crypto-aes.js) against Node's OpenSSL:
// known-answer vectors, every algorithm / chunking / padding combination, the exact results of every update() call (OpenSSL holds
// the last block back when it decrypts with padding), every error Node reports, the encodings, the stream interface and the legacy
// password based createCipher (Node 22 no longer has it, so it is compared with a reference built from md5 + createCipheriv).
//
//   usage: node dev/test/aes.test.js
const fs = require('fs');
const os = require('os');
const path = require('path');
const nodeCrypto = require('crypto');
const { Readable, Writable, pipeline } = require('stream');
const { loadShim } = require('./shim-node-harness');

let pass = 0, fail = 0;
function ok(cond, msg, extra) {
  if (cond) { pass++; } else { fail++; if (fail <= 60) console.log('FAIL: ' + msg + (extra !== undefined ? '   -> ' + (typeof extra === 'string' ? extra : JSON.stringify(extra)) : '')); }
}
function eq(got, want, msg) { ok(JSON.stringify(got) === JSON.stringify(want), msg, { got, want }); }

const T = fs.mkdtempSync(path.join(os.tmpdir(), 'rr-aes-'));
const sh = loadShim(T);
const C = sh.crypto, SB = sh.Buffer;
process.on('exit', () => { try { fs.rmSync(T, { recursive: true, force: true }); } catch (e) { /* ignore */ } });

const hex = (x) => (typeof x === 'string' ? 'str:' + x : Buffer.from(x.buffer, x.byteOffset, x.length).toString('hex'));
function rng(seed) {
  let a = seed >>> 0;
  return function () { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
const R = rng(20260513);
const rnd = (n) => { const b = Buffer.alloc(n); for (let i = 0; i < n; i++) b[i] = (R() * 256) | 0; return b; };
const int = (n) => (R() * n) | 0;

/** What a call did: its result, or the interesting fields of its error (the same shape for Node and the shim). */
function outcome(f) {
  try {
    const r = f();
    return { ok: r === undefined ? 'undefined' : (r !== null && typeof r === 'object' && r.buffer ? hex(r) : typeof r === 'object' ? 'object' : String(r)) };
  } catch (e) { return { err: [e.name, e.code, e.message, e.reason, e.library] }; }
}
const both = (label, mk) => eq(outcome(() => mk(C, SB)), outcome(() => mk(nodeCrypto, Buffer)), label);

// ------------------------------------------------------------------------------------------------ known answers
{
  const H = (s) => Buffer.from(s, 'hex');
  // FIPS-197 appendix C: one block, all three key sizes
  const pt = H('00112233445566778899aabbccddeeff');
  const fips = [['000102030405060708090a0b0c0d0e0f', '69c4e0d86a7b0430d8cdb78070b4c55a'],
    ['000102030405060708090a0b0c0d0e0f1011121314151617', 'dda97ca4864cdfe06eaf70a0ec0d7191'],
    ['000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f', '8ea2b7ca516745bfeafc49904b496089']];
  for (const [k, want] of fips) {
    eq(hex(C._aesBlock(H(k), pt, false)), want, 'FIPS-197 encrypt ' + k.length * 4 + ' bit');
    eq(hex(C._aesBlock(H(k), H(want), true)), hex(pt), 'FIPS-197 decrypt ' + k.length * 4 + ' bit');
  }
  // NIST SP 800-38A, first block of each example
  const p1 = '6bc1bee22e409f96e93d7e117393172a';
  const sp = [
    ['aes-128-ecb', '2b7e151628aed2a6abf7158809cf4f3c', null, '3ad77bb40d7a3660a89ecaf32466ef97'],
    ['aes-128-cbc', '2b7e151628aed2a6abf7158809cf4f3c', '000102030405060708090a0b0c0d0e0f', '7649abac8119b246cee98e9b12e9197d'],
    ['aes-128-ctr', '2b7e151628aed2a6abf7158809cf4f3c', 'f0f1f2f3f4f5f6f7f8f9fafbfcfdfeff', '874d6191b620e3261bef6864990db6ce'],
    ['aes-192-ecb', '8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b', null, 'bd334f1d6e45f25ff712a214571fa5cc'],
    ['aes-192-cbc', '8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b', '000102030405060708090a0b0c0d0e0f', '4f021db243bc633d7178183a9fa071e8'],
    ['aes-192-ctr', '8e73b0f7da0e6452c810f32b809079e562f8ead2522c6b7b', 'f0f1f2f3f4f5f6f7f8f9fafbfcfdfeff', '1abc932417521ca24f2b0459fe7e6e0b'],
    ['aes-256-ecb', '603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4', null, 'f3eed1bdb5d2a03c064b5a7e3db181f8'],
    ['aes-256-cbc', '603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4', '000102030405060708090a0b0c0d0e0f', 'f58c4c04d6e5f1ba779eabfb5f7bfbd6'],
    ['aes-256-ctr', '603deb1015ca71be2b73aef0857d77811f352c073b6108d72d9810a30914dff4', 'f0f1f2f3f4f5f6f7f8f9fafbfcfdfeff', '601ec313775789a5b7a7f504bbf3d228'],
  ];
  for (const [alg, k, iv, want] of sp) {
    const c = C.createCipheriv(alg, H(k), iv ? H(iv) : null);
    c.setAutoPadding(false);
    eq(hex(Buffer.concat([c.update(H(p1)), c.final()])), want, 'SP 800-38A ' + alg);
    const d = C.createDecipheriv(alg, H(k), iv ? H(iv) : null);
    d.setAutoPadding(false);
    eq(hex(Buffer.concat([d.update(H(want)), d.final()])), p1, 'SP 800-38A decrypt ' + alg);
  }
  // the counter is 128 bits wide: carries run through all 16 bytes
  const ctrIv = H('00000000000000000000000000ffffff');
  both('ctr carry across bytes', (c, B) => { const x = c.createCipheriv('aes-128-ctr', B.alloc(16, 1), ctrIv); return Buffer.concat([x.update(B.alloc(64)), x.final()]); });
  both('ctr wraps around at 2^128', (c, B) => { const x = c.createCipheriv('aes-128-ctr', B.alloc(16, 1), B.alloc(16, 255)); return Buffer.concat([x.update(B.alloc(40)), x.final()]); });
}

// ------------------------------------------------------------------------------------------------ the whole matrix
const ALGS = ['aes-128-cbc', 'aes-192-cbc', 'aes-256-cbc', 'aes-128-ecb', 'aes-192-ecb', 'aes-256-ecb', 'aes-128-ctr', 'aes-192-ctr', 'aes-256-ctr',
  'aes128', 'aes192', 'aes256', 'AES-256-CBC', 'Aes-128-Ctr'];
const keyLen = (a) => parseInt(/(\d+)/.exec(a)[1], 10) / 8;
const needsIv = (a) => !/ecb/i.test(a);
function chunks(buf, maxPiece) { // random split, empty pieces included
  const out = []; let i = 0;
  while (i < buf.length) { const n = int(maxPiece + 1); out.push(buf.subarray(i, i + n)); i += n; }
  if (!out.length || R() < 0.3) out.push(buf.subarray(0, 0));
  return out;
}
/** The complete visible behaviour of one cipher: what every update() returned, then final() (or its error). */
function drive(mod, B, kind, alg, key, iv, pieces, padding) {
  const trace = [];
  let c;
  try { c = mod[kind](alg, key, iv); } catch (e) { return ['create ' + e.name + ' ' + e.code + ' ' + e.message]; }
  if (padding === false) c.setAutoPadding(false);
  for (const p of pieces) { const o = outcome(() => c.update(B.from(p))); trace.push(o.ok !== undefined ? 'u:' + o.ok : 'u!' + JSON.stringify(o.err)); }
  const f = outcome(() => c.final());
  trace.push(f.ok !== undefined ? 'f:' + f.ok : 'f!' + JSON.stringify(f.err));
  return trace;
}
{
  const LENS = [0, 1, 7, 15, 16, 17, 31, 32, 33, 47, 48, 64, 100, 255, 256, 257, 1000, 4097];
  let n = 0;
  for (const alg of ALGS) {
    for (const len of LENS) {
      const key = rnd(keyLen(alg)), iv = needsIv(alg) ? rnd(16) : null, data = rnd(len);
      const pieces = chunks(data, 40);
      for (const padding of [true, false]) {
        if (padding === false && /ecb|cbc|aes\d+$/i.test(alg) && len % 16 !== 0) {
          // not a multiple of the block size: encrypt fails in final(), identical error expected
          eq(drive(C, SB, 'createCipheriv', alg, key, iv, pieces, false), drive(nodeCrypto, Buffer, 'createCipheriv', alg, key, iv, pieces, false), 'unpadded encrypt of ' + len + ' bytes ' + alg);
          continue;
        }
        const a = drive(nodeCrypto, Buffer, 'createCipheriv', alg, key, iv, pieces, padding);
        const b = drive(C, SB, 'createCipheriv', alg, key, iv, pieces, padding);
        eq(b, a, 'encrypt ' + alg + ' len=' + len + ' pad=' + padding);
        // decrypt what Node produced, in different pieces
        const nc = nodeCrypto.createCipheriv(alg, key, iv); if (padding === false) nc.setAutoPadding(false);
        const ct = Buffer.concat([nc.update(data), nc.final()]);
        const cp = chunks(ct, 50);
        eq(drive(C, SB, 'createDecipheriv', alg, key, iv, cp, padding), drive(nodeCrypto, Buffer, 'createDecipheriv', alg, key, iv, cp, padding), 'decrypt ' + alg + ' len=' + len + ' pad=' + padding);
        // and garbage: wrong key, flipped bytes, truncated
        const wrongKey = rnd(keyLen(alg));
        eq(drive(C, SB, 'createDecipheriv', alg, wrongKey, iv, cp, padding), drive(nodeCrypto, Buffer, 'createDecipheriv', alg, wrongKey, iv, cp, padding), 'decrypt with a wrong key ' + alg + ' len=' + len);
        if (ct.length > 1) {
          const cut = [ct.subarray(0, ct.length - 1 - int(Math.min(ct.length - 1, 20)))];
          eq(drive(C, SB, 'createDecipheriv', alg, key, iv, cut, padding), drive(nodeCrypto, Buffer, 'createDecipheriv', alg, key, iv, cut, padding), 'decrypt of truncated data ' + alg + ' len=' + len + ' pad=' + padding);
        }
        n += 3;
      }
    }
  }
  ok(n > 500, 'matrix ran', n);
}

// ------------------------------------------------------------------------------------------------ errors of the factory functions
{
  const k32 = Buffer.alloc(32, 3), k16 = Buffer.alloc(16, 3), iv16 = Buffer.alloc(16, 9);
  const cases = {
    'algorithm is a number': (c) => c.createCipheriv(5, k32, iv16),
    'algorithm is undefined': (c) => c.createCipheriv(undefined, k32, iv16),
    'algorithm is a Buffer': (c) => c.createCipheriv(Buffer.from('aes-256-cbc'), k32, iv16),
    'key is a number': (c) => c.createCipheriv('aes-256-cbc', 5, iv16),
    'key is undefined': (c) => c.createCipheriv('aes-256-cbc', undefined, iv16),
    'key is null': (c) => c.createCipheriv('aes-256-cbc', null, iv16),
    'key is an array': (c) => c.createCipheriv('aes-256-cbc', [1, 2, 3], iv16),
    'key is an object': (c) => c.createCipheriv('aes-256-cbc', {}, iv16),
    'iv is a number': (c) => c.createCipheriv('aes-256-cbc', k32, 5),
    'iv is undefined': (c) => c.createCipheriv('aes-256-cbc', k32, undefined),
    'iv is an array': (c) => c.createCipheriv('aes-256-cbc', k32, [1, 2]),
    'iv is null (cbc)': (c) => c.createCipheriv('aes-256-cbc', k32, null),
    'iv is null (ecb)': (c) => c.createCipheriv('aes-256-ecb', k32, null),
    'iv is empty (ecb)': (c) => c.createCipheriv('aes-256-ecb', k32, Buffer.alloc(0)),
    'iv is 16 bytes (ecb)': (c) => c.createCipheriv('aes-256-ecb', k32, iv16),
    'iv is 15 bytes': (c) => c.createCipheriv('aes-256-cbc', k32, Buffer.alloc(15)),
    'iv is 17 bytes': (c) => c.createCipheriv('aes-256-ctr', k32, Buffer.alloc(17)),
    'iv is 12 bytes (ctr)': (c) => c.createCipheriv('aes-256-ctr', k32, Buffer.alloc(12)),
    'key is 16 bytes for aes-256': (c) => c.createCipheriv('aes-256-cbc', k16, iv16),
    'key is 0 bytes': (c) => c.createCipheriv('aes-128-cbc', Buffer.alloc(0), iv16),
    'key is 33 bytes': (c) => c.createCipheriv('aes-256-cbc', Buffer.alloc(33), iv16),
    'key is 24 bytes for aes-128': (c) => c.createCipheriv('aes-128-ecb', Buffer.alloc(24), null),
    'unknown cipher': (c) => c.createCipheriv('nope-256-cbc', k32, iv16),
    'unknown cipher with a bad key': (c) => c.createCipheriv('nope-256-cbc', k16, Buffer.alloc(3)),
    'bad iv with a bad key': (c) => c.createCipheriv('aes-256-cbc', k16, Buffer.alloc(3)),
    'empty algorithm name': (c) => c.createCipheriv('', k32, iv16),
    'aes-256 without a mode': (c) => c.createCipheriv('aes-256', k32, iv16),
    'string key of the right length': (c) => c.createCipheriv('aes-256-cbc', 'k'.repeat(32), iv16).update('x'),
    'string key of the wrong length': (c) => c.createCipheriv('aes-256-cbc', 'k'.repeat(31), iv16),
    'string key, utf8 multi-byte (32 bytes)': (c) => c.createCipheriv('aes-256-cbc', '가'.repeat(10) + 'ab', iv16).update('x'),
    'string iv': (c) => c.createCipheriv('aes-256-cbc', k32, 'i'.repeat(16)).update('x'),
    'hex key with the encoding option': (c) => c.createCipheriv('aes-128-cbc', '00'.repeat(16), iv16, { encoding: 'hex' }).update('x'),
    'Uint8Array key and iv': (c) => c.createCipheriv('aes-256-cbc', new Uint8Array(32).fill(4), new Uint8Array(16).fill(5)).update('x'),
    'DataView key and iv': (c) => c.createCipheriv('aes-256-cbc', new DataView(new ArrayBuffer(32)), new DataView(new ArrayBuffer(16))).update('x'),
    'ArrayBuffer key and iv': (c) => c.createCipheriv('aes-256-cbc', new ArrayBuffer(32), new ArrayBuffer(16)).update('x'),
    'Uint32Array key (32 bytes)': (c) => c.createCipheriv('aes-256-cbc', new Uint32Array(8), iv16).update('x'),
    'key is a view into a larger buffer': (c) => c.createCipheriv('aes-256-cbc', Buffer.alloc(100, 7).subarray(10, 42), iv16).update('x'),
    'createDecipheriv: unknown cipher': (c) => c.createDecipheriv('nope', k32, iv16),
    'createDecipheriv: bad key length': (c) => c.createDecipheriv('aes-256-ctr', k16, iv16),
    'createDecipheriv: bad iv length': (c) => c.createDecipheriv('aes-256-ctr', k32, Buffer.alloc(8)),
  };
  for (const name of Object.keys(cases)) both('factory: ' + name, (c, B) => { const r = cases[name](c, B); return r && r.update ? 'cipher object' : r; });
}

// ------------------------------------------------------------------------------------------------ update / final / setAutoPadding
{
  const k = Buffer.alloc(32, 1), iv = Buffer.alloc(16, 2);
  const seq = {
    'update(number)': (x) => x.update(5),
    'update(undefined)': (x) => x.update(undefined),
    'update(null)': (x) => x.update(null),
    'update(array)': (x) => x.update([1, 2, 3]),
    'update(ArrayBuffer)': (x) => x.update(new ArrayBuffer(4)),
    'update(object)': (x) => x.update({}),
    'update(Uint16Array)': (x) => x.update(new Uint16Array([1, 2, 3])),
    'update(DataView)': (x) => x.update(new DataView(new ArrayBuffer(20))),
    'update(string, hex)': (x) => x.update('00ff10', 'hex'),
    'update(odd hex)': (x) => x.update('00f', 'hex'),
    'update(string, base64)': (x) => x.update('AQID', 'base64'),
    'update(string, latin1)': (x) => x.update('héllo wörld!!', 'latin1'),
    'update(string, utf8)': (x) => x.update('가나다라마바사 héllo', 'utf8'),
    'update(string, unknown encoding)': (x) => x.update('abc', 'klingon'),
    'update(string, buffer)': (x) => x.update('abc', 'buffer'),
    'update(string, null)': (x) => x.update('abc', null),
    'update -> hex output': (x) => x.update('0123456789abcdef0123456789abcdef', 'utf8', 'hex') + '|' + x.final('hex'),
    'update -> base64 output': (x) => x.update('0123456789abcdef0123456789abcdef!', 'utf8', 'base64') + '|' + x.final('base64'),
    'update -> latin1 output': (x) => x.update('0123456789abcdef', 'utf8', 'latin1').length + '|' + x.final('latin1').length,
    'update -> buffer output': (x) => hex(x.update('0123456789abcdef0123', 'utf8', 'buffer')),
    'update -> unknown output encoding': (x) => x.update('0123456789abcdef0123', 'utf8', 'klingon'),
    'final -> hex': (x) => x.final('hex'),
    'final after nothing': (x) => x.final(),
    'final twice': (x) => { x.final(); return x.final(); },
    'update after final': (x) => { x.final(); return x.update('a'); },
    'setAutoPadding after final': (x) => { x.final(); return x.setAutoPadding(false); },
    'setAutoPadding(false) returns this': (x) => x.setAutoPadding(false) === x,
    'setAutoPadding() = true': (x) => { x.setAutoPadding(false); x.setAutoPadding(); return hex(Buffer.concat([x.update('abc'), x.final()])); },
    'setAutoPadding(0)': (x) => { x.setAutoPadding(0); return hex(Buffer.concat([x.update('abcdefghijklmnop'), x.final()])); },
    'setAutoPadding(false) after update': (x) => { const a = x.update('abc'); x.setAutoPadding(false); return hex(a) + '|' + hex(x.final()); },
    'setAutoPadding(false) after update, multiple of 16': (x) => { const a = x.update('abcdefghijklmnop'); x.setAutoPadding(false); return hex(a) + '|' + hex(x.final()); },
    'update with an empty string': (x) => hex(x.update('')),
    'update with an empty buffer': (x) => hex(x.update(Buffer.alloc(0))),
    'is a Transform stream': (x, S) => (x instanceof S.Transform) + ' ' + typeof x.pipe + ' ' + typeof x.write,
  };
  for (const kind of ['createCipheriv', 'createDecipheriv']) {
    for (const alg of ['aes-256-cbc', 'aes-256-ctr', 'aes-128-ecb']) {
      for (const name of Object.keys(seq)) {
        const kk = alg === 'aes-128-ecb' ? k.subarray(0, 16) : k, vv = alg === 'aes-128-ecb' ? null : iv;
        if (name === 'is a Transform stream' && alg !== 'aes-256-cbc') continue;
        const run = (mod, B) => { const x = mod[kind](alg, B.from(kk), vv && B.from(vv)); return seq[name](x, mod === C ? sh.streamMod : require('stream')); };
        const a = outcome(() => run(nodeCrypto, Buffer)), b = outcome(() => run(C, SB));
        if (name === 'is a Transform stream') { eq(b.ok, 'true function function', 'cipher is a shim Transform'); continue; }
        eq(b, a, kind + ' ' + alg + ': ' + name);
      }
    }
  }
}

// ------------------------------------------------------------------------------------------------ result types and instances
{
  const c = C.createCipheriv('aes-256-cbc', SB.alloc(32), SB.alloc(16));
  const o = c.update('hello');
  ok(SB.isBuffer(c.final()) && SB.isBuffer(o), 'update() and final() return Buffers of the shim');
  ok(c instanceof C.Cipheriv && C.createDecipheriv('aes-256-cbc', SB.alloc(32), SB.alloc(16)) instanceof C.Decipheriv, 'Cipheriv / Decipheriv are exported');
  ok(typeof C.createCipher === 'function' && typeof C.createDecipher === 'function', 'createCipher / createDecipher exist');
  const names = C.getCiphers();
  ok(Array.isArray(names) && names.length >= 9, 'getCiphers() lists the supported ones', names);
  for (const n of names) ok(outcome(() => nodeCrypto.createCipheriv(n, Buffer.alloc(keyLen(n)), /ecb/.test(n) ? null : Buffer.alloc(16)).update('x')).ok !== undefined && outcome(() => C.createCipheriv(n, SB.alloc(keyLen(n)), /ecb/.test(n) ? null : SB.alloc(16)).update('x')).ok !== undefined, 'getCiphers() entry works in Node and in the shim: ' + n);
  const nodeNames = nodeCrypto.getCiphers();
  for (const n of names) ok(nodeNames.includes(n), 'getCiphers() entry exists in Node: ' + n);
}

// ------------------------------------------------------------------------------------------------ as streams
function collect(stream, input, encoding) {
  return new Promise((resolve) => {
    const out = []; const events = [];
    if (encoding) stream.setEncoding(encoding);
    stream.on('data', (d) => out.push(typeof d === 'string' ? d : Buffer.from(d.buffer, d.byteOffset, d.length).toString('hex')));
    stream.on('end', () => events.push('end'));
    stream.on('error', (e) => events.push('error ' + e.code + ' ' + e.message));
    stream.on('close', () => resolve({ out: out.join(encoding ? '' : '|'), events }));
    for (const p of input) stream.write(p);
    stream.end();
  });
}
async function streamTests() {
  const key = Buffer.alloc(32, 5), iv = Buffer.alloc(16, 6);
  const data = rnd(5000);
  const parts = chunks(data, 700);
  for (const alg of ['aes-256-cbc', 'aes-256-ctr', 'aes-128-ecb']) {
    const k = alg === 'aes-128-ecb' ? key.subarray(0, 16) : key, v = alg === 'aes-128-ecb' ? null : iv;
    for (const enc of [undefined, 'hex', 'base64']) {
      const a = await collect(nodeCrypto.createCipheriv(alg, k, v), parts, enc);
      const b = await collect(C.createCipheriv(alg, SB.from(k), v && SB.from(v)), parts.map((p) => SB.from(p)), enc);
      eq(b, a, 'stream encrypt ' + alg + ' enc=' + enc);
    }
    const nc = nodeCrypto.createCipheriv(alg, k, v); const ct = Buffer.concat([nc.update(data), nc.final()]);
    const dparts = chunks(ct, 333);
    eq(await collect(C.createDecipheriv(alg, SB.from(k), v && SB.from(v)), dparts.map((p) => SB.from(p))), await collect(nodeCrypto.createDecipheriv(alg, k, v), dparts), 'stream decrypt ' + alg);
    // broken data: the error must come out of the stream, after the good part
    const bad = dparts.slice(0, -1);
    if (alg !== 'aes-256-ctr') eq(await collect(C.createDecipheriv(alg, SB.from(k), v && SB.from(v)), bad.map((p) => SB.from(p))), await collect(nodeCrypto.createDecipheriv(alg, k, v), bad), 'stream decrypt of cut data ' + alg);
  }
  // string chunks written to a cipher stream
  eq(await collect(C.createCipheriv('aes-256-cbc', SB.from(key), SB.from(iv)), ['hello ', 'wörld']), await collect(nodeCrypto.createCipheriv('aes-256-cbc', key, iv), ['hello ', 'wörld']), 'string chunks');
  // pipeline: Readable -> cipher -> decipher -> Writable, and a real file round trip
  const outShim = [], outNode = [];
  const sink = (arr) => new Writable({ write(c, e, cb) { arr.push(Buffer.from(c)); cb(); } });
  await new Promise((res) => pipeline(Readable.from(parts), nodeCrypto.createCipheriv('aes-256-cbc', key, iv), nodeCrypto.createDecipheriv('aes-256-cbc', key, iv), sink(outNode), res));
  await new Promise((res) => pipeline(Readable.from(parts), C.createCipheriv('aes-256-cbc', SB.from(key), SB.from(iv)), C.createDecipheriv('aes-256-cbc', SB.from(key), SB.from(iv)), sink(outShim), res));
  ok(Buffer.concat(outShim).equals(data) && Buffer.concat(outNode).equals(data), 'pipeline round trip');
  const p1 = path.join(T, 'plain.bin'), p2 = path.join(T, 'enc.bin'), p3 = path.join(T, 'dec.bin');
  fs.writeFileSync(p1, rnd(300001));
  await new Promise((res, rej) => sh.fs.createReadStream(p1).pipe(C.createCipheriv('aes-256-ctr', SB.from(key), SB.from(iv))).pipe(sh.fs.createWriteStream(p2)).on('finish', res).on('error', rej));
  const nodeEnc = nodeCrypto.createCipheriv('aes-256-ctr', key, iv);
  ok(Buffer.concat([nodeEnc.update(fs.readFileSync(p1)), nodeEnc.final()]).equals(fs.readFileSync(p2)), 'fs stream -> cipher -> fs stream matches Node');
  await new Promise((res, rej) => sh.fs.createReadStream(p2).pipe(C.createDecipheriv('aes-256-ctr', SB.from(key), SB.from(iv))).pipe(sh.fs.createWriteStream(p3)).on('finish', res).on('error', rej));
  ok(fs.readFileSync(p3).equals(fs.readFileSync(p1)), 'file decrypts back');
}

// ------------------------------------------------------------------------------------------------ legacy password based ciphers
function evpBytesToKey(password, keyLen, ivLen) {
  let d = Buffer.alloc(0), prev = Buffer.alloc(0);
  while (d.length < keyLen + ivLen) { prev = nodeCrypto.createHash('md5').update(Buffer.concat([prev, Buffer.from(password)])).digest(); d = Buffer.concat([d, prev]); }
  return { key: d.subarray(0, keyLen), iv: d.subarray(keyLen, keyLen + ivLen) };
}
{
  ok(nodeCrypto.createCipher === undefined || typeof nodeCrypto.createCipher === 'function', 'info: Node ' + process.version + (nodeCrypto.createCipher ? ' still has' : ' no longer has') + ' createCipher');
  // OpenSSL's well known result for `openssl enc -aes-256-cbc -md md5 -nosalt -k secret`: key/iv from EVP_BytesToKey
  for (const alg of ['aes-256-cbc', 'aes-192-ctr', 'aes-128-ecb', 'aes-256-ctr']) {
    for (const pw of ['secret', 'a longer password with spaces ✓', '']) {
      const kd = evpBytesToKey(pw, keyLen(alg), needsIv(alg) ? 16 : 0);
      const data = rnd(100);
      const ref = nodeCrypto.createCipheriv(alg, kd.key, needsIv(alg) ? kd.iv : null);
      const want = Buffer.concat([ref.update(data), ref.final()]);
      const c = C.createCipher(alg, pw);
      const got = Buffer.concat([c.update(SB.from(data)), c.final()]);
      eq(hex(got), want.toString('hex'), 'createCipher ' + alg + ' password "' + pw + '"');
      const d = C.createDecipher(alg, Buffer.from(pw));
      eq(hex(Buffer.concat([d.update(got), d.final()])), data.toString('hex'), 'createDecipher ' + alg + ' password "' + pw + '"');
    }
  }
  ok(outcome(() => C.createCipher('aes-256-cbc', 5)).err[2].indexOf('"password"') > 0, 'createCipher: a password that is no string or buffer');
  ok(outcome(() => C.createCipher('nope', 'x')).err[1] === 'ERR_CRYPTO_UNKNOWN_CIPHER', 'createCipher: unknown cipher');
}

// ------------------------------------------------------------------------------------------------ ciphers that are real but not available
{
  const before = sh.logs.length;
  for (const alg of ['aes-256-gcm', 'aes-128-cfb', 'aes-256-ofb', 'des-ede3-cbc', 'chacha20-poly1305', 'bf-cbc', 'camellia-128-cbc', 'rc4']) {
    const e = outcome(() => C.createCipheriv(alg, SB.alloc(32), SB.alloc(16))).err;
    ok(e && /not available in RPG Runner/.test(e[2]), 'unsupported cipher is reported clearly: ' + alg, e);
    ok(nodeCrypto.getCiphers().indexOf(alg) >= 0 || /^(rc4|bf-cbc|chacha20-poly1305)$/.test(alg), 'info: ' + alg + ' exists in Node');
  }
}
eq(outcome(() => C.createCipheriv('aes-256-gcm', SB.alloc(32), SB.alloc(12))).err ? 1 : 0, 1, 'aes-256-gcm throws');
ok(sh.logs.filter((l) => /aes-256-gcm/.test(l)).length === 1, 'an unsupported cipher is logged once, not on every call', sh.logs.filter((l) => /gcm/.test(l)));

// ------------------------------------------------------------------------------------------------ speed (information, and a floor)
function speed() {
  const MB = 8, data = Buffer.alloc(MB << 20, 7), out = [];
  for (const alg of ['aes-256-ctr', 'aes-256-cbc']) {
    const t0 = process.hrtime.bigint();
    const c = C.createCipheriv(alg, SB.alloc(32, 1), SB.alloc(16, 2)); const e = Buffer.concat([c.update(SB.from(data)), c.final()]);
    const t1 = process.hrtime.bigint();
    const d = C.createDecipheriv(alg, SB.alloc(32, 1), SB.alloc(16, 2)); const p = Buffer.concat([d.update(e), d.final()]);
    const t2 = process.hrtime.bigint();
    ok(p.equals(data), alg + ' ' + MB + ' MB round trip');
    const enc = MB / (Number(t1 - t0) / 1e9), dec = MB / (Number(t2 - t1) / 1e9);
    out.push(alg + ' encrypt ' + enc.toFixed(0) + ' MB/s, decrypt ' + dec.toFixed(0) + ' MB/s');
    ok(enc > 2 && dec > 2, alg + ' is fast enough (' + enc.toFixed(1) + ' / ' + dec.toFixed(1) + ' MB/s)');
  }
  console.log('speed (Node, JS code of the shim): ' + out.join('; '));
}

(async () => {
  await streamTests();
  speed();
  console.log('aes: ' + pass + ' passed, ' + fail + ' failed');
  process.exit(fail ? 1 : 0);
})().catch((e) => { console.error(e); process.exit(2); });
