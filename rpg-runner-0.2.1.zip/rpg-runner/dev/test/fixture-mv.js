'use strict';
// Builds a tiny RPG Maker MV style NW.js game on disk. It is NOT a real game: the "core" below only contains
// faithful copies of the rpg_core.js 1.6 code paths that touch NW.js / Node (Utils, StorageManager, Input, WebAudio),
// which is exactly what RPG Runner's compatibility layer has to satisfy.
const fs = require('fs');
const path = require('path');

function put(root, rel, data) {
  const p = path.join(root, rel);
  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, data);
  return p;
}

const INDEX_HTML = `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Fixture MV</title>
<link rel="icon" href="icon/icon.png" type="image/png">
</head>
<body style="background-color: black">
<script type="text/javascript" src="js/libs/pixi.js"></script>
<script type="text/javascript" src="js/rpg_core.js"></script>
<script type="text/javascript" src="js/plugins.js"></script>
<script type="text/javascript" src="js/plugins/Plug.js"></script>
<script type="text/javascript" src="js/main.js"></script>
</body>
</html>
`;

// Real pixi.js 4.x is a UMD bundle: it attaches to module.exports when a global "module"/"exports" exists and to window.PIXI otherwise.
const PIXI_JS = `(function (f) {
  if (typeof exports === "object" && typeof module !== "undefined") { module.exports = f(); }
  else if (typeof define === "function" && define.amd) { define([], f); }
  else { var g; if (typeof window !== "undefined") { g = window; } else if (typeof global !== "undefined") { g = global; } else { g = this; } g.PIXI = f(); }
})(function () { return { VERSION: 'fake-4.x', autoDetectRenderer: function () { return {}; } }; });
`;

const CORE_JS = `
Array.prototype.contains = function (element) { return this.indexOf(element) >= 0; };
String.prototype.format = function () { var args = arguments; return this.replace(/%([0-9]+)/g, function (s, n) { return args[Number(n) - 1]; }); };

function Utils() { throw new Error('This is a static class'); }
Utils.isOptionValid = function (name) {
  if (location.search.slice(1).split('&').contains(name)) { return 1; }
  if (typeof nw !== 'undefined' && nw.App.argv.length > 0 && nw.App.argv[0].split('&').contains(name)) { return 1; }
  return 0;
};
Utils.isNwjs = function () { return typeof require === 'function' && typeof process === 'object'; };
Utils.isMobileDevice = function () { var r = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i; return !!navigator.userAgent.match(r); };

var LZString = {
  compressToBase64: function (s) { return btoa(unescape(encodeURIComponent(s))); },
  decompressFromBase64: function (s) { return s === null ? null : decodeURIComponent(escape(atob(s))); }
};

function StorageManager() { throw new Error('This is a static class'); }
StorageManager.save = function (id, json) { if (this.isLocalMode()) { this.saveToLocalFile(id, json); } };
StorageManager.load = function (id) { return this.isLocalMode() ? this.loadFromLocalFile(id) : null; };
StorageManager.exists = function (id) { return this.isLocalMode() ? this.localFileExists(id) : false; };
StorageManager.remove = function (id) { if (this.isLocalMode()) { this.removeLocalFile(id); } };
StorageManager.isLocalMode = function () { return Utils.isNwjs(); };
StorageManager.saveToLocalFile = function (savefileId, json) {
  var data = LZString.compressToBase64(json);
  var fs = require('fs');
  var dirPath = this.localFileDirectoryPath();
  var filePath = this.localFilePath(savefileId);
  if (!fs.existsSync(dirPath)) { fs.mkdirSync(dirPath); }
  fs.writeFileSync(filePath, data);
};
StorageManager.loadFromLocalFile = function (savefileId) {
  var data = null;
  var fs = require('fs');
  var filePath = this.localFilePath(savefileId);
  if (fs.existsSync(filePath)) { data = fs.readFileSync(filePath, { encoding: 'utf8' }); }
  return LZString.decompressFromBase64(data);
};
StorageManager.localFileExists = function (savefileId) { var fs = require('fs'); return fs.existsSync(this.localFilePath(savefileId)); };
StorageManager.removeLocalFile = function (savefileId) {
  var fs = require('fs');
  var filePath = this.localFilePath(savefileId);
  if (fs.existsSync(filePath)) { fs.unlinkSync(filePath); }
};
StorageManager.localFileDirectoryPath = function () {
  var path = require('path');
  var base = path.dirname(process.mainModule.filename);
  return path.join(base, 'save/');
};
StorageManager.localFilePath = function (savefileId) {
  var name;
  if (savefileId < 0) { name = 'config.rpgsave'; }
  else if (savefileId === 0) { name = 'global.rpgsave'; }
  else { name = 'file%1.rpgsave'.format(savefileId); }
  return this.localFileDirectoryPath() + name;
};

function Input() { throw new Error('This is a static class'); }
Input.keyMapper = {
  9: 'tab', 13: 'ok', 16: 'shift', 17: 'control', 18: 'control', 27: 'escape', 32: 'ok', 33: 'pageup', 34: 'pagedown',
  37: 'left', 38: 'up', 39: 'right', 40: 'down', 45: 'escape', 81: 'pageup', 87: 'pagedown', 88: 'escape', 90: 'ok',
  96: 'escape', 98: 'down', 100: 'left', 102: 'right', 104: 'up', 120: 'debug'
};
Input.initialize = function () { this.clear(); this._setupEventHandlers(); };
Input.clear = function () { this._currentState = {}; };
Input._setupEventHandlers = function () {
  document.addEventListener('keydown', this._onKeyDown.bind(this));
  document.addEventListener('keyup', this._onKeyUp.bind(this));
  window.addEventListener('blur', this._onLostFocus.bind(this));
};
Input._onKeyDown = function (event) {
  if (this._shouldPreventDefault(event.keyCode)) { event.preventDefault(); }
  var buttonName = this.keyMapper[event.keyCode];
  if (buttonName) { this._currentState[buttonName] = true; }
};
Input._shouldPreventDefault = function (keyCode) {
  switch (keyCode) { case 8: case 33: case 34: case 37: case 38: case 39: case 40: return true; }
  return false;
};
Input._onKeyUp = function (event) {
  var buttonName = this.keyMapper[event.keyCode];
  if (buttonName) { this._currentState[buttonName] = false; }
};
Input._onLostFocus = function () { this.clear(); };
Input.isPressed = function (name) { return !!this._currentState[name]; };
Input.pressed = function () { var o = []; for (var n in this._currentState) { if (this._currentState[n]) { o.push(n); } } return o.sort(); };

// what the game's own mouse / touch handling would see
var TouchInput = { events: [] };
['mousedown', 'mouseup', 'touchstart', 'touchend', 'click'].forEach(function (t) {
  document.addEventListener(t, function (e) { TouchInput.events.push(t + ':' + ((e.target && (e.target.id || e.target.tagName)) || '?')); }, { passive: false });
});

var WebAudio = { _context: null };
WebAudio._createContext = function () {
  try {
    if (typeof AudioContext !== 'undefined') { this._context = new AudioContext(); }
    else if (typeof webkitAudioContext !== 'undefined') { this._context = new webkitAudioContext(); }
  } catch (e) { this._context = null; }
};

var Graphics = { frames: 0, canvas: null, px: 100, py: 100, last: 0 };
Graphics.boot = function () {
  var c = document.createElement('canvas');
  c.id = 'GameCanvas'; c.width = 816; c.height = 624;
  c.style.cssText = 'position:absolute;left:50%;top:0;height:100vh;width:auto;transform:translateX(-50%);image-rendering:pixelated';
  document.body.appendChild(c);
  this.canvas = c;
  var ctx = c.getContext('2d'), self = this;
  function loop(t) {
    self.frames++;
    var dt = self.last ? Math.min(50, t - self.last) : 16; self.last = t;
    if (Input.isPressed('left')) self.px -= 0.25 * dt;
    if (Input.isPressed('right')) self.px += 0.25 * dt;
    if (Input.isPressed('up')) self.py -= 0.25 * dt;
    if (Input.isPressed('down')) self.py += 0.25 * dt;
    self.px = Math.max(16, Math.min(800, self.px)); self.py = Math.max(16, Math.min(608, self.py));
    ctx.fillStyle = '#16243a'; ctx.fillRect(0, 0, 816, 624);
    ctx.strokeStyle = '#2d4a73';
    for (var x = 0; x <= 816; x += 48) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, 624); ctx.stroke(); }
    for (var y = 0; y <= 624; y += 48) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(816, y); ctx.stroke(); }
    ctx.fillStyle = Input.isPressed('ok') ? '#ffd23f' : (Input.isPressed('escape') ? '#ee4266' : '#3bceac');
    ctx.fillRect(self.px - 16, self.py - 16, 32, 32);
    ctx.fillStyle = '#fff'; ctx.font = '22px sans-serif';
    ctx.fillText('FIXTURE MV  frame ' + self.frames, 16, 32);
    ctx.fillText('input: ' + (Input.pressed().join(' ') || '-'), 16, 62);
    requestAnimationFrame(loop);
  }
  requestAnimationFrame(loop);
};
`;

const MAIN_JS = `window.__fixture = window.__fixture || {};
window.onload = function () {
  Input.initialize();
  Graphics.boot();
  WebAudio._createContext();
  window.__fixture.booted = true;
};
`;

const PLUG_JS = `(function () {
  var fs = require('fs'), path = require('path');
  var base = path.dirname(process.mainModule.filename);
  var info = window.__fixture = window.__fixture || {};
  info.plugin = {
    base: base,
    hasSystem: fs.existsSync(path.join(base, 'data/System.json')),
    helper: require('./js/plugins/helper.js'),
    fakemod: require('fakemod'),
    pkg: require('../package.json').name,
    isNwjs: Utils.isNwjs(),
    mobile: Utils.isMobileDevice(),
    pixi: typeof PIXI !== 'undefined' ? PIXI.VERSION : null,
    moduleGlobal: typeof module,
    exportsGlobal: typeof exports
  };
})();
`;

module.exports = function buildMvFixture(root) {
  put(root, 'package.json', JSON.stringify({ name: 'fixture-mv', main: 'www/index.html', window: { title: 'Fixture MV', width: 816, height: 624 } }));
  put(root, 'www/index.html', INDEX_HTML);
  put(root, 'www/js/libs/pixi.js', PIXI_JS);
  put(root, 'www/js/rpg_core.js', CORE_JS);
  put(root, 'www/js/main.js', MAIN_JS);
  put(root, 'www/js/plugins.js', 'var $plugins = [{"name":"Plug","status":true,"description":"","parameters":{}}];\n');
  put(root, 'www/js/plugins/Plug.js', PLUG_JS);
  put(root, 'www/js/plugins/helper.js', 'module.exports = { x: 1, dir: __dirname.split("/").slice(-2).join("/"), file: __filename.split("/").pop() };\n');
  put(root, 'www/data/System.json', JSON.stringify({ gameTitle: 'Fixture 게임', locale: 'ko_KR' }));
  put(root, 'www/node_modules/fakemod/package.json', JSON.stringify({ name: 'fakemod', main: 'lib/main.js' }));
  put(root, 'www/node_modules/fakemod/lib/main.js', 'module.exports = { name: "fakemod", file: __filename.split("/").slice(-3).join("/"), requireType: typeof require };\n');
  const ogg = Buffer.alloc(4096);
  for (let i = 0; i < ogg.length; i++) ogg[i] = (i * 7) & 255;
  put(root, 'www/audio/bgm/Theme.ogg', ogg);
  put(root, 'www/img/pictures/Ünï 그림 #1.txt', 'unicode name ok');
  // 1x1 transparent PNG
  put(root, 'www/icon/icon.png', Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64'));
  return root;
};
