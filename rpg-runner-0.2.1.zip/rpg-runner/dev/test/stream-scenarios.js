'use strict';
// Stream scenarios. Each one is a self-contained async function of `env` (no closure variables, so the very same source can also be
// evaluated inside the browser page): it logs what happened and the runner compares the log of real Node with the log of the shim.
//   env = { stream, fs, zlib, crypto, StringDecoder, Buffer, T (a fresh temp dir), log(str), sleep(ms) }
const S = {};

S['readable: flowing, sync push'] = async (env) => {
  const { Readable } = env.stream, log = env.log;
  let i = 0;
  const r = new Readable({ read() { i++; if (i <= 3) this.push('chunk' + i); else this.push(null); } });
  r.on('data', (d) => log('data ' + env.Buffer.isBuffer(d) + ' ' + d.toString()));
  r.on('end', () => log('end readable=' + r.readable + ' ended=' + r.readableEnded));
  r.on('close', () => log('close destroyed=' + r.destroyed));
  await new Promise((res) => r.on('close', res));
};

S['readable: async push, setEncoding with a split multi-byte char'] = async (env) => {
  const { Readable } = env.stream, log = env.log;
  const bytes = env.Buffer.from('가나다 ✓ héllo');
  const parts = [bytes.subarray(0, 2), bytes.subarray(2, 5), bytes.subarray(5, 7), bytes.subarray(7)];
  let i = 0;
  const r = new Readable({ read() { setTimeout(() => this.push(i < parts.length ? parts[i++] : null), 1); } });
  r.setEncoding('utf8');
  let all = '';
  r.on('data', (d) => { all += d; log('data string=' + (typeof d === 'string')); });
  r.on('end', () => log('end ' + all));
  await new Promise((res) => r.on('close', res));
};

S['readable: paused mode with readable event and read(n)'] = async (env) => {
  const { Readable } = env.stream, log = env.log;
  const parts = ['abcd', 'efg', 'hijklm'];
  let i = 0;
  const r = new Readable({ read() { this.push(i < parts.length ? parts[i++] : null); } });
  const got = [];
  r.on('readable', () => {
    let c;
    while ((c = r.read(3)) !== null) got.push(c.toString());
  });
  r.on('end', () => log('end ' + JSON.stringify(got)));
  await new Promise((res) => r.on('close', res));
};

S['readable: read() without size returns everything buffered'] = async (env) => {
  const { Readable } = env.stream, log = env.log;
  const r = new Readable({ read() {} });
  r.push('abc'); r.push('def');
  await env.sleep(5);
  log('len ' + r.readableLength);
  log('read ' + r.read().toString());
  log('read again ' + r.read());
  r.push(null);
  r.on('end', () => log('end'));
  r.resume();
  await new Promise((res) => r.on('close', res));
};

S['readable: object mode'] = async (env) => {
  const { Readable } = env.stream, log = env.log;
  const r = Readable.from([1, 'two', { three: 3 }, [4], 0, false, '']);
  r.on('data', (d) => log('data ' + JSON.stringify(d)));
  r.on('end', () => log('end'));
  await new Promise((res) => r.on('close', res));
  const r2 = new Readable({ objectMode: true, read() {} });
  r2.push({ a: 1 }); r2.push({ b: 2 }); r2.push(null);
  log('len ' + r2.readableLength + ' hwm ' + r2.readableHighWaterMark + ' mode ' + r2.readableObjectMode);
  r2.on('data', (d) => log('data2 ' + JSON.stringify(d)));
  await new Promise((res) => r2.on('close', res));
};

S['readable: pause and resume'] = async (env) => {
  const { Readable } = env.stream, log = env.log;
  let i = 0;
  const r = new Readable({ read() { this.push(i < 5 ? String(++i) : null); } });
  r.on('data', (d) => {
    log('data ' + d);
    if (d.toString() === '2') {
      r.pause();
      log('paused ' + r.isPaused() + ' flowing=' + r.readableFlowing);
      setTimeout(() => { log('resuming'); r.resume(); }, 10);
    }
  });
  r.on('end', () => log('end'));
  await new Promise((res) => r.on('close', res));
};

S['readable: destroy with and without an error'] = async (env) => {
  const { Readable } = env.stream, log = env.log;
  const r = new Readable({ read() {} });
  r.on('error', (e) => log('error ' + e.message));
  r.on('close', () => log('close destroyed=' + r.destroyed + ' readable=' + r.readable));
  r.destroy(new Error('boom'));
  log('sync destroyed=' + r.destroyed);
  await env.sleep(10);
  const r2 = new Readable({ read() {} });
  r2.on('error', () => log('unexpected error'));
  r2.on('close', () => log('close2'));
  r2.destroy();
  await env.sleep(10);
  const r3 = new Readable({ read() {}, destroy(err, cb) { log('_destroy ' + err); cb(err); } });
  r3.on('close', () => log('close3'));
  r3.destroy();
  await env.sleep(10);
};

S['readable: push after EOF and bad chunks'] = async (env) => {
  const { Readable } = env.stream, log = env.log;
  const r = new Readable({ read() {} });
  r.on('error', (e) => log('error ' + e.code + ' ' + e.message));
  r.push(null);
  r.push('x');
  await env.sleep(10);
  const r2 = new Readable({ read() {} });
  r2.on('error', (e) => log('error2 ' + e.code));
  r2.push(123);
  await env.sleep(10);
  const r3 = new Readable({ read() {} });
  log('push empty ' + r3.push('') + ' ' + r3.push(env.Buffer.alloc(0)) + ' len=' + r3.readableLength);
  log('push ret ' + r3.push('abc') + ' ' + r3.push(env.Buffer.alloc(70000)));
};

S['writable: basic writes, callbacks and finish'] = async (env) => {
  const { Writable } = env.stream, log = env.log;
  const got = [];
  const w = new Writable({ write(chunk, enc, cb) { got.push(env.Buffer.isBuffer(chunk) ? chunk.toString('hex') : 'str:' + chunk + ':' + enc); setTimeout(cb, 1); } });
  w.on('finish', () => log('finish ' + JSON.stringify(got) + ' finished=' + w.writableFinished + ' ended=' + w.writableEnded));
  w.on('close', () => log('close destroyed=' + w.destroyed + ' writable=' + w.writable));
  log('r1 ' + w.write('ab', () => log('cb1')));
  log('r2 ' + w.write(env.Buffer.from([1, 2]), () => log('cb2')));
  log('r3 ' + w.write('ff', 'hex', () => log('cb3')));
  log('r4 ' + w.write(new Uint8Array([9]), () => log('cb4')));
  w.end('z', () => log('end cb'));
  log('after end ended=' + w.writableEnded + ' finished=' + w.writableFinished + ' len=' + w.writableLength);
  await new Promise((res) => w.on('close', res));
};

S['writable: decodeStrings false, object mode and bad chunks'] = async (env) => {
  const { Writable } = env.stream, log = env.log;
  const w = new Writable({ decodeStrings: false, write(c, e, cb) { log('write ' + typeof c + ' ' + e); cb(); } });
  w.write('abc'); w.write('4142', 'hex'); w.write(env.Buffer.from('x'));
  w.end();
  await new Promise((res) => w.on('close', res));
  const w2 = new Writable({ objectMode: true, write(c, e, cb) { log('obj ' + JSON.stringify(c)); cb(); } });
  w2.write({ a: 1 }); w2.write(5); w2.write('s'); w2.end();
  await new Promise((res) => w2.on('close', res));
  const w3 = new Writable({ write(c, e, cb) { cb(); } });
  for (const bad of [123, {}, [], true, undefined]) {
    try { w3.write(bad); log('no throw'); } catch (e) { log('throw ' + e.code + ' ' + e.name); }
  }
  try { w3.write(null); } catch (e) { log('null ' + e.code + ' ' + e.name + ' ' + e.message); }
};

S['writable: back-pressure, drain and return values'] = async (env) => {
  const { Writable } = env.stream, log = env.log;
  const w = new Writable({ highWaterMark: 5, write(c, e, cb) { setTimeout(cb, 2); } });
  w.on('drain', () => log('drain len=' + w.writableLength + ' needDrain=' + w.writableNeedDrain));
  log('w1 ' + w.write('abc') + ' len=' + w.writableLength);
  log('w2 ' + w.write('de') + ' len=' + w.writableLength + ' needDrain=' + w.writableNeedDrain);
  log('w3 ' + w.write('f'));
  await new Promise((res) => w.once('drain', res));
  log('w4 ' + w.write('g') + ' hwm=' + w.writableHighWaterMark);
  w.end();
  await new Promise((res) => w.on('close', res));
};

S['writable: write after end and write after destroy'] = async (env) => {
  const { Writable } = env.stream, log = env.log;
  const w = new Writable({ write(c, e, cb) { cb(); } });
  w.on('error', (e) => log('error ' + e.code + ' ' + e.message));
  w.on('close', () => log('close'));
  w.end();
  const r = w.write('late', (err) => log('cb ' + (err && err.code)));
  log('ret ' + r);
  await env.sleep(10);
  const w2 = new Writable({ write(c, e, cb) { cb(); } });
  w2.on('error', (e) => log('error2 ' + e.code + ' ' + e.message));
  w2.destroy();
  w2.write('x', (err) => log('cb2 ' + (err && err.code)));
  await env.sleep(10);
};

S['writable: error from _write destroys the stream'] = async (env) => {
  const { Writable } = env.stream, log = env.log;
  const w = new Writable({ write(c, e, cb) { cb(new Error('nope')); } });
  w.on('error', (e) => log('error ' + e.message));
  w.on('finish', () => log('finish'));
  w.on('close', () => log('close destroyed=' + w.destroyed));
  w.write('a', (err) => log('cb ' + (err && err.message)));
  await new Promise((res) => w.on('close', res));
};

S['writable: cork and uncork keep order'] = async (env) => {
  const { Writable } = env.stream, log = env.log;
  const w = new Writable({ write(c, e, cb) { log('_write ' + c.toString()); cb(); } });
  w.cork(); w.write('a'); w.write('b');
  log('corked ' + w.writableCorked + ' len=' + w.writableLength);
  await env.sleep(5);
  w.uncork();
  w.end('c');
  await new Promise((res) => w.on('close', res));
};

S['writable: _final runs before finish'] = async (env) => {
  const { Writable } = env.stream, log = env.log;
  const w = new Writable({ write(c, e, cb) { cb(); }, final(cb) { log('_final'); setTimeout(cb, 3); } });
  w.on('prefinish', () => log('prefinish'));
  w.on('finish', () => log('finish'));
  w.end('x');
  await new Promise((res) => w.on('close', res));
};

S['pipe: slow writable applies back-pressure'] = async (env) => {
  const { Readable, Writable } = env.stream, log = env.log;
  let i = 0;
  const src = new Readable({ highWaterMark: 4, read() { i++; this.push(i <= 20 ? String.fromCharCode(96 + i) : null); } });
  const got = [];
  let maxLen = 0;
  const dst = new Writable({ highWaterMark: 3, write(c, e, cb) { got.push(c.toString()); maxLen = Math.max(maxLen, dst.writableLength); setTimeout(cb, 1); } });
  src.pipe(dst);
  dst.on('finish', () => log('finish ' + got.join('')));
  dst.on('close', () => log('dst close'));
  src.on('end', () => log('src end'));
  await new Promise((res) => dst.on('close', res));
  log('maxLen<=hwm+1 ' + (maxLen <= 4));
};

S['pipe: end false and unpipe'] = async (env) => {
  const { Readable, Writable } = env.stream, log = env.log;
  const got = [];
  const dst = new Writable({ write(c, e, cb) { got.push(c.toString()); cb(); } });
  dst.on('pipe', () => log('pipe event'));
  dst.on('unpipe', () => log('unpipe event'));
  const src = Readable.from(['a', 'b', 'c']);
  src.pipe(dst, { end: false });
  await new Promise((res) => src.on('end', res));
  await env.sleep(5);
  log('after src end: ' + got.join('') + ' writableEnded=' + dst.writableEnded);
  const src2 = new Readable({ read() {} });
  src2.pipe(dst);
  src2.push('x');
  await env.sleep(5);
  src2.unpipe(dst);
  src2.push('y');
  await env.sleep(5);
  log('got ' + got.join(''));
  dst.end();
  await new Promise((res) => dst.on('close', res));
};

S['pipe: destination error is rethrown to its listeners'] = async (env) => {
  const { Readable, Writable } = env.stream, log = env.log;
  const src = new Readable({ read() { this.push('a'); } });
  const dst = new Writable({ write(c, e, cb) { cb(new Error('disk full')); } });
  dst.on('error', (e) => log('dst error ' + e.message));
  src.on('unpipe', () => log('src unpipe'));
  src.pipe(dst);
  await new Promise((res) => dst.on('close', res));
  src.destroy();
};

S['transform: uppercase with flush'] = async (env) => {
  const { Readable, Transform, Writable } = env.stream, log = env.log;
  const up = new Transform({
    transform(chunk, enc, cb) { cb(null, chunk.toString().toUpperCase()); },
    flush(cb) { this.push('!'); cb(); },
  });
  let out = '';
  up.on('data', (d) => { out += d; });
  up.on('end', () => log('end ' + out));
  up.on('finish', () => log('finish'));
  up.on('close', () => log('close'));
  up.write('ab'); up.write('cd'); up.end('ef');
  await new Promise((res) => up.on('close', res));
  const collected = [];
  const sink = new Writable({ write(c, e, cb) { collected.push(c.toString()); cb(); } });
  Readable.from(['x', 'y']).pipe(new Transform({ transform(c, e, cb) { this.push(c); this.push(c); cb(); } })).pipe(sink);
  await new Promise((res) => sink.on('close', res));
  log('piped ' + collected.join(''));
};

S['passthrough and chaining'] = async (env) => {
  const { Readable, PassThrough, Writable } = env.stream, log = env.log;
  const pt1 = new PassThrough(), pt2 = new PassThrough();
  const chunks = [];
  const sink = new Writable({ write(c, e, cb) { chunks.push(c.toString()); cb(); } });
  Readable.from(['1', '2', '3']).pipe(pt1).pipe(pt2).pipe(sink);
  await new Promise((res) => sink.on('close', res));
  log('chunks ' + chunks.join(','));
  log('flags ' + [pt1.destroyed, pt2.destroyed, pt1.readableEnded, pt1.writableFinished].join(','));
};

S['transform: error in _transform'] = async (env) => {
  const { Transform } = env.stream, log = env.log;
  const t = new Transform({ transform(c, e, cb) { cb(new Error('bad ' + c)); } });
  t.on('error', (e) => log('error ' + e.message));
  t.on('close', () => log('close destroyed=' + t.destroyed));
  t.write('q');
  await new Promise((res) => t.on('close', res));
};

S['pipeline: success, error, and promises'] = async (env) => {
  const { Readable, Transform, Writable, pipeline } = env.stream, log = env.log;
  const got = [];
  const sink = () => new Writable({ write(c, e, cb) { got.push(c.toString()); cb(); } });
  const up = () => new Transform({ transform(c, e, cb) { cb(null, c.toString().toUpperCase()); } });
  await new Promise((res) => pipeline(Readable.from(['a', 'b']), up(), sink(), (err) => { log('cb1 ' + err); res(); }));
  log('got ' + got.join(''));
  const failing = new Transform({ transform(c, e, cb) { cb(new Error('transform failed')); } });
  const dst = sink();
  const src = new Readable({ read() { this.push('z'); } });
  await new Promise((res) => pipeline(src, failing, dst, (err) => { log('cb2 ' + (err && err.message)); res(); }));
  await env.sleep(10);
  log('destroyed ' + [src.destroyed, failing.destroyed, dst.destroyed].join(','));
  try {
    await env.stream.promises.pipeline(Readable.from(['k']), up(), sink());
    log('promise ok');
  } catch (e) { log('promise failed ' + e.message); }
  try {
    await env.stream.promises.pipeline(Readable.from(['k']), failing2(env), sink());
  } catch (e) { log('promise rejected ' + e.message); }
  function failing2(e) { return new e.stream.Transform({ transform(c, en, cb) { cb(new Error('late fail')); } }); }
};

S['finished: end, finish, error and premature close'] = async (env) => {
  const { Readable, Writable, finished } = env.stream, log = env.log;
  const r = Readable.from(['a']);
  r.resume();
  await new Promise((res) => finished(r, (err) => { log('readable done ' + err); res(); }));
  const w = new Writable({ write(c, e, cb) { cb(); } });
  w.end('x');
  await new Promise((res) => finished(w, (err) => { log('writable done ' + err); res(); }));
  const r2 = new Readable({ read() {} });
  await new Promise((res) => { finished(r2, (err) => { log('premature ' + (err && err.code)); res(); }); r2.destroy(); });
  const r3 = new Readable({ read() {} });
  await new Promise((res) => { finished(r3, (err) => { log('error ' + (err && err.message)); res(); }); r3.destroy(new Error('x broke')); });
};

S['async iteration'] = async (env) => {
  const { Readable } = env.stream, log = env.log;
  const out = [];
  for await (const c of Readable.from(['a', 'b', 'c'])) out.push(c);
  log('from ' + out.join(''));
  let i = 0;
  const r = new Readable({ read() { setTimeout(() => this.push(i < 3 ? 'p' + (++i) : null), 1); } });
  const out2 = [];
  for await (const c of r) out2.push(c.toString());
  log('custom ' + out2.join(','));
  const r2 = new Readable({ read() { this.push('x'); } });
  let n = 0;
  for await (const c of r2) { if (++n >= 2) break; }
  await env.sleep(5);
  log('break destroyed ' + r2.destroyed);
  const r3 = new Readable({ read() { this.destroy(new Error('iter fail')); } });
  try { for await (const c of r3) log('never ' + c); } catch (e) { log('caught ' + e.message); }
};

S['string_decoder'] = async (env) => {
  const { StringDecoder, Buffer } = env, log = env.log;
  const text = '가나다 ✓ héllo 😀 end';
  const bytes = Buffer.from(text);
  for (const enc of ['utf8', 'hex', 'base64', 'latin1']) {
    for (const step of [1, 2, 3, 5]) {
      const d = new StringDecoder(enc);
      let s = '';
      for (let i = 0; i < bytes.length; i += step) s += d.write(bytes.subarray(i, i + step));
      s += d.end();
      log(enc + ' step ' + step + ' => ' + (enc === 'utf8' ? s === text : s.length + ':' + s.slice(0, 24)));
    }
  }
  const d16 = new StringDecoder('utf16le');
  const u16 = Buffer.from('hi 한글', 'utf16le');
  let s16 = '';
  for (let i = 0; i < u16.length; i += 3) s16 += d16.write(u16.subarray(i, i + 3));
  log('utf16le ' + (s16 + d16.end()));
  const trunc = new StringDecoder('utf8');
  log('truncated ' + JSON.stringify(trunc.write(bytes.subarray(0, 1)) + trunc.end()));
  log('string passthrough ' + new StringDecoder('utf8').write('plain'));
};

S['duplex: echo and half open'] = async (env) => {
  const { Duplex } = env.stream, log = env.log;
  const d = new Duplex({ read() {}, write(c, e, cb) { this.push(c.toString().toUpperCase()); cb(); }, final(cb) { this.push(null); cb(); } });
  const out = [];
  d.on('data', (c) => out.push(c.toString()));
  d.on('end', () => log('end ' + out.join('')));
  d.on('finish', () => log('finish'));
  d.on('close', () => log('close'));
  d.write('ab'); d.end('cd');
  await new Promise((res) => d.on('close', res));
  log('instanceof ' + (d instanceof env.stream.Writable) + ' ' + (d instanceof env.stream.Readable) + ' ' + (d instanceof env.stream.Stream));
};

S['readable: unshift, read(0), highWaterMark and length'] = async (env) => {
  const { Readable } = env.stream, log = env.log;
  const r = new Readable({ highWaterMark: 8, read() {} });
  log('push ' + r.push('abcd') + ' ' + r.push('efgh') + ' len=' + r.readableLength + ' hwm=' + r.readableHighWaterMark);
  await env.sleep(5);
  log('read2 ' + r.read(2) + ' len=' + r.readableLength);
  r.unshift('XY');
  log('after unshift len=' + r.readableLength + ' read(4) ' + r.read(4));
  log('read(100) ' + r.read(100));
  log('read(0) ' + r.read(0));
  r.push(null);
  r.resume();
  await new Promise((res) => r.on('end', res));
  log('ended ' + r.readableEnded);
};

S['pipeline with zlib streams and a corrupt input'] = async (env) => {
  const { Readable, Writable, pipeline } = env.stream, log = env.log;
  const data = env.Buffer.alloc(200000);
  for (let i = 0; i < data.length; i++) data[i] = (i * 7 + (i >> 8)) & 255;
  const parts = [];
  for (let i = 0; i < data.length; i += 30000) parts.push(data.subarray(i, i + 30000));
  const out = [];
  const sink = () => new Writable({ write(c, e, cb) { out.push(env.Buffer.from(c)); cb(); } });
  await new Promise((res) => pipeline(Readable.from(parts), env.zlib.createGzip(), env.zlib.createGunzip(), sink(), (err) => { log('roundtrip done ' + err); res(); }));
  const all = env.Buffer.concat(out);
  log('same ' + (all.length === data.length && env.Buffer.compare(all, data) === 0));
  const bad = env.Buffer.from('this is not gzip data at all');
  await new Promise((res) => pipeline(Readable.from([bad]), env.zlib.createGunzip(), sink(), (err) => { log('corrupt -> ' + (err && err.code) + ' ' + (err && err.message)); res(); }));
};

S['crypto: aes ciphers as streams (chunked input, hex output, pipeline)'] = async (env) => {
  const { Readable, Writable, pipeline } = env.stream, log = env.log, B = env.Buffer;
  const key = B.alloc(32, 5), iv = B.alloc(16, 6), data = env.bigData(5000);
  const parts = [];
  for (let i = 0, n = 1; i < data.length; i += n, n = (n * 3 + 7) % 411 + 1) parts.push(data.subarray(i, i + n));
  for (const alg of ['aes-256-cbc', 'aes-256-ctr']) {
    const c = env.crypto.createCipheriv(alg, key, iv);
    c.setEncoding('hex');
    let out = '', chunks = 0;
    c.on('data', (d) => { out += d; chunks++; });
    await new Promise((res) => { c.on('end', res); for (const p of parts) c.write(p); c.end(); });
    log(alg + ' hex length ' + out.length + ' head ' + out.slice(0, 32) + ' tail ' + out.slice(-32) + ' pieces>0 ' + (chunks > 0));
    const got = [];
    const sink = new Writable({ write(c2, e, cb) { got.push(B.from(c2)); cb(); } });
    await new Promise((res) => pipeline(Readable.from(parts), env.crypto.createCipheriv(alg, key, iv), env.crypto.createDecipheriv(alg, key, iv), sink, (err) => { log(alg + ' pipeline ' + err); res(); }));
    log(alg + ' round trip same ' + (B.compare(B.concat(got), data) === 0));
  }
};

S['crypto: aes update(), final(), padding and errors'] = async (env) => {
  const log = env.log, B = env.Buffer, C = env.crypto;
  const key = B.alloc(32, 1), iv = B.alloc(16, 2);
  const run = (label, f) => { try { log(label + ': ' + f()); } catch (e) { log(label + ': ERR ' + (e.code || e.name) + ' | ' + e.message); } };
  const c = C.createCipheriv('aes-256-cbc', key, iv);
  log('update 10 -> ' + c.update(B.alloc(10, 65)).length + ', update 30 -> ' + c.update(B.alloc(30, 66)).length);
  const ct = c.final();
  log('final ' + ct.length + ' ' + ct.toString('hex'));
  run('final twice', () => c.final());
  run('update after final', () => c.update('x'));
  const d = C.createDecipheriv('aes-256-cbc', key, iv);
  log('decrypt update(16) -> ' + d.update(ct.subarray(0, 16)).length + ', update(rest) -> ' + d.update(ct.subarray(16)).length);
  log('decrypt final -> ' + d.final().toString());
  const wrong = C.createDecipheriv('aes-256-cbc', B.alloc(32, 9), iv);
  wrong.update(ct);
  run('wrong key', () => wrong.final());
  const cut = C.createDecipheriv('aes-256-cbc', key, iv);
  cut.update(ct.subarray(0, 20));
  run('truncated', () => cut.final());
  const nopad = C.createCipheriv('aes-256-cbc', key, iv);
  nopad.setAutoPadding(false);
  nopad.update(B.alloc(10));
  run('no padding, 10 bytes', () => nopad.final());
  run('bad key length', () => C.createCipheriv('aes-256-cbc', B.alloc(16), iv));
  run('bad iv length', () => C.createCipheriv('aes-256-cbc', key, B.alloc(8)));
  run('unknown cipher', () => C.createCipheriv('rot13', key, iv));
  run('hex in / base64 out', () => { const x = C.createCipheriv('aes-128-ecb', B.alloc(16, 3), null); return x.update('00112233445566778899aabbccddeeff', 'hex', 'base64') + '|' + x.final('base64'); });
  run('string in / hex out', () => { const x = C.createCipheriv('aes-128-ctr', B.alloc(16, 3), B.alloc(16, 4)); return x.update('héllo wörld ✓', 'utf8', 'hex') + '|' + x.final('hex'); });
};

S['crypto: aes-256-ctr file decrypted through fs streams'] = async (env) => {
  const { fs, T, log, Buffer: B, crypto: C } = env;
  const key = B.alloc(32, 11), iv = B.alloc(16, 12), data = env.bigData(200001);
  fs.writeFileSync(T + '/plain.bin', data);
  const enc = C.createCipheriv('aes-256-ctr', key, iv);
  await new Promise((res, rej) => fs.createReadStream(T + '/plain.bin', { highWaterMark: 7000 }).pipe(enc).pipe(fs.createWriteStream(T + '/enc.bin')).on('finish', res).on('error', rej));
  const e = fs.readFileSync(T + '/enc.bin');
  log('encrypted ' + e.length + ' differs ' + (B.compare(e, data) !== 0) + ' head ' + e.subarray(0, 8).toString('hex'));
  const dec = C.createDecipheriv('aes-256-ctr', key, iv);
  await new Promise((res, rej) => fs.createReadStream(T + '/enc.bin', { highWaterMark: 9000 }).pipe(dec).pipe(fs.createWriteStream(T + '/dec.bin')).on('finish', res).on('error', rej));
  log('decrypted same ' + (B.compare(fs.readFileSync(T + '/dec.bin'), data) === 0));
  const one = C.createDecipheriv('aes-256-ctr', key, iv);
  const all = B.concat([one.update(fs.readFileSync(T + '/enc.bin')), one.final()]);
  log('one shot same ' + (B.compare(all, data) === 0));
};

module.exports = S;
