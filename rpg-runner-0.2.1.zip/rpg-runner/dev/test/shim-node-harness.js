'use strict';
// Loads the browser-independent shim parts (dev/shim-parts/10 .. 26) into Node with a tiny fake window and a fake Android bridge
// that works on real files, so the shim's stream and file-descriptor code can be compared with real Node, quickly and without a browser.
const fs = require('fs');
const path = require('path');
const { performance } = require('perf_hooks');

const PARTS = path.join(__dirname, '..', 'shim-parts');

/** window.RRNative on real files below `roots` (everything else is EACCES, like the app). */
function fakeBridge(roots, logs) {
  const inside = (p) => roots.some((r) => p === r || p.startsWith(r + '/'));
  const guard = (p, f) => {
    if (!inside(path.resolve(p))) return '!EACCES';
    try { return f(); } catch (e) { return '!' + (e && e.code ? e.code : 'EIO'); }
  };
  return {
    log: (level, msg) => { logs.push(level + ' ' + msg); return ''; },
    exists: (p) => (inside(path.resolve(p)) && fs.existsSync(p) ? '1' : '0'),
    stat: (p) => guard(p, () => {
      const s = fs.statSync(p);
      return JSON.stringify({ f: s.isFile() ? 1 : 0, d: s.isDirectory() ? 1 : 0, s: s.size, m: Math.floor(s.mtimeMs) });
    }),
    readdir: (p) => guard(p, () => JSON.stringify(fs.readdirSync(p).sort())),
    readBase64: (p) => guard(p, () => fs.readFileSync(p).toString('base64')),
    writeBase64: (p, b64, append) => guard(p, () => {
      const d = Buffer.from(b64, 'base64');
      if (append) fs.appendFileSync(p, d); else fs.writeFileSync(p, d);
      return '';
    }),
    mkdir: (p, rec) => guard(p, () => { fs.mkdirSync(p, { recursive: !!rec }); return ''; }),
    unlink: (p) => guard(p, () => { fs.unlinkSync(p); return ''; }),
    rmdir: (p, rec) => guard(p, () => { if (rec) fs.rmSync(p, { recursive: true }); else fs.rmdirSync(p); return ''; }),
    rename: (a, b) => guard(a, () => { fs.renameSync(a, b); return ''; }),
    copy: (a, b) => guard(a, () => { fs.copyFileSync(a, b); return ''; }),
    exit: () => '', showMenu: () => '', openUrl: () => '',
  };
}

/** The synchronous XMLHttpRequest the shim uses to read files (the app serves them over HTTP). */
function fakeXhr(roots) {
  const inside = (p) => roots.some((r) => p === r || p.startsWith(r + '/'));
  return function XMLHttpRequest() {
    this.open = function (m, url) { this._url = url; };
    this.setRequestHeader = function () {};
    this.overrideMimeType = function (t) { this._latin1 = /x-user-defined/.test(t); };
    this.send = function () {
      const p = decodeURIComponent(new URL(this._url).pathname);
      if (!inside(p)) { this.status = 403; this.responseText = ''; return; }
      try {
        const d = fs.readFileSync(p);
        this.status = 200;
        this.responseText = this._latin1 ? d.toString('latin1') : d.toString('utf8');
      } catch (e) { this.status = 404; this.responseText = ''; }
    };
  };
}

/**
 * @param {string} rootDir game folder (process.cwd() of the shim)
 * @param {string[]} [extraRoots] more folders the fake bridge may touch
 * @returns {object} { fs, streamMod, RR, Buffer, EventEmitter, util, path, zlib, crypto, logs, dirty() }
 */
function loadShim(rootDir, extraRoots) {
  const logs = [];
  const roots = [rootDir].concat(extraRoots || []);
  const names = fs.readdirSync(PARTS).filter((f) => /\.js$/.test(f) && f < '30').sort();
  const src = names.map((f) => fs.readFileSync(path.join(PARTS, f), 'utf8')).join('\n') +
    '\n;global.__t = { fs: fs, streamMod: streamMod, RR: RR, Buffer: Buffer, EventEmitter: EventEmitter, util: util, path: path,' +
    ' zlib: zlibMod, crypto: cryptoMod, StringDecoder: StringDecoder, dirty: function () { return dirtyFds; }, flush: function () { flushAll(); } };\n})(window);';
  const win = {
    RRNative: fakeBridge(roots, logs),
    __RR_CONFIG: { root: rootDir, dataDir: rootDir + '/.rr-data', tmpDir: rootDir + '/.rr-tmp', mainHtml: rootDir + '/index.html', engine: 'mv', platform: 'linux' },
    navigator: { userAgent: 'Mozilla/5.0 (X11; Linux x86_64) Chrome/120.0.0.0 Safari/537.36', hardwareConcurrency: 4 },
    location: { origin: 'http://127.0.0.1:1' },
    performance,
    addEventListener() {},
    setTimeout, setInterval, clearTimeout, clearInterval,
  };
  new Function('window', 'XMLHttpRequest', src)(win, fakeXhr(roots)); // eslint-disable-line no-new-func
  return Object.assign({ logs, win }, win.__t);
}

module.exports = { loadShim };
