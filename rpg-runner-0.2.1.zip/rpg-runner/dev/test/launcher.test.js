'use strict';
// Chromium test for the launcher page (app/src/main/assets/launcher/index.html) with a mock of the Java "Launcher" interface.
// The mock enforces the same method names / argument counts as LauncherActivity.LauncherBridge (see bridge-contract.test.js).
// Cover pictures are answered by a Playwright route for https://rrcover.local/<id> (what shouldInterceptRequest does in the app).
const { chromium } = require('playwright');
const path = require('path');
const fs = require('fs');
const { LAUNCHER_SPEC } = require('./bridge-spec');

const ROOT = path.resolve(__dirname, '..', '..');
const PAGE = 'file://' + path.join(ROOT, 'app', 'src', 'main', 'assets', 'launcher', 'index.html');
const SHOTS = process.env.RR_SHOTS || path.join(ROOT, 'dev', '.build', 'shots');

let pass = 0, fail = 0;
function ok(cond, msg, extra) { if (cond) pass++; else { fail++; console.log('FAIL: ' + msg + (extra !== undefined ? '   -> ' + JSON.stringify(extra) : '')); } }
function eq(got, want, msg) { ok(JSON.stringify(got) === JSON.stringify(want), msg, { got, want }); }

/** A fake cover: gradient + title, 3:4 portrait like a box art. */
function coverSvg(title, h1, h2) {
  return '<svg xmlns="http://www.w3.org/2000/svg" width="600" height="800" viewBox="0 0 600 800"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">'
    + '<stop offset="0" stop-color="hsl(' + h1 + ',70%,52%)"/><stop offset="1" stop-color="hsl(' + h2 + ',70%,20%)"/></linearGradient></defs>'
    + '<rect width="600" height="800" fill="url(#g)"/><circle cx="300" cy="330" r="150" fill="rgba(255,255,255,.18)"/>'
    + '<text x="300" y="640" font-size="64" font-family="sans-serif" font-weight="700" fill="#fff" text-anchor="middle">' + title + '</text></svg>';
}
const COVERS = { omori: coverSvg('OMORI', 210, 280), witch: coverSvg('Witch', 340, 20), yume: coverSvg('Yume', 140, 200), ib: coverSvg('IB', 0, 340) };
const coverUrl = (id) => 'https://rrcover.local/' + id + '?v=1';

function game(over) {
  return Object.assign({ id: 'id' + Math.random().toString(16).slice(2, 10), name: 'Game', path: '/storage/emulated/0/Games/Game', engine: 'mv', mainHtml: '', mainQuery: '', renderer: 'auto',
    pad: true, padOpacity: 60, padScale: 100, fpsLimit: 0, encoding: '', addedAt: 1000, lastPlayed: 0, exists: true, shared: true, cover: '', log: '' }, over);
}

function baseState(games, over) {
  return Object.assign({ version: '0.2.0', sdk: 33, device: 'AYN Odin2 Pro', storageOk: true, logDir: '/storage/emulated/0/RPGRunner/logs', easyrpgWeb: true, easyrpgApp: false,
    games, logs: [{ name: 'OMORI-id1-20261104-120000.log', size: 52311, time: 1 }, { name: 'Yume_Nikki-id3-20261103-090000.log', size: 800, time: 0 }] }, over || {});
}

// The mock lives in the page: records calls, enforces the spec, and keeps a tiny in-memory "app state".
function mockScript(initialState, spec) {
  return `(function () {
  var SPEC = ${JSON.stringify(spec)};
  var state = ${JSON.stringify(initialState)};
  var calls = window.__calls = [];
  var pathResult = { ok: true, added: 1, found: 1, names: ['Added Game'] };
  window.__setPathResult = function (r) { pathResult = r; };
  window.__state = function () { return state; };
  var L = {};
  Object.keys(SPEC).forEach(function (name) {
    L[name] = function () {
      if (arguments.length !== SPEC[name].length) throw new Error('Java method ' + name + ' with ' + arguments.length + ' argument(s) not found');
      for (var i = 0; i < arguments.length; i++) if (typeof arguments[i] !== 'string') throw new Error('argument ' + i + ' of ' + name + ' must be a string');
      calls.push([name].concat(Array.prototype.slice.call(arguments)));
      var a0 = arguments[0];
      switch (name) {
        case 'getState': return JSON.stringify(state);
        case 'addGamePath':
          if (pathResult.ok) state.games.push({ id: 'newid' + state.games.length, name: pathResult.names[0], path: a0, engine: 'mv', renderer: 'auto', pad: true, padOpacity: 60, padScale: 100, fpsLimit: 0, encoding: '', addedAt: 2, lastPlayed: 0, exists: true, shared: true, cover: '', log: '' });
          return JSON.stringify(pathResult);
        case 'removeGame':
          state.games = state.games.filter(function (g) { return g.id !== a0; });
          return undefined;
        case 'removeCover':
          state.games.forEach(function (g) { if (g.id === a0) g.cover = ''; });
          return undefined;
        case 'saveSettings':
          var s = JSON.parse(arguments[1]);
          state.games.forEach(function (g) { if (g.id === a0) Object.keys(s).forEach(function (k) { g[k] = s[k]; }); });
          return undefined;
        case 'readLog': return 'line1\\nline2 <b>not html</b>\\nlast line';
      }
      return undefined;
    };
  });
  window.Launcher = L;
  // a fake gamepad the test can press buttons on
  var pad = { connected: true, id: 'Fake Pad', buttons: [], axes: [0, 0, 0, 0] };
  for (var b = 0; b < 17; b++) pad.buttons.push({ pressed: false, value: 0 });
  window.__pad = pad;
  window.__padPress = function (i, down) { pad.buttons[i].pressed = !!down; pad.buttons[i].value = down ? 1 : 0; };
  navigator.getGamepads = function () { return [pad]; };
})();`;
}

async function open(browser, state, viewport) {
  const context = await browser.newContext({ viewport, deviceScaleFactor: 2, hasTouch: true });
  await context.addInitScript({ content: mockScript(state, LAUNCHER_SPEC) });
  await context.route('https://rrcover.local/**', (route) => {
    const id = new URL(route.request().url()).pathname.slice(1);
    if (COVERS[id]) route.fulfill({ status: 200, contentType: 'image/svg+xml', body: COVERS[id], headers: { 'Access-Control-Allow-Origin': '*' } });
    else route.fulfill({ status: 404, contentType: 'text/plain', body: '' });
  });
  const page = await context.newPage();
  const errors = [];
  page.on('pageerror', (e) => errors.push(String(e)));
  await page.goto(PAGE);
  await page.waitForSelector('#games .tile');
  await settle(page);
  return { context, page, errors };
}

/** Waits until the tile row has stopped moving. */
async function settle(page) {
  await page.evaluate(() => new Promise((res) => {
    let last = -1, n = 0;
    (function f() { const x = document.getElementById('games').scrollLeft; if (x === last) n++; else { n = 0; last = x; } if (n >= 8) res(); else requestAnimationFrame(f); })();
  }));
}

const calls = (page) => page.evaluate(() => __calls.slice());
const clearCalls = (page) => page.evaluate(() => { __calls.length = 0; });
const title = (page) => page.textContent('#title');
const selectedName = (page) => page.evaluate(() => { const t = document.querySelector('.tile.sel'); return t ? t.getAttribute('aria-label') : null; });
/** Presses on the centre of tile i the way a finger would (no automatic scrolling like locator.click()). */
async function tapTile(page, i) {
  const r = await page.evaluate((k) => { const b = document.getElementById('games').children[k].getBoundingClientRect(); return { x: b.left + b.width / 2, y: b.top + b.height / 2 }; }, i);
  await page.mouse.click(r.x, r.y);
}
const barLabels = (page) => page.evaluate(() => Array.from(document.querySelectorAll('#bar .rb')).map((b) => b.getAttribute('aria-label')));
const clickBar = (page, label) => page.evaluate((l) => { const b = Array.from(document.querySelectorAll('#bar .rb')).find((x) => x.getAttribute('aria-label') === l); b.click(); }, label);
const press = async (page, key) => { await page.keyboard.press(key); await settle(page); };

async function main() {
  fs.mkdirSync(SHOTS, { recursive: true });
  const browser = await chromium.launch();
  try {
    // ---------------------------------------------------------------- empty state, permission banner, help
    let s = await open(browser, baseState([], { storageOk: false, logs: [] }), { width: 915, height: 412 });
    eq(await s.page.locator('#games .tile').count(), 1, 'empty: only the add tile');
    ok(await s.page.locator('#games .tile.add.sel').count() === 1, 'empty: the add tile is selected');
    eq(await title(s.page), '게임 추가', 'empty: title of the add tile');
    ok(/아직 게임이 없습니다/.test(await s.page.textContent('#sub')), 'empty state is explained');
    eq(await s.page.evaluate(() => getComputedStyle(document.getElementById('perm')).display), 'flex', 'permission banner is shown when storage access is missing');
    eq(await barLabels(s.page), ['경로 입력', '폴더 선택', '도움말'], 'empty: buttons under the add tile');
    await s.page.click('#btnPerm');
    ok((await calls(s.page)).some((c) => c[0] === 'openPermissionSettings'), 'permission button calls openPermissionSettings');
    await clearCalls(s.page);
    await clickBar(s.page, '폴더 선택');
    eq(await calls(s.page), [['addGameFolder']], 'the big button opens the native folder picker');
    await s.page.screenshot({ path: path.join(SHOTS, 'launcher-empty.png') });
    await s.page.click('#btnHelp');
    ok(await s.page.locator('#modal.open').count() === 1, 'help opens in a dialog');
    await s.page.click('#box #logsBox summary');
    ok(/아직 로그가 없습니다/.test(await s.page.textContent('#logs')), 'no logs yet message');
    ok(/TCOAAL|Coffin of Andy and Leyley 한글패치/.test(await s.page.textContent('#box')), 'help mentions the Korean patch location');
    await s.page.screenshot({ path: path.join(SHOTS, 'launcher-help.png') });
    eq(await s.page.evaluate(() => RRL.back()), true, 'back closes the help dialog');
    eq(await s.errors, [], 'no page errors (empty state)');
    await s.context.close();

    // ---------------------------------------------------------------- tiles, selection, covers
    const games = [
      game({ id: 'omori', name: 'OMORI', engine: 'mv', cover: coverUrl('omori'), log: 'OMORI-omori-20261104-120000.log', lastPlayed: Date.now() - 3600e3, path: '/storage/emulated/0/Games/OMORI' }),
      game({ id: 'witch', name: "The Witch's House MV", engine: 'mv', cover: coverUrl('witch'), renderer: 'canvas', fpsLimit: 30, padOpacity: 40, padScale: 120, lastPlayed: 5000 }),
      game({ id: 'yume', name: '유메닛키', engine: 'rm2k', encoding: '949', cover: coverUrl('yume'), path: '/storage/1234-ABCD/Games/YumeNikki' }),
      game({ id: 'ib', name: 'IB', engine: 'rm2k', cover: coverUrl('missing') }), // the picture is gone: falls back to the placeholder
      game({ id: 'mz', name: 'Some MZ Game With A Rather Long Title That Wraps', engine: 'mz' }),
      game({ id: 'gone', name: 'Moved Game', engine: 'mv', exists: false }),
      game({ id: 'xss', name: '<img src=x onerror="window.__xss=1">', engine: 'nwjs', cover: 'javascript:alert(1)' }),
    ];
    s = await open(browser, baseState(games), { width: 915, height: 412 });
    eq(await s.page.locator('#games .tile').count(), 8, 'seven games + the add tile');
    eq(await selectedName(s.page), 'OMORI', 'starts on the most recently played game');
    eq(await title(s.page), 'OMORI', 'title of the selected game');
    ok(await s.page.locator('#games .tile').nth(0).locator('img.art').count() === 1, 'a game with a cover shows the picture');
    ok(await s.page.locator('#games .tile').nth(4).locator('.ph').count() === 1, 'a game without a cover gets a generated placeholder with its name');
    ok((await s.page.locator('#games .tile').nth(4).textContent()).includes('Some MZ Game'), 'placeholder shows the game name');
    ok(await s.page.locator('#games .tile').nth(3).locator('.ph').count() === 1 && await s.page.locator('#games .tile').nth(3).locator('img').count() === 0, 'a cover that fails to load falls back to the placeholder');
    ok(await s.page.locator('#games .tile').nth(6).locator('img').count() === 0, 'only app-served picture URLs are used (javascript: is ignored)');
    ok(await s.page.locator('#games .tile').nth(5).locator('.warnmark').count() === 1, 'a game with a missing folder is marked');
    const geo = await s.page.evaluate(() => {
      const row = document.getElementById('games');
      const t = Array.from(row.children).map((c) => c.getBoundingClientRect());
      const sel = document.querySelector('.tile.sel').getBoundingClientRect();
      return { w: t[1].width, h: t[1].height, selCenter: sel.left + sel.width / 2, view: innerWidth / 2, selW: sel.width, plain: row.children[1].offsetWidth };
    });
    ok(Math.abs(geo.w - geo.h) < 1, 'tiles are square', geo);
    ok(Math.abs(geo.selCenter - geo.view) < 2, 'the selected tile is centred', geo);
    ok(geo.selW > geo.plain * 1.05, 'the selected tile is enlarged', geo);
    eq(await s.page.evaluate(() => window.__xss), undefined, 'no script injection through game names');
    await s.page.screenshot({ path: path.join(SHOTS, 'launcher-landscape.png') });

    // the buttons under the tiles
    eq(await barLabels(s.page), ['표지 변경', '설정', '실행', '로그', '삭제'], 'buttons for a game with a cover');
    ok(await s.page.evaluate(() => document.querySelector('#bar .rb.go').getBoundingClientRect().width > document.querySelector('#bar .rb:not(.go)').getBoundingClientRect().width), 'the start button is the big one');

    // tap a neighbour: selects it, does not start it
    await clearCalls(s.page);
    await tapTile(s.page, 1);
    await settle(s.page);
    eq(await selectedName(s.page), "The Witch's House MV", 'tapping a neighbour selects it');
    eq(await title(s.page), "The Witch's House MV", 'title follows the selection');
    eq(await calls(s.page), [], 'selecting does not start the game');
    const centred = await s.page.evaluate(() => { const b = document.querySelector('.tile.sel').getBoundingClientRect(); return Math.abs(b.left + b.width / 2 - innerWidth / 2); });
    ok(centred < 2, 'the row scrolled so that the selection is centred', centred);
    await s.page.screenshot({ path: path.join(SHOTS, 'launcher-selected.png') });
    // tap the selected tile: starts it (and a double tap starts it once)
    await tapTile(s.page, 1);
    await tapTile(s.page, 1);
    eq(await calls(s.page), [['play', 'witch']], 'tapping the selected tile starts the game (once)');

    // swiping the row selects whatever ends up in the middle
    await s.page.evaluate(() => { const r = document.getElementById('games'); r.scrollTo({ left: 4 * (r.children[1].offsetLeft - r.children[0].offsetLeft), behavior: 'instant' }); });
    await settle(s.page);
    eq(await selectedName(s.page), 'Some MZ Game With A Rather Long Title That Wraps', 'a swipe selects the tile that stops in the middle');
    ok(/MZ/.test(await s.page.textContent('#chips')), 'chips show the engine of the selected game');

    // the remembered selection survives a refresh from the app (back from a game)
    await s.page.evaluate(() => RRL.onEvent('refresh', null));
    eq(await selectedName(s.page), 'Some MZ Game With A Rather Long Title That Wraps', 'a refresh keeps the selection');

    // keyboard: arrows, Home/End, down to the buttons, Enter
    await press(s.page, 'Home');
    eq(await selectedName(s.page), 'OMORI', 'Home selects the first game');
    await press(s.page, 'ArrowLeft');
    eq(await selectedName(s.page), 'OMORI', 'Left at the first game stays');
    await press(s.page, 'ArrowRight');
    await press(s.page, 'ArrowRight');
    eq(await selectedName(s.page), '유메닛키', 'Right moves to the next game');
    await press(s.page, 'End');
    eq(await selectedName(s.page), '게임 추가', 'End selects the add tile');
    await press(s.page, 'ArrowLeft');
    await press(s.page, 'Home');
    await clearCalls(s.page);
    await press(s.page, 'Enter');
    eq(await calls(s.page), [['play', 'omori']], 'Enter starts the selected game');
    await s.page.waitForTimeout(1600); // double-start guard
    await clearCalls(s.page);
    await press(s.page, 'ArrowDown');
    eq(await s.page.evaluate(() => document.querySelector('#bar .rb.kf').getAttribute('aria-label')), '실행', 'Down moves the focus to the start button');
    await press(s.page, 'ArrowLeft');
    eq(await s.page.evaluate(() => document.querySelector('#bar .rb.kf').getAttribute('aria-label')), '설정', 'Left/Right move between the buttons');
    await press(s.page, 'Enter');
    ok(await s.page.locator('#modal.open').count() === 1, 'Enter on a focused button presses it (settings dialog)');
    await press(s.page, 'Escape');
    eq(await s.page.locator('#modal.open').count(), 0, 'Escape closes the dialog');
    await press(s.page, 'ArrowUp');
    eq(await s.page.locator('#bar .rb.kf').count(), 0, 'Up returns to the tiles');

    // a game that cannot start: marked, explained, start button disabled
    await press(s.page, 'End');
    await press(s.page, 'ArrowLeft'); // xss game
    await press(s.page, 'ArrowLeft'); // gone
    eq(await selectedName(s.page), 'Moved Game', 'selected the game with the missing folder');
    ok(/폴더를 찾을 수 없음/.test(await s.page.textContent('#chips')), 'the missing folder is explained');
    ok(await s.page.evaluate(() => document.querySelector('#bar .rb.go').disabled), 'start button disabled for a missing folder');
    await clearCalls(s.page);
    await tapTile(s.page, 5);
    ok(/게임 폴더를 찾을 수 없습니다/.test(await s.page.textContent('#notice')) && (await calls(s.page)).length === 0, 'tapping a blocked tile explains instead of starting');
    // the game named like HTML is shown as text
    await press(s.page, 'ArrowRight');
    eq(await title(s.page), '<img src=x onerror="window.__xss=1">', 'game names are shown as text, not HTML');
    eq(await s.page.evaluate(() => window.__xss), undefined, 'still no script injection');

    // the log button: newest log of that game
    await press(s.page, 'Home');
    await clearCalls(s.page);
    await clickBar(s.page, '로그');
    eq(await calls(s.page), [['copyLog', 'OMORI-omori-20261104-120000.log']], 'log button copies the newest log of the selected game');
    await press(s.page, 'ArrowRight');
    await clearCalls(s.page);
    await clickBar(s.page, '로그');
    ok(/아직 없습니다/.test(await s.page.textContent('#notice')) && (await calls(s.page)).length === 0, 'no log yet: explained, nothing copied');

    eq(s.errors, [], 'no page errors on the tile screen');
    await s.context.close();

    // ---------------------------------------------------------------- settings (MV + rm2k), delete, add
    s = await open(browser, baseState(games.map((g) => Object.assign({}, g))), { width: 915, height: 412 });
    await press(s.page, 'ArrowRight'); // witch
    await clickBar(s.page, '설정');
    const form = await s.page.evaluate(() => ({ name: document.querySelector('#box input[type=text]').value, selects: Array.from(document.querySelectorAll('#box select')).map((x) => x.value),
      pad: document.querySelector('#box input[type=checkbox]').checked, ranges: Array.from(document.querySelectorAll('#box input[type=range]')).map((x) => x.value) }));
    eq(form, { name: "The Witch's House MV", selects: ['canvas', '30'], pad: true, ranges: ['40', '120'] }, 'settings form shows the stored values');
    ok(/폴더: \/storage\/emulated\/0\/Games\/Game/.test(await s.page.textContent('#box .hint')), 'settings show the game folder');
    await s.page.screenshot({ path: path.join(SHOTS, 'launcher-settings.png') });
    await s.page.selectOption('#box select >> nth=0', 'webgl');
    await s.page.selectOption('#box select >> nth=1', '60');
    await s.page.uncheck('#box input[type=checkbox]');
    await s.page.fill('#box input[type=text]', 'Witch Renamed');
    await s.page.evaluate(() => { var r = document.querySelectorAll('#box input[type=range]'); r[0].value = 85; r[0].dispatchEvent(new Event('input')); r[1].value = 90; r[1].dispatchEvent(new Event('input')); __calls.length = 0; });
    ok(/85%/.test(await s.page.evaluate(() => document.querySelectorAll('#box .field label')[3].textContent)), 'the opacity label follows the slider');
    await s.page.click('#box button.primary');
    const saved = (await calls(s.page)).filter((c) => c[0] === 'saveSettings');
    eq(saved.length, 1, 'save calls saveSettings once');
    eq(saved[0][1], 'witch', 'saveSettings id');
    eq(JSON.parse(saved[0][2]), { name: 'Witch Renamed', renderer: 'webgl', fpsLimit: 60, pad: false, padOpacity: 85, padScale: 90 }, 'saveSettings payload');
    eq(await title(s.page), 'Witch Renamed', 'the new name shows right away');
    eq(await selectedName(s.page), 'Witch Renamed', 'and the selection stays on that game');
    ok(/설정을 저장했습니다/.test(await s.page.textContent('#notice')), 'confirmation notice');

    await press(s.page, 'ArrowRight'); // yume (rm2k)
    await clickBar(s.page, '설정');
    eq(await s.page.evaluate(() => document.querySelectorAll('#box select').length), 1, 'rm2k settings offer the encoding (no renderer / fps)');
    eq(await s.page.evaluate(() => document.querySelector('#box select').value), '949', 'rm2k encoding preselected');
    eq(await s.page.evaluate(() => document.querySelectorAll('#box input[type=range]').length), 2, 'rm2k settings also offer the pad opacity and size');
    ok(/9/.test(await s.page.textContent('#box .sub') || ''), 'rm2k settings explain the number buttons');
    await s.page.selectOption('#box select', '932');
    await clearCalls(s.page);
    await s.page.click('#box button.primary');
    const saved2 = (await calls(s.page)).filter((c) => c[0] === 'saveSettings');
    eq(JSON.parse(saved2[0][2]), { name: '유메닛키', encoding: '932', pad: true, padOpacity: 60, padScale: 100 }, 'rm2k saveSettings payload');

    // back button: closes dialogs first
    await clickBar(s.page, '설정');
    eq(await s.page.evaluate(() => RRL.back()), true, 'back closes an open dialog');
    eq(await s.page.evaluate(() => RRL.back()), false, 'back with nothing open is left to the app');

    // delete with confirmation; the selection moves to the neighbour
    await press(s.page, 'End');
    await press(s.page, 'ArrowLeft');
    await press(s.page, 'ArrowLeft'); // gone
    eq(await selectedName(s.page), 'Moved Game', 'selected the game to delete');
    await clickBar(s.page, '삭제');
    ok(/게임 파일은 삭제되지 않습니다/.test(await s.page.textContent('#box')), 'delete explains that files stay');
    await s.page.click('#box button.ghost'); // cancel
    eq(await s.page.locator('#games .tile').count(), 8, 'cancel keeps the game');
    await clickBar(s.page, '삭제');
    await clearCalls(s.page);
    await s.page.click('#box button.danger');
    eq((await calls(s.page)).filter((c) => c[0] === 'removeGame'), [['removeGame', 'gone']], 'delete calls removeGame(id)');
    eq(await s.page.locator('#games .tile').count(), 7, 'tile removed after confirming');
    await settle(s.page);
    eq(await selectedName(s.page), '<img src=x onerror="window.__xss=1">', 'after a delete the next game is selected');

    // add by folder picker and by path
    await press(s.page, 'End');
    eq(await selectedName(s.page), '게임 추가', 'the add tile is the last one');
    await clearCalls(s.page);
    await tapTile(s.page, 6);
    eq(await calls(s.page), [['addGameFolder']], 'tapping the selected add tile opens the native folder picker');
    await s.page.evaluate(() => RRL.onEvent('added', { ok: true, added: 2, found: 2, names: ['A', 'B'] }));
    ok(/2개 게임을 추가했습니다: A, B/.test(await s.page.textContent('#notice')), 'added event shows a success notice');
    await s.page.evaluate(() => RRL.onEvent('added', { ok: false, message: '지원하는 게임을 찾지 못했습니다.' }));
    ok(/지원하는 게임을 찾지 못했습니다/.test(await s.page.textContent('#notice')) && (await s.page.getAttribute('#notice', 'class')) === 'err', 'failed add shows the reason as an error');
    await clickBar(s.page, '경로 입력');
    eq(await s.page.evaluate(() => document.querySelector('#box input').value), '/storage/emulated/0/', 'manual path field is prefilled');
    await s.page.fill('#box input', '/storage/emulated/0/Games/Fear & Hunger');
    await clearCalls(s.page);
    await s.page.click('#box button.primary');
    eq((await calls(s.page)).filter((c) => c[0] === 'addGamePath'), [['addGamePath', '/storage/emulated/0/Games/Fear & Hunger']], 'manual path is sent as typed');
    ok(await s.page.locator('#games .tile[aria-label="Added Game"]').count() === 1, 'game from the path appears in the row');
    await s.page.evaluate(() => __setPathResult({ ok: false, message: '폴더를 찾을 수 없습니다: /nope' }));
    await clickBar(s.page, '경로 입력');
    await s.page.fill('#box input', '/nope');
    await s.page.keyboard.press('Enter');
    ok(/폴더를 찾을 수 없습니다: \/nope/.test(await s.page.textContent('#notice')), 'Enter submits; failure reason shown');

    // logs in the help dialog
    await clickBar(s.page, '도움말');
    await s.page.click('#box #logsBox summary');
    eq(await s.page.locator('#logs .log').count(), 2, 'two log files listed');
    await clearCalls(s.page);
    await s.page.locator('#logs .log').first().locator('button', { hasText: '보기' }).click();
    ok(/line2 <b>not html<\/b>/.test(await s.page.textContent('#box pre')), 'log text is shown verbatim (no HTML)');
    await s.page.screenshot({ path: path.join(SHOTS, 'launcher-log.png') });
    await s.page.click('#box button.primary');
    await clickBar(s.page, '도움말');
    await s.page.click('#box #logsBox summary');
    await s.page.locator('#logs .log').first().locator('button', { hasText: '복사' }).click();
    await s.page.locator('#logs .log').first().locator('button', { hasText: '공유' }).click();
    eq((await calls(s.page)).map((c) => c.join('|')), ['readLog|OMORI-id1-20261104-120000.log', 'copyLog|OMORI-id1-20261104-120000.log', 'shareLog|OMORI-id1-20261104-120000.log'], 'log buttons call readLog / copyLog / shareLog');
    ok((await s.page.textContent('#info')).indexOf('AYN Odin2 Pro') >= 0, 'device info shown');
    await s.page.keyboard.press('Escape');
    eq(s.errors, [], 'no page errors (settings / delete / add)');
    await s.context.close();

    // ---------------------------------------------------------------- covers: add, change, remove
    s = await open(browser, baseState(games.map((g) => Object.assign({}, g))), { width: 915, height: 412 });
    await press(s.page, 'End');
    await press(s.page, 'ArrowLeft');
    await press(s.page, 'ArrowLeft');
    await press(s.page, 'ArrowLeft'); // mz: no cover
    eq(await selectedName(s.page), 'Some MZ Game With A Rather Long Title That Wraps', 'selected a game without a cover');
    eq((await barLabels(s.page))[0], '표지 추가', 'the cover button says "add" when there is none');
    await clearCalls(s.page);
    await clickBar(s.page, '표지 추가');
    eq(await calls(s.page), [['pickCover', 'mz']], 'cover button opens the native picture picker for this game');
    // the app answers: stored cover + event
    COVERS.mz = coverSvg('MZ', 90, 150);
    await s.page.evaluate((u) => { __state().games.find((g) => g.id === 'mz').cover = u; RRL.onEvent('coverChanged', { id: 'mz', ok: true }); }, coverUrl('mz'));
    await s.page.waitForSelector('#games .tile[aria-label^="Some MZ"] img.art');
    ok(/표지를 설정했습니다/.test(await s.page.textContent('#notice')), 'cover set: confirmation');
    eq((await barLabels(s.page))[0], '표지 변경', 'the button now says "change"');
    await s.page.evaluate(() => RRL.onEvent('coverChanged', { id: 'mz', ok: false, message: '이 이미지를 불러올 수 없습니다. (x)' }));
    ok(/이 이미지를 불러올 수 없습니다/.test(await s.page.textContent('#notice')) && (await s.page.getAttribute('#notice', 'class')) === 'err', 'a failed import shows the reason');

    await clickBar(s.page, '표지 변경');
    ok(await s.page.locator('#box .coverprev img').count() === 1, 'change: the dialog shows the current cover');
    await s.page.screenshot({ path: path.join(SHOTS, 'launcher-cover.png') });
    await clearCalls(s.page);
    await s.page.locator('#box button', { hasText: '다른 이미지 선택' }).click();
    eq(await calls(s.page), [['pickCover', 'mz']], 'change: opens the picker again');
    eq(await s.page.locator('#modal.open').count(), 0, 'change: the dialog closes');
    await clickBar(s.page, '표지 변경');
    await clearCalls(s.page);
    await s.page.locator('#box button', { hasText: '표지 삭제' }).click();
    eq((await calls(s.page)).filter((c) => c[0] === 'removeCover'), [['removeCover', 'mz']], 'remove: calls removeCover(id)');
    await s.page.waitForSelector('#games .tile[aria-label^="Some MZ"] .ph');
    ok(await s.page.locator('#games .tile[aria-label^="Some MZ"] img').count() === 0, 'remove: the tile shows the placeholder again');
    eq((await barLabels(s.page))[0], '표지 추가', 'remove: button says "add" again');
    await press(s.page, 'y');
    eq(await calls(s.page).then((c) => c.filter((x) => x[0] === 'pickCover').length), 1, 'the Y key / button opens the cover picker');
    eq(s.errors, [], 'no page errors (covers)');
    await s.context.close();

    // ---------------------------------------------------------------- gamepad
    s = await open(browser, baseState(games.map((g) => Object.assign({}, g))), { width: 915, height: 412 });
    await s.page.evaluate(() => window.dispatchEvent(new Event('gamepadconnected')));
    await s.page.evaluate(() => __padPress(15, true));
    await s.page.waitForTimeout(120);
    await s.page.evaluate(() => __padPress(15, false));
    await settle(s.page);
    eq(await selectedName(s.page), "The Witch's House MV", 'gamepad d-pad right selects the next game');
    await s.page.evaluate(() => { __padPress(15, true); });
    await s.page.waitForTimeout(700); // held: repeats
    await s.page.evaluate(() => { __padPress(15, false); });
    await settle(s.page);
    ok((await selectedName(s.page)) !== "The Witch's House MV" && (await selectedName(s.page)) !== 'OMORI', 'a held d-pad direction repeats', await selectedName(s.page));
    await s.page.evaluate(() => { __pad.axes[0] = -1; });
    await s.page.waitForTimeout(150);
    await s.page.evaluate(() => { __pad.axes[0] = 0; });
    await clearCalls(s.page);
    await s.page.evaluate(() => { __padPress(0, true); });
    await s.page.waitForTimeout(100);
    await s.page.evaluate(() => { __padPress(0, false); });
    ok((await calls(s.page)).some((c) => c[0] === 'play'), 'gamepad A starts the selected game');
    // a button that is still held when the launcher comes back must not trigger anything
    await s.page.waitForTimeout(1600);
    await clearCalls(s.page);
    await s.page.evaluate(() => { __padPress(0, true); RRL.onEvent('refresh', null); });
    await s.page.waitForTimeout(150);
    eq((await calls(s.page)).filter((c) => c[0] === 'play'), [], 'a button already held when the launcher is shown is ignored until released');
    await s.page.evaluate(() => { __padPress(0, false); });
    await s.page.waitForTimeout(80);
    await s.page.evaluate(() => { __padPress(0, true); });
    await s.page.waitForTimeout(100);
    await s.page.evaluate(() => { __padPress(0, false); });
    ok((await calls(s.page)).some((c) => c[0] === 'play'), 'after releasing, the next press counts');
    // dialog navigation with the pad: B closes, d-pad moves the focus
    await s.page.evaluate(() => { __padPress(9, true); });
    await s.page.waitForTimeout(100);
    await s.page.evaluate(() => { __padPress(9, false); });
    ok(await s.page.locator('#modal.open').count() === 1, 'gamepad Start opens the help dialog');
    await s.page.evaluate(() => { __padPress(1, true); });
    await s.page.waitForTimeout(100);
    await s.page.evaluate(() => { __padPress(1, false); });
    eq(await s.page.locator('#modal.open').count(), 0, 'gamepad B closes the dialog');
    eq(s.errors, [], 'no page errors (gamepad)');
    await s.context.close();

    // ---------------------------------------------------------------- dialogs with the keyboard / d-pad: focus moves by direction
    s = await open(browser, baseState(games.map((g) => Object.assign({}, g))), { width: 915, height: 412 });
    await clickBar(s.page, '설정');
    const focusLabel = () => s.page.evaluate(() => { const a = document.activeElement; return a ? (a.tagName + ':' + (a.textContent || a.type || '').trim().slice(0, 12)) : ''; });
    await s.page.evaluate(() => document.querySelector('#box input[type=text]').focus());
    await s.page.evaluate(() => document.activeElement.blur());
    await s.page.evaluate(() => document.querySelector('#box button.ghost').focus());
    eq(await focusLabel(), 'BUTTON:취소', 'dialog: start on the cancel button');
    await s.page.keyboard.press('ArrowRight');
    eq(await focusLabel(), 'BUTTON:저장', 'dialog: Right moves to the neighbouring button');
    await s.page.keyboard.press('ArrowUp');
    ok((await focusLabel()).startsWith('INPUT:'), 'dialog: Up moves to the control above', await focusLabel());
    await s.context.close();

    // ---------------------------------------------------------------- layouts: nothing may overflow
    const layouts = [['landscape phone', 915, 412], ['Odin 2 style', 731, 411], ['small landscape', 640, 360], ['portrait phone', 412, 915], ['small portrait', 360, 640], ['tablet', 1280, 800]];
    for (const [label0, w, hgt, noPerm] of layouts.flatMap((l) => [[l[0], l[1], l[2], false], [l[0] + ' with permission banner', l[1], l[2], true]])) {
      const label = label0;
      s = await open(browser, baseState(games.map((g) => Object.assign({}, g)), noPerm ? { storageOk: false } : {}), { width: w, height: hgt });
      const m = await s.page.evaluate(() => {
        const app = document.getElementById('app');
        const bar = document.getElementById('bar').getBoundingClientRect();
        const info = document.querySelector('.info').getBoundingClientRect();
        const tile = document.querySelector('.tile.sel').getBoundingClientRect();
        return { scroll: app.scrollHeight - app.clientHeight, barBottom: bar.bottom, vh: innerHeight, infoTop: info.top, tileBottom: tile.bottom, tileTop: tile.top, tile: tile.width };
      });
      ok(m.scroll <= 1, label + ': the screen needs no vertical scrolling', m);
      ok(m.barBottom <= m.vh + 0.5 && m.tileTop >= 0, label + ': buttons and tiles are inside the screen', m);
      ok(m.infoTop >= m.tileBottom - 12, label + ': the title does not overlap the selected tile', m);
      await s.page.screenshot({ path: path.join(SHOTS, 'launcher-' + label.replace(/\s+/g, '-') + '.png') });
      eq(s.errors, [], label + ': no page errors');
      await s.context.close();
    }

    // ---------------------------------------------------------------- permission banner with games
    s = await open(browser, baseState(games.slice(0, 4).map((g) => Object.assign({}, g)), { storageOk: false, easyrpgWeb: false, easyrpgApp: true }), { width: 915, height: 412 });
    ok(await s.page.evaluate(() => document.querySelector('#bar .rb.go').disabled), 'without storage access a game on shared storage cannot be started');
    ok(await s.page.locator('#games .tile .warnmark').count() >= 3, 'and its tiles are marked');
    await press(s.page, 'ArrowRight');
    await press(s.page, 'ArrowRight'); // yume (rm2k, shared)
    ok((await s.page.textContent('#chips')).includes('EasyRPG 웹 플레이어 없음 (앱으로 열기)'), 'rm2k without web player mentions the EasyRPG app');
    await s.page.screenshot({ path: path.join(SHOTS, 'launcher-permission.png') });
    eq(s.errors, [], 'no page errors (permission)');
    await s.context.close();

    // ---------------------------------------------------------------- preview mode: no Android interface at all
    const ctx = await browser.newContext({ viewport: { width: 412, height: 915 } });
    const pg = await ctx.newPage();
    const errs = [];
    pg.on('pageerror', (e) => errs.push(String(e)));
    await pg.goto(PAGE);
    await pg.waitForSelector('#games .tile');
    ok(/미리보기 모드/.test(await pg.textContent('#notice')), 'works (with a hint) when opened without the app');
    eq(errs, [], 'no page errors in preview mode');
    await ctx.close();
  } finally {
    await browser.close().catch(() => {});
  }
  console.log('\n' + pass + ' passed, ' + fail + ' failed');
  process.exit(fail === 0 ? 0 : 1);
}

main().catch((e) => { console.error('TEST CRASH', e); process.exit(2); });
