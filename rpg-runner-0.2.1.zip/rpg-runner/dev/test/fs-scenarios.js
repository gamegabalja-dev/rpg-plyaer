'use strict';
// File descriptor / file stream scenarios (see stream-scenarios.js for the rules). `env.T` is a fresh empty folder; env.show(f) runs f
// and returns "ok <result>" or "ERR <code> | <message>".
const S = {};

S['fd: write, read back, close'] = async (env) => {
  const { fs, T, log, show, Buffer } = env;
  const p = T + '/a.txt';
  const fd = fs.openSync(p, 'w');
  log('type ' + typeof fd);
  log('w1 ' + fs.writeSync(fd, 'hello '));
  log('w2 ' + fs.writeSync(fd, Buffer.from('wörld')));
  log('w3 ' + fs.writeSync(fd, new Uint8Array([33, 34])));
  log('fstat ' + fs.fstatSync(fd).size + ' ' + fs.fstatSync(fd).isFile());
  fs.closeSync(fd);
  log('content ' + JSON.stringify(fs.readFileSync(p, 'utf8')));
  const fd2 = fs.openSync(p, 'r');
  const b = Buffer.alloc(6);
  log('r1 ' + fs.readSync(fd2, b, 0, 6, null) + ' ' + b.toString());
  log('r2 ' + fs.readSync(fd2, b, 0, 6, null) + ' ' + b.toString('latin1'));
  log('r3 ' + fs.readSync(fd2, b, 0, 6, null) + ' ' + b.toString('latin1', 0, 2));
  log('r4 at eof ' + fs.readSync(fd2, b, 0, 6, null));
  log('r5 positional ' + fs.readSync(fd2, b, 0, 5, 1) + ' ' + b.toString('latin1', 0, 5));
  log('r6 into offset ' + fs.readSync(fd2, b, 2, 3, 0) + ' ' + b.toString('latin1'));
  log('write to read-only ' + show(() => fs.writeSync(fd2, 'x')));
  fs.closeSync(fd2);
  log('read after close ' + show(() => fs.readSync(fd2, b, 0, 1, 0)));
  log('close twice ' + show(() => fs.closeSync(fd2)));
};

S['fd: open flags'] = async (env) => {
  const { fs, T, log, show } = env;
  const p = T + '/f.txt';
  const body = (path) => JSON.stringify(fs.readFileSync(path, 'utf8'));
  log('r missing ' + show(() => fs.openSync(p, 'r')));
  log('r+ missing ' + show(() => fs.openSync(p, 'r+')));
  log('a creates ' + show(() => { const fd = fs.openSync(p, 'a'); fs.writeSync(fd, 'one'); fs.closeSync(fd); return body(p); }));
  log('a appends ' + show(() => { const fd = fs.openSync(p, 'a'); fs.writeSync(fd, 'two'); fs.closeSync(fd); return body(p); }));
  log('wx exists ' + show(() => fs.openSync(p, 'wx')));
  log('ax exists ' + show(() => fs.openSync(p, 'ax')));
  log('w truncates ' + show(() => { const fd = fs.openSync(p, 'w'); fs.closeSync(fd); return body(p); }));
  log('wx new ' + show(() => { const q = T + '/new.txt'; const fd = fs.openSync(q, 'wx'); fs.writeSync(fd, 'x'); fs.closeSync(fd); return body(q); }));
  fs.writeFileSync(p, 'abcdef');
  log('r+ overwrite ' + show(() => { const fd = fs.openSync(p, 'r+'); fs.writeSync(fd, 'XY'); fs.closeSync(fd); return body(p); }));
  log('w+ read back ' + show(() => { const fd = fs.openSync(p, 'w+'); fs.writeSync(fd, 'hello'); const b = Buffer.alloc(5); const n = fs.readSync(fd, b, 0, 5, 0); fs.closeSync(fd); return n + ':' + b.toString(); }));
  log('a+ read ' + show(() => { const fd = fs.openSync(p, 'a+'); fs.writeSync(fd, '!!'); const b = Buffer.alloc(7); const n = fs.readSync(fd, b, 0, 7, 0); fs.closeSync(fd); return n + ':' + b.toString(); }));
  log('read from w ' + show(() => { const fd = fs.openSync(p, 'a'); try { return fs.readSync(fd, Buffer.alloc(1), 0, 1, 0); } finally { fs.closeSync(fd); } }));
  log('numeric flags ' + show(() => { const q = T + '/num.txt'; const c = fs.constants; const fd = fs.openSync(q, c.O_WRONLY | c.O_CREAT | c.O_TRUNC); fs.writeSync(fd, 'n'); fs.closeSync(fd); return body(q); }));
  log('bad flags ' + show(() => fs.openSync(p, 'q')));
  log('directory ' + show(() => fs.openSync(T, 'w')));
  log('missing folder ' + show(() => fs.openSync(T + '/nope/x.txt', 'w')));
  log('bad fd type ' + show(() => fs.closeSync('3')));
};

S['fd: positions and append semantics'] = async (env) => {
  const { fs, T, log, Buffer } = env;
  const p = T + '/pos.bin';
  let fd = fs.openSync(p, 'w+');
  fs.writeSync(fd, 'abcdef');
  fs.writeSync(fd, 'XY', 1);        // positional: does not move the pointer
  fs.writeSync(fd, 'gh');           // continues after 'abcdef'
  log('after writes ' + JSON.stringify(fs.readFileSync(p, 'utf8')));
  fs.writeSync(fd, 'Z', 12);        // beyond the end: gap is zero filled
  const all = fs.readFileSync(p);
  log('sparse len ' + all.length + ' ' + Array.from(all.subarray(8, 13)).join(','));
  fs.closeSync(fd);
  fd = fs.openSync(p, 'a');
  fs.writeSync(fd, '++', 0);        // append ignores the position
  fs.closeSync(fd);
  log('append ' + JSON.stringify(fs.readFileSync(p, 'latin1')));
  fd = fs.openSync(p, 'r');
  const b = Buffer.alloc(4);
  log('opts form ' + fs.readSync(fd, b, { position: 2 }) + ' ' + b.toString());
  log('opts offset ' + fs.readSync(fd, b, { offset: 1, length: 2, position: 0 }) + ' ' + b.toString('latin1'));
  log('no length ' + fs.readSync(fd, b, 0) + ' ' + b.toString());
  log('zero length ' + fs.readSync(fd, b, 0, 0, 0));
  log('big position ' + fs.readSync(fd, b, 0, 4, 1000));
  fs.closeSync(fd);
  const q = T + '/str.txt';
  fd = fs.openSync(q, 'w');
  log('string pos+enc ' + fs.writeSync(fd, '616263', 0, 'hex') + ' ' + fs.writeSync(fd, 'é', null, 'utf8') + ' ' + fs.writeSync(fd, 'xyz', 10));
  fs.closeSync(fd);
  log('str file ' + JSON.stringify(fs.readFileSync(q).toString('latin1')));
  fd = fs.openSync(q, 'w');
  log('buffer offset/length ' + fs.writeSync(fd, Buffer.from('0123456789'), 2, 5));
  log('buffer opts ' + fs.writeSync(fd, Buffer.from('ABCDEF'), { offset: 1, length: 2 }));
  fs.closeSync(fd);
  log('buf file ' + fs.readFileSync(q, 'utf8'));
};

S['fd: truncate and grow'] = async (env) => {
  const { fs, T, log, show } = env;
  const p = T + '/t.bin';
  fs.writeFileSync(p, 'abcdefghij');
  const fd = fs.openSync(p, 'r+');
  fs.ftruncateSync(fd, 4);
  log('shrunk ' + fs.fstatSync(fd).size + ' ' + fs.readFileSync(p, 'utf8'));
  fs.ftruncateSync(fd, 8);
  log('grown ' + Array.from(fs.readFileSync(p)).join(','));
  fs.writeSync(fd, 'Z', 6);
  fs.ftruncateSync(fd);
  log('emptied ' + fs.fstatSync(fd).size + ' ' + fs.readFileSync(p).length);
  log('negative ' + show(() => fs.ftruncateSync(fd, -1)));
  fs.closeSync(fd);
  fs.writeFileSync(p, '0123456789');
  fs.truncateSync(p, 3);
  log('truncateSync ' + fs.readFileSync(p, 'utf8'));
  fs.truncateSync(p, 5);
  log('truncateSync grow ' + Array.from(fs.readFileSync(p)).join(','));
  log('truncate missing ' + show(() => fs.truncateSync(T + '/missing', 1)));
  const ro = fs.openSync(p, 'r');
  log('ftruncate read-only ' + show(() => fs.ftruncateSync(ro, 1)));
  fs.closeSync(ro);
};

S['fd: argument errors'] = async (env) => {
  const { fs, T, log, show, Buffer } = env;
  const p = T + '/e.bin';
  fs.writeFileSync(p, 'abc');
  const fd = fs.openSync(p, 'r+');
  const codeOf = (f) => { try { f(); return 'no error'; } catch (e) { return e.name + ' ' + e.code; } };
  log('buffer type ' + codeOf(() => fs.readSync(fd, 'str', 0, 1, 0)));
  log('offset range ' + codeOf(() => fs.readSync(fd, Buffer.alloc(4), 5, 1, 0)));
  log('length range ' + codeOf(() => fs.readSync(fd, Buffer.alloc(4), 0, 9, 0)));
  log('negative length ' + codeOf(() => fs.readSync(fd, Buffer.alloc(4), 0, -1, 0)));
  log('write offset range ' + codeOf(() => fs.writeSync(fd, Buffer.alloc(4), 9, 1)));
  log('write data type ' + codeOf(() => fs.writeSync(fd, 123)));
  log('fd type ' + codeOf(() => fs.fstatSync('x')));
  log('unknown fd ' + codeOf(() => fs.fstatSync(99999)));
  log('unknown fd msg ' + show(() => fs.fsyncSync(99999)));
  fs.closeSync(fd);
};

S['fd: unflushed writes are visible to path based calls'] = async (env) => {
  const { fs, T, log } = env;
  const p = T + '/v.txt';
  const fd = fs.openSync(p, 'w');
  log('exists ' + fs.existsSync(p) + ' size ' + fs.statSync(p).size);
  fs.writeSync(fd, 'first');
  log('size after write ' + fs.statSync(p).size + ' ' + JSON.stringify(fs.readFileSync(p, 'utf8')));
  fs.writeSync(fd, '+second');
  fs.copyFileSync(p, T + '/copy.txt');
  log('copy ' + fs.readFileSync(T + '/copy.txt', 'utf8'));
  fs.writeSync(fd, '+third');
  log('readdir ' + fs.readdirSync(T).join(','));
  fs.fsyncSync(fd);
  log('after fsync ' + fs.readFileSync(p, 'utf8'));
  fs.closeSync(fd);
  log('final ' + fs.readFileSync(p, 'utf8'));
};

S['fd: readFileSync and writeFileSync with a descriptor'] = async (env) => {
  const { fs, T, log } = env;
  const p = T + '/w.txt';
  const fd = fs.openSync(p, 'w+');
  fs.writeFileSync(fd, 'line1\n');
  fs.writeFileSync(fd, Buffer.from('line2\n'));
  fs.appendFileSync(fd, 'line3\n');
  log('size ' + fs.fstatSync(fd).size);
  fs.closeSync(fd);
  const fd2 = fs.openSync(p, 'r');
  log('first read ' + JSON.stringify(fs.readFileSync(fd2, 'utf8')));
  log('second read ' + JSON.stringify(fs.readFileSync(fd2, 'utf8')));
  fs.closeSync(fd2);
};

S['fd: callback flavours'] = async (env) => {
  const { fs, T, log, Buffer } = env;
  const p = T + '/cb.txt';
  const call = (name, ...args) => new Promise((res) => fs[name](...args, (err, ...rest) => res([err && err.code, ...rest])));
  let r = await call('open', p, 'w+');
  const fd = r[1];
  log('open ' + r[0] + ' ' + typeof fd);
  r = await call('write', fd, 'hello world');
  log('write ' + r[0] + ' ' + r[1] + ' ' + r[2]);
  r = await call('write', fd, Buffer.from('!!'), 0, 2, null);
  log('write buf ' + r[0] + ' ' + r[1]);
  const b = Buffer.alloc(20);
  r = await call('read', fd, b, 0, 20, 0);
  log('read ' + r[0] + ' ' + r[1] + ' ' + (r[2] === b) + ' ' + b.toString('utf8', 0, r[1]));
  r = await call('fstat', fd);
  log('fstat ' + r[0] + ' ' + r[1].size);
  r = await call('ftruncate', fd, 5);
  log('ftruncate ' + r[0]);
  r = await call('fsync', fd);
  log('fsync ' + r[0]);
  r = await call('close', fd);
  log('close ' + r[0]);
  log('content ' + fs.readFileSync(p, 'utf8'));
  r = await call('close', fd);
  log('close again ' + r[0]);
  r = await call('open', T + '/nope/x', 'r');
  log('open missing ' + r[0]);
  r = await call('read', fd, Buffer.alloc(1), 0, 1, 0);
  log('read closed ' + r[0]);
  r = await call('truncate', p, 2);
  log('truncate ' + r[0] + ' ' + fs.readFileSync(p, 'utf8'));
  log('no cb throws ' + (() => { try { fs.open(p, 'r'); return 'no'; } catch (e) { return e.code; } })());
};

S['fd: promises FileHandle'] = async (env) => {
  const { fs, T, log, Buffer } = env;
  const p = T + '/fh.txt';
  const fh = await fs.promises.open(p, 'w+');
  log('has fd ' + (typeof fh.fd));
  log('write ' + (await fh.write('héllo wörld')).bytesWritten);
  const w2 = await fh.write(Buffer.from('!!'));
  log('write buf ' + w2.bytesWritten + ' ' + Buffer.isBuffer(w2.buffer));
  const b = Buffer.alloc(8);
  const r = await fh.read(b, 0, 8, 0);
  log('read ' + r.bytesRead + ' ' + (r.buffer === b) + ' ' + b.toString('latin1').length);
  log('stat ' + (await fh.stat()).size);
  await fh.truncate(6);
  log('after truncate ' + (await fh.stat()).size);
  await fh.sync();
  await fh.close();
  log('fd after close ' + fh.fd);
  log('content ' + JSON.stringify(fs.readFileSync(p, 'latin1')));
  const fh2 = await fs.promises.open(p, 'r');
  log('readFile ' + JSON.stringify((await fh2.readFile('utf8'))));
  await fh2.close();
  try { await fs.promises.open(T + '/missing.txt', 'r'); } catch (e) { log('open rejected ' + e.code); }
  try { await fh2.stat(); } catch (e) { log('closed stat ' + e.code); }
};


S['createReadStream: events, chunk sizes and content'] = async (env) => {
  const { fs, T, log, Buffer } = env;
  const p = T + '/big.bin';
  const data = env.bigData(200000);
  fs.writeFileSync(p, data);
  const rs = fs.createReadStream(p);
  const sizes = [];
  const parts = [];
  rs.on('open', (fd) => log('open ' + typeof fd));
  rs.on('ready', () => log('ready'));
  rs.on('data', (d) => { sizes.push(d.length); parts.push(Buffer.from(d)); });
  rs.on('end', () => log('end bytesRead=' + rs.bytesRead));
  rs.on('close', () => log('close'));
  log('sync props ' + [rs.path === p, rs.flags, rs.start, rs.end, rs.autoClose, rs.pending].join(','));
  await new Promise((res) => rs.on('close', res));
  log('sizes ' + sizes.join(','));
  log('same ' + (Buffer.compare(Buffer.concat(parts), data) === 0));
  log('after ' + [rs.destroyed, rs.readable, rs.readableEnded, rs.fd].join(','));
};

S['createReadStream: highWaterMark, start, end and encoding'] = async (env) => {
  const { fs, T, log, Buffer } = env;
  const p = T + '/t.txt';
  fs.writeFileSync(p, '0123456789abcdefghij');
  const collect = async (opts) => {
    const out = [];
    const rs = fs.createReadStream(p, opts);
    rs.on('data', (d) => out.push(typeof d === 'string' ? d : d.toString()));
    await new Promise((res) => rs.on('close', res));
    return JSON.stringify(out);
  };
  log('hwm 6 ' + await collect({ highWaterMark: 6 }));
  log('start 4 ' + await collect({ start: 4, highWaterMark: 8 }));
  log('start 4 end 9 ' + await collect({ start: 4, end: 9, highWaterMark: 4 }));
  log('end only ' + await collect({ end: 5, highWaterMark: 4 }));
  log('start==end ' + await collect({ start: 3, end: 3 }));
  log('start beyond ' + await collect({ start: 100 }));
  log('encoding ' + await collect({ encoding: 'utf8', highWaterMark: 7 }));
  log('string options ' + await collect('hex'));
  const kr = T + '/kr.txt';
  fs.writeFileSync(kr, '가나다라마바사 한국어 텍스트 ✓ héllo');
  const out = [];
  const rs = fs.createReadStream(kr, { encoding: 'utf8', highWaterMark: 5 });
  rs.on('data', (d) => out.push(d));
  await new Promise((res) => rs.on('close', res));
  log('korean ' + out.join(''));
  const code = (f) => { try { f(); return 'no error'; } catch (e) { return e.name + ' ' + e.code; } };
  log('start > end ' + code(() => fs.createReadStream(p, { start: 5, end: 2 })));
  log('bad start ' + code(() => fs.createReadStream(p, { start: 'x' })));
  log('bad path ' + code(() => fs.createReadStream(undefined)));
};

S['createReadStream: missing file and empty file'] = async (env) => {
  const { fs, T, log } = env;
  const rs = fs.createReadStream(T + '/missing.bin');
  rs.on('open', () => log('open'));
  rs.on('error', (e) => log('error ' + e.code + ' ' + e.syscall + ' ' + e.message));
  rs.on('close', () => log('close destroyed=' + rs.destroyed));
  rs.on('data', () => log('data?'));
  await new Promise((res) => rs.on('close', res));
  fs.writeFileSync(T + '/empty.bin', '');
  const e2 = fs.createReadStream(T + '/empty.bin');
  e2.on('data', () => log('empty data?'));
  e2.on('end', () => log('empty end'));
  await new Promise((res) => e2.on('close', res));
  log('empty closed');
};

S['createReadStream: pause, resume and destroy'] = async (env) => {
  const { fs, T, log, Buffer } = env;
  const p = T + '/pr.bin';
  fs.writeFileSync(p, env.bigData(300000));
  const rs = fs.createReadStream(p, { highWaterMark: 1000 });
  let n = 0;
  rs.on('data', (d) => {
    n += d.length;
    if (n === 5000) { rs.pause(); log('paused at ' + n); setTimeout(() => { log('resume'); rs.resume(); }, 5); }
    if (n >= 20000 && !rs.destroyed) { log('destroying at ' + n); rs.destroy(); }
  });
  rs.on('end', () => log('end?'));
  rs.on('close', () => log('close ' + n));
  await new Promise((res) => rs.on('close', res));
  const r2 = fs.createReadStream(p);
  r2.on('close', () => log('closed without reading'));
  r2.destroy();
  await new Promise((res) => r2.on('close', res));
  const r3 = fs.createReadStream(p, { highWaterMark: 100000 });
  const out = [];
  r3.on('readable', () => { let c; while ((c = r3.read(70000)) !== null) out.push(c.length); });
  r3.on('end', () => log('readable sizes ' + out.join(',')));
  await new Promise((res) => r3.on('close', res));
};

S['createWriteStream: events, bytesWritten and content'] = async (env) => {
  const { fs, T, log, Buffer } = env;
  const p = T + '/out.txt';
  const ws = fs.createWriteStream(p);
  ws.on('open', (fd) => log('open ' + typeof fd));
  ws.on('ready', () => log('ready'));
  ws.on('finish', () => log('finish bytesWritten=' + ws.bytesWritten + ' content=' + JSON.stringify(fs.readFileSync(p, 'utf8'))));
  ws.on('close', () => log('close'));
  log('props ' + [ws.path === p, ws.flags, ws.autoClose, ws.pending].join(','));
  log('w1 ' + ws.write('héllo '));
  log('w2 ' + ws.write(Buffer.from('wörld')));
  log('w3 ' + ws.write('!!', 'latin1', () => log('cb3')));
  ws.end('\nthe end');
  await new Promise((res) => ws.on('close', res));
  log('after ' + [ws.destroyed, ws.writable, ws.writableFinished].join(','));
  log('size ' + fs.statSync(p).size);
};

S['createWriteStream: flags, start and errors'] = async (env) => {
  const { fs, T, log } = env;
  const p = T + '/f.txt';
  fs.writeFileSync(p, 'abcdefgh');
  const run = async (opts, ...chunks) => {
    const ws = fs.createWriteStream(p, opts);
    ws.on('error', (e) => log('error ' + e.code));
    for (const c of chunks) ws.write(c);
    ws.end();
    await new Promise((res) => ws.on('close', res));
    return JSON.stringify(fs.readFileSync(p, 'latin1'));
  };
  log('append ' + await run({ flags: 'a' }, '123'));
  log('r+ start ' + await run({ flags: 'r+', start: 2 }, 'XY'));
  log('w default ' + await run(undefined, 'new'));
  log('encoding hex ' + await run({ encoding: 'hex' }, '4142'));
  log('wx exists ' + await run({ flags: 'wx' }, 'no'));
  const missing = fs.createWriteStream(T + '/nodir/x.txt');
  missing.on('error', (e) => log('missing dir error ' + e.code + ' ' + e.syscall));
  missing.on('close', () => log('missing dir close'));
  missing.write('lost');
  await new Promise((res) => missing.on('close', res));
  const bad = fs.createWriteStream(p);
  bad.on('error', (e) => log('after end error ' + e.code));
  bad.end('x');
  bad.write('y');
  await new Promise((res) => bad.on('close', res));
  const code = (f) => { try { f(); return 'no error'; } catch (e) { return e.name + ' ' + e.code; } };
  log('bad path ' + code(() => fs.createWriteStream(null)));
};

S['file streams: copy, gzip round trip and hashing'] = async (env) => {
  const { fs, T, log, Buffer, stream, zlib, crypto } = env;
  const src = T + '/src.bin', dst = T + '/dst.bin';
  const data = env.bigData(250000);
  fs.writeFileSync(src, data);
  await new Promise((res) => fs.createReadStream(src).pipe(fs.createWriteStream(dst)).on('close', res));
  log('copy same ' + (Buffer.compare(fs.readFileSync(dst), data) === 0));
  await new Promise((res) => stream.pipeline(fs.createReadStream(src), zlib.createGzip(), fs.createWriteStream(T + '/z.gz'), (err) => { log('gzip pipeline ' + err); res(); }));
  log('gunzip same ' + (Buffer.compare(zlib.gunzipSync(fs.readFileSync(T + '/z.gz')), data) === 0));
  await new Promise((res) => stream.pipeline(fs.createReadStream(T + '/z.gz'), zlib.createGunzip(), fs.createWriteStream(T + '/back.bin'), (err) => { log('gunzip pipeline ' + err); res(); }));
  log('back same ' + (Buffer.compare(fs.readFileSync(T + '/back.bin'), data) === 0));
  const digest = await new Promise((res, rej) => {
    const h = crypto.createHash('md5');
    const rs = fs.createReadStream(src);
    rs.on('data', (d) => h.update(d));
    rs.on('end', () => res(h.digest('hex')));
    rs.on('error', rej);
  });
  log('md5 ' + digest + ' ' + (digest === crypto.createHash('md5').update(data).digest('hex')));
  await new Promise((res) => stream.pipeline(fs.createReadStream(T + '/missing.bin'), fs.createWriteStream(T + '/never.bin'), (err) => { log('pipeline missing -> ' + (err && err.code)); res(); }));
  log('never created? ' + fs.existsSync(T + '/never.bin'));
};

S['file streams: async iteration and fd option'] = async (env) => {
  const { fs, T, log, Buffer } = env;
  const p = T + '/it.txt';
  fs.writeFileSync(p, 'abcdefghijklmnop');
  const parts = [];
  for await (const c of fs.createReadStream(p, { highWaterMark: 5 })) parts.push(c.toString());
  log('iter ' + parts.join('|'));
  const fd = fs.openSync(p, 'r');
  const b = Buffer.alloc(4);
  fs.readSync(fd, b, 0, 4, null);
  const rest = [];
  const rs = fs.createReadStream(null, { fd, highWaterMark: 6 });
  rs.on('data', (d) => rest.push(d.toString()));
  await new Promise((res) => rs.on('close', res));
  log('from fd ' + rest.join('|'));
  const fd2 = fs.openSync(T + '/wfd.txt', 'w');
  const ws = fs.createWriteStream(null, { fd: fd2 });
  ws.write('via fd ');
  ws.end('stream');
  await new Promise((res) => ws.on('close', res));
  log('wfd ' + fs.readFileSync(T + '/wfd.txt', 'utf8'));
  const fh = await fs.promises.open(p, 'r');
  const out = [];
  for await (const c of fh.createReadStream({ highWaterMark: 7 })) out.push(c.toString());
  log('filehandle stream ' + out.join('|'));
};

S['crypto: Hash and Hmac as streams'] = async (env) => {
  const { fs, T, log, Buffer, stream, crypto } = env;
  const p = T + '/h.bin';
  const data = env.bigData(150000);
  fs.writeFileSync(p, data);
  const h = crypto.createHash('sha256');
  h.write('abc'); h.write(Buffer.from('def')); h.end();
  log('write/end/read ' + h.read().toString('hex') + ' ' + (h.read() === null));
  await new Promise((res) => h.on('end', res));
  const h2 = crypto.createHash('md5').setEncoding('hex');
  await new Promise((res) => fs.createReadStream(p).pipe(h2).on('finish', res));
  log('pipe + setEncoding ' + h2.read() + ' ' + (h2.read() === null));
  const h3 = crypto.createHmac('sha1', 'key');
  h3.setEncoding('base64');
  await new Promise((res) => stream.pipeline(fs.createReadStream(p), h3, (err) => { log('pipeline ' + err); res(); }));
  log('hmac ' + h3.read());
  log('same as sync ' + (crypto.createHmac('sha1', 'key').update(data).digest('base64')));
  const h4 = crypto.createHash('sha1');
  log('update chain ' + (h4.update('a').update('b') === h4) + ' ' + h4.digest('hex'));
  try { h4.update('c'); } catch (e) { log('after digest ' + e.code + ' ' + e.message); }
  try { h4.digest(); } catch (e) { log('digest twice ' + e.code); }
  const h5 = crypto.createHash('sha512');
  h5.on('readable', () => { const d = h5.read(); if (d) log('readable ' + d.length + ' ' + Buffer.isBuffer(d)); });
  h5.end('x');
  await new Promise((res) => h5.on('end', res));
  log('copy ' + (() => { const a = crypto.createHash('md5').update('ab'); const b = a.copy(); b.update('c'); return a.digest('hex') + ' ' + b.digest('hex'); })());
};

S['fd: deleting or moving a file that is open'] = async (env) => {
  const { fs, T, log } = env;
  const a = T + '/a.txt', b = T + '/b.txt';
  let fd = fs.openSync(a, 'w');
  fs.writeSync(fd, 'abc');
  fs.unlinkSync(a);
  fs.writeSync(fd, 'def');
  log('size after unlink ' + fs.fstatSync(fd).size + ' exists ' + fs.existsSync(a));
  fs.closeSync(fd);
  log('after close exists ' + fs.existsSync(a) + ' listing ' + fs.readdirSync(T).join(','));
  fd = fs.openSync(a, 'w');
  fs.writeSync(fd, 'x');
  fs.renameSync(a, b);
  fs.writeSync(fd, 'y');
  fs.closeSync(fd);
  log('moved ' + fs.existsSync(a) + ' ' + JSON.stringify(fs.readFileSync(b, 'utf8')) + ' listing ' + fs.readdirSync(T).join(','));
  fs.mkdirSync(T + '/d');
  fd = fs.openSync(T + '/d/f.txt', 'w');
  fs.writeSync(fd, '1');
  fs.renameSync(T + '/d', T + '/e');
  fs.writeSync(fd, '2');
  fs.closeSync(fd);
  log('dir moved ' + fs.existsSync(T + '/d') + ' ' + fs.readFileSync(T + '/e/f.txt', 'utf8'));
  fd = fs.openSync(T + '/e/g.txt', 'w');
  fs.writeSync(fd, 'gone');
  fs.rmSync(T + '/e', { recursive: true });
  fs.writeSync(fd, 'more');
  fs.closeSync(fd);
  log('dir removed ' + fs.existsSync(T + '/e') + ' listing ' + fs.readdirSync(T).join(','));
};

module.exports = S;
