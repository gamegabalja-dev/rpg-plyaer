'use strict';
// Chromium test for the lag diagnostics (app/src/main/assets/shim/perf.js): it must report a frozen frame together with the
// script task and the files that arrived meanwhile, slow files, how long a new RPG Maker scene needed, a periodic summary; it must stay
// quiet without a bridge or when switched off, never write more than its line budget, and ignore the time the page was hidden.
// The Android bridge is a plain object that collects the log lines.
//
//   usage: node dev/test/perf.test.js
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..', '..');
const PERF_JS = fs.readFileSync(path.join(ROOT, 'app', 'src', 'main', 'assets', 'shim', 'perf.js'), 'utf8');

let pass = 0, fail = 0;
function ok(cond, msg, extra) { if (cond) pass++; else { fail++; console.log('FAIL: ' + msg + (extra !== undefined ? '   -> ' + (typeof extra === 'string' ? extra : JSON.stringify(extra)) : '')); } }
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const PAGE_URL = 'http://rr.test/game/index.html';
const HTML = '<!doctype html><html><head><meta charset="utf-8"><title>t</title></head><body><canvas id="c" width="64" height="64"></canvas></body></html>';

async function newPage(browser, opts) {
  opts = opts || {};
  const ctx = await browser.newContext({ viewport: { width: 640, height: 360 } });
  const page = await ctx.newPage();
  await page.route('http://rr.test/**', async (route) => {
    const url = route.request().url();
    if (url.endsWith('/index.html')) return route.fulfill({ status: 200, contentType: 'text/html', body: HTML });
    if (/slow\.png/.test(url)) { await sleep(450); return route.fulfill({ status: 200, contentType: 'image/png', body: Buffer.alloc(3000, 1) }); }
    if (/fast\d*\.png/.test(url)) return route.fulfill({ status: 200, contentType: 'image/png', body: Buffer.alloc(300, 2) });
    return route.fulfill({ status: 404, body: '' });
  });
  await page.addInitScript((o) => {
    window.__lines = [];
    if (o.bridge !== false) window.RRNative = { log: (level, msg) => { window.__lines.push(level + ' ' + msg); return ''; } };
    if (o.config) window.__RR_CONFIG = o.config;
  }, opts);
  await page.goto(PAGE_URL);
  return { page, ctx };
}
const lines = (page) => page.evaluate(() => window.__lines.slice());
const inject = (page) => page.addScriptTag({ content: PERF_JS });

(async () => {
  const browser = await chromium.launch();

  // ---- 1. start line, quiet when nothing happens, a frozen frame is reported with script task and files
  {
    const { page, ctx } = await newPage(browser);
    await inject(page);
    await sleep(300);
    let l = await lines(page);
    ok(l.some((x) => /^I perf: page: /.test(x) && /load event after/.test(x)), 'start line is logged', l);
    ok(!l.some((x) => /stall:/.test(x)), 'no stall without a stall', l);
    await page.evaluate(() => { window.__RR_PERF_T = performance.now(); });
    // load two files, then block the main thread for 400 ms inside one frame
    await page.evaluate(async () => {
      await Promise.all([fetch('/game/img/fast1.png').then((r) => r.arrayBuffer()), fetch('/game/img/tilesets/fast2.png').then((r) => r.arrayBuffer())]);
      await new Promise((res) => requestAnimationFrame(() => { const t = performance.now(); while (performance.now() - t < 400) { /* busy */ } res(); }));
    });
    await sleep(900);
    l = await lines(page);
    const stall = l.find((x) => /perf: stall: frame took/.test(x));
    ok(!!stall, 'a frozen frame is reported', l);
    const ms = stall ? parseInt(/frame took (\d+) ms/.exec(stall)[1], 10) : 0;
    ok(ms >= 380 && ms < 900, 'the stall duration is about right: ' + ms, stall);
    ok(stall && /script task \d+ ms/.test(stall), 'the script task that blocked the page is named', stall);
    const state = await page.evaluate(() => ({ stalls: window.__RR_PERF.stalls, frames: window.__RR_PERF.frames, longTasks: window.__RR_PERF.longTasks }));
    ok(state.stalls >= 1 && state.frames > 5 && state.longTasks >= 1, 'counters', state);
    // ---- 2. a slow file is reported with its short name
    await page.evaluate(async () => { await fetch('/game/img/pictures/%EC%A0%9C%EB%AA%A9/slow.png?v=2').then((r) => r.arrayBuffer()); });
    await sleep(2200); // the files are looked at every 2 s
    l = await lines(page);
    const slow = l.find((x) => /perf: slow file:/.test(x));
    ok(!!slow && /img\/pictures\/제목\/slow\.png|pictures\/제목\/slow\.png/.test(slow), 'slow file is listed with a decoded short name: ' + slow, l);
    ok(slow && /took (4\d\d|5\d\d) ms/.test(slow), 'slow file duration', slow);
    ok(!l.some((x) => /slow file: .*fast/.test(x)), 'fast files are not listed', l);
    // ---- 3. the summary
    await page.evaluate(() => window.__RR_PERF.flush());
    l = await lines(page);
    const sum = l.find((x) => /perf: [\d.]+ s: [\d.]+ fps \(worst frame \d+ ms; frames >= 100 ms: \d+/.test(x));
    ok(!!sum, 'summary line', l);
    ok(sum && /files: \d+ \(/.test(sum) && /script tasks >= 50 ms: \d+/.test(sum), 'summary mentions files and script tasks', sum);
    ok(sum && /heap \d+\/\d+ MB/.test(sum), 'summary mentions the heap', sum);
    await ctx.close();
  }

  // ---- 4. RPG Maker scenes: a new scene that needs a while to become ready is reported with its map
  {
    const { page, ctx } = await newPage(browser);
    await page.evaluate(() => {
      function Scene_Map() {}
      function Scene_Title() {}
      window.Scene_Map = Scene_Map;
      window.$gameMap = { mapId: () => 12 };
      window.$gamePlayer = { _transferring: true, _newMapId: 13 };
      window.SceneManager = { _scene: null, _sceneStarted: false };
      window.__setScene = (s, started) => { SceneManager._scene = s; SceneManager._sceneStarted = started; };
      window.__Scene_Map = Scene_Map; window.__Scene_Title = Scene_Title;
    });
    await inject(page);
    await sleep(200);
    await page.evaluate(() => window.__setScene(new window.__Scene_Map(), false));
    await sleep(600);
    await page.evaluate(() => window.__setScene(SceneManager._scene, true));
    await sleep(200);
    // a quick scene change is not reported
    await page.evaluate(() => { window.$gamePlayer._transferring = false; window.__setScene(new window.__Scene_Title(), false); });
    await sleep(60);
    await page.evaluate(() => window.__setScene(SceneManager._scene, true));
    await sleep(300);
    const l = await lines(page);
    const sc = l.filter((x) => /perf: scene /.test(x));
    ok(sc.length === 1 && /scene Scene_Map \(going to map 13\) needed [5-9]\d\d ms until it was ready/.test(sc[0]), 'a slow scene is reported once, with the destination map', l);
    ok(await page.evaluate(() => window.__RR_PERF.scenes) === 2, 'both scenes were counted');
    ok(l.some((x) => /page: .*\(RPG Maker MV\/MZ\)/.test(x)), 'start line recognises an RPG Maker MV/MZ page', l);
    await page.evaluate(() => window.__RR_PERF.flush());
    ok((await lines(page)).some((x) => /scene loading \d+ ms/.test(x)), 'summary includes the scene loading time');
    await ctx.close();
  }

  // ---- 5. nothing happens without a bridge, with perf switched off, or twice
  {
    const a = await newPage(browser, { bridge: false });
    await inject(a.page);
    ok(await a.page.evaluate(() => window.__RR_PERF === undefined), 'no bridge: the script does nothing');
    await a.ctx.close();
    const b = await newPage(browser, { config: { perf: false } });
    await inject(b.page);
    await sleep(200);
    ok(await b.page.evaluate(() => window.__RR_PERF === undefined) && (await lines(b.page)).length === 0, 'perf: false switches it off');
    await b.ctx.close();
    const c = await newPage(browser);
    await inject(c.page); await inject(c.page);
    await sleep(300);
    ok((await lines(c.page)).filter((x) => /perf: page:/.test(x)).length === 1, 'a second injection does nothing');
    await c.ctx.close();
  }

  // ---- 6. line budget: hundreds of stalls do not flood the log
  {
    const { page, ctx } = await newPage(browser);
    await inject(page);
    await page.evaluate(async () => {
      for (let i = 0; i < 90; i++) await new Promise((res) => requestAnimationFrame(() => { const t = performance.now(); while (performance.now() - t < 140) { /* busy */ } res(); }));
    });
    await sleep(1200);
    const l = await lines(page);
    const stalls = l.filter((x) => /perf: stall:/.test(x));
    ok(stalls.length === 70, 'at most 70 stall lines (' + stalls.length + ')', stalls.length);
    ok(/no more stalls are listed/.test(stalls[stalls.length - 1] || ''), 'the last stall line says that no more follow');
    ok(await page.evaluate(() => window.__RR_PERF.stalls) >= 85, 'all stalls are still counted');
    await ctx.close();
  }

  // ---- 7. time in the background is not a stall
  {
    const { page, ctx } = await newPage(browser);
    await inject(page);
    await sleep(200);
    await page.evaluate(() => {
      Object.defineProperty(document, 'hidden', { configurable: true, get: () => true });
      document.dispatchEvent(new Event('visibilitychange'));
    });
    await sleep(700);
    await page.evaluate(() => {
      Object.defineProperty(document, 'hidden', { configurable: true, get: () => false });
      document.dispatchEvent(new Event('visibilitychange'));
    });
    await sleep(500);
    const l = await lines(page);
    ok(!l.some((x) => /stall:/.test(x)), 'hidden time is not reported as a stall', l);
    await ctx.close();
  }

  await browser.close();
  console.log('\n' + pass + ' passed, ' + fail + ' failed');
  process.exit(fail === 0 ? 0 : 1);
})().catch((e) => { console.error(e); process.exit(2); });
