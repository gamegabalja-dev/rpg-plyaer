#!/bin/bash
# The GitHub workflow can build from ONE uploaded zip (rpg-runner*.zip in the repository root) because GitHub's web
# uploader silently drops folders in some situations. This test pulls that step's script out of
# .github/workflows/build-apk.yml and runs it in simulated checkouts: no zip, a zip with and without a wrapping folder,
# leftovers of an older upload, a broken zip, several zips, odd file names.
#
# Needs: bash, zip, unzip, sort -V (skipped with a note when one is missing).   Usage: bash dev/test/workflow-zip.test.sh
cd "$(dirname "$0")/../.." || exit 1
ROOT="$(pwd)"
YML="$ROOT/.github/workflows/build-apk.yml"

for tool in zip unzip awk; do
    command -v "$tool" >/dev/null 2>&1 || { echo "skipped: '$tool' is not installed"; exit 0; }
done
printf '1.10\n1.9\n' | sort -V 2>/dev/null | head -n 1 | grep -q '^1.9$' || { echo "skipped: this sort has no -V"; exit 0; }

W="$(mktemp -d 2>/dev/null || mktemp -d -t rrwf)" || exit 1
trap 'rm -rf "$W"' EXIT
pass=0
fail=0
ok() { if [ "$1" -eq 0 ]; then pass=$((pass + 1)); else fail=$((fail + 1)); echo "  FAIL: $2"; fi; }

# a step's script, taken from the workflow file itself
extract_step() {
    awk -v want="      - name: $1" '
        $0 == want { found = 1; next }
        found && /^        run: \|$/ { inrun = 1; next }
        inrun { if ($0 ~ /^          / || $0 ~ /^$/) { sub(/^          /, ""); print; next } exit }
    ' "$YML"
}
extract_step "Use the project zip if one is in the repository" > "$W/step.sh"
[ -s "$W/step.sh" ]; ok $? "the step 'Use the project zip if one is in the repository' was not found in build-apk.yml"
extract_step "Set up the Android SDK" > "$W/sdk-step.sh"
[ -s "$W/sdk-step.sh" ]; ok $? "the step 'Set up the Android SDK' was not found in build-apk.yml"
grep -q 'uses: android-actions/setup-android' "$YML" && { echo "  FAIL: the workflow must not use android-actions/setup-android (its 'tools' package no longer exists)"; fail=$((fail + 1)); }
[ "$fail" -eq 0 ] || { echo "$pass passed, $fail failed"; exit 1; }

# the project as a user would download it (wrapping folder) and as a flat zip
NAME="$(basename "$ROOT")"
(cd "$ROOT/.." && zip -r -q -X "$W/proj.zip" "$NAME" -x "$NAME/dev/.build/*") || { echo "cannot create the zip"; exit 1; }
(cd "$ROOT" && zip -r -q -X "$W/flat.zip" app gradle tools gradlew gradlew.bat build.gradle settings.gradle gradle.properties README.md)
mkdir "$W/t" && echo hi > "$W/t/a.txt" && (cd "$W/t" && zip -q "$W/bad.zip" a.txt)

new_ws() { rm -rf "$W/ws" "$W/rt"; mkdir -p "$W/ws" "$W/rt"; : > "$W/summary.md"; }
run_step() { (cd "$W/ws" && RUNNER_TEMP="$W/rt" GITHUB_STEP_SUMMARY="$W/summary.md" bash --noprofile --norc -e "$W/step.sh" > "$W/out.txt" 2>&1); }
has_project() { [ -f "$W/ws/app/build.gradle" ] && [ -f "$W/ws/settings.gradle" ] && [ -f "$W/ws/gradlew" ] && [ -f "$W/ws/gradle/wrapper/gradle-wrapper.jar" ] && [ -f "$W/ws/tools/fetch-easyrpg-web.sh" ] && [ -f "$W/ws/app/src/main/assets/shim/shim.js" ]; }

# A: no zip -> nothing changes
new_ws; mkdir -p "$W/ws/app"; echo old > "$W/ws/app/x.txt"; echo loose > "$W/ws/build.gradle"
run_step; ok $? "A: exit code"
[ "$(cat "$W/ws/app/x.txt")" = old ] && [ "$(cat "$W/ws/build.gradle")" = loose ]; ok $? "A: files must stay untouched without a zip"
grep -q "as they are" "$W/out.txt"; ok $? "A: message"

# B: leftovers of an older upload + zip with a wrapping folder
new_ws; mkdir -p "$W/ws/app/old" "$W/ws/tools"; echo stale > "$W/ws/app/old/Stale.java"; echo junk > "$W/ws/tools/junk.sh"; echo old > "$W/ws/build.gradle"
cp "$W/proj.zip" "$W/ws/rpg-runner-0.2.0.zip"
run_step; ok $? "B: exit code"
[ ! -e "$W/ws/app/old/Stale.java" ] && [ ! -e "$W/ws/tools/junk.sh" ]; ok $? "B: stale files must be removed"
has_project; ok $? "B: project files present"
[ -x "$W/ws/gradlew" ]; ok $? "B: gradlew keeps its exec bit"
cmp -s "$ROOT/build.gradle" "$W/ws/build.gradle"; ok $? "B: build.gradle comes from the zip"
cmp -s "$ROOT/app/src/main/assets/shim/shim.js" "$W/ws/app/src/main/assets/shim/shim.js"; ok $? "B: shim.js comes from the zip"
[ -f "$W/ws/.gitignore" ] && [ -f "$W/ws/.github/workflows/build-apk.yml" ]; ok $? "B: hidden files are copied too"
grep -q "rpg-runner-0.2.0.zip" "$W/summary.md"; ok $? "B: step summary names the zip"

# C: flat zip (no wrapping folder)
new_ws; cp "$W/flat.zip" "$W/ws/rpg-runner-flat.zip"
run_step; ok $? "C: exit code"; has_project; ok $? "C: project files present"

# D: a zip that is not the project -> clear error, nothing deleted
new_ws; cp "$W/bad.zip" "$W/ws/rpg-runner-bad.zip"; echo keep > "$W/ws/keep.txt"
run_step; [ $? -ne 0 ]; ok $? "D: must fail"
grep -q "settings.gradle was not found" "$W/out.txt"; ok $? "D: error message"
[ -f "$W/ws/keep.txt" ]; ok $? "D: nothing may be deleted"

# E: several zips -> the highest version wins (0.10.0 > 0.9.0)
new_ws; cp "$W/bad.zip" "$W/ws/rpg-runner-0.1.1.zip"; cp "$W/proj.zip" "$W/ws/rpg-runner-0.10.0.zip"; cp "$W/bad.zip" "$W/ws/rpg-runner-0.9.0.zip"
run_step; ok $? "E: exit code"; grep -q "rpg-runner-0.10.0.zip" "$W/out.txt"; ok $? "E: picked 0.10.0"

# F: a browser-style duplicate name with spaces
new_ws; cp "$W/proj.zip" "$W/ws/rpg-runner-0.2.0 (1).zip"
run_step; ok $? "F: exit code"; has_project; ok $? "F: project files present"

# G: an unrelated zip is ignored
new_ws; cp "$W/bad.zip" "$W/ws/other.zip"; mkdir "$W/ws/app"; echo keep > "$W/ws/app/k.txt"
run_step; ok $? "G: exit code"; [ -f "$W/ws/app/k.txt" ]; ok $? "G: files untouched"

# ---- the Android SDK step (fake sdkmanager / curl, nothing is downloaded)
fake_sdkmanager() { # $1 = path of the fake, $2 = "ok" or "broken"
    mkdir -p "$(dirname "$1")"
    {
        echo '#!/bin/sh'
        if [ "$2" = broken ]; then echo 'exit 1'; else
            echo 'echo "sdkmanager $*" >> "$FAKE_LOG"'
            echo 'case "$*" in *--version*) echo 12.0;; esac'
            echo 'cat > /dev/null 2>&1 < /dev/null; exit 0'
        fi
    } > "$1"
    chmod +x "$1"
}
run_sdk() { (cd "$W" && PATH="$W/bin:$PATH" RUNNER_TEMP="$W/rt" GITHUB_ENV="$W/github_env" FAKE_LOG="$W/fake.log" bash --noprofile --norc -e "$W/sdk-step.sh" > "$W/sdk-out.txt" 2>&1); }

# H: a working preinstalled sdkmanager is used and the three packages are requested
rm -rf "$W/sdk" "$W/bin" "$W/rt"; mkdir -p "$W/bin" "$W/rt"; : > "$W/fake.log"; : > "$W/github_env"
fake_sdkmanager "$W/sdk/cmdline-tools/latest/bin/sdkmanager" ok
ANDROID_HOME="$W/sdk" run_sdk; ok $? "H: exit code"
grep -q -- "--sdk_root=$W/sdk --licenses" "$W/fake.log"; ok $? "H: licenses are accepted"
grep -q 'platform-tools platforms;android-35 build-tools;34.0.0' "$W/fake.log"; ok $? "H: platform-tools, android-35 and build-tools 34.0.0 are installed"
grep -q "^ANDROID_HOME=$W/sdk$" "$W/github_env"; ok $? "H: ANDROID_HOME is handed to the later steps"

# I: no sdkmanager at all -> the command-line tools are downloaded (fake curl) and used
rm -rf "$W/sdk" "$W/bin" "$W/rt" "$W/clt-src"; mkdir -p "$W/bin" "$W/rt" "$W/sdk"; : > "$W/fake.log"; : > "$W/github_env"
fake_sdkmanager "$W/clt-src/cmdline-tools/bin/sdkmanager" ok
(cd "$W/clt-src" && zip -q -r "$W/clt.zip" cmdline-tools)
printf '#!/bin/sh\nwhile [ $# -gt 0 ]; do [ "$1" = -o ] && out="$2"; shift; done\ncp "%s" "$out"\n' "$W/clt.zip" > "$W/bin/curl"; chmod +x "$W/bin/curl"
ANDROID_HOME="$W/sdk" run_sdk; ok $? "I: exit code"
grep -q "downloading the command-line tools" "$W/sdk-out.txt"; ok $? "I: falls back to the download"
grep -q 'platforms;android-35' "$W/fake.log"; ok $? "I: the downloaded sdkmanager installs the packages"

# J: a broken preinstalled sdkmanager is replaced the same way
rm -rf "$W/sdk" "$W/rt"; mkdir -p "$W/rt"; : > "$W/fake.log"; : > "$W/github_env"
fake_sdkmanager "$W/sdk/cmdline-tools/latest/bin/sdkmanager" broken
ANDROID_HOME="$W/sdk" run_sdk; ok $? "J: exit code"
grep -q "downloading the command-line tools" "$W/sdk-out.txt"; ok $? "J: broken sdkmanager triggers the download"

echo
echo "$pass passed, $fail failed"
[ "$fail" -eq 0 ]
