#!/bin/sh
# Concatenates dev/shim-parts/*.js (in name order) into the single file the app serves as /__rr/shim.js.
# The parts share one function scope on purpose: 10-core opens the IIFE, 40-platform closes it.
set -e
cd "$(dirname "$0")/.."
out=app/src/main/assets/shim/shim.js
mkdir -p "$(dirname "$out")"
cat dev/shim-parts/*.js > "$out"
node --check "$out"
echo "built $out ($(wc -c < "$out") bytes)"
