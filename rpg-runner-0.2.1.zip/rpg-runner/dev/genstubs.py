#!/usr/bin/env python3
"""Generates hand-written Android API stubs (only the members RPG Runner uses) so the Android classes can be type-checked with plain javac."""
import os, sys
out = sys.argv[1]
S = {}

def cls(fq, body, kind='public class', ext='', imports=''):
    S[fq] = (kind, ext, body, imports)

cls('android.annotation.SuppressLint', 'String[] value();', kind='public @interface')
cls('android.Manifest', 'public static final class permission { public static final String READ_EXTERNAL_STORAGE = "android.permission.READ_EXTERNAL_STORAGE"; public static final String WRITE_EXTERNAL_STORAGE = "android.permission.WRITE_EXTERNAL_STORAGE"; }')
cls('android.os.Bundle', 'public String getString(String key, String defaultValue) { return defaultValue; } public void putString(String key, String value) {}')
cls('android.R', 'public static final class string { public static final int ok = 1; public static final int cancel = 2; }')
cls('android.os.Looper', 'public static Looper getMainLooper() { return null; }')
cls('android.os.Handler', 'public Handler(Looper l) {} public boolean post(Runnable r) { return true; } public boolean postDelayed(Runnable r, long ms) { return true; }')
cls('android.os.Process', 'public static int myPid() { return 0; } public static void killProcess(int pid) {}')
cls('android.os.Environment', 'public static java.io.File getExternalStorageDirectory() { return null; } public static boolean isExternalStorageManager() { return false; }')
cls('android.os.Build', 'public static final String MANUFACTURER = ""; public static final String MODEL = ""; public static final String[] SUPPORTED_ABIS = {}; public static class VERSION { public static final int SDK_INT = 34; public static final String RELEASE = ""; }')
cls('android.net.Uri', 'public static Uri parse(String s) { return null; } public String getHost() { return null; } public String getScheme() { return null; } public String getAuthority() { return null; } public String getPath() { return null; } public java.util.List<String> getPathSegments() { return null; }')
cls('android.util.Log', 'public static String getStackTraceString(Throwable t) { return ""; }')
cls('android.util.DisplayMetrics', 'public int widthPixels; public int heightPixels; public float density;')
cls('android.graphics.Color', 'public static final int BLACK = 0xff000000; public static int rgb(int r, int g, int b) { return 0; }')
cls('android.graphics.Matrix', 'public boolean postRotate(float degrees) { return true; } public boolean postScale(float sx, float sy) { return true; }')
cls('android.graphics.Bitmap', 'public enum CompressFormat { JPEG, PNG, WEBP } public static Bitmap createScaledBitmap(Bitmap src, int dstWidth, int dstHeight, boolean filter) { return null; } '
    'public static Bitmap createBitmap(Bitmap source, int x, int y, int width, int height, Matrix m, boolean filter) { return null; } '
    'public int getWidth() { return 0; } public int getHeight() { return 0; } public boolean hasAlpha() { return false; } public boolean compress(CompressFormat format, int quality, java.io.OutputStream stream) { return false; } public void recycle() {}')
cls('android.graphics.BitmapFactory', 'public static class Options { public boolean inJustDecodeBounds; public int inSampleSize; public int outWidth; public int outHeight; } '
    'public static Bitmap decodeByteArray(byte[] data, int offset, int length, Options opts) { return null; }')
cls('android.media.ExifInterface', 'public static final String TAG_ORIENTATION = "Orientation"; public static final int ORIENTATION_NORMAL = 1; '
    'public ExifInterface(java.io.InputStream inputStream) throws java.io.IOException {} public int getAttributeInt(String tag, int defaultValue) { return defaultValue; }')
cls('android.provider.DocumentsContract', 'public static String getTreeDocumentId(android.net.Uri u) { return null; }')
cls('android.provider.Settings', 'public static final String ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION = "a"; public static final String ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION = "b";')
cls('android.content.ActivityNotFoundException', '', ext='extends RuntimeException')
cls('android.content.ClipData', 'public static ClipData newPlainText(CharSequence label, CharSequence text) { return null; }')
cls('android.content.ClipboardManager', 'public void setPrimaryClip(ClipData c) {}')
cls('android.content.DialogInterface', 'public interface OnClickListener { void onClick(DialogInterface dialog, int which); } public interface OnDismissListener { void onDismiss(DialogInterface dialog); }', kind='public interface')
cls('android.content.Intent', 'public static final String ACTION_VIEW = "v"; public static final String ACTION_SEND = "s"; public static final String ACTION_OPEN_DOCUMENT_TREE = "t"; public static final String ACTION_OPEN_DOCUMENT = "d"; public static final String CATEGORY_OPENABLE = "o"; public static final String EXTRA_SUBJECT = "s"; public static final String EXTRA_TEXT = "t"; public static final int FLAG_ACTIVITY_NEW_TASK = 1; '
    'public Intent() {} public Intent(String action) {} public Intent(String action, android.net.Uri uri) {} public Intent(Context c, Class<?> k) {} '
    'public Intent setType(String t) { return this; } public Intent addCategory(String c) { return this; } public Intent putExtra(String k, String v) { return this; } public Intent addFlags(int f) { return this; } public String getStringExtra(String k) { return null; } public android.net.Uri getData() { return null; } '
    'public static Intent createChooser(Intent i, CharSequence title) { return i; }')
cls('android.content.Context', 'public static final String CLIPBOARD_SERVICE = "clipboard"; public static final String ACTIVITY_SERVICE = "activity"; '
    'public android.content.res.AssetManager getAssets() { return null; } public java.io.File getFilesDir() { return null; } public java.io.File getCacheDir() { return null; } public java.io.File getExternalFilesDir(String type) { return null; } '
    'public android.content.res.Resources getResources() { return null; } public android.content.ContentResolver getContentResolver() { return null; } public android.content.pm.PackageManager getPackageManager() { return null; } public String getPackageName() { return ""; } '
    'public android.content.pm.ApplicationInfo getApplicationInfo() { return null; } public Object getSystemService(String name) { return null; } public int checkSelfPermission(String p) { return 0; } public void startActivity(Intent i) {}', kind='public abstract class')
cls('android.content.ContentResolver', 'public final java.io.InputStream openInputStream(android.net.Uri uri) throws java.io.FileNotFoundException { return null; }')
cls('android.content.ContextWrapper', '', kind='public class', ext='extends Context')
cls('android.content.res.AssetManager', 'public java.io.InputStream open(String name) throws java.io.IOException { return null; } public String[] list(String path) throws java.io.IOException { return null; }')
cls('android.content.res.Resources', 'public android.util.DisplayMetrics getDisplayMetrics() { return null; }')
cls('android.content.pm.ApplicationInfo', 'public static final int FLAG_DEBUGGABLE = 2; public int flags;')
cls('android.content.pm.PackageInfo', 'public String packageName; public String versionName;')
cls('android.content.pm.PackageManager', 'public static final int PERMISSION_GRANTED = 0; public android.content.Intent getLaunchIntentForPackage(String p) { return null; } public PackageInfo getPackageInfo(String p, int flags) throws NameNotFoundException { return null; } public static class NameNotFoundException extends Exception {}',
    imports='import android.content.pm.PackageInfo;')
cls('android.app.Application', 'public static String getProcessName() { return null; } public void onCreate() {}', ext='extends android.content.ContextWrapper')
cls('android.app.ActivityManager', 'public static class MemoryInfo { public long totalMem; public long availMem; } public void getMemoryInfo(MemoryInfo i) {} public int getMemoryClass() { return 0; } public int getLargeMemoryClass() { return 0; }')
cls('android.app.AlertDialog', 'public static final int X = 0; public void setOnDismissListener(android.content.DialogInterface.OnDismissListener l) {} public void show() {} '
    'public static class Builder { public Builder(android.content.Context c) {} public Builder setTitle(CharSequence t) { return this; } public Builder setMessage(CharSequence m) { return this; } public Builder setCancelable(boolean b) { return this; } '
    'public Builder setItems(CharSequence[] items, android.content.DialogInterface.OnClickListener l) { return this; } public Builder setPositiveButton(CharSequence t, android.content.DialogInterface.OnClickListener l) { return this; } public Builder setPositiveButton(int t, android.content.DialogInterface.OnClickListener l) { return this; } '
    'public Builder setNegativeButton(CharSequence t, android.content.DialogInterface.OnClickListener l) { return this; } public Builder setNegativeButton(int t, android.content.DialogInterface.OnClickListener l) { return this; } public AlertDialog create() { return null; } public AlertDialog show() { return null; } }', ext='extends android.app.Dialog')
cls('android.app.Dialog', 'public void setOnDismissListener(android.content.DialogInterface.OnDismissListener l) {} public void show() {}')
cls('android.app.Activity', 'public static final int RESULT_OK = -1; '
    'protected void onCreate(android.os.Bundle b) {} protected void onSaveInstanceState(android.os.Bundle b) {} protected void onResume() {} protected void onPause() {} protected void onDestroy() {} public void onWindowFocusChanged(boolean f) {} public void onTrimMemory(int level) {} public void onLowMemory() {} public void onBackPressed() {} '
    'protected void onActivityResult(int requestCode, int resultCode, android.content.Intent data) {} public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {} '
    'public void finish() {} public boolean isFinishing() { return false; } public android.view.Window getWindow() { return null; } public android.content.Intent getIntent() { return null; } public void setContentView(android.view.View v) {} public void setContentView(android.view.View v, android.view.ViewGroup.LayoutParams p) {} '
    'public void runOnUiThread(Runnable r) {} public void startActivityForResult(android.content.Intent i, int code) {} public void requestPermissions(String[] p, int code) {}', ext='extends android.content.ContextWrapper')
cls('android.view.Gravity', 'public static final int CENTER = 17;')
cls('android.view.View', 'public static final int OVER_SCROLL_NEVER = 2; public static final int SYSTEM_UI_FLAG_LAYOUT_STABLE = 1; public static final int SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION = 2; public static final int SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN = 4; public static final int SYSTEM_UI_FLAG_HIDE_NAVIGATION = 8; public static final int SYSTEM_UI_FLAG_FULLSCREEN = 16; public static final int SYSTEM_UI_FLAG_IMMERSIVE_STICKY = 32; '
    'public View(android.content.Context c) {} public void setBackgroundColor(int c) {} public void setOverScrollMode(int m) {} public void setVerticalScrollBarEnabled(boolean b) {} public void setHorizontalScrollBarEnabled(boolean b) {} public void setLongClickable(boolean b) {} public void setHapticFeedbackEnabled(boolean b) {} '
    'public void setFocusable(boolean b) {} public void setFocusableInTouchMode(boolean b) {} public boolean requestFocus() { return true; } public void setSystemUiVisibility(int v) {}')
cls('android.view.ViewGroup', 'public ViewGroup(android.content.Context c) { super(c); } public void addView(View v) {} public void addView(View v, LayoutParams p) {} public void addView(View v, int index, LayoutParams p) {} public void removeView(View v) {} '
    'public static class LayoutParams { public static final int MATCH_PARENT = -1; public static final int WRAP_CONTENT = -2; public LayoutParams(int w, int h) {} }', ext='extends View')
cls('android.widget.FrameLayout', 'public FrameLayout(android.content.Context c) { super(c); } public static class LayoutParams extends android.view.ViewGroup.LayoutParams { public LayoutParams(int w, int h) { super(w, h); } }', ext='extends android.view.ViewGroup')
cls('android.widget.TextView', 'public TextView(android.content.Context c) { super(c); } public void setText(CharSequence t) {} public void setTextColor(int c) {} public void setTextSize(float s) {} public void setGravity(int g) {}', ext='extends android.view.View')
cls('android.widget.Toast', 'public static final int LENGTH_SHORT = 0; public static final int LENGTH_LONG = 1; public static Toast makeText(android.content.Context c, CharSequence t, int d) { return null; } public void show() {}')
cls('android.view.WindowManager', 'public static class LayoutParams { public static final int FLAG_KEEP_SCREEN_ON = 128; public static final int LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES = 1; public int layoutInDisplayCutoutMode; }', kind='public interface')
cls('android.view.Window', 'public void addFlags(int f) {} public WindowManager.LayoutParams getAttributes() { return null; } public void setAttributes(WindowManager.LayoutParams a) {} public View getDecorView() { return null; } public void setDecorFitsSystemWindows(boolean b) {} public WindowInsetsController getInsetsController() { return null; }',
    imports='import android.view.WindowManager;')
cls('android.view.WindowInsets', 'public static final class Type { public static int statusBars() { return 1; } public static int navigationBars() { return 2; } }')
cls('android.view.WindowInsetsController', 'public static final int BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE = 2; void hide(int types); void setSystemBarsBehavior(int b);', kind='public interface')
cls('android.webkit.JavascriptInterface', '', kind='public @interface')
cls('android.webkit.ValueCallback', 'void onReceiveValue(T value);', kind='public interface', ext='<T>')
cls('android.webkit.ConsoleMessage', 'public enum MessageLevel { TIP, LOG, WARNING, ERROR, DEBUG } public MessageLevel messageLevel() { return null; } public String message() { return null; } public String sourceId() { return null; } public int lineNumber() { return 0; }')
cls('android.webkit.JsResult', 'public void confirm() {} public void cancel() {}')
cls('android.webkit.PermissionRequest', 'public String[] getResources() { return null; } public void deny() {}')
cls('android.webkit.RenderProcessGoneDetail', 'public boolean didCrash() { return false; }')
cls('android.webkit.WebResourceError', 'public int getErrorCode() { return 0; } public CharSequence getDescription() { return null; }')
cls('android.webkit.WebResourceRequest', 'android.net.Uri getUrl(); boolean isForMainFrame(); boolean hasGesture();', kind='public interface')
cls('android.webkit.WebResourceResponse', 'public WebResourceResponse(String mimeType, String encoding, java.io.InputStream data) {} public WebResourceResponse(String mimeType, String encoding, int statusCode, String reasonPhrase, java.util.Map<String, String> responseHeaders, java.io.InputStream data) {} public int getStatusCode() { return 0; }')
cls('android.webkit.WebSettings', 'public static final int LOAD_NO_CACHE = 2; public static String getDefaultUserAgent(android.content.Context c) { return null; } '
    'public void setJavaScriptEnabled(boolean b) {} public void setDomStorageEnabled(boolean b) {} public void setDatabaseEnabled(boolean b) {} public void setAllowFileAccess(boolean b) {} public void setAllowContentAccess(boolean b) {} public void setMediaPlaybackRequiresUserGesture(boolean b) {} '
    'public void setSupportZoom(boolean b) {} public void setBuiltInZoomControls(boolean b) {} public void setDisplayZoomControls(boolean b) {} public void setUseWideViewPort(boolean b) {} public void setLoadWithOverviewMode(boolean b) {} public void setTextZoom(int z) {} public void setCacheMode(int m) {} '
    'public void setJavaScriptCanOpenWindowsAutomatically(boolean b) {} public void setUserAgentString(String s) {}', kind='public abstract class')
cls('android.webkit.WebViewClient', 'public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; } public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) { return null; } public void onPageFinished(WebView v, String url) {} public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {} '
    'public void onReceivedHttpError(WebView v, WebResourceRequest r, WebResourceResponse e) {} public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) { return false; }')
cls('android.webkit.WebChromeClient', 'public boolean onConsoleMessage(ConsoleMessage m) { return false; } public boolean onJsAlert(WebView v, String url, String message, JsResult r) { return false; } public boolean onJsConfirm(WebView v, String url, String message, JsResult r) { return false; } public void onPermissionRequest(PermissionRequest r) {}')
cls('android.webkit.WebView', 'public WebView(android.content.Context c) { super(c); } public WebSettings getSettings() { return null; } public void loadUrl(String u) {} public void evaluateJavascript(String s, ValueCallback<String> cb) {} public void addJavascriptInterface(Object o, String name) {} public void removeJavascriptInterface(String name) {} '
    'public void setWebViewClient(WebViewClient c) {} public void setWebChromeClient(WebChromeClient c) {} public void onPause() {} public void onResume() {} public void destroy() {} public void stopLoading() {} '
    'public static void setWebContentsDebuggingEnabled(boolean b) {} public static void setDataDirectorySuffix(String s) {} public static android.content.pm.PackageInfo getCurrentWebViewPackage() { return null; }', ext='extends android.view.ViewGroup')

for fq, (kind, ext, body, imports) in S.items():
    pkg, name = fq.rsplit('.', 1)
    path = os.path.join(out, *pkg.split('.'), name + '.java')
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if kind.endswith('@interface'):
        text = f'package {pkg};\n{kind} {name} {{ {body} }}\n'
    elif ext.startswith('<'):
        text = f'package {pkg};\n{kind} {name}{ext} {{ {body} }}\n'
    else:
        text = f'package {pkg};\n{imports}\n{kind} {name} {ext} {{ {body} }}\n'
    open(path, 'w').write(text)
print(len(S), 'stubs written to', out)
