
  // ------------------------------------------------------------------ stand-ins for modules that cannot exist on Android
  // Steam / Discord add-ons: every call is a harmless no-op returning undefined (so "init failed" paths are taken).
  var NOOP_MODULE = /(^|[\/\\])(greenworks[^\/\\]*|steamworks(\.js)?|steam_api[^\/\\]*|discord[-_]?rpc|discord-rich-presence)(\.node|\.js)?$/i;
  function noopStub(name) {
    var target = function () {};
    if (typeof Proxy !== 'function') return {};
    return new Proxy(target, {
      get: function (t, k) {
        if (k === 'then' || typeof k === 'symbol') return undefined; // keep it non-thenable / non-iterable
        if (k === '__esModule') return false;
        RR.warnOnce('noop:' + name + '.' + String(k), 'native module "' + name + '": ' + String(k) + ' is a no-op on Android');
        return noopStub(name + '.' + String(k));
      },
      apply: function () { return undefined; },
      construct: function () { return noopStub(name + '()'); },
      set: function () { return true; },
      has: function () { return true; }
    });
  }
  // Node core modules the app does not implement: requiring them works, using them throws a clear error.
  function unavailable(name) {
    RR.warnOnce('unavailable:' + name, 'require("' + name + '"): this Node module is not available in RPG Runner, using it will throw');
    var fail = function (what) {
      RR.warnOnce('unavailable-use:' + name + '.' + what, 'Node module "' + name + '" was used (' + what + ') but is not available in RPG Runner');
      throw new Error("Node module '" + name + "' is not available in RPG Runner");
    };
    if (typeof Proxy !== 'function') return { __unavailable: name };
    return new Proxy(function () {}, {
      get: function (t, k) { return (k === 'then' || typeof k === 'symbol') ? undefined : function () { return fail(String(k)); }; },
      apply: function () { return fail('call'); }, construct: function () { return fail('new'); }
    });
  }
  var UNAVAILABLE = ['http', 'https', 'http2', 'net', 'tls', 'dns', 'dgram', 'cluster', 'vm', 'readline', 'repl', 'worker_threads', 'tty',
    'v8', 'inspector', 'async_hooks', 'domain', 'punycode', 'sys', 'constants', 'module', 'electron', 'node-fetch'];

  var querystring = {
    parse: function (s) { var o = {}; new URLSearchParams(String(s)).forEach(function (v, k) { o[k] = (k in o) ? [].concat(o[k], v) : v; }); return o; },
    stringify: function (o) { return Object.keys(o || {}).map(function (k) { return encodeURIComponent(k) + '=' + encodeURIComponent(o[k]); }).join('&'); }
  };

  var builtins = {
    fs: fs, path: path, os: os, util: util, events: EventEmitter, url: urlMod, child_process: childProcess, crypto: cryptoMod, zlib: zlibMod,
    string_decoder: stringDecoder, timers: timersMod, assert: assertMod, process: proc, stream: streamMod, querystring: querystring,
    buffer: { Buffer: Buffer, SlowBuffer: Buffer, kMaxLength: 2147483647 },
    perf_hooks: { performance: global.performance }
  };
  RR.builtins = builtins;

  // ------------------------------------------------------------------ require()
  var moduleCache = {};
  function isFile(p) { try { return fs.statSync(p).isFile(); } catch (e) { return false; } }
  function isDir(p) { try { return fs.statSync(p).isDirectory(); } catch (e) { return false; } }
  function tryFile(p) {
    if (isFile(p)) return p;
    var exts = ['.js', '.json', '.node'];
    for (var i = 0; i < exts.length; i++) if (isFile(p + exts[i])) return p + exts[i];
    return null;
  }
  function tryDir(p) {
    if (!isDir(p)) return null;
    var pj = p + '/package.json';
    if (isFile(pj)) {
      try {
        var m = JSON.parse(xhrRead(pj, true)).main;
        if (m) { var q = path.resolve(p, m), r = tryFile(q) || tryFile(q + '/index'); if (r) return r; }
      } catch (e) { /* fall through to index */ }
    }
    return tryFile(p + '/index');
  }
  function resolveFile(name, dir) {
    if (/^(\.{1,2}(\/|$)|\/)/.test(name)) {
      var base = path.resolve(dir, name);
      return tryFile(base) || tryDir(base);
    }
    for (var d = dir; ; d = path.dirname(d)) {
      var cand = path.join(d, 'node_modules', name), r = tryFile(cand) || tryDir(cand);
      if (r) return r;
      if (d === '/' || d === '.' || !d) break;
    }
    return null;
  }
  function evalModule(file, code) {
    if (code.charCodeAt(0) === 35) code = '//' + code; // "#!shebang"
    var mod = { id: file, filename: file, path: path.dirname(file), exports: {}, loaded: false, parent: mainModule, children: [], paths: [] };
    mod.require = makeRequire(mod.path);
    moduleCache[file] = mod;
    var fn;
    try {
      fn = new Function('exports', 'require', 'module', '__filename', '__dirname', code + '\n//# sourceURL=' + file);
    } catch (e) {
      delete moduleCache[file];
      nlog('E', 'syntax error in module ' + file + ': ' + e);
      throw e;
    }
    try { fn.call(mod.exports, mod.exports, mod.require, mod, file, mod.path); } catch (e2) { delete moduleCache[file]; throw e2; }
    mod.loaded = true;
    return mod.exports;
  }
  function requireFrom(request, dir) {
    var n = String(request).replace(/^node:/, '');
    if (n === 'nw.gui' || n === 'nw') return global.nw;
    if (Object.prototype.hasOwnProperty.call(builtins, n)) return builtins[n];
    if (NOOP_MODULE.test(n)) return noopStub(n);
    if (UNAVAILABLE.indexOf(n) >= 0) return unavailable(n);
    var file = resolveFile(n, dir) || (dir !== ROOT ? resolveFile(n, ROOT) : null);
    if (!file) {
      var err = new Error("Cannot find module '" + request + "'");
      err.code = 'MODULE_NOT_FOUND';
      nlog('W', 'require("' + request + '") from ' + dir + ' failed: module not found');
      throw err;
    }
    if (moduleCache[file]) return moduleCache[file].exports;
    if (/\.node$/i.test(file)) return noopStub(file);
    if (/\.json$/i.test(file)) {
      var j = { exports: JSON.parse(xhrRead(file, true)) };
      moduleCache[file] = j;
      return j.exports;
    }
    return evalModule(file, xhrRead(file, true));
  }
  function makeRequire(dir) {
    var req = function (name) {
      if (typeof name !== 'string') { var e = new TypeError('The "id" argument must be of type string. Received ' + typeof name); e.code = 'ERR_INVALID_ARG_TYPE'; throw e; }
      return requireFrom(name, dir);
    };
    req.resolve = function (name) {
      var n = String(name).replace(/^node:/, '');
      if (Object.prototype.hasOwnProperty.call(builtins, n) || n === 'nw.gui') return n;
      var f = resolveFile(n, dir);
      if (!f) { var e = new Error("Cannot find module '" + name + "'"); e.code = 'MODULE_NOT_FOUND'; throw e; }
      return f;
    };
    req.cache = moduleCache; req.main = mainModule; req.extensions = {};
    return req;
  }
  global.global = global;
  global.process = proc;
  global.require = makeRequire(path.dirname(MAIN));
  RR.require = global.require;

  // ------------------------------------------------------------------ nw (NW.js API surface)
  function MenuStub(o) { this.items = []; this.options = o || {}; }
  MenuStub.prototype.append = function (i) { this.items.push(i); };
  MenuStub.prototype.insert = function (i, at) { this.items.splice(at, 0, i); };
  MenuStub.prototype.remove = function (i) { var k = this.items.indexOf(i); if (k >= 0) this.items.splice(k, 1); };
  MenuStub.prototype.removeAt = function (k) { this.items.splice(k, 1); };
  MenuStub.prototype.popup = MenuStub.prototype.createMacBuiltin = function () {};
  function ItemStub(o) { EventEmitter.call(this); for (var k in (o || {})) this[k] = o[k]; }
  util.inherits(ItemStub, EventEmitter);
  function TrayStub(o) { EventEmitter.call(this); for (var k in (o || {})) this[k] = o[k]; }
  util.inherits(TrayStub, EventEmitter);
  TrayStub.prototype.remove = function () {};

  var NOOP = function () {};
  var win = new EventEmitter();
  var winState = { closing: false };
  function emitFs(on) { win.isFullscreen = on; win.emit(on ? 'enter-fullscreen' : 'leave-fullscreen'); }
  win.window = global; win.id = 1; win.x = 0; win.y = 0; win.zoomLevel = 0; win.menu = null;
  win.isFullscreen = true; win.isKioskMode = false; win.isTransparent = false; win.isAlwaysOnTop = false;
  Object.defineProperty(win, 'width', { get: function () { return global.innerWidth; }, set: NOOP, enumerable: true });
  Object.defineProperty(win, 'height', { get: function () { return global.innerHeight; }, set: NOOP, enumerable: true });
  Object.defineProperty(win, 'title', { get: function () { return document.title; }, set: function (t) { document.title = t; }, enumerable: true });
  win.enterFullscreen = function () { emitFs(true); };
  win.leaveFullscreen = NOOP; // the app is always full screen
  win.toggleFullscreen = NOOP;
  win.isDevToolsOpen = function () { return false; };
  win.close = function (force) {
    if (!force && !winState.closing && win.listenerCount('close') > 0) {
      winState.closing = true; // NW.js: a 'close' handler decides; it ends the window with this.close(true)
      win.emit('close');
      winState.closing = false;
      return;
    }
    RR.exit();
  };
  ('show hide focus blur minimize maximize unmaximize restore setPosition moveTo moveBy resizeTo resizeBy setMinimumSize setMaximumSize ' +
    'setResizable setAlwaysOnTop setVisibleOnAllWorkspaces setShowInTaskbar requestAttention setBadgeLabel showDevTools closeDevTools print ' +
    'enterKioskMode leaveKioskMode toggleKioskMode setTransparent setProgressBar setMaximumSize').split(' ').forEach(function (m) { win[m] = NOOP; });
  win.reload = win.reloadDev = win.reloadIgnoringCache = function () { global.location.reload(); };
  win.eval = function (frame, code) { return (0, global.eval)(code); };
  win.capturePage = function (cb) { if (typeof cb === 'function') setTimeout(function () { cb(''); }, 0); };
  win.cookies = { get: NOOP, getAll: NOOP, set: NOOP, remove: NOOP, onChanged: new EventEmitter() };
  var winProxy = typeof Proxy === 'function' ? new Proxy(win, {
    get: function (t, k) {
      if (k in t || typeof k === 'symbol') return t[k];
      RR.warnOnce('win.' + String(k), 'nw.Window.' + String(k) + ' is not implemented (no-op)');
      return NOOP;
    }
  }) : win;
  // browser focus / blur / resize -> NW.js window events
  global.addEventListener('focus', function () { win.emit('focus'); });
  global.addEventListener('blur', function () { win.emit('blur'); });
  global.addEventListener('resize', function () { win.emit('resize', global.innerWidth, global.innerHeight); });

  var manifest = null;
  var App = {
    argv: [], fullArgv: [], filteredArgv: [], dataPath: DATA, startPath: ROOT,
    quit: function () { RR.exit(); }, closeAllWindows: function () { RR.exit(); },
    clearCache: NOOP, setProxyConfig: NOOP, crashBrowser: NOOP, crashRenderer: NOOP, getProxyForURL: function () { return 'DIRECT'; },
    registerGlobalHotKey: NOOP, unregisterGlobalHotKey: NOOP, addOriginAccessWhitelistEntry: NOOP, removeOriginAccessWhitelistEntry: NOOP,
    on: NOOP, once: NOOP, removeListener: NOOP, removeAllListeners: NOOP
  };
  Object.defineProperty(App, 'manifest', {
    enumerable: true,
    get: function () {
      if (!manifest) {
        try { manifest = JSON.parse(xhrRead(ROOT + '/package.json', true)); } catch (e) { manifest = { name: CFG.name || 'game', main: MAIN }; }
      }
      return manifest;
    }
  });
  var clipboard = {
    get: function () { return { get: function () { return ''; }, set: NOOP, clear: NOOP, readAvailableTypes: function () { return ['text']; } }; }
  };
  var nw = {
    Window: { get: function () { return winProxy; }, open: function (url, o, cb) { RR.warnOnce('win.open', 'nw.Window.open ignored: ' + url); if (typeof o === 'function') cb = o; if (cb) cb(winProxy); return winProxy; }, getAll: function (cb) { if (cb) cb([winProxy]); } },
    App: App,
    Shell: {
      openExternal: function (u) { try { if (N && N.openUrl) N.openUrl(String(u)); } catch (e) { /* ignore */ } },
      openItem: NOOP, showItemInFolder: NOOP
    },
    Clipboard: clipboard,
    Screen: {
      Init: NOOP, on: NOOP, removeListener: NOOP, chooseDesktopMedia: NOOP,
      get screens() {
        var w = global.screen ? global.screen.width : global.innerWidth, h = global.screen ? global.screen.height : global.innerHeight;
        return [{ id: 0, bounds: { x: 0, y: 0, width: w, height: h }, work_area: { x: 0, y: 0, width: w, height: h }, scaleFactor: global.devicePixelRatio || 1, isBuiltIn: true }];
      }
    },
    Menu: MenuStub, MenuItem: ItemStub, Tray: TrayStub, Shortcut: ItemStub,
    require: global.require, global: global, process: proc
  };
  global.nw = nw;
  RR.nw = nw;
  RR.nwWindow = win;
