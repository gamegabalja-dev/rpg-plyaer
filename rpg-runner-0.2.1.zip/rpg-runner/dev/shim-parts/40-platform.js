
  // ------------------------------------------------------------------ audio: keep every AudioContext reachable, unlock on first gesture, suspend while paused
  var audioCtxs = [];
  var BaseAudioContext = global.AudioContext || global.webkitAudioContext;
  if (BaseAudioContext) {
    var RRAudioContext = class extends BaseAudioContext {
      constructor(o) { super(o); audioCtxs.push(this); }
    };
    global.AudioContext = RRAudioContext;
    global.webkitAudioContext = RRAudioContext;
  }
  RR.audioContexts = audioCtxs;
  function unlockAudio() {
    if (RR.paused) return;
    for (var i = 0; i < audioCtxs.length; i++) {
      if (audioCtxs[i].state === 'suspended') { try { var p = audioCtxs[i].resume(); if (p && p.catch) p.catch(NOOP); } catch (e) { /* ignore */ } }
    }
  }
  ['pointerdown', 'touchstart', 'mousedown', 'keydown'].forEach(function (ev) { global.addEventListener(ev, unlockAudio, true); });

  var pausedMedia = [];
  /** Called by the Android activity from onPause()/onResume(). */
  RR.setPaused = function (p) {
    p = !!p;
    if (p === RR.paused) return;
    RR.paused = p;
    var i, m;
    if (p) {
      for (i = 0; i < audioCtxs.length; i++) {
        try { if (audioCtxs[i].state === 'running') { audioCtxs[i].suspend(); audioCtxs[i].__rrSuspended = true; } } catch (e) { /* ignore */ }
      }
      pausedMedia = [];
      var media = document.querySelectorAll('video,audio');
      for (i = 0; i < media.length; i++) { m = media[i]; if (!m.paused) { try { m.pause(); pausedMedia.push(m); } catch (e2) { /* ignore */ } } }
    } else {
      for (i = 0; i < audioCtxs.length; i++) {
        if (audioCtxs[i].__rrSuspended) { audioCtxs[i].__rrSuspended = false; try { audioCtxs[i].resume(); } catch (e3) { /* ignore */ } }
      }
      for (i = 0; i < pausedMedia.length; i++) { try { var pr = pausedMedia[i].play(); if (pr && pr.catch) pr.catch(NOOP); } catch (e4) { /* ignore */ } }
      pausedMedia = [];
    }
    nlog('I', 'paused=' + p);
  };

  // The WebView reports visibility changes too (onPause/onResume, screen off): follow them even if the native call was lost.
  document.addEventListener('visibilitychange', function () { RR.setPaused(!!document.hidden); });

  // ------------------------------------------------------------------ optional frame limiter (battery / heat)
  (function () {
    var limit = parseInt(CFG.fpsLimit, 10) || 0;
    if (limit < 10 || limit >= 60 || !global.requestAnimationFrame) return;
    var interval = 1000 / limit, raf = global.requestAnimationFrame.bind(global);
    var queue = [], nextId = 1, last = 0, scheduled = false;
    function schedule() { if (!scheduled) { scheduled = true; raf(pump); } }
    function pump(t) {
      scheduled = false;
      if (t - last < interval - 2) { if (queue.length) schedule(); return; }
      last = t;
      var q = queue;
      queue = [];
      for (var i = 0; i < q.length; i++) {
        if (q[i].dead) continue;
        try { q[i].cb(t); } catch (e) { (function (err) { setTimeout(function () { throw err; }, 0); })(e); }
      }
      if (queue.length) schedule();
    }
    global.requestAnimationFrame = function (cb) { var h = { id: nextId++, cb: cb, dead: false }; queue.push(h); schedule(); return h.id; };
    global.cancelAnimationFrame = function (id) { for (var i = 0; i < queue.length; i++) if (queue[i].id === id) queue[i].dead = true; };
    nlog('I', 'frame limiter active: ' + limit + ' fps');
  })();

  // ------------------------------------------------------------------ error reporting (log file + short on-screen banner)
  var bannerCount = 0, bannerEl = null, bannerTimer = 0;
  function showBanner(text) {
    if (!CFG.debug || bannerCount >= 4 || !document.documentElement) return;
    bannerCount++;
    if (!bannerEl) {
      bannerEl = document.createElement('div');
      bannerEl.style.cssText = 'position:fixed;left:0;right:0;top:0;z-index:2147483646;padding:6px 10px;background:rgba(160,0,0,.88);' +
        'color:#fff;font:12px/1.35 monospace;white-space:pre-wrap;max-height:35vh;overflow:hidden;pointer-events:auto';
      bannerEl.addEventListener('click', function () { bannerEl.style.display = 'none'; });
      document.documentElement.appendChild(bannerEl);
    }
    bannerEl.textContent = String(text).slice(0, 600) + '\n(탭하면 닫힘 · 로그에 기록됨)';
    bannerEl.style.display = 'block';
    clearTimeout(bannerTimer);
    bannerTimer = setTimeout(function () { bannerEl.style.display = 'none'; }, 9000);
  }
  global.addEventListener('error', function (ev) {
    var t = ev.target;
    if (t && t !== global && t.tagName) { // a <script>/<img>/<link> that failed to load (does not bubble, hence capture)
      nlog('W', 'resource failed: <' + String(t.tagName).toLowerCase() + '> ' + (t.src || t.href || ''));
      return;
    }
    var msg = ev.message + ' @ ' + ev.filename + ':' + ev.lineno + ':' + ev.colno;
    if (ev.error && ev.error.stack) msg += '\n' + ev.error.stack;
    nlog('E', 'uncaught: ' + msg);
    showBanner(ev.message + '\n' + ev.filename + ':' + ev.lineno);
  }, true);
  global.addEventListener('unhandledrejection', function (ev) {
    var r = ev.reason;
    nlog('E', 'unhandled rejection: ' + ((r && r.stack) || r));
    showBanner('Unhandled rejection: ' + ((r && r.message) || r));
  });

  // ------------------------------------------------------------------ page fix-ups: viewport, background, no text selection / context menu
  function onDomReady(fn) {
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn); else fn();
  }
  onDomReady(function () {
    var head = document.head || document.documentElement;
    var meta = document.querySelector('meta[name=viewport]');
    if (!meta) { meta = document.createElement('meta'); meta.name = 'viewport'; head.appendChild(meta); }
    meta.setAttribute('content', 'width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1, user-scalable=no, viewport-fit=cover');
    var st = document.createElement('style');
    st.textContent = 'html,body{margin:0;padding:0;background:#000;overflow:hidden;touch-action:none;-webkit-tap-highlight-color:transparent}' +
      '*{-webkit-touch-callout:none;-webkit-user-select:none;user-select:none}input,textarea{-webkit-user-select:text;user-select:text}';
    head.appendChild(st);
  });
  document.addEventListener('contextmenu', function (e) { e.preventDefault(); }, true);
  global.close = function () { RR.exit(); }; // games quit with window.close() when they are not running in NW.js

  nlog('I', 'shim ' + RR.version + ' ready: engine=' + CFG.engine + ' root=' + ROOT + ' main=' + MAIN);
  nlog('I', 'UA ' + (global.navigator ? global.navigator.userAgent : '?') + ' dpr=' + global.devicePixelRatio + ' ' + global.innerWidth + 'x' + global.innerHeight);
  RR.ready = true;
})(window);
