
  // ------------------------------------------------------------------ crypto: hashes, HMAC, PBKDF2, random helpers
  // Node's crypto module needs OpenSSL. Here the parts games commonly use are written in JS: md5, sha1, sha224/256/384/512,
  // HMAC, PBKDF2 and the random helpers (the AES ciphers are in 27-crypto-aes.js). Signatures, key exchange and the other
  // ciphers are not available: calling them logs a warning (so the log shows what the game tried) and throws.
  (function () {
    var i, j;
    function rotl(x, n) { return (x << n) | (x >>> (32 - n)); }
    function rotr(x, n) { return (x >>> n) | (x << (32 - n)); }
    function be32(b, o) { return (b[o] << 24) | (b[o + 1] << 16) | (b[o + 2] << 8) | b[o + 3]; }
    function putBe32(out, o, v) { out[o] = v >>> 24; out[o + 1] = v >>> 16; out[o + 2] = v >>> 8; out[o + 3] = v; }
    function putLe32(out, o, v) { out[o] = v; out[o + 1] = v >>> 8; out[o + 2] = v >>> 16; out[o + 3] = v >>> 24; }

    function describe(v) {
      if (v === null || v === undefined) return String(v);
      if (typeof v === 'function') return 'function ' + v.name;
      if (typeof v === 'object') return 'an instance of ' + ((v.constructor && v.constructor.name) || 'Object');
      var s = typeof v === 'string' ? "'" + (v.length > 28 ? v.slice(0, 25) + '...' : v) + "'" : String(v);
      return 'type ' + typeof v + ' (' + s + ')';
    }
    function codedError(Ctor, code, msg) { var e = new Ctor(msg); e.code = code; return e; }
    function argError(name, expected, v) { return codedError(TypeError, 'ERR_INVALID_ARG_TYPE', 'The "' + name + '" argument must be ' + expected + '. Received ' + describe(v)); }
    // string (with encoding) or any binary view -> Uint8Array without copying
    function bytesArg(v, enc, name, expected) {
      if (typeof v === 'string') return strToBytes(v, enc || 'utf8');
      if (v instanceof Uint8Array) return v;
      if (v instanceof ArrayBuffer) return new Uint8Array(v);
      if (ArrayBuffer.isView(v)) return new Uint8Array(v.buffer, v.byteOffset, v.byteLength);
      throw argError(name, expected, v);
    }
    function outBuf(u8, enc) {
      var b = new Buffer(u8.length);
      b.set(u8);
      return !enc || enc === 'buffer' ? b : bytesToStr(b, enc);
    }

    // ---------------------------------------------------------------- constants
    var primes = [];
    for (i = 2; primes.length < 80; i++) {
      var isPrime = true;
      for (j = 0; j < primes.length && primes[j] * primes[j] <= i; j++) if (i % primes[j] === 0) { isPrime = false; break; }
      if (isPrime) primes.push(i);
    }
    function frac32(x) { return Math.floor((x - Math.floor(x)) * 4294967296); }
    var MD5_R = new Uint8Array([7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20,
      4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21]);
    var MD5_K = new Int32Array(64);
    for (i = 0; i < 64; i++) MD5_K[i] = Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296);
    var K256 = new Int32Array(64), H256 = new Int32Array(8);
    for (i = 0; i < 64; i++) K256[i] = frac32(Math.cbrt(primes[i]));
    for (i = 0; i < 8; i++) H256[i] = frac32(Math.sqrt(primes[i]));
    var H224 = new Int32Array([0xc1059ed8, 0x367cd507, 0x3070dd17, 0xf70e5939, 0xffc00b31, 0x68581511, 0x64f98fa7, 0xbefa4fa4]);
    // SHA-384/512 constants are 64-bit fractions of roots of the first primes: exact integer roots with BigInt, on first use
    var c512 = null;
    function sha512Constants() {
      if (c512) return c512;
      if (typeof BigInt !== 'function') throw new Error('sha384/sha512 need BigInt, which this WebView does not have');
      var B = BigInt, mask = (B(1) << B(64)) - B(1);
      function isqrt(n) {
        var x = B(1) << B((n.toString(2).length >> 1) + 1), y;
        for (;;) { y = (x + n / x) >> B(1); if (y >= x) return x; x = y; }
      }
      function icbrt(n) {
        var x = B(1) << B(Math.floor(n.toString(2).length / 3) + 1), y;
        for (;;) { y = (B(2) * x + n / (x * x)) / B(3); if (y >= x) return x; x = y; }
      }
      function pair(arr, k, v) { arr[2 * k] = Number(v >> B(32)) | 0; arr[2 * k + 1] = Number(v & B(4294967295)) | 0; }
      var K = new Int32Array(160), H512 = new Int32Array(16), H384 = new Int32Array(16), k;
      for (k = 0; k < 80; k++) pair(K, k, icbrt(B(primes[k]) << B(192)) & mask);
      for (k = 0; k < 8; k++) { pair(H512, k, isqrt(B(primes[k]) << B(128)) & mask); pair(H384, k, isqrt(B(primes[8 + k]) << B(128)) & mask); }
      c512 = { K: K, H512: H512, H384: H384 };
      return c512;
    }

    // ---------------------------------------------------------------- compression functions (state: Int32Array)
    var W16 = new Int32Array(16), W80 = new Int32Array(80), W64 = new Int32Array(64), W160 = new Int32Array(160);
    function md5Block(h, b, o) {
      var w = W16, a = h[0], bb = h[1], c = h[2], d = h[3], f, g, t, k;
      for (k = 0; k < 16; k++) w[k] = b[o + 4 * k] | (b[o + 4 * k + 1] << 8) | (b[o + 4 * k + 2] << 16) | (b[o + 4 * k + 3] << 24);
      for (k = 0; k < 64; k++) {
        if (k < 16) { f = (bb & c) | (~bb & d); g = k; }
        else if (k < 32) { f = (d & bb) | (~d & c); g = (5 * k + 1) & 15; }
        else if (k < 48) { f = bb ^ c ^ d; g = (3 * k + 5) & 15; }
        else { f = c ^ (bb | ~d); g = (7 * k) & 15; }
        t = d; d = c; c = bb;
        bb = (bb + rotl((a + f + MD5_K[k] + w[g]) | 0, MD5_R[k])) | 0;
        a = t;
      }
      h[0] = (h[0] + a) | 0; h[1] = (h[1] + bb) | 0; h[2] = (h[2] + c) | 0; h[3] = (h[3] + d) | 0;
    }
    function sha1Block(h, b, o) {
      var w = W80, a = h[0], bb = h[1], c = h[2], d = h[3], e = h[4], f, kk, t, k;
      for (k = 0; k < 16; k++) w[k] = be32(b, o + 4 * k);
      for (k = 16; k < 80; k++) w[k] = rotl(w[k - 3] ^ w[k - 8] ^ w[k - 14] ^ w[k - 16], 1);
      for (k = 0; k < 80; k++) {
        if (k < 20) { f = (bb & c) | (~bb & d); kk = 0x5a827999; }
        else if (k < 40) { f = bb ^ c ^ d; kk = 0x6ed9eba1; }
        else if (k < 60) { f = (bb & c) | (bb & d) | (c & d); kk = 0x8f1bbcdc | 0; }
        else { f = bb ^ c ^ d; kk = 0xca62c1d6 | 0; }
        t = (rotl(a, 5) + f + e + kk + w[k]) | 0;
        e = d; d = c; c = rotl(bb, 30); bb = a; a = t;
      }
      h[0] = (h[0] + a) | 0; h[1] = (h[1] + bb) | 0; h[2] = (h[2] + c) | 0; h[3] = (h[3] + d) | 0; h[4] = (h[4] + e) | 0;
    }
    function sha256Block(h, b, o) {
      var w = W64, a = h[0], bb = h[1], c = h[2], d = h[3], e = h[4], f = h[5], g = h[6], hh = h[7], k, x, y, t1, t2;
      for (k = 0; k < 16; k++) w[k] = be32(b, o + 4 * k);
      for (k = 16; k < 64; k++) {
        x = w[k - 15]; y = w[k - 2];
        w[k] = (w[k - 16] + (rotr(x, 7) ^ rotr(x, 18) ^ (x >>> 3)) + w[k - 7] + (rotr(y, 17) ^ rotr(y, 19) ^ (y >>> 10))) | 0;
      }
      for (k = 0; k < 64; k++) {
        t1 = (hh + (rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25)) + ((e & f) ^ (~e & g)) + K256[k] + w[k]) | 0;
        t2 = ((rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22)) + ((a & bb) ^ (a & c) ^ (bb & c))) | 0;
        hh = g; g = f; f = e; e = (d + t1) | 0; d = c; c = bb; bb = a; a = (t1 + t2) | 0;
      }
      h[0] = (h[0] + a) | 0; h[1] = (h[1] + bb) | 0; h[2] = (h[2] + c) | 0; h[3] = (h[3] + d) | 0;
      h[4] = (h[4] + e) | 0; h[5] = (h[5] + f) | 0; h[6] = (h[6] + g) | 0; h[7] = (h[7] + hh) | 0;
    }
    // 64-bit words are kept as (high, low) pairs of int32; carries are added through doubles (all sums stay below 2^53)
    function sha512Block(h, b, o) {
      var W = W160, K = sha512Constants().K, k, lo;
      var xh, xl, yh, yl, s0h, s0l, s1h, s1l;
      for (k = 0; k < 32; k++) W[k] = be32(b, o + 4 * k);
      for (k = 16; k < 80; k++) {
        xh = W[2 * k - 30]; xl = W[2 * k - 29]; yh = W[2 * k - 4]; yl = W[2 * k - 3];
        s0h = ((xh >>> 1) | (xl << 31)) ^ ((xh >>> 8) | (xl << 24)) ^ (xh >>> 7);
        s0l = ((xl >>> 1) | (xh << 31)) ^ ((xl >>> 8) | (xh << 24)) ^ ((xl >>> 7) | (xh << 25));
        s1h = ((yh >>> 19) | (yl << 13)) ^ ((yl >>> 29) | (yh << 3)) ^ (yh >>> 6);
        s1l = ((yl >>> 19) | (yh << 13)) ^ ((yh >>> 29) | (yl << 3)) ^ ((yl >>> 6) | (yh << 26));
        lo = (W[2 * k - 31] >>> 0) + (s0l >>> 0) + (W[2 * k - 13] >>> 0) + (s1l >>> 0);
        W[2 * k + 1] = lo | 0;
        W[2 * k] = (W[2 * k - 32] + s0h + W[2 * k - 14] + s1h + Math.floor(lo / 4294967296)) | 0;
      }
      var ah = h[0], al = h[1], bh = h[2], bl = h[3], ch = h[4], cl = h[5], dh = h[6], dl = h[7];
      var eh = h[8], el = h[9], fh = h[10], fl = h[11], gh = h[12], gl = h[13], hh = h[14], hl = h[15];
      var S1h, S1l, chh, chl, t1h, t1l, S0h, S0l, mjh, mjl, t2h, t2l, l1, l2;
      for (k = 0; k < 80; k++) {
        S1h = ((eh >>> 14) | (el << 18)) ^ ((eh >>> 18) | (el << 14)) ^ ((el >>> 9) | (eh << 23));
        S1l = ((el >>> 14) | (eh << 18)) ^ ((el >>> 18) | (eh << 14)) ^ ((eh >>> 9) | (el << 23));
        chh = (eh & fh) ^ (~eh & gh); chl = (el & fl) ^ (~el & gl);
        l1 = (hl >>> 0) + (S1l >>> 0) + (chl >>> 0) + (K[2 * k + 1] >>> 0) + (W[2 * k + 1] >>> 0);
        t1l = l1 | 0;
        t1h = (hh + S1h + chh + K[2 * k] + W[2 * k] + Math.floor(l1 / 4294967296)) | 0;
        S0h = ((ah >>> 28) | (al << 4)) ^ ((al >>> 2) | (ah << 30)) ^ ((al >>> 7) | (ah << 25));
        S0l = ((al >>> 28) | (ah << 4)) ^ ((ah >>> 2) | (al << 30)) ^ ((ah >>> 7) | (al << 25));
        mjh = (ah & bh) ^ (ah & ch) ^ (bh & ch); mjl = (al & bl) ^ (al & cl) ^ (bl & cl);
        l2 = (S0l >>> 0) + (mjl >>> 0);
        t2l = l2 | 0;
        t2h = (S0h + mjh + Math.floor(l2 / 4294967296)) | 0;
        hh = gh; hl = gl; gh = fh; gl = fl; fh = eh; fl = el;
        l1 = (dl >>> 0) + (t1l >>> 0);
        el = l1 | 0; eh = (dh + t1h + Math.floor(l1 / 4294967296)) | 0;
        dh = ch; dl = cl; ch = bh; cl = bl; bh = ah; bl = al;
        l1 = (t1l >>> 0) + (t2l >>> 0);
        al = l1 | 0; ah = (t1h + t2h + Math.floor(l1 / 4294967296)) | 0;
      }
      var v = [ah, al, bh, bl, ch, cl, dh, dl, eh, el, fh, fl, gh, gl, hh, hl];
      for (k = 0; k < 8; k++) {
        lo = (h[2 * k + 1] >>> 0) + (v[2 * k + 1] >>> 0);
        h[2 * k + 1] = lo | 0;
        h[2 * k] = (h[2 * k] + v[2 * k] + Math.floor(lo / 4294967296)) | 0;
      }
    }

    function words(h, count, le) {
      var o = new Uint8Array(count * 4);
      for (var k = 0; k < count; k++) (le ? putLe32 : putBe32)(o, 4 * k, h[k]);
      return o;
    }
    var SPECS = {
      md5: { block: 64, lenBytes: 8, le: true, size: 16, init: function () { return new Int32Array([0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476]); }, compress: md5Block, out: function (h) { return words(h, 4, true); } },
      sha1: { block: 64, lenBytes: 8, le: false, size: 20, init: function () { return new Int32Array([0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0]); }, compress: sha1Block, out: function (h) { return words(h, 5, false); } },
      sha224: { block: 64, lenBytes: 8, le: false, size: 28, init: function () { return new Int32Array(H224); }, compress: sha256Block, out: function (h) { return words(h, 7, false); } },
      sha256: { block: 64, lenBytes: 8, le: false, size: 32, init: function () { return new Int32Array(H256); }, compress: sha256Block, out: function (h) { return words(h, 8, false); } },
      sha384: { block: 128, lenBytes: 16, le: false, size: 48, init: function () { return new Int32Array(sha512Constants().H384); }, compress: sha512Block, out: function (h) { return words(h, 12, false); } },
      sha512: { block: 128, lenBytes: 16, le: false, size: 64, init: function () { return new Int32Array(sha512Constants().H512); }, compress: sha512Block, out: function (h) { return words(h, 16, false); } }
    };
    function specOf(alg) {
      var a = String(alg).toLowerCase().replace(/^rsa-/, '');
      var m = /^sha(?:2-|-)?(\d+)$/.exec(a); // sha256, sha-256, sha2-256
      if (m) a = 'sha' + m[1];
      return Object.prototype.hasOwnProperty.call(SPECS, a) ? SPECS[a] : null;
    }

    // ---------------------------------------------------------------- streaming hasher, HMAC
    function Hasher(spec) { this.s = spec; this.h = spec.init(); this.buf = new Uint8Array(spec.block); this.n = 0; this.len = 0; }
    Hasher.prototype.update = function (u8) {
      var s = this.s, bs = s.block, k = 0, len = u8.length;
      this.len += len;
      if (this.n) {
        var take = Math.min(bs - this.n, len);
        this.buf.set(u8.subarray(0, take), this.n);
        this.n += take; k = take;
        if (this.n < bs) return;
        s.compress(this.h, this.buf, 0); this.n = 0;
      }
      for (; k + bs <= len; k += bs) s.compress(this.h, u8, k);
      if (k < len) { this.buf.set(u8.subarray(k), 0); this.n = len - k; }
    };
    Hasher.prototype.digest = function () {
      var s = this.s, bs = s.block, lb = s.lenBytes, total = this.len;
      var zeros = (bs - ((this.n + 1 + lb) % bs)) % bs, tail = new Uint8Array(1 + zeros + lb);
      tail[0] = 0x80;
      var hi = Math.floor(total / 536870912), lo = ((total % 536870912) * 8) >>> 0; // bit length = hi * 2^32 + lo
      var o = tail.length - 8;
      if (s.le) { putLe32(tail, o, lo); putLe32(tail, o + 4, hi); } else { putBe32(tail, o, hi); putBe32(tail, o + 4, lo); }
      this.update(tail);
      return s.out(this.h);
    };
    Hasher.prototype.clone = function () {
      var c = new Hasher(this.s);
      c.h = new Int32Array(this.h); c.buf.set(this.buf); c.n = this.n; c.len = this.len;
      return c;
    };
    function Hmac(spec, key) {
      var bs = spec.block, k = key, ipad = new Uint8Array(bs), opad = new Uint8Array(bs), x;
      if (k.length > bs) { var kh = new Hasher(spec); kh.update(k); k = kh.digest(); }
      for (x = 0; x < bs; x++) { var kb = x < k.length ? k[x] : 0; ipad[x] = kb ^ 0x36; opad[x] = kb ^ 0x5c; }
      this.spec = spec; this.inner = new Hasher(spec); this.inner.update(ipad); this.opad = opad;
    }
    Hmac.prototype.update = function (u8) { this.inner.update(u8); };
    Hmac.prototype.digest = function () {
      var d = this.inner.digest(), o = new Hasher(this.spec);
      o.update(this.opad); o.update(d);
      return o.digest();
    };
    Hmac.prototype.clone = function () {
      var c = Object.create(Hmac.prototype);
      c.spec = this.spec; c.inner = this.inner.clone(); c.opad = this.opad;
      return c;
    };

    function finalized() { return codedError(Error, 'ERR_CRYPTO_HASH_FINALIZED', 'Digest already called'); }
    var DATA_TYPES = 'of type string or an instance of Buffer, TypedArray, or DataView';
    // like in Node a Hash / Hmac is also a Transform stream: input.pipe(hash), hash.write() / end(), hash.read() gives the digest
    function Hash(h) { Transform.call(this); this._h = h; this._done = false; }
    util.inherits(Hash, Transform);
    Hash.prototype._transform = function (chunk, enc, cb) { try { this.update(chunk); } catch (e) { cb(e); return; } cb(); };
    Hash.prototype._flush = function (cb) { var d; try { d = this.digest(); } catch (e) { cb(e); return; } this.push(d); cb(); };
    Hash.prototype.update = function (data, enc) {
      if (this._done) throw finalized();
      this._h.update(bytesArg(data, enc, 'data', DATA_TYPES));
      return this;
    };
    Hash.prototype.digest = function (enc) {
      if (this._done) throw finalized();
      this._done = true;
      return outBuf(this._h.digest(), enc);
    };
    Hash.prototype.copy = function () {
      if (this._done) throw finalized();
      return new Hash(this._h.clone());
    };

    // ---------------------------------------------------------------- public API
    cryptoMod.createHash = function (alg) {
      var s = specOf(alg);
      if (!s) throw new Error('Digest method not supported');
      return new Hash(new Hasher(s));
    };
    cryptoMod.createHmac = function (alg, key) {
      var s = specOf(alg);
      if (!s) throw codedError(TypeError, 'ERR_CRYPTO_INVALID_DIGEST', 'Invalid digest: ' + alg);
      return new Hash(new Hmac(s, bytesArg(key, 'utf8', 'key', 'of type string or an instance of ArrayBuffer, Buffer, TypedArray, DataView, KeyObject, or CryptoKey')));
    };
    cryptoMod.getHashes = function () { return ['md5', 'sha1', 'sha224', 'sha256', 'sha384', 'sha512']; };
    cryptoMod.getCurves = function () { return []; };
    cryptoMod.pbkdf2Sync = function (password, salt, iterations, keylen, digest) {
      var pw = bytesArg(password, 'utf8', 'password', 'of type string or an instance of ArrayBuffer, Buffer, TypedArray, or DataView');
      var sl = bytesArg(salt, 'utf8', 'salt', 'of type string or an instance of ArrayBuffer, Buffer, TypedArray, or DataView');
      if (typeof iterations !== 'number') throw argError('iterations', 'of type number', iterations);
      if (typeof keylen !== 'number') throw argError('keylen', 'of type number', keylen);
      if (!(iterations >= 1) || Math.floor(iterations) !== iterations) throw codedError(RangeError, 'ERR_OUT_OF_RANGE', 'The value of "iterations" is out of range. It must be >= 1 && <= 2147483647. Received ' + iterations);
      if (!(keylen >= 0) || Math.floor(keylen) !== keylen) throw codedError(RangeError, 'ERR_OUT_OF_RANGE', 'The value of "keylen" is out of range. It must be >= 0 && <= 2147483647. Received ' + keylen);
      if (typeof digest !== 'string') throw argError('digest', 'of type string', digest);
      var s = specOf(digest);
      if (!s) throw codedError(TypeError, 'ERR_CRYPTO_INVALID_DIGEST', 'Invalid digest: ' + digest);
      var base = new Hmac(s, pw), out = new Uint8Array(keylen), blocks = Math.ceil(keylen / s.size), b, k, h, u, t, cnt = new Uint8Array(4);
      for (b = 1; b <= blocks; b++) {
        putBe32(cnt, 0, b);
        h = base.clone(); h.update(sl); h.update(cnt);
        u = h.digest(); t = new Uint8Array(u);
        for (j = 1; j < iterations; j++) {
          h = base.clone(); h.update(u); u = h.digest();
          for (k = 0; k < t.length; k++) t[k] ^= u[k];
        }
        out.set(t.subarray(0, Math.min(s.size, keylen - (b - 1) * s.size)), (b - 1) * s.size);
      }
      return outBuf(out);
    };
    cryptoMod.pbkdf2 = function (password, salt, iterations, keylen, digest, cb) {
      if (typeof cb !== 'function') throw argError('callback', 'of type function', cb);
      var res, err = null;
      try { res = cryptoMod.pbkdf2Sync(password, salt, iterations, keylen, digest); } catch (e) { err = e; }
      setTimeout(function () { if (err) cb(err); else cb(null, res); }, 0);
    };

    function fillRandom(u8) {
      var c = global.crypto;
      if (c && typeof c.getRandomValues === 'function') {
        for (var k = 0; k < u8.length; k += 65536) c.getRandomValues(u8.subarray(k, Math.min(u8.length, k + 65536))); // 64 KiB per call at most
      } else {
        for (var m = 0; m < u8.length; m++) u8[m] = Math.floor(Math.random() * 256);
      }
      return u8;
    }
    cryptoMod.randomBytes = function (n, cb) {
      if (typeof n !== 'number') throw argError('size', 'of type number', n);
      if (!(n >= 0 && n <= 2147483647) || Math.floor(n) !== n) throw codedError(RangeError, 'ERR_OUT_OF_RANGE', 'The value of "size" is out of range. It must be >= 0 && <= 2147483647. Received ' + n);
      var b = new Buffer(n);
      fillRandom(b);
      if (typeof cb === 'function') { setTimeout(function () { cb(null, b); }, 0); return undefined; }
      return b;
    };
    cryptoMod.randomFillSync = function (buf, offset, size) {
      var u = bytesArg(buf, undefined, 'buf', 'an instance of ArrayBuffer, Buffer, TypedArray, or DataView');
      offset = offset === undefined ? 0 : offset;
      size = size === undefined ? u.length - offset : size;
      if (!(offset >= 0 && offset <= u.length)) throw codedError(RangeError, 'ERR_OUT_OF_RANGE', 'The value of "offset" is out of range. It must be >= 0 && <= ' + u.length + '. Received ' + offset);
      if (!(size >= 0 && size <= u.length - offset)) throw codedError(RangeError, 'ERR_OUT_OF_RANGE', 'The value of "size" is out of range. It must be >= 0 && <= ' + (u.length - offset) + '. Received ' + size);
      fillRandom(u.subarray(offset, offset + size));
      return buf;
    };
    cryptoMod.randomFill = function (buf, offset, size, cb) {
      if (typeof offset === 'function') { cb = offset; offset = undefined; size = undefined; }
      else if (typeof size === 'function') { cb = size; size = undefined; }
      if (typeof cb !== 'function') throw argError('callback', 'of type function', cb);
      var err = null;
      try { cryptoMod.randomFillSync(buf, offset, size); } catch (e) { err = e; }
      setTimeout(function () { if (err) cb(err); else cb(null, buf); }, 0);
    };
    cryptoMod.randomInt = function (min, max, cb) {
      if (cb === undefined && typeof max === 'function') { cb = max; max = undefined; }
      if (max === undefined) { max = min; min = 0; }
      if (!Number.isSafeInteger(min)) throw argError('min', 'a safe integer', min);
      if (!Number.isSafeInteger(max)) throw argError('max', 'a safe integer', max);
      if (max <= min) throw codedError(RangeError, 'ERR_OUT_OF_RANGE', 'The value of "max" is out of range. It must be greater than the value of "min" (' + min + '). Received ' + max);
      var range = max - min;
      if (range > 281474976710655) throw codedError(RangeError, 'ERR_OUT_OF_RANGE', 'The value of "max - min" is out of range. It must be <= 281474976710655. Received ' + range);
      var limit = Math.floor(281474976710656 / range) * range, r, b;
      do { // rejection sampling over 48 random bits: every value in [min, max) is equally likely
        b = fillRandom(new Uint8Array(6));
        r = ((((b[0] * 256 + b[1]) * 256 + b[2]) * 256 + b[3]) * 256 + b[4]) * 256 + b[5];
      } while (r >= limit);
      var v = min + (r % range);
      if (typeof cb === 'function') { setTimeout(function () { cb(null, v); }, 0); return undefined; }
      return v;
    };
    cryptoMod.timingSafeEqual = function (a, b) {
      var x = bytesArg(a, undefined, 'buf1', 'an instance of ArrayBuffer, Buffer, TypedArray, or DataView'), y = bytesArg(b, undefined, 'buf2', 'an instance of ArrayBuffer, Buffer, TypedArray, or DataView');
      if (typeof a === 'string') throw argError('buf1', 'an instance of ArrayBuffer, Buffer, TypedArray, or DataView', a);
      if (typeof b === 'string') throw argError('buf2', 'an instance of ArrayBuffer, Buffer, TypedArray, or DataView', b);
      if (x.length !== y.length) throw codedError(RangeError, 'ERR_CRYPTO_TIMING_SAFE_EQUAL_LENGTH', 'Input buffers must have the same byte length');
      var d = 0;
      for (var k = 0; k < x.length; k++) d |= x[k] ^ y[k];
      return d === 0;
    };
    cryptoMod.getRandomValues = function (arr) { return global.crypto.getRandomValues(arr); };
    cryptoMod.webcrypto = global.crypto;
    cryptoMod.subtle = global.crypto && global.crypto.subtle;
    cryptoMod.constants = cryptoMod.constants || {};

    ['createSign', 'createVerify', 'createECDH', 'createDiffieHellman',
      'createDiffieHellmanGroup', 'scrypt', 'scryptSync', 'generateKeyPair', 'generateKeyPairSync', 'generateKey', 'generateKeySync',
      'publicEncrypt', 'privateDecrypt', 'privateEncrypt', 'publicDecrypt', 'sign', 'verify', 'hkdf', 'hkdfSync', 'createPrivateKey',
      'createPublicKey', 'createSecretKey', 'generatePrime', 'generatePrimeSync', 'checkPrime', 'checkPrimeSync'].forEach(function (name) {
      cryptoMod[name] = function () {
        RR.warnOnce('crypto:' + name, 'crypto.' + name + ' is not available in RPG Runner (only hashes, HMAC, PBKDF2, random numbers and AES ciphers are)');
        throw new Error('crypto.' + name + ' is not available in RPG Runner');
      };
    });
  })();
