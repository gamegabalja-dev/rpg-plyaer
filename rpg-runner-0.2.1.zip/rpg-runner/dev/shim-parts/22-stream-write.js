  // ------------------------------------------------------------------ stream: Writable, Duplex, Transform, PassThrough, pipeline, finished
  function Writable(opts) {
    if (!(this instanceof Writable) && !(this instanceof Duplex)) return new Writable(opts);
    Stream.call(this);
    opts = opts || {};
    var om = !!(opts.objectMode || opts.writableObjectMode), hwm = opts.writableHighWaterMark;
    if (hwm === undefined) hwm = opts.highWaterMark;
    if (hwm === undefined) hwm = om ? 16 : 16384;
    this._w = { om: om, hwm: hwm, queue: [], len: 0, writing: false, draining: false, ending: false, finished: false, needDrain: false,
      corked: 0, decode: opts.decodeStrings !== false, defEnc: opts.defaultEncoding || 'utf8', pending: 0, finalCalled: false,
      onFinished: [], autoDestroy: opts.autoDestroy !== false };
    this._emitClose = opts.emitClose !== false;
    this.writable = true;
    if (typeof opts.write === 'function') this._write = opts.write;
    if (typeof opts.final === 'function') this._final = opts.final;
    if (typeof opts.destroy === 'function') this._destroy = opts.destroy;
  }
  util.inherits(Writable, Stream);
  if (typeof Symbol === 'function' && Symbol.hasInstance) { // a Duplex counts as a Writable, like in Node
    Object.defineProperty(Writable, Symbol.hasInstance, { value: function (o) {
      if (Function.prototype[Symbol.hasInstance].call(this, o)) return true;
      return this === Writable && !!(o && o._w);
    } });
  }
  Writable.prototype._write = function (chunk, enc, cb) { cb(sErr(Error, 'ERR_METHOD_NOT_IMPLEMENTED', 'The _write() method is not implemented')); };
  Writable.prototype.destroy = destroyImpl;
  Writable.prototype._destroy = function (err, cb) { cb(err); };

  function failQueued(s) {
    var w = s._w, q = w.queue, i, err = sErr(Error, 'ERR_STREAM_DESTROYED', 'Cannot call write after a stream was destroyed');
    var ends = w.onFinished.splice(0);
    w.queue = [];
    for (i = 0; i < q.length; i++) { w.pending--; w.len -= q[i].size; if (q[i].cb) streamTick(q[i].cb, err); }
    for (i = 0; i < ends.length; i++) streamTick(ends[i], s.errored || null); // end(cb) callbacks of a stream that never finished
  }
  function doWrite(s, item) {
    var w = s._w, done = false, sync = true;
    w.writing = true;
    function onwrite(er) {
      if (done) return;
      done = true;
      w.writing = false; w.len -= item.size;
      if (er) {
        w.pending--;
        if (item.cb) streamTick(item.cb, er);
        errorOrDestroy(s, er);
        return;
      }
      clearQueue(s);
      if (sync) streamTick(afterWrite, s, item.cb); else afterWrite(s, item.cb);
    }
    try { s._write(item.chunk, item.enc, onwrite); } catch (e) { onwrite(e); }
    sync = false;
  }
  function clearQueue(s) { // not recursive: a write that completes synchronously just lets the running loop continue
    var w = s._w;
    if (w.draining) return;
    w.draining = true;
    while (w.queue.length && !w.writing && !w.corked && !s.destroyed) doWrite(s, w.queue.shift());
    w.draining = false;
  }
  function afterWrite(s, cb) {
    var w = s._w;
    if (!w.ending && !s.destroyed && w.len === 0 && w.needDrain) { w.needDrain = false; s.emit('drain'); }
    w.pending--;
    if (cb) cb();
    finishMaybe(s);
  }
  function finishMaybe(s) {
    var w = s._w, called = false;
    if (!w.ending || w.finished || w.finalCalled || w.len > 0 || w.queue.length || w.writing || s.destroyed) return;
    w.finalCalled = true;
    function fin() {
      streamTick(function () {
        if (s.destroyed) return;
        var ends = w.onFinished.splice(0), i;
        w.finished = true;
        for (i = 0; i < ends.length; i++) ends[i](); // end(cb) callbacks run before the 'finish' listeners, like in Node
        s.emit('finish');
        if (w.autoDestroy && !s.destroyed && (!s._r || s._r.endEmitted)) s.destroy();
      });
    }
    if (typeof s._final !== 'function') { s.emit('prefinish'); fin(); return; }
    try {
      s._final(function (er) {
        if (called) return;
        called = true;
        if (er) errorOrDestroy(s, er); else { s.emit('prefinish'); fin(); }
      });
    } catch (e) { errorOrDestroy(s, e); }
  }

  Writable.prototype.write = function (chunk, enc, cb) {
    var w = this._w, err, size, ret;
    if (typeof enc === 'function') { cb = enc; enc = null; }
    if (chunk === null) throw sErr(TypeError, 'ERR_STREAM_NULL_VALUES', 'May not write null values to stream');
    if (!w.om) {
      if (typeof chunk === 'string') {
        if (w.decode) { chunk = toBuf(strToBytes(chunk, enc || w.defEnc)); enc = 'buffer'; } else enc = enc || w.defEnc;
      } else if (chunk instanceof Uint8Array) {
        chunk = toBuf(chunk); enc = 'buffer';
      } else {
        throw sErr(TypeError, 'ERR_INVALID_ARG_TYPE', 'The "chunk" argument must be of type string or an instance of Buffer or Uint8Array. Received ' + describeVal(chunk));
      }
    }
    if (w.ending) err = sErr(Error, 'ERR_STREAM_WRITE_AFTER_END', 'write after end');
    else if (this.destroyed) err = sErr(Error, 'ERR_STREAM_DESTROYED', 'Cannot call write after a stream was destroyed');
    if (err) {
      if (typeof cb === 'function') streamTick(cb, err);
      errorOrDestroy(this, err);
      return false;
    }
    w.pending++;
    size = w.om ? 1 : chunk.length;
    w.len += size;
    ret = w.len < w.hwm;
    if (!ret) w.needDrain = true;
    if (w.writing || w.corked) w.queue.push({ chunk: chunk, enc: enc, cb: cb, size: size });
    else doWrite(this, { chunk: chunk, enc: enc, cb: cb, size: size });
    return ret;
  };
  Writable.prototype.end = function (chunk, enc, cb) {
    var w = this._w, err;
    if (typeof chunk === 'function') { cb = chunk; chunk = null; enc = null; } else if (typeof enc === 'function') { cb = enc; enc = null; }
    if (chunk !== null && chunk !== undefined) this.write(chunk, enc);
    if (w.corked) { w.corked = 1; this.uncork(); }
    if (!w.ending && !this.destroyed) { w.ending = true; finishMaybe(this); }
    else if (w.finished) err = sErr(Error, 'ERR_STREAM_ALREADY_FINISHED', 'Cannot call end after a stream was finished');
    else if (this.destroyed) err = sErr(Error, 'ERR_STREAM_DESTROYED', 'Cannot call end after a stream was destroyed');
    if (typeof cb === 'function') {
      if (err || w.finished) streamTick(cb, err); else w.onFinished.push(cb);
    }
    return this;
  };
  Writable.prototype.cork = function () { this._w.corked++; };
  Writable.prototype.uncork = function () {
    var w = this._w;
    if (w.corked) { w.corked--; if (!w.writing && !w.corked) clearQueue(this); }
  };
  Writable.prototype.setDefaultEncoding = function (enc) {
    enc = normEnc(enc);
    if (!Buffer.isEncoding(enc)) throw sErr(TypeError, 'ERR_UNKNOWN_ENCODING', 'Unknown encoding: ' + enc);
    this._w.defEnc = enc;
    return this;
  };
  Object.defineProperties(Writable.prototype, {
    writableLength: { get: function () { return this._w.len; } },
    writableHighWaterMark: { get: function () { return this._w.hwm; } },
    writableEnded: { get: function () { return this._w.ending; } },
    writableFinished: { get: function () { return this._w.finished; } },
    writableObjectMode: { get: function () { return this._w.om; } },
    writableCorked: { get: function () { return this._w.corked; } },
    writableNeedDrain: { get: function () { var w = this._w; return !this.destroyed && !w.ending && w.needDrain; } }
  });

  function Duplex(opts) {
    if (!(this instanceof Duplex)) return new Duplex(opts);
    Readable.call(this, opts);
    Writable.call(this, opts);
    this.allowHalfOpen = !(opts && opts.allowHalfOpen === false);
    if (!this.allowHalfOpen) this.once('end', function () { this.end(); });
  }
  util.inherits(Duplex, Readable);
  Object.getOwnPropertyNames(Writable.prototype).forEach(function (k) {
    if (k !== 'constructor' && !(k in Duplex.prototype)) Object.defineProperty(Duplex.prototype, k, Object.getOwnPropertyDescriptor(Writable.prototype, k));
  });

  function Transform(opts) {
    if (!(this instanceof Transform)) return new Transform(opts);
    Duplex.call(this, opts);
    this._r.sync = false; // _read() is a no-op, so nothing has to wait for a first _read() call (same as Node)
    if (opts && typeof opts.transform === 'function') this._transform = opts.transform;
    if (opts && typeof opts.flush === 'function') this._flush = opts.flush;
  }
  util.inherits(Transform, Duplex);
  Transform.prototype._transform = function () { throw sErr(Error, 'ERR_METHOD_NOT_IMPLEMENTED', 'The _transform() method is not implemented'); };
  Transform.prototype._read = function () {}; // push-driven: nothing to ask for
  Transform.prototype._write = function (chunk, enc, cb) {
    var self = this;
    this._transform(chunk, enc, function (err, data) {
      if (err) { cb(err); return; }
      if (data !== undefined && data !== null) self.push(data);
      cb();
    });
  };
  Transform.prototype._final = function (cb) {
    var self = this;
    function done(err, data) {
      if (err) { cb(err); return; }
      if (data !== undefined && data !== null) self.push(data);
      self.push(null);
      cb();
    }
    if (typeof this._flush === 'function') this._flush(done); else done();
  };
  function PassThrough(opts) {
    if (!(this instanceof PassThrough)) return new PassThrough(opts);
    Transform.call(this, opts);
  }
  util.inherits(PassThrough, Transform);
  PassThrough.prototype._transform = function (chunk, enc, cb) { cb(null, chunk); };

  // finished(): calls back once the stream has ended and / or finished, failed or closed early
  function noop() {}
  function finished(stream, opts, cb) {
    if (typeof opts === 'function') { cb = opts; opts = {}; }
    opts = opts || {};
    var wantR = opts.readable !== undefined ? !!opts.readable : (stream.readable === true || !!stream._r);
    var wantW = opts.writable !== undefined ? !!opts.writable : (stream.writable === true || !!stream._w);
    var rDone = !wantR || (stream._r ? stream._r.endEmitted : false);
    var wDone = !wantW || (stream._w ? stream._w.finished : false);
    var called = false;
    function cleanup() {
      stream.removeListener('end', onend); stream.removeListener('finish', onfinish);
      stream.removeListener('error', onerror); stream.removeListener('close', onclose);
    }
    function call(err) { if (called) return; called = true; cleanup(); cb.call(stream, err); }
    function onend() { rDone = true; if (wDone) call(); }
    function onfinish() { wDone = true; if (rDone) call(); }
    function onerror(e) { call(e); }
    function onclose() { call(!rDone || !wDone ? sErr(Error, 'ERR_STREAM_PREMATURE_CLOSE', 'Premature close') : undefined); }
    stream.on('end', onend); stream.on('finish', onfinish); stream.on('error', onerror); stream.on('close', onclose);
    if (rDone && wDone) streamTick(call);
    return cleanup;
  }
  function pipeline() {
    var args = Array.prototype.slice.call(arguments), cb = typeof args[args.length - 1] === 'function' ? args.pop() : null;
    var streams = args.length === 1 && Array.isArray(args[0]) ? args[0] : args, cleanups = [], over = false, i;
    if (streams.length < 2) throw sErr(TypeError, 'ERR_MISSING_ARGS', 'The "streams" argument must be specified');
    function done(err) {
      if (over) return;
      over = true;
      cleanups.forEach(function (c) { c(); });
      streams.forEach(function (s) { s.on('error', noop); if (err && typeof s.destroy === 'function') s.destroy(); });
      if (cb) cb(err);
    }
    streams.forEach(function (s, idx) {
      cleanups.push(finished(s, { readable: idx < streams.length - 1, writable: idx > 0 }, function (err) {
        if (err) done(err); else if (idx === streams.length - 1) done();
      }));
    });
    for (i = 0; i < streams.length - 1; i++) streams[i].pipe(streams[i + 1]);
    return streams[streams.length - 1];
  }
  Stream.Stream = Stream; Stream.Readable = Readable; Stream.Writable = Writable; Stream.Duplex = Duplex;
  Stream.Transform = Transform; Stream.PassThrough = PassThrough; Stream.pipeline = pipeline; Stream.finished = finished;
  Stream.promises = {
    pipeline: function () {
      var args = Array.prototype.slice.call(arguments);
      return new Promise(function (res, rej) { args.push(function (e) { if (e) rej(e); else res(); }); pipeline.apply(null, args); });
    },
    finished: function (stream, opts) {
      return new Promise(function (res, rej) { finished(stream, opts || {}, function (e) { if (e) rej(e); else res(); }); });
    }
  };
  var streamMod = Stream;
