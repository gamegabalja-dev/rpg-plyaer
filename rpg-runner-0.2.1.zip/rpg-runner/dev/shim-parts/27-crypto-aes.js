  // ------------------------------------------------------------------ crypto: AES ciphers (cbc, ecb, ctr)
  // createCipheriv / createDecipheriv (and the legacy password based createCipher / createDecipher) for aes-128/192/256 in the
  // modes cbc, ecb and ctr, written in JS because Node's OpenSSL is not available. Block handling, padding rules, error
  // messages and the update()/final() state machine follow OpenSSL 3 as Node 22 reports it. Other ciphers (gcm, cfb, des ...)
  // log what the game asked for and throw.
  (function () {
    var SBOX = new Uint8Array(256), ISBOX = new Uint8Array(256);
    var TE0 = new Int32Array(256), TE1 = new Int32Array(256), TE2 = new Int32Array(256), TE3 = new Int32Array(256);
    var TD0 = new Int32Array(256), TD1 = new Int32Array(256), TD2 = new Int32Array(256), TD3 = new Int32Array(256);
    var tablesReady = false;

    function precompute() {
      var d = [], th = [], i, k, x, x2 = 0, x4, x8, xInv, s, tEnc, tDec, te = [TE0, TE1, TE2, TE3], td = [TD0, TD1, TD2, TD3];
      for (i = 0; i < 256; i++) th[(d[i] = (i << 1) ^ ((i >> 7) * 283)) ^ i] = i;
      for (i = 0, x = 0, xInv = 0; i < 256; i++, x ^= x2 || 1, xInv = th[xInv] || 1) {
        s = xInv ^ (xInv << 1) ^ (xInv << 2) ^ (xInv << 3) ^ (xInv << 4);
        s = (s >> 8) ^ (s & 255) ^ 99;
        SBOX[x] = s; ISBOX[s] = x;
        x8 = d[x4 = d[x2 = d[x]]];
        tDec = x8 * 0x1010101 ^ x4 * 0x10001 ^ x2 * 0x101 ^ x * 0x1010100;
        tEnc = d[s] * 0x101 ^ s * 0x1010100;
        for (k = 0; k < 4; k++) {
          te[k][x] = tEnc = (tEnc << 24) ^ (tEnc >>> 8);
          td[k][s] = tDec = (tDec << 24) ^ (tDec >>> 8);
        }
      }
      tablesReady = true;
    }

    // key: 16 / 24 / 32 bytes -> round keys for encryption and for the equivalent inverse cipher
    function expandKey(key) {
      if (!tablesReady) precompute();
      var kl = key.length >> 2, total = 4 * kl + 28, ek = new Int32Array(total), dk = new Int32Array(total), i, j, tmp, rcon = 1;
      for (i = 0; i < kl; i++) ek[i] = (key[4 * i] << 24) | (key[4 * i + 1] << 16) | (key[4 * i + 2] << 8) | key[4 * i + 3];
      for (i = kl; i < total; i++) {
        tmp = ek[i - 1];
        if (i % kl === 0 || (kl === 8 && i % kl === 4)) {
          tmp = (SBOX[tmp >>> 24] << 24) ^ (SBOX[(tmp >> 16) & 255] << 16) ^ (SBOX[(tmp >> 8) & 255] << 8) ^ SBOX[tmp & 255];
          if (i % kl === 0) { tmp = (tmp << 8) ^ (tmp >>> 24) ^ (rcon << 24); rcon = (rcon << 1) ^ ((rcon >> 7) * 283); }
        }
        ek[i] = ek[i - kl] ^ tmp;
      }
      for (j = 0, i = total; i; j++, i--) {
        tmp = ek[j & 3 ? i : i - 4];
        dk[j] = (i <= 4 || j < 4) ? tmp : TD0[SBOX[tmp >>> 24]] ^ TD1[SBOX[(tmp >> 16) & 255]] ^ TD2[SBOX[(tmp >> 8) & 255]] ^ TD3[SBOX[tmp & 255]];
      }
      return { enc: ek, dec: dk };
    }

    // one 16-byte block, src[so..so+16) -> dst[doff..doff+16); src and dst may be the same array
    function encBlock(rk, src, so, dst, doff) {
      var a = ((src[so] << 24) | (src[so + 1] << 16) | (src[so + 2] << 8) | src[so + 3]) ^ rk[0],
        b = ((src[so + 4] << 24) | (src[so + 5] << 16) | (src[so + 6] << 8) | src[so + 7]) ^ rk[1],
        c = ((src[so + 8] << 24) | (src[so + 9] << 16) | (src[so + 10] << 8) | src[so + 11]) ^ rk[2],
        d = ((src[so + 12] << 24) | (src[so + 13] << 16) | (src[so + 14] << 8) | src[so + 15]) ^ rk[3],
        a2, b2, c2, k = 4, n = (rk.length >> 2) - 2, i, o0, o1, o2, o3;
      for (i = 0; i < n; i++) {
        a2 = TE0[a >>> 24] ^ TE1[(b >> 16) & 255] ^ TE2[(c >> 8) & 255] ^ TE3[d & 255] ^ rk[k];
        b2 = TE0[b >>> 24] ^ TE1[(c >> 16) & 255] ^ TE2[(d >> 8) & 255] ^ TE3[a & 255] ^ rk[k + 1];
        c2 = TE0[c >>> 24] ^ TE1[(d >> 16) & 255] ^ TE2[(a >> 8) & 255] ^ TE3[b & 255] ^ rk[k + 2];
        d = TE0[d >>> 24] ^ TE1[(a >> 16) & 255] ^ TE2[(b >> 8) & 255] ^ TE3[c & 255] ^ rk[k + 3];
        k += 4; a = a2; b = b2; c = c2;
      }
      o0 = ((SBOX[a >>> 24] << 24) ^ (SBOX[(b >> 16) & 255] << 16) ^ (SBOX[(c >> 8) & 255] << 8) ^ SBOX[d & 255]) ^ rk[k];
      o1 = ((SBOX[b >>> 24] << 24) ^ (SBOX[(c >> 16) & 255] << 16) ^ (SBOX[(d >> 8) & 255] << 8) ^ SBOX[a & 255]) ^ rk[k + 1];
      o2 = ((SBOX[c >>> 24] << 24) ^ (SBOX[(d >> 16) & 255] << 16) ^ (SBOX[(a >> 8) & 255] << 8) ^ SBOX[b & 255]) ^ rk[k + 2];
      o3 = ((SBOX[d >>> 24] << 24) ^ (SBOX[(a >> 16) & 255] << 16) ^ (SBOX[(b >> 8) & 255] << 8) ^ SBOX[c & 255]) ^ rk[k + 3];
      dst[doff] = o0 >>> 24; dst[doff + 1] = o0 >>> 16; dst[doff + 2] = o0 >>> 8; dst[doff + 3] = o0;
      dst[doff + 4] = o1 >>> 24; dst[doff + 5] = o1 >>> 16; dst[doff + 6] = o1 >>> 8; dst[doff + 7] = o1;
      dst[doff + 8] = o2 >>> 24; dst[doff + 9] = o2 >>> 16; dst[doff + 10] = o2 >>> 8; dst[doff + 11] = o2;
      dst[doff + 12] = o3 >>> 24; dst[doff + 13] = o3 >>> 16; dst[doff + 14] = o3 >>> 8; dst[doff + 15] = o3;
    }
    function decBlock(rk, src, so, dst, doff) {
      var a = ((src[so] << 24) | (src[so + 1] << 16) | (src[so + 2] << 8) | src[so + 3]) ^ rk[0],
        b = ((src[so + 12] << 24) | (src[so + 13] << 16) | (src[so + 14] << 8) | src[so + 15]) ^ rk[1],
        c = ((src[so + 8] << 24) | (src[so + 9] << 16) | (src[so + 10] << 8) | src[so + 11]) ^ rk[2],
        d = ((src[so + 4] << 24) | (src[so + 5] << 16) | (src[so + 6] << 8) | src[so + 7]) ^ rk[3],
        a2, b2, c2, k = 4, n = (rk.length >> 2) - 2, i, o0, o1, o2, o3;
      for (i = 0; i < n; i++) {
        a2 = TD0[a >>> 24] ^ TD1[(b >> 16) & 255] ^ TD2[(c >> 8) & 255] ^ TD3[d & 255] ^ rk[k];
        b2 = TD0[b >>> 24] ^ TD1[(c >> 16) & 255] ^ TD2[(d >> 8) & 255] ^ TD3[a & 255] ^ rk[k + 1];
        c2 = TD0[c >>> 24] ^ TD1[(d >> 16) & 255] ^ TD2[(a >> 8) & 255] ^ TD3[b & 255] ^ rk[k + 2];
        d = TD0[d >>> 24] ^ TD1[(a >> 16) & 255] ^ TD2[(b >> 8) & 255] ^ TD3[c & 255] ^ rk[k + 3];
        k += 4; a = a2; b = b2; c = c2;
      }
      o0 = ((ISBOX[a >>> 24] << 24) ^ (ISBOX[(b >> 16) & 255] << 16) ^ (ISBOX[(c >> 8) & 255] << 8) ^ ISBOX[d & 255]) ^ rk[k];
      o3 = ((ISBOX[b >>> 24] << 24) ^ (ISBOX[(c >> 16) & 255] << 16) ^ (ISBOX[(d >> 8) & 255] << 8) ^ ISBOX[a & 255]) ^ rk[k + 1];
      o2 = ((ISBOX[c >>> 24] << 24) ^ (ISBOX[(d >> 16) & 255] << 16) ^ (ISBOX[(a >> 8) & 255] << 8) ^ ISBOX[b & 255]) ^ rk[k + 2];
      o1 = ((ISBOX[d >>> 24] << 24) ^ (ISBOX[(a >> 16) & 255] << 16) ^ (ISBOX[(b >> 8) & 255] << 8) ^ ISBOX[c & 255]) ^ rk[k + 3];
      dst[doff] = o0 >>> 24; dst[doff + 1] = o0 >>> 16; dst[doff + 2] = o0 >>> 8; dst[doff + 3] = o0;
      dst[doff + 4] = o1 >>> 24; dst[doff + 5] = o1 >>> 16; dst[doff + 6] = o1 >>> 8; dst[doff + 7] = o1;
      dst[doff + 8] = o2 >>> 24; dst[doff + 9] = o2 >>> 16; dst[doff + 10] = o2 >>> 8; dst[doff + 11] = o2;
      dst[doff + 12] = o3 >>> 24; dst[doff + 13] = o3 >>> 16; dst[doff + 14] = o3 >>> 8; dst[doff + 15] = o3;
    }

    // ---------------------------------------------------------------- errors (OpenSSL 3 wording, as Node 22 reports them)
    function codedError(Ctor, code, msg) { var e = new Ctor(msg); if (code) e.code = code; return e; }
    function ossl(reason, hex) {
      var e = new Error('error:' + hex + ':Provider routines::' + reason);
      e.library = 'Provider routines'; e.reason = reason;
      e.code = 'ERR_OSSL_' + reason.toUpperCase().replace(/ /g, '_');
      return e;
    }
    function describeArg(v) {
      if (v === null || v === undefined) return String(v);
      if (typeof v === 'function') return 'function ' + v.name;
      if (typeof v === 'object') return 'an instance of ' + ((v.constructor && v.constructor.name) || 'Object');
      var s = typeof v === 'string' ? "'" + (v.length > 28 ? v.slice(0, 25) + '...' : v) + "'" : String(v);
      return 'type ' + typeof v + ' (' + s + ')';
    }
    function argType(name, expected, v) {
      return codedError(TypeError, 'ERR_INVALID_ARG_TYPE', 'The "' + name + '" argument must be ' + expected + '. Received ' + describeArg(v));
    }
    function toU8(v, enc) {
      if (typeof v === 'string') { var e = normEnc(enc); try { return strToBytes(v, Buffer.isEncoding(e) ? e : 'utf8'); } catch (x) { return strToBytes(v, 'utf8'); } }
      if (v instanceof Uint8Array) return v;
      if (v instanceof ArrayBuffer) return new Uint8Array(v);
      if (ArrayBuffer.isView(v)) return new Uint8Array(v.buffer, v.byteOffset, v.byteLength);
      return null;
    }

    // ---------------------------------------------------------------- the cipher engine (one EVP context)
    function Engine(decrypt, mode, key, iv) {
      var ks = expandKey(key);
      this.dec = decrypt; this.mode = mode;
      this.rk = decrypt && mode !== 'ctr' ? ks.dec : ks.enc;
      this.iv = iv && iv.length ? new Uint8Array(iv) : null; // chaining value (cbc) or counter (ctr)
      this.pad = true;
      this.buf = new Uint8Array(16); this.bufLen = 0;        // pending input (cbc / ecb); a decrypting padded engine holds a whole block back
      this.ks = new Uint8Array(16); this.ksPos = 16;         // ctr key stream
      this.tmp = new Uint8Array(16);
    }
    // whole blocks, src[so .. so+n) -> dst[doff ..]
    Engine.prototype.blocks = function (src, so, n, dst, doff) {
      var rk = this.rk, iv = this.iv, tmp = this.tmp, j, end = so + n;
      if (this.mode === 'ecb') {
        for (; so < end; so += 16, doff += 16) { if (this.dec) decBlock(rk, src, so, dst, doff); else encBlock(rk, src, so, dst, doff); }
      } else if (this.dec) { // cbc decrypt
        for (; so < end; so += 16, doff += 16) {
          for (j = 0; j < 16; j++) tmp[j] = src[so + j];
          decBlock(rk, src, so, dst, doff);
          for (j = 0; j < 16; j++) { dst[doff + j] ^= iv[j]; iv[j] = tmp[j]; }
        }
      } else { // cbc encrypt
        for (; so < end; so += 16, doff += 16) {
          for (j = 0; j < 16; j++) tmp[j] = src[so + j] ^ iv[j];
          encBlock(rk, tmp, 0, dst, doff);
          for (j = 0; j < 16; j++) iv[j] = dst[doff + j];
        }
      }
    };
    Engine.prototype.ctr = function (data) {
      var out = Buffer.alloc(data.length), ks = this.ks, iv = this.iv, rk = this.rk, pos = this.ksPos, i, j;
      for (i = 0; i < data.length; i++) {
        if (pos === 16) {
          encBlock(rk, iv, 0, ks, 0);
          for (j = 15; j >= 0; j--) { iv[j] = (iv[j] + 1) & 255; if (iv[j]) break; } // 128 bit big-endian counter
          pos = 0;
        }
        out[i] = data[i] ^ ks[pos++];
      }
      this.ksPos = pos;
      return out;
    };
    // OpenSSL's generic block update: a decrypting padded engine keeps the last whole block until it knows whether more follows
    Engine.prototype.update = function (data) {
      if (this.mode === 'ctr') return this.ctr(data);
      var enc = !this.dec, pad = this.pad, buf = this.buf, inPos = 0, inl = data.length, outLen = 0, parts = [], take, nextBlocks, blk, o;
      if (this.bufLen) {
        take = Math.min(16 - this.bufLen, inl);
        buf.set(data.subarray(0, take), this.bufLen);
        this.bufLen += take; inPos = take; inl -= take;
      }
      nextBlocks = inl - (inl % 16);
      if (this.bufLen === 16 && (enc || inl > 0 || !pad)) {
        o = Buffer.alloc(16); this.blocks(buf, 0, 16, o, 0); parts.push(o); outLen += 16; this.bufLen = 0;
      }
      if (nextBlocks > 0) {
        if (!enc && pad && nextBlocks === inl) nextBlocks -= 16;
        if (nextBlocks > 0) {
          o = Buffer.alloc(nextBlocks); this.blocks(data, inPos, nextBlocks, o, 0); parts.push(o); outLen += nextBlocks;
          inPos += nextBlocks; inl -= nextBlocks;
        }
      }
      if (inl > 0) { buf.set(data.subarray(inPos, inPos + inl), this.bufLen); this.bufLen += inl; }
      if (parts.length === 1) return parts[0];
      blk = Buffer.alloc(outLen);
      for (var p = 0, at = 0; p < parts.length; p++) { blk.set(parts[p], at); at += parts[p].length; }
      return blk;
    };
    Engine.prototype.final = function () {
      var buf = this.buf, n = this.bufLen, o, padv, i;
      if (this.mode === 'ctr') return Buffer.alloc(0);
      if (!this.dec) {
        if (this.pad) { padv = 16 - n; for (i = n; i < 16; i++) buf[i] = padv; }
        else if (n === 0) return Buffer.alloc(0);
        else if (n !== 16) throw ossl('wrong final block length', '1C80006B');
        o = Buffer.alloc(16); this.blocks(buf, 0, 16, o, 0); this.bufLen = 0;
        return o;
      }
      if (n !== 16) {
        if (n === 0 && !this.pad) return Buffer.alloc(0);
        throw ossl('wrong final block length', '1C80006B');
      }
      o = Buffer.alloc(16); this.blocks(buf, 0, 16, o, 0); this.bufLen = 0;
      if (!this.pad) return o;
      padv = o[15];
      if (padv === 0 || padv > 16) throw ossl('bad decrypt', '1C800064');
      for (i = 16 - padv; i < 16; i++) if (o[i] !== padv) throw ossl('bad decrypt', '1C800064');
      return o.slice(0, 16 - padv);
    };

    // ---------------------------------------------------------------- Node's Cipheriv / Decipheriv
    function CipherBase(engine) { Transform.call(this); this._e = engine; this._state = 0; this._decoder = null; }
    util.inherits(CipherBase, Transform);
    function Cipheriv(engine) { CipherBase.call(this, engine); }
    util.inherits(Cipheriv, CipherBase);
    function Decipheriv(engine) { CipherBase.call(this, engine); }
    util.inherits(Decipheriv, CipherBase);

    CipherBase.prototype.update = function (data, inputEncoding, outputEncoding) {
      var u, enc, out;
      if (typeof data === 'string') {
        enc = !inputEncoding || inputEncoding === 'buffer' ? 'utf8' : inputEncoding;
        if (normEnc(enc) === 'hex' && data.length % 2 !== 0) {
          throw codedError(TypeError, 'ERR_INVALID_ARG_VALUE', "The argument 'encoding' is invalid for data of length " + data.length + ". Received '" + inputEncoding + "'");
        }
        u = toU8(data, enc);
      } else if (ArrayBuffer.isView(data)) {
        u = toU8(data);
      } else {
        throw argType('data', 'of type string or an instance of Buffer, TypedArray, or DataView', data);
      }
      if (this._state) throw new Error('Trying to add data in unsupported state');
      out = this._e.update(u);
      if (outputEncoding && outputEncoding !== 'buffer') {
        this._decoder = this._decoder || new StringDecoder(outputEncoding);
        return this._decoder.write(out);
      }
      return out;
    };
    CipherBase.prototype.final = function (outputEncoding) {
      var out;
      if (this._state) throw codedError(Error, 'ERR_CRYPTO_INVALID_STATE', 'Invalid state');
      this._state = 1; // like Node, the context is gone after final(), even when it failed
      out = this._e.final();
      if (outputEncoding && outputEncoding !== 'buffer') {
        this._decoder = this._decoder || new StringDecoder(outputEncoding);
        return this._decoder.end(out);
      }
      return out;
    };
    CipherBase.prototype.setAutoPadding = function (ap) {
      if (this._state) throw codedError(Error, 'ERR_CRYPTO_INVALID_STATE', 'Invalid state for operation setAutoPadding');
      this._e.pad = !!ap; // like Node 22: no argument means false
      return this;
    };
    CipherBase.prototype._transform = function (chunk, enc, cb) {
      var out;
      try { out = this._e.update(toU8(chunk, enc) || chunk); } catch (e) { cb(e); return; }
      if (out.length) this.push(out);
      cb();
    };
    CipherBase.prototype._flush = function (cb) {
      var out;
      try { this._state = 1; out = this._e.final(); } catch (e) { cb(e); return; }
      if (out.length) this.push(out);
      cb();
    };

    // ---------------------------------------------------------------- algorithm names, factory functions
    var KNOWN_UNSUPPORTED = /^(aes-(128|192|256)-(cfb|cfb1|cfb8|ofb|gcm|ccm|ocb|xts|wrap|cts)|aes-(128|256)-xts|des|des3|des-|bf|blowfish|rc2|rc4|chacha20|camellia|aria|seed|sm4|cast|idea|id-)/i;
    function parseAlgorithm(name) {
      var lower = name.toLowerCase(), m = /^aes-(128|192|256)-(cbc|ecb|ctr)$/.exec(lower), a = /^aes(128|192|256)$/.exec(lower);
      if (m) return { keyLen: m[1] / 8, mode: m[2] };
      if (a) return { keyLen: a[1] / 8, mode: 'cbc' };
      if (KNOWN_UNSUPPORTED.test(lower)) {
        RR.warnOnce('crypto:cipher:' + lower, 'crypto cipher "' + name + '" is not available in RPG Runner (only aes-128/192/256 in the modes cbc, ecb and ctr are)');
        throw new Error('Cipher "' + name + '" is not available in RPG Runner');
      }
      throw codedError(Error, 'ERR_CRYPTO_UNKNOWN_CIPHER', 'Unknown cipher');
    }
    var KEY_TYPES = 'of type string or an instance of ArrayBuffer, Buffer, TypedArray, DataView, KeyObject, or CryptoKey';
    function makeCipher(decrypt, algorithm, key, iv, options) {
      var k, v = null, alg, enc = options && typeof options === 'object' ? options.encoding : undefined;
      if (typeof algorithm !== 'string') throw argType('cipher', 'of type string', algorithm);
      k = toU8(key, enc);
      if (!k) throw argType('key', KEY_TYPES, key);
      if (iv !== null) {
        v = toU8(iv, undefined);
        if (!v) throw argType('iv', 'of type string or an instance of ArrayBuffer, Buffer, TypedArray, or DataView', iv);
      }
      alg = parseAlgorithm(algorithm);
      if (alg.mode === 'ecb' ? (v && v.length) : (!v || v.length !== 16)) throw codedError(TypeError, 'ERR_CRYPTO_INVALID_IV', 'Invalid initialization vector');
      if (k.length !== alg.keyLen) throw codedError(RangeError, 'ERR_CRYPTO_INVALID_KEYLEN', 'Invalid key length');
      var engine = new Engine(decrypt, alg.mode, k, v);
      return decrypt ? new Decipheriv(engine) : new Cipheriv(engine);
    }
    cryptoMod.createCipheriv = function (algorithm, key, iv, options) { return makeCipher(false, algorithm, key, iv, options); };
    cryptoMod.createDecipheriv = function (algorithm, key, iv, options) { return makeCipher(true, algorithm, key, iv, options); };

    // legacy createCipher / createDecipher: key and IV from the password with OpenSSL's EVP_BytesToKey (md5, no salt, 1 round)
    function bytesToKey(password, keyLen, ivLen) {
      var out = new Uint8Array(keyLen + ivLen), have = 0, prev = new Uint8Array(0), h, d;
      while (have < out.length) {
        h = cryptoMod.createHash('md5');
        h.update(prev); h.update(password);
        d = h.digest();
        out.set(d.subarray(0, Math.min(d.length, out.length - have)), have);
        have += d.length; prev = d;
      }
      return { key: out.subarray(0, keyLen), iv: out.subarray(keyLen) };
    }
    function makeLegacy(decrypt, algorithm, password, options) {
      var pw, alg, kd;
      if (typeof algorithm !== 'string') throw argType('cipher', 'of type string', algorithm);
      pw = toU8(password, undefined);
      if (!pw) throw argType('password', 'of type string or an instance of ArrayBuffer, Buffer, TypedArray, or DataView', password);
      alg = parseAlgorithm(algorithm);
      kd = bytesToKey(pw, alg.keyLen, alg.mode === 'ecb' ? 0 : 16);
      var engine = new Engine(decrypt, alg.mode, kd.key, alg.mode === 'ecb' ? null : kd.iv);
      return decrypt ? new Decipheriv(engine) : new Cipheriv(engine);
    }
    cryptoMod.createCipher = function (algorithm, password, options) { return makeLegacy(false, algorithm, password, options); };
    cryptoMod.createDecipher = function (algorithm, password, options) { return makeLegacy(true, algorithm, password, options); };
    cryptoMod.Cipheriv = Cipheriv;
    cryptoMod.Decipheriv = Decipheriv;
    cryptoMod.getCiphers = function () {
      return ['aes-128-cbc', 'aes-128-ctr', 'aes-128-ecb', 'aes-192-cbc', 'aes-192-ctr', 'aes-192-ecb', 'aes-256-cbc', 'aes-256-ctr', 'aes-256-ecb', 'aes128', 'aes192', 'aes256'];
    };
    // for the tests: the raw block functions
    cryptoMod._aesBlock = function (key, block, decrypt) {
      var ks = expandKey(key), out = new Uint8Array(16);
      (decrypt ? decBlock : encBlock)(decrypt ? ks.dec : ks.enc, block, 0, out, 0);
      return out;
    };
  })();
