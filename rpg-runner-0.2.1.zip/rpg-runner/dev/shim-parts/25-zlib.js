
  // ------------------------------------------------------------------ zlib
  // Pure-JS stand-in for Node's zlib. Decompression handles stored / fixed / dynamic blocks in zlib, gzip (multi-member, header
  // flags, CRC-16) and raw streams with the same checks and error codes as Node. Compression writes valid streams (stored
  // blocks for level 0, otherwise LZ77 + the fixed Huffman code) that every inflater reads; they are not byte-identical to zlib's.
  // Everything is synchronous underneath; the callback and stream flavours only defer the work. Brotli is not available.
  var zlibMod = (function () {
    var CONST = {
      Z_NO_FLUSH: 0, Z_PARTIAL_FLUSH: 1, Z_SYNC_FLUSH: 2, Z_FULL_FLUSH: 3, Z_FINISH: 4, Z_BLOCK: 5,
      Z_OK: 0, Z_STREAM_END: 1, Z_NEED_DICT: 2, Z_ERRNO: -1, Z_STREAM_ERROR: -2, Z_DATA_ERROR: -3, Z_MEM_ERROR: -4, Z_BUF_ERROR: -5, Z_VERSION_ERROR: -6,
      Z_NO_COMPRESSION: 0, Z_BEST_SPEED: 1, Z_BEST_COMPRESSION: 9, Z_DEFAULT_COMPRESSION: -1,
      Z_FILTERED: 1, Z_HUFFMAN_ONLY: 2, Z_RLE: 3, Z_FIXED: 4, Z_DEFAULT_STRATEGY: 0, ZLIB_VERNUM: 4880,
      DEFLATE: 1, INFLATE: 2, GZIP: 3, GUNZIP: 4, DEFLATERAW: 5, INFLATERAW: 6, UNZIP: 7,
      Z_MIN_WINDOWBITS: 8, Z_MAX_WINDOWBITS: 15, Z_DEFAULT_WINDOWBITS: 15, Z_MIN_CHUNK: 64, Z_MAX_CHUNK: Infinity, Z_DEFAULT_CHUNK: 16384,
      Z_MIN_MEMLEVEL: 1, Z_MAX_MEMLEVEL: 9, Z_DEFAULT_MEMLEVEL: 8, Z_MIN_LEVEL: -1, Z_MAX_LEVEL: 9, Z_DEFAULT_LEVEL: -1
    };
    var CODES = {};
    ['Z_OK', 'Z_STREAM_END', 'Z_NEED_DICT', 'Z_ERRNO', 'Z_STREAM_ERROR', 'Z_DATA_ERROR', 'Z_MEM_ERROR', 'Z_BUF_ERROR', 'Z_VERSION_ERROR'].forEach(function (k) {
      CODES[k] = CONST[k]; CODES[CONST[k]] = k;
    });
    var M_DEFLATE = 1, M_INFLATE = 2, M_GZIP = 3, M_GUNZIP = 4, M_DEFLATERAW = 5, M_INFLATERAW = 6, M_UNZIP = 7;
    var Z_FINISH = 4;

    // ---------------------------------------------------------------- errors and argument checks
    function zerr(errno, msg) { var e = new Error(msg); e.errno = errno; e.code = CODES[errno]; return e; }
    function eofErr() { return zerr(-5, 'unexpected end of file'); }
    function describe(v) {
      if (v === null || v === undefined) return String(v);
      if (typeof v === 'function') return 'function ' + v.name;
      if (typeof v === 'object') return 'an instance of ' + ((v.constructor && v.constructor.name) || 'Object');
      var s = typeof v === 'string' ? "'" + (v.length > 28 ? v.slice(0, 25) + '...' : v) + "'" : String(v);
      return 'type ' + typeof v + ' (' + s + ')';
    }
    function argError(name, expected, v) {
      var e = new TypeError('The "' + name + '" argument must be ' + expected + '. Received ' + describe(v));
      e.code = 'ERR_INVALID_ARG_TYPE';
      return e;
    }
    function input(v) {
      if (typeof v === 'string') return strToBytes(v, 'utf8');
      if (v instanceof Uint8Array) return v;
      if (v instanceof ArrayBuffer) return new Uint8Array(v);
      if (ArrayBuffer.isView(v)) return new Uint8Array(v.buffer, v.byteOffset, v.byteLength);
      throw argError('buffer', 'of type string or an instance of Buffer, TypedArray, DataView, or ArrayBuffer', v);
    }
    function wrap(u8) {
      if (u8.buffer.byteLength > 4096 && u8.length * 2 < u8.buffer.byteLength) { var c = new Buffer(u8.length); c.set(u8); return c; }
      return new Buffer(u8.buffer, u8.byteOffset, u8.length);
    }
    function concat(list, total) {
      if (list.length === 1) return list[0];
      var o = new Uint8Array(total), p = 0;
      for (var i = 0; i < list.length; i++) { o.set(list[i], p); p += list[i].length; }
      return o;
    }

    // ---------------------------------------------------------------- checksums
    var CRC_T = (function () {
      var t = new Int32Array(256);
      for (var n = 0; n < 256; n++) {
        var c = n;
        for (var k = 0; k < 8; k++) c = (c & 1) ? (-306674912 ^ (c >>> 1)) : (c >>> 1); // 0xEDB88320
        t[n] = c;
      }
      return t;
    })();
    function crc32(u8, prev, i, n) {
      var c = ~(prev | 0);
      if (i === undefined) i = 0;
      if (n === undefined) n = u8.length;
      for (; i < n; i++) c = CRC_T[(c ^ u8[i]) & 255] ^ (c >>> 8);
      return (~c) >>> 0;
    }
    function adler32(u8, i, n) {
      var a = 1, b = 0;
      while (i < n) {
        var e = Math.min(n, i + 5552);
        for (; i < e; i++) { a += u8[i]; b += a; }
        a %= 65521; b %= 65521;
      }
      return ((b << 16) | a) >>> 0;
    }

    // ---------------------------------------------------------------- inflate
    var LBASE = new Uint16Array([3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258]);
    var LEXT = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0]);
    var DBASE = new Uint16Array([1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385, 24577]);
    var DEXT = new Uint8Array([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13]);
    var CL_ORDER = new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]);

    // Decoding table of a canonical Huffman code: index = the next `bits` input bits, entry = (symbol << 4) | code length (0 = no code).
    // kind: 0 = code-length code, 1 = literal/length code, 2 = distance code. Returns null for an over-subscribed or (like zlib)
    // incomplete code; the only incomplete code allowed is a lone 1-bit code, and a code with no symbols at all (valid for distances).
    function huff(lens, n, kind) {
      var count = new Uint16Array(16), i, sym;
      for (sym = 0; sym < n; sym++) count[lens[sym]]++;
      var max = 15;
      while (max >= 1 && count[max] === 0) max--;
      // No codes at all. For distances that is fine until a distance is needed. zlib quirk for the code-length code: every
      // 1-bit pattern then decodes as "length 0" (so such a block fails later, not here); mimic it to report the same errors.
      if (max === 0) return { t: kind === 0 ? new Uint16Array([1, 1]) : new Uint16Array(2), bits: 1 };
      var left = 1;
      for (i = 1; i <= 15; i++) { left = (left << 1) - count[i]; if (left < 0) return null; }
      if (left > 0 && (kind === 0 || max !== 1)) return null;
      count[0] = 0;
      var next = new Uint16Array(16), code = 0;
      for (i = 1; i <= 15; i++) { code = (code + count[i - 1]) << 1; next[i] = code; }
      var size = 1 << max, t = new Uint16Array(size);
      for (sym = 0; sym < n; sym++) {
        var len = lens[sym];
        if (!len) continue;
        var c = next[len]++, r = 0;
        for (i = 0; i < len; i++) { r = (r << 1) | (c & 1); c >>= 1; } // deflate packs Huffman codes most significant bit first
        var entry = (sym << 4) | len;
        for (i = r; i < size; i += 1 << len) t[i] = entry;
      }
      return { t: t, bits: max };
    }
    var fixedL = null, fixedD = null;
    function fixedTables() {
      if (fixedL) return;
      var l = new Uint8Array(288), d = new Uint8Array(32), i;
      for (i = 0; i < 144; i++) l[i] = 8;
      for (; i < 256; i++) l[i] = 9;
      for (; i < 280; i++) l[i] = 7;
      for (; i < 288; i++) l[i] = 8;
      for (i = 0; i < 32; i++) d[i] = 5;
      fixedL = huff(l, 288, 1); fixedD = huff(d, 32, 2);
    }
    function grow(out, used, need) {
      var c = out.length * 2;
      while (c < used + need) c *= 2;
      var o = new Uint8Array(c);
      o.set(out.subarray(0, used));
      return o;
    }

    // Decodes the raw deflate stream that starts at src[start]. `preset` is an optional dictionary, `hint` the expected output size.
    // Returns { out, base, end, pos, ended }: the data is out[base..end), pos is the input position behind the stream, and
    // ended is false when the input ran out first (the data decoded so far is still returned). Corrupt data throws.
    function inflateCore(src, start, preset, hint) {
      var n = src.length, p = start, bb = 0, bc = 0, eof = false, last = 0;
      var base = preset ? preset.length : 0;
      var cap = Math.min(Math.max(4096, hint > 0 ? hint : n * 4), 1 << 26) + base;
      var out = new Uint8Array(cap), op = base;
      var i, k, e, l, sym, eb, len, dist, from, type, lt, dt, lmask, dmask, ltab, dtab;
      if (base) out.set(preset);

      function refill() { while (bc <= 24 && p < n) { bb |= src[p++] << bc; bc += 8; } }
      function bits(cnt) {
        if (bc < cnt) { refill(); if (bc < cnt) { eof = true; return 0; } }
        var v = bb & ((1 << cnt) - 1);
        bb >>>= cnt; bc -= cnt;
        return v;
      }

      do {
        last = bits(1);
        type = bits(2);
        if (eof) break;
        if (type === 0) {
          // stored block: drop the rest of the current byte, give the look-ahead bytes back to the input, read LEN / NLEN
          p -= bc >> 3; bb = 0; bc = 0;
          if (p + 4 > n) { eof = true; break; }
          len = src[p] | (src[p + 1] << 8);
          if ((len ^ 0xffff) !== (src[p + 2] | (src[p + 3] << 8))) throw zerr(-3, 'invalid stored block lengths');
          p += 4;
          k = Math.min(len, n - p);
          if (op + k > out.length) out = grow(out, op, k);
          out.set(src.subarray(p, p + k), op);
          op += k; p += k;
          if (k < len) { eof = true; break; }
          continue;
        }
        if (type === 3) throw zerr(-3, 'invalid block type');
        if (type === 1) {
          fixedTables(); lt = fixedL; dt = fixedD;
        } else {
          var hlit = bits(5) + 257, hdist = bits(5) + 1, hclen = bits(4) + 4;
          if (eof) break;
          if (hlit > 286 || hdist > 30) throw zerr(-3, 'too many length or distance symbols');
          var cl = new Uint8Array(19);
          for (i = 0; i < hclen; i++) cl[CL_ORDER[i]] = bits(3);
          if (eof) break;
          var ct = huff(cl, 19, 0);
          if (!ct) throw zerr(-3, 'invalid code lengths set');
          var total = hlit + hdist, lens = new Uint8Array(total), cmask = (1 << ct.bits) - 1;
          k = 0;
          while (k < total) {
            if (bc < 15) refill();
            e = ct.t[bb & cmask]; l = e & 15;
            if (l === 0) throw zerr(-3, 'invalid code lengths set');
            if (l > bc) { eof = true; break; }
            bb >>>= l; bc -= l;
            sym = e >> 4;
            if (sym < 16) { lens[k++] = sym; continue; }
            var rep, val = 0;
            if (sym === 16) {
              if (k === 0) throw zerr(-3, 'invalid bit length repeat');
              val = lens[k - 1]; rep = 3 + bits(2);
            } else if (sym === 17) rep = 3 + bits(3);
            else rep = 11 + bits(7);
            if (eof) break;
            if (k + rep > total) throw zerr(-3, 'invalid bit length repeat');
            while (rep-- > 0) lens[k++] = val;
          }
          if (eof) break;
          if (lens[256] === 0) throw zerr(-3, 'invalid code -- missing end-of-block');
          lt = huff(lens.subarray(0, hlit), hlit, 1);
          if (!lt) throw zerr(-3, 'invalid literal/lengths set');
          dt = huff(lens.subarray(hlit), hdist, 2);
          if (!dt) throw zerr(-3, 'invalid distances set');
        }
        ltab = lt.t; lmask = (1 << lt.bits) - 1; dtab = dt.t; dmask = (1 << dt.bits) - 1;
        for (;;) {
          if (op + 258 > out.length) out = grow(out, op, 258);
          if (bc < 15) refill();
          e = ltab[bb & lmask]; l = e & 15;
          if (l === 0) throw zerr(-3, 'invalid literal/length code');
          if (l > bc) { eof = true; break; }
          bb >>>= l; bc -= l;
          sym = e >> 4;
          if (sym < 256) { out[op++] = sym; continue; }
          if (sym === 256) break;
          sym -= 257;
          if (sym >= 29) throw zerr(-3, 'invalid literal/length code');
          eb = LEXT[sym]; len = LBASE[sym];
          if (eb) {
            if (bc < eb) refill();
            if (bc < eb) { eof = true; break; }
            len += bb & ((1 << eb) - 1); bb >>>= eb; bc -= eb;
          }
          if (bc < 15) refill();
          e = dtab[bb & dmask]; l = e & 15;
          if (l === 0) throw zerr(-3, 'invalid distance code');
          if (l > bc) { eof = true; break; }
          bb >>>= l; bc -= l;
          sym = e >> 4;
          if (sym >= 30) throw zerr(-3, 'invalid distance code');
          eb = DEXT[sym]; dist = DBASE[sym];
          if (eb) {
            if (bc < eb) refill();
            if (bc < eb) { eof = true; break; }
            dist += bb & ((1 << eb) - 1); bb >>>= eb; bc -= eb;
          }
          if (dist > op) throw zerr(-3, 'invalid distance too far back');
          from = op - dist;
          for (i = 0; i < len; i++) out[op + i] = out[from + i]; // byte by byte on purpose: the source may overlap the destination
          op += len;
        }
      } while (!last && !eof);
      if (!eof) p -= bc >> 3;
      return { out: out, base: base, end: op, pos: p, ended: !eof };
    }

    // Container level: zlib / gzip / raw / auto-detect, with Node's checks. Returns a Buffer.
    function decode(mode, src, opts) {
      var finish = opts.finishFlush === undefined ? Z_FINISH : opts.finishFlush;
      var dict = opts.dictionary ? input(opts.dictionary) : null;
      var n = src.length, pos = 0, parts = [], total = 0, truncated = false, r, q, flg;
      if (mode === M_UNZIP) mode = (n >= 2 && src[0] === 0x1f && src[1] === 0x8b) ? M_GUNZIP : M_INFLATE;
      member: for (;;) {
        var hdr = pos, hint = 0;
        if (mode === M_INFLATE) {
          if (n - pos < 2) { truncated = true; break; }
          var cmf = src[pos], fl = src[pos + 1];
          if ((cmf * 256 + fl) % 31 !== 0) throw zerr(-3, 'incorrect header check');
          if ((cmf & 15) !== 8) throw zerr(-3, 'unknown compression method');
          if ((cmf >> 4) > 7) throw zerr(-3, 'invalid window size');
          pos += 2;
          if (fl & 0x20) {
            if (n - pos < 4) { truncated = true; break; }
            var did = ((src[pos] << 24) | (src[pos + 1] << 16) | (src[pos + 2] << 8) | src[pos + 3]) >>> 0;
            pos += 4;
            if (!dict) throw zerr(2, 'Missing dictionary');
            if (adler32(dict, 0, dict.length) !== did) throw zerr(2, 'Bad dictionary');
          }
        } else if (mode === M_GUNZIP) {
          // zlib validates while the bytes arrive: magic after 2 bytes, method + flags after 4, the rest after 10
          if (n - pos < 2) { truncated = true; break; }
          if (src[pos] !== 0x1f || src[pos + 1] !== 0x8b) throw zerr(-3, 'incorrect header check');
          if (n - pos < 4) { truncated = true; break; }
          if (src[pos + 2] !== 8) throw zerr(-3, 'unknown compression method');
          flg = src[pos + 3];
          if (flg & 0xe0) throw zerr(-3, 'unknown header flags set');
          if (n - pos < 10) { truncated = true; break; }
          q = pos + 10;
          if (flg & 4) {
            if (n - q < 2) { truncated = true; break; }
            q += 2 + (src[q] | (src[q + 1] << 8));
            if (q > n) { truncated = true; break; }
          }
          if (flg & 8) { while (q < n && src[q] !== 0) q++; if (q >= n) { truncated = true; break; } q++; }
          if (flg & 16) { while (q < n && src[q] !== 0) q++; if (q >= n) { truncated = true; break; } q++; }
          if (flg & 2) {
            if (n - q < 2) { truncated = true; break; }
            if ((crc32(src, 0, pos, q) & 0xffff) !== (src[q] | (src[q + 1] << 8))) throw zerr(-3, 'header crc mismatch');
            q += 2;
          }
          pos = q;
          if (n - pos >= 8 && hdr === 0) { // the ISIZE trailer of a single-member file tells the output size (a hint only)
            hint = (src[n - 4] | (src[n - 3] << 8) | (src[n - 2] << 16) | (src[n - 1] << 24)) >>> 0;
            if (hint > n * 64 || hint > (1 << 27)) hint = 0;
          }
        }
        r = inflateCore(src, pos, mode === M_INFLATE || mode === M_INFLATERAW ? dict : null, hint);
        if (!r.ended) {
          if (r.end > r.base) { parts.push(r.out.subarray(r.base, r.end)); total += r.end - r.base; }
          truncated = true; break;
        }
        pos = r.pos;
        if (mode === M_INFLATE) {
          if (n - pos < 4) { parts.push(r.out.subarray(r.base, r.end)); total += r.end - r.base; truncated = true; break; }
          var want = ((src[pos] << 24) | (src[pos + 1] << 16) | (src[pos + 2] << 8) | src[pos + 3]) >>> 0;
          if (adler32(r.out, r.base, r.end) !== want) throw zerr(-3, 'incorrect data check');
          pos += 4;
        } else if (mode === M_GUNZIP) {
          // the CRC is checked as soon as its 4 bytes are there, the length once the other 4 have arrived
          if (n - pos < 4) { parts.push(r.out.subarray(r.base, r.end)); total += r.end - r.base; truncated = true; break; }
          var wcrc = (src[pos] | (src[pos + 1] << 8) | (src[pos + 2] << 16) | (src[pos + 3] << 24)) >>> 0;
          if (crc32(r.out, 0, r.base, r.end) !== wcrc) throw zerr(-3, 'incorrect data check');
          if (n - pos < 8) { parts.push(r.out.subarray(r.base, r.end)); total += r.end - r.base; truncated = true; break; }
          var wlen = (src[pos + 4] | (src[pos + 5] << 8) | (src[pos + 6] << 16) | (src[pos + 7] << 24)) >>> 0;
          if (((r.end - r.base) >>> 0) !== wlen) throw zerr(-3, 'incorrect length check');
          pos += 8;
        }
        parts.push(r.out.subarray(r.base, r.end)); total += r.end - r.base;
        // like Node: after a gzip member more input is read as the next member unless it is zero padding
        if (mode === M_GUNZIP && pos < n && src[pos] !== 0) continue member;
        break;
      }
      if (truncated && finish === Z_FINISH) throw eofErr();
      return wrap(total ? concat(parts, total) : new Uint8Array(0));
    }

    // ---------------------------------------------------------------- deflate
    var FIX_CODE = null, FIX_LEN = null, LSYM = null, DSYM = null, REV5 = null;
    function revBits(v, len) { var r = 0; for (var i = 0; i < len; i++) { r = (r << 1) | (v & 1); v >>= 1; } return r; }
    function deflateTables() {
      if (FIX_CODE) return;
      var i, j, code, len;
      FIX_CODE = new Uint16Array(288); FIX_LEN = new Uint8Array(288);
      for (i = 0; i < 288; i++) {
        if (i < 144) { code = 0x30 + i; len = 8; }
        else if (i < 256) { code = 0x190 + i - 144; len = 9; }
        else if (i < 280) { code = i - 256; len = 7; }
        else { code = 0xc0 + i - 280; len = 8; }
        FIX_CODE[i] = revBits(code, len); FIX_LEN[i] = len;
      }
      LSYM = new Uint8Array(259);
      for (i = 0; i < 29; i++) {
        var hi = i === 28 ? 258 : LBASE[i] + (1 << LEXT[i]) - 1;
        for (j = LBASE[i]; j <= hi; j++) LSYM[j] = i;
      }
      DSYM = new Uint8Array(32769);
      for (i = 0; i < 30; i++) for (j = DBASE[i]; j < DBASE[i] + (1 << DEXT[i]); j++) DSYM[j] = i;
      REV5 = new Uint8Array(32);
      for (i = 0; i < 32; i++) REV5[i] = revBits(i, 5);
    }
    function storedSize(n) { return n + Math.max(1, Math.ceil(n / 65535)) * 5; }
    function deflateStored(src) {
      var n = src.length, nb = Math.max(1, Math.ceil(n / 65535)), out = new Uint8Array(storedSize(n)), op = 0, pos = 0;
      for (var b = 0; b < nb; b++) {
        var len = Math.min(65535, n - pos);
        out[op++] = b === nb - 1 ? 1 : 0;
        out[op++] = len & 255; out[op++] = len >> 8; out[op++] = ~len & 255; out[op++] = (~len >> 8) & 255;
        out.set(src.subarray(pos, pos + len), op);
        op += len; pos += len;
      }
      return out;
    }
    function deflateFixed(src, level) {
      deflateTables();
      var n = src.length;
      var chain = level <= 1 ? 4 : level <= 3 ? 8 : level <= 5 ? 16 : level === 6 ? 32 : level <= 8 ? 128 : 256;
      var out = new Uint8Array(n + (n >> 3) + 64), op = 0, acc = 0, nb = 0;
      function put(code, len) {
        acc |= code << nb; nb += len;
        while (nb >= 8) { out[op++] = acc & 255; acc >>>= 8; nb -= 8; }
      }
      var head = new Int32Array(32768), prev = new Int32Array(32768);
      head.fill(-1);
      put(1, 1); put(1, 2); // BFINAL = 1, BTYPE = 01 (fixed Huffman codes)
      var i = 0, j, h, cand, l, maxl, bestLen, bestDist, ch, sym, ds;
      while (i < n) {
        if (op + 16 > out.length) out = grow(out, op, 16);
        bestLen = 0; bestDist = 0;
        if (i + 2 < n) {
          h = ((src[i] << 10) ^ (src[i + 1] << 5) ^ src[i + 2]) & 32767;
          cand = head[h];
          maxl = n - i < 258 ? n - i : 258;
          ch = chain;
          while (cand >= 0 && i - cand <= 32768 && ch-- > 0) {
            if (src[cand + bestLen] === src[i + bestLen]) {
              l = 0;
              while (l < maxl && src[cand + l] === src[i + l]) l++;
              if (l > bestLen) { bestLen = l; bestDist = i - cand; if (l >= maxl) break; }
            }
            cand = prev[cand & 32767];
          }
        }
        if (bestLen >= 3) {
          sym = LSYM[bestLen];
          put(FIX_CODE[257 + sym], FIX_LEN[257 + sym]);
          if (LEXT[sym]) put(bestLen - LBASE[sym], LEXT[sym]);
          ds = DSYM[bestDist];
          put(REV5[ds], 5);
          if (DEXT[ds]) put(bestDist - DBASE[ds], DEXT[ds]);
          for (j = 0; j < bestLen; j++, i++) {
            if (i + 2 < n) { h = ((src[i] << 10) ^ (src[i + 1] << 5) ^ src[i + 2]) & 32767; prev[i & 32767] = head[h]; head[h] = i; }
          }
        } else {
          put(FIX_CODE[src[i]], FIX_LEN[src[i]]);
          if (i + 2 < n) { h = ((src[i] << 10) ^ (src[i + 1] << 5) ^ src[i + 2]) & 32767; prev[i & 32767] = head[h]; head[h] = i; }
          i++;
        }
      }
      put(FIX_CODE[256], FIX_LEN[256]);
      if (nb > 0) out[op++] = acc & 255;
      return out.subarray(0, op);
    }

    function encode(mode, src, opts) {
      var level = opts.level === undefined || opts.level === null ? -1 : opts.level;
      if (typeof level !== 'number' || level !== level || level < -1 || level > 9) {
        var re = new RangeError('The value of "options.level" is out of range. It must be >= -1 and <= 9. Received ' + String(level));
        re.code = 'ERR_OUT_OF_RANGE';
        throw re;
      }
      var lv = level === -1 ? 6 : Math.floor(level);
      var body = lv === 0 ? deflateStored(src) : deflateFixed(src, lv);
      if (lv !== 0 && body.length > storedSize(src.length)) body = deflateStored(src); // incompressible: never grow more than stored blocks do
      if (mode === M_DEFLATERAW) return wrap(body);
      var head, tail, dict = mode === M_DEFLATE && opts.dictionary ? input(opts.dictionary) : null;
      if (mode === M_DEFLATE) {
        var fl = ((lv < 2 ? 0 : lv < 6 ? 1 : lv === 6 ? 2 : 3) << 6) | (dict ? 0x20 : 0);
        fl += 31 - (((0x78 << 8) | fl) % 31);
        head = [0x78, fl];
        if (dict) { var d = adler32(dict, 0, dict.length); head.push(d >>> 24, (d >>> 16) & 255, (d >>> 8) & 255, d & 255); }
        var a = adler32(src, 0, src.length);
        tail = [a >>> 24, (a >>> 16) & 255, (a >>> 8) & 255, a & 255];
      } else {
        head = [0x1f, 0x8b, 8, 0, 0, 0, 0, 0, lv === 9 ? 2 : lv < 2 ? 4 : 0, 3];
        var c = crc32(src, 0), sz = src.length >>> 0;
        tail = [c & 255, (c >>> 8) & 255, (c >>> 16) & 255, c >>> 24, sz & 255, (sz >>> 8) & 255, (sz >>> 16) & 255, sz >>> 24];
      }
      var res = new Buffer(head.length + body.length + tail.length), i;
      for (i = 0; i < head.length; i++) res[i] = head[i];
      res.set(body, head.length);
      for (i = 0; i < tail.length; i++) res[head.length + body.length + i] = tail[i];
      return res;
    }

    // ---------------------------------------------------------------- public API
    var mod = { constants: CONST, codes: CODES };
    Object.keys(CONST).forEach(function (k) { if (/^Z_/.test(k)) mod[k] = CONST[k]; });
    mod.crc32 = function (data, value) {
      if (value === undefined) value = 0;
      if (typeof value !== 'number' || value !== value || value < 0 || value > 4294967295 || Math.floor(value) !== value) {
        var e = new RangeError('The value of "value" is out of range. It must be an integer >= 0 and <= 4294967295. Received ' + String(value));
        e.code = 'ERR_OUT_OF_RANGE';
        throw e;
      }
      if (typeof data !== 'string' && !(data instanceof Uint8Array) && !ArrayBuffer.isView(data)) throw argError('data', 'of type string or an instance of Buffer, TypedArray, or DataView', data);
      return crc32(input(data), value);
    };

    var KINDS = [['deflate', M_DEFLATE, encode], ['inflate', M_INFLATE, decode], ['gzip', M_GZIP, encode], ['gunzip', M_GUNZIP, decode],
      ['deflateRaw', M_DEFLATERAW, encode], ['inflateRaw', M_INFLATERAW, decode], ['unzip', M_UNZIP, decode]];
    KINDS.forEach(function (kd) {
      var mode = kd[1], fn = kd[2];
      mod[kd[0] + 'Sync'] = function (data, opts) { return fn(mode, input(data), opts || {}); };
      mod[kd[0]] = function (data, opts, cb) {
        if (typeof opts === 'function') { cb = opts; opts = {}; }
        var src = input(data);
        if (typeof cb !== 'function') throw argError('callback', 'of type function', cb);
        setTimeout(function () {
          var res, err = null;
          try { res = fn(mode, src, opts || {}); } catch (e) { err = e; }
          if (err) cb(err); else cb(null, res);
        }, 0);
      };
    });

    // Minimal buffering streams: everything written is processed when end() is called, then emitted as one 'data' chunk.
    function ZStream(mode, fn, opts) {
      EventEmitter.call(this);
      this._mode = mode; this._fn = fn; this._opts = opts || {}; this._chunks = []; this._size = 0; this._ended = false;
      this.bytesWritten = 0; this.readable = true; this.writable = true;
    }
    ZStream.prototype = Object.create(EventEmitter.prototype);
    ZStream.prototype.constructor = ZStream;
    ZStream.prototype.write = function (chunk, enc, cb) {
      if (typeof enc === 'function') { cb = enc; enc = undefined; }
      var self = this;
      if (this._ended) {
        var we = new Error('write after end'); we.code = 'ERR_STREAM_WRITE_AFTER_END';
        setTimeout(function () { self.emit('error', we); }, 0);
        return false;
      }
      var u8 = typeof chunk === 'string' ? strToBytes(chunk, enc || 'utf8') : input(chunk);
      this._chunks.push(new Uint8Array(u8)); this._size += u8.length; this.bytesWritten += u8.length;
      if (cb) setTimeout(cb, 0);
      return true;
    };
    ZStream.prototype.end = function (chunk, enc, cb) {
      if (typeof chunk === 'function') { cb = chunk; chunk = null; enc = undefined; }
      else if (typeof enc === 'function') { cb = enc; enc = undefined; }
      if (chunk !== undefined && chunk !== null) this.write(chunk, enc);
      if (this._ended) return this;
      this._ended = true;
      var self = this;
      setTimeout(function () {
        var res = null, err = null;
        try { res = self._fn(self._mode, concat(self._chunks.length ? self._chunks : [new Uint8Array(0)], self._size), self._opts); } catch (e) { err = e; }
        self._chunks = [];
        if (err) { self.emit('error', err); return; }
        if (res.length) self.emit('data', res);
        self.emit('finish'); self.emit('end'); self.emit('close');
        if (cb) cb();
      }, 0);
      return this;
    };
    ZStream.prototype.pipe = function (dest, o) {
      this.on('data', function (c) { if (dest && typeof dest.write === 'function') dest.write(c); });
      if (!o || o.end !== false) this.on('end', function () { if (dest && typeof dest.end === 'function') dest.end(); });
      return dest;
    };
    ZStream.prototype.flush = function (kind, cb) { if (typeof kind === 'function') cb = kind; if (typeof cb === 'function') setTimeout(cb, 0); };
    ZStream.prototype.params = function (level, strategy, cb) { if (typeof cb === 'function') setTimeout(cb, 0); };
    ZStream.prototype.reset = function () { this._chunks = []; this._size = 0; this._ended = false; };
    ZStream.prototype.close = ZStream.prototype.destroy = function (cb) {
      if (typeof cb === 'function') setTimeout(cb, 0);
      this._ended = true; this._chunks = [];
      return this;
    };
    ZStream.prototype.setEncoding = function () { return this; };
    [['Deflate', 'createDeflate', M_DEFLATE, encode], ['Inflate', 'createInflate', M_INFLATE, decode], ['Gzip', 'createGzip', M_GZIP, encode],
      ['Gunzip', 'createGunzip', M_GUNZIP, decode], ['DeflateRaw', 'createDeflateRaw', M_DEFLATERAW, encode],
      ['InflateRaw', 'createInflateRaw', M_INFLATERAW, decode], ['Unzip', 'createUnzip', M_UNZIP, decode]].forEach(function (kd) {
      mod[kd[0]] = function (o) { return new ZStream(kd[2], kd[3], o); };
      mod[kd[1]] = function (o) { return new ZStream(kd[2], kd[3], o); };
    });

    ['brotliCompress', 'brotliCompressSync', 'brotliDecompress', 'brotliDecompressSync', 'createBrotliCompress', 'createBrotliDecompress',
      'BrotliCompress', 'BrotliDecompress'].forEach(function (name) {
      mod[name] = function () {
        RR.warnOnce('zlib:' + name, 'zlib.' + name + ' is not available in RPG Runner (brotli is not implemented)');
        throw new Error('zlib.' + name + ' is not available in RPG Runner');
      };
    });
    mod._internals = { inflateCore: inflateCore, deflateFixed: deflateFixed, adler32: adler32, crc32: crc32 };
    return mod;
  })();
