  // ------------------------------------------------------------------ stream: StringDecoder, Stream, Readable
  // A compact implementation of Node's stream classes (the app has no real Node): flowing and paused reading, push() / read(),
  // 'readable', pipe() with back-pressure, async iteration, destroy(). Writable, Duplex, Transform and pipeline() follow in part 22.
  var streamTick = function (fn) {
    var a = Array.prototype.slice.call(arguments, 1);
    Promise.resolve().then(function () { fn.apply(null, a); });
  };
  function sErr(Ctor, code, msg) { var e = new Ctor(msg); e.code = code; return e; }
  function describeVal(v) {
    if (v === null || v === undefined) return String(v);
    if (typeof v === 'object' || typeof v === 'function') return 'an instance of ' + ((v.constructor && v.constructor.name) || 'Object');
    if (typeof v === 'string') return "type string ('" + (v.length > 28 ? v.slice(0, 25) + '...' : v) + "')";
    return 'type ' + typeof v + ' (' + String(v) + ')';
  }
  function toBuf(u8) { return u8 instanceof Buffer ? u8 : new Buffer(u8.buffer, u8.byteOffset, u8.length); }

  // string_decoder: multi-byte characters (and base64 / utf16 units) that are split across chunks are held back until complete
  function StringDecoder(enc) {
    this.encoding = normEnc(enc);
    if (!Buffer.isEncoding(this.encoding)) throw sErr(TypeError, 'ERR_UNKNOWN_ENCODING', 'Unknown encoding: ' + enc);
    this._td = this.encoding === 'utf8' && typeof TextDecoder === 'function' ? new TextDecoder('utf-8', { ignoreBOM: true }) : null;
    this._carry = null;
  }
  StringDecoder.prototype.write = function (buf) {
    if (typeof buf === 'string') return buf;
    var u = RR.toBytes(buf), enc = this.encoding;
    if (enc === 'utf8' && this._td) return this._td.decode(u, { stream: true });
    var unit = enc === 'utf16le' ? 2 : (enc === 'base64' || enc === 'base64url') ? 3 : 1;
    if (unit === 1) return bytesToStr(u, enc);
    var joined = u, keep;
    if (this._carry && this._carry.length) { joined = new Uint8Array(this._carry.length + u.length); joined.set(this._carry); joined.set(u, this._carry.length); }
    keep = joined.length % unit;
    this._carry = keep ? joined.slice(joined.length - keep) : null;
    return bytesToStr(keep ? joined.subarray(0, joined.length - keep) : joined, enc);
  };
  StringDecoder.prototype.end = function (buf) {
    var r = buf === undefined ? '' : this.write(buf);
    if (this._td) r += this._td.decode();
    else if (this._carry && this._carry.length) r += bytesToStr(this._carry, this.encoding);
    this._carry = null;
    return r;
  };
  stringDecoder.StringDecoder = StringDecoder;

  function Stream(opts) { EventEmitter.call(this); this.destroyed = false; }
  util.inherits(Stream, EventEmitter);
  Stream.prototype.pipe = function (dest, opts) { // old-style streams
    var src = this;
    src.on('data', function (c) { if (dest.write(c) === false && typeof src.pause === 'function') src.pause(); });
    dest.on('drain', function () { if (typeof src.resume === 'function') src.resume(); });
    if (!opts || opts.end !== false) src.on('end', function () { dest.end(); });
    dest.emit('pipe', src);
    return dest;
  };

  function Readable(opts) {
    if (!(this instanceof Readable)) return new Readable(opts);
    Stream.call(this);
    opts = opts || {};
    var om = !!(opts.objectMode || opts.readableObjectMode), hwm = opts.readableHighWaterMark;
    if (hwm === undefined) hwm = opts.highWaterMark;
    if (hwm === undefined) hwm = om ? 16 : 16384;
    this._r = { om: om, hwm: hwm, buf: [], len: 0, flowing: null, ended: false, endEmitted: false, endScheduled: false, reading: false, sync: true, pumping: false,
      listening: false, emittedReadable: false, needReadable: false, decoder: null, pipes: [], awaitDrain: 0, autoDestroy: opts.autoDestroy !== false };
    this._emitClose = opts.emitClose !== false;
    this.readable = true;
    if (typeof opts.read === 'function') this._read = opts.read;
    if (typeof opts.destroy === 'function') this._destroy = opts.destroy;
    if (opts.encoding) this.setEncoding(opts.encoding);
  }
  util.inherits(Readable, Stream);
  Readable.prototype._read = function () { throw sErr(Error, 'ERR_METHOD_NOT_IMPLEMENTED', 'The _read() method is not implemented'); };

  function errorOrDestroy(s, err) {
    if (s.destroyed) return;
    if ((s._r && s._r.autoDestroy) || (s._w && s._w.autoDestroy)) s.destroy(err);
    else if (err && !s._errorEmitted) { s._errorEmitted = true; s.errored = err; streamTick(function () { s.emit('error', err); }); }
  }
  function destroyImpl(err, cb) {
    var s = this, called = false;
    if (typeof err === 'function') { cb = err; err = null; }
    if (s.destroyed) { if (typeof cb === 'function') streamTick(cb); return s; }
    s.destroyed = true; s.readable = false; s.writable = false;
    if (err) s.errored = err;
    function after(er) {
      if (called) return;
      called = true;
      er = er || err;
      streamTick(function () {
        if (er && !s._errorEmitted) { s._errorEmitted = true; s.emit('error', er); }
        if (s._emitClose !== false && !s._closeEmitted) { s._closeEmitted = true; s.emit('close'); }
        if (typeof cb === 'function') cb(er);
      });
    }
    try { s._destroy(err || null, after); } catch (e) { after(e); }
    if (s._w && typeof failQueued === 'function') failQueued(s);
    return s;
  }
  Readable.prototype.destroy = destroyImpl;
  Readable.prototype._destroy = function (err, cb) { cb(err); };

  // push() only buffers; the pump (a microtask) delivers 'data' / 'readable' / 'end' and asks the source for more
  function addChunk(s, chunk, enc, front) {
    var r = s._r, rest;
    if (chunk === null) {
      r.reading = false;
      if (!r.ended) {
        if (r.decoder) { rest = r.decoder.end(); if (rest) { r.buf.push(rest); r.len += rest.length; } }
        r.ended = true;
        if (r.flowing && r.len === 0) endReadable(s); else schedulePump(s);
      }
      return false;
    }
    if (r.ended && !front) { errorOrDestroy(s, sErr(Error, 'ERR_STREAM_PUSH_AFTER_EOF', 'stream.push() after EOF')); return false; }
    if (!r.om) {
      if (typeof chunk === 'string') {
        enc = enc || 'utf8';
        if (!r.decoder || normEnc(enc) !== r.decoder.encoding) chunk = toBuf(strToBytes(chunk, enc));
      } else if (chunk instanceof Uint8Array) {
        chunk = toBuf(chunk);
      } else if (chunk !== undefined) {
        errorOrDestroy(s, sErr(TypeError, 'ERR_INVALID_ARG_TYPE', 'The "chunk" argument must be of type string or an instance of Buffer or Uint8Array. Received ' + describeVal(chunk)));
        return false;
      }
      if (chunk !== undefined && r.decoder && typeof chunk !== 'string') chunk = r.decoder.write(chunk);
      if (chunk === undefined || chunk.length === 0) { r.reading = false; schedulePump(s); return r.len < r.hwm; }
    }
    r.reading = false;
    if (r.flowing && r.len === 0 && !r.sync && !front && s.listenerCount('data') > 0) { // nobody is waiting: hand it over right away
      s.emit('data', chunk);
      schedulePump(s);
      return true;
    }
    if (front) r.buf.unshift(chunk); else r.buf.push(chunk);
    r.len += r.om ? 1 : chunk.length;
    schedulePump(s);
    return r.len < r.hwm || r.len === 0;
  }
  Readable.prototype.push = function (chunk, enc) { return addChunk(this, chunk, enc, false); };
  Readable.prototype.unshift = function (chunk, enc) { addChunk(this, chunk, enc, true); };

  function schedulePump(s) {
    var r = s._r;
    if (r.pumping || s.destroyed) return;
    r.pumping = true;
    streamTick(pump, s);
  }
  function pump(s) {
    var r = s._r;
    r.pumping = false;
    if (s.destroyed) return;
    if (r.flowing) {
      do { s.read(); } while (r.flowing && !s.destroyed && r.len > 0); // read() emits 'data'; with an empty buffer it asks for more or ends
    } else if (r.listening && !r.emittedReadable && (r.len > 0 || r.ended)) {
      r.emittedReadable = true; r.needReadable = false;
      s.emit('readable');
    } else {
      maybeRead(s);
    }
  }
  function maybeRead(s) {
    var r = s._r;
    if (r.reading || r.ended || s.destroyed || r.len >= r.hwm) return;
    r.reading = true; r.sync = true;
    try { s._read(r.hwm); } catch (e) { r.reading = false; errorOrDestroy(s, e); }
    r.sync = false;
  }
  function endReadable(s) {
    var r = s._r;
    if (r.endScheduled || r.endEmitted || s.destroyed) return;
    r.endScheduled = true;
    streamTick(function () {
      if (s.destroyed || r.endEmitted) return;
      if (r.len > 0) { r.endScheduled = false; return; } // something was unshift()ed meanwhile
      r.endEmitted = true; s.readable = false;
      s.emit('end');
      if (r.autoDestroy && !s.destroyed && (!s._w || s._w.finished)) s.destroy();
    });
  }

  // n units (bytes / characters / one object) from the buffer, or null when there are not enough yet
  function takeChunk(s, n) {
    var r = s._r, b = r.buf, first, all, str, ret;
    if (r.len === 0) return null;
    if (r.om) { r.len--; return b.shift(); }
    if (n !== n) { // read() without a size: the first chunk while flowing, everything otherwise
      if (r.flowing) { first = b.shift(); r.len -= first.length; return first; }
      n = r.len;
    }
    if (n > r.len) { if (!r.ended) return null; n = r.len; }
    first = b[0]; str = typeof first === 'string';
    if (first.length === n) { b.shift(); r.len -= n; return first; }
    if (first.length > n) { b[0] = str ? first.slice(n) : first.subarray(n); r.len -= n; return str ? first.slice(0, n) : first.subarray(0, n); }
    all = str ? b.join('') : Buffer.concat(b);
    ret = all.length === n ? all : (str ? all.slice(0, n) : all.subarray(0, n));
    r.buf = all.length === n ? [] : [str ? all.slice(n) : all.subarray(n)];
    r.len -= n;
    return ret;
  }
  Readable.prototype.read = function (n) {
    var r = this._r, ret;
    n = n === undefined ? NaN : Number(n);
    if (n === 0) { if (r.ended && r.len === 0) schedulePump(this); else maybeRead(this); return null; }
    ret = takeChunk(this, n);
    r.emittedReadable = false;
    if (ret === null) {
      r.needReadable = true;
      if (r.ended && r.len === 0) endReadable(this); else maybeRead(this);
      return null;
    }
    if (r.ended && r.len === 0) endReadable(this); else maybeRead(this);
    this.emit('data', ret);
    return ret;
  };

  function listenSideEffects(s, ev) {
    var r = s._r;
    if (ev === 'data') {
      r.listening = s.listenerCount('readable') > 0;
      if (r.flowing !== false) s.resume();
    } else if (ev === 'readable' && !r.endEmitted && !r.listening) {
      r.listening = r.needReadable = true; r.flowing = false; r.emittedReadable = false;
      schedulePump(s);
    }
  }
  Readable.prototype.on = Readable.prototype.addListener = function (ev, fn) { EventEmitter.prototype.on.call(this, ev, fn); listenSideEffects(this, ev); return this; };
  Readable.prototype.once = function (ev, fn) { EventEmitter.prototype.once.call(this, ev, fn); listenSideEffects(this, ev); return this; };
  Readable.prototype.resume = function () {
    var r = this._r, s = this;
    if (!r.flowing) {
      r.flowing = !r.listening;
      if (r.flowing) streamTick(function () { if (!s.destroyed && r.flowing) s.emit('resume'); });
    }
    schedulePump(this);
    return this;
  };
  Readable.prototype.pause = function () {
    if (this._r.flowing !== false) { this._r.flowing = false; this.emit('pause'); }
    return this;
  };
  Readable.prototype.isPaused = function () { return this._r.flowing === false; };
  Readable.prototype.setEncoding = function (enc) {
    var r = this._r, d = new StringDecoder(enc), joined = '', i;
    r.decoder = d;
    for (i = 0; i < r.buf.length; i++) joined += typeof r.buf[i] === 'string' ? r.buf[i] : d.write(r.buf[i]);
    r.buf = joined ? [joined] : []; r.len = joined.length;
    return this;
  };

  Readable.prototype.pipe = function (dest, opts) {
    var src = this, r = this._r, blocked = false, rec;
    var doEnd = (!opts || opts.end !== false) && dest !== proc.stdout && dest !== proc.stderr;
    function ondata(chunk) {
      if (dest.write(chunk) === false && !blocked) { blocked = true; r.awaitDrain++; src.pause(); dest.once('drain', ondrain); }
    }
    function ondrain() { if (!blocked) return; blocked = false; if (--r.awaitDrain <= 0) { r.awaitDrain = 0; src.resume(); } }
    function onend() { dest.end(); }
    function cleanup() {
      src.removeListener('data', ondata); src.removeListener('end', onend);
      dest.removeListener('drain', ondrain); dest.removeListener('error', onerror);
      dest.removeListener('close', onclose); dest.removeListener('finish', onfinish);
      if (blocked) { blocked = false; r.awaitDrain = Math.max(0, r.awaitDrain - 1); }
    }
    function unpipe() { var i = r.pipes.indexOf(rec); cleanup(); if (i >= 0) r.pipes.splice(i, 1); dest.emit('unpipe', src); }
    function onerror(er) { unpipe(); if (dest.listenerCount('error') === 0) dest.emit('error', er); }
    function onclose() { dest.removeListener('finish', onfinish); unpipe(); }
    function onfinish() { dest.removeListener('close', onclose); unpipe(); }
    rec = { dest: dest, unpipe: unpipe };
    r.pipes.push(rec);
    src.on('data', ondata);
    src.once('end', doEnd ? onend : unpipe);
    dest.prependListener('error', onerror);
    dest.once('close', onclose); dest.once('finish', onfinish);
    dest.emit('pipe', src);
    if (!r.flowing) src.resume();
    return dest;
  };
  Readable.prototype.unpipe = function (dest) {
    var list = this._r.pipes.slice(), i;
    for (i = 0; i < list.length; i++) if (!dest || list[i].dest === dest) list[i].unpipe();
    return this;
  };

  Object.defineProperties(Readable.prototype, {
    readableFlowing: { get: function () { return this._r.flowing; } },
    readableLength: { get: function () { return this._r.len; } },
    readableHighWaterMark: { get: function () { return this._r.hwm; } },
    readableEnded: { get: function () { return this._r.endEmitted; } },
    readableObjectMode: { get: function () { return this._r.om; } },
    readableEncoding: { get: function () { return this._r.decoder ? this._r.decoder.encoding : null; } }
  });

  Readable.from = function (iterable, opts) {
    var it, rd, busy = false;
    if (iterable === null || iterable === undefined) throw sErr(TypeError, 'ERR_INVALID_ARG_TYPE', 'The "iterable" argument must be an instance of Iterable. Received ' + describeVal(iterable));
    if (typeof iterable === 'string' || iterable instanceof Uint8Array) iterable = [iterable];
    it = iterable[Symbol.asyncIterator] ? iterable[Symbol.asyncIterator]() : iterable[Symbol.iterator]();
    rd = new Readable(Object.assign({ objectMode: true, highWaterMark: 1 }, opts));
    rd._read = function () {
      if (busy) return;
      busy = true;
      Promise.resolve().then(function () { return it.next(); }).then(function (res) {
        if (res.done) { busy = false; rd.push(null); return undefined; }
        return Promise.resolve(res.value).then(function (v) {
          busy = false;
          if (v === null) throw sErr(TypeError, 'ERR_STREAM_NULL_VALUES', 'May not write null values to stream');
          rd.push(v);
        });
      }).catch(function (e) { busy = false; rd.destroy(e); });
    };
    return rd;
  };

  if (typeof Symbol === 'function' && Symbol.asyncIterator) {
    Readable.prototype[Symbol.asyncIterator] = function () {
      var s = this, q = [], wake = null, done = false, err = null, it;
      function poke() { var w = wake; wake = null; if (w) w(); }
      s.on('data', function (c) { q.push(c); s.pause(); poke(); });
      s.on('end', function () { done = true; poke(); });
      s.on('error', function (e) { err = e; poke(); });
      s.on('close', function () { if (!done && !err) err = sErr(Error, 'ERR_STREAM_PREMATURE_CLOSE', 'Premature close'); poke(); });
      it = {
        next: function () {
          return new Promise(function (resolve, reject) {
            (function step() {
              if (q.length) { resolve({ value: q.shift(), done: false }); return; }
              if (err) { reject(err); return; }
              if (done) { resolve({ value: undefined, done: true }); return; }
              wake = step; s.resume();
            })();
          });
        },
        'return': function () { s.destroy(); return Promise.resolve({ value: undefined, done: true }); }
      };
      it[Symbol.asyncIterator] = function () { return this; };
      return it;
    };
  }
