/*!
 * RPG Runner - NW.js / Node compatibility layer (part 1: core).
 * Injected by the local game server before any script of the game runs.
 * Inputs: window.__RR_CONFIG (/__rr/config.js) and window.RRNative (Android JS interface, may be absent).
 */
(function (global) {
  'use strict';
  if (global.__RR && global.__RR.loaded) return;

  var CFG = global.__RR_CONFIG || {};
  var N = global.RRNative || null;
  var RR = global.__RR = { loaded: true, version: '0.2.1', cfg: CFG, native: N, paused: false, modules: {}, lazy: {} };

  // ------------------------------------------------------------------ logging / errors
  var warned = {};
  function nlog(level, msg) {
    try { if (N && typeof N.log === 'function') N.log(level, String(msg).slice(0, 4000)); } catch (e) { /* ignore */ }
  }
  RR.log = nlog;
  RR.warnOnce = function (key, msg) {
    if (warned[key]) return;
    warned[key] = true;
    nlog('W', msg || key);
  };

  var ERR_TEXT = { ENOENT: 'no such file or directory', EACCES: 'permission denied', EEXIST: 'file already exists',
    EISDIR: 'illegal operation on a directory', ENOTDIR: 'not a directory', ENOTEMPTY: 'directory not empty',
    EIO: 'i/o error', EINVAL: 'invalid argument', EFBIG: 'file too large', ENOSYS: 'function not implemented', EBADF: 'bad file descriptor' };
  var ERR_NUM = { ENOENT: -2, EIO: -5, EBADF: -9, EACCES: -13, EEXIST: -17, ENOTDIR: -20, EISDIR: -21, EINVAL: -22, EFBIG: -27, ENOSYS: -38, ENOTEMPTY: -39 };
  function fsError(code, syscall, p) {
    var e = new Error(code + ': ' + (ERR_TEXT[code] || 'error') + ', ' + syscall + (p ? " '" + p + "'" : ''));
    e.code = code; e.errno = ERR_NUM[code] || -1; e.syscall = syscall;
    if (p) e.path = p;
    return e;
  }
  RR.fsError = fsError;

  // ------------------------------------------------------------------ encodings
  var B64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
  var B64REV = (function () { var t = {}; for (var i = 0; i < 64; i++) t[B64.charAt(i)] = i; t['-'] = 62; t['_'] = 63; return t; })();
  function b64enc(u8) {
    var out = [], chunk = '', i = 0, n = u8.length, v;
    for (; i + 2 < n; i += 3) {
      v = (u8[i] << 16) | (u8[i + 1] << 8) | u8[i + 2];
      chunk += B64.charAt(v >> 18) + B64.charAt((v >> 12) & 63) + B64.charAt((v >> 6) & 63) + B64.charAt(v & 63);
      if (chunk.length >= 8192) { out.push(chunk); chunk = ''; }
    }
    if (i < n) {
      var two = i + 1 < n;
      v = (u8[i] << 16) | ((two ? u8[i + 1] : 0) << 8);
      chunk += B64.charAt(v >> 18) + B64.charAt((v >> 12) & 63) + (two ? B64.charAt((v >> 6) & 63) : '=') + '=';
    }
    out.push(chunk);
    return out.join('');
  }
  function b64dec(s) {
    var clean = String(s).replace(/[^A-Za-z0-9+\/_-]/g, '');
    var n = clean.length, outLen = (n * 3) >> 2, out = new Uint8Array(outLen), o = 0, acc = 0, bits = 0;
    for (var i = 0; i < n; i++) {
      acc = (acc << 6) | B64REV[clean.charAt(i)];
      bits += 6;
      if (bits >= 8) { bits -= 8; out[o++] = (acc >> bits) & 255; acc &= (1 << bits) - 1; }
    }
    return o === outLen ? out : out.subarray(0, o);
  }
  var TE = typeof TextEncoder === 'function' ? new TextEncoder() : null;
  var TD = typeof TextDecoder === 'function' ? new TextDecoder('utf-8', { ignoreBOM: true }) : null;
  function utf8enc(s) {
    if (TE) return TE.encode(s);
    var u = unescape(encodeURIComponent(s)), o = new Uint8Array(u.length);
    for (var i = 0; i < u.length; i++) o[i] = u.charCodeAt(i);
    return o;
  }
  function utf8dec(u8) {
    if (TD) return TD.decode(u8);
    var s = '';
    for (var i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i]);
    try { return decodeURIComponent(escape(s)); } catch (e) { return s; }
  }
  function latin1dec(u8) {
    var out = [];
    for (var i = 0; i < u8.length; i += 8192) out.push(String.fromCharCode.apply(null, u8.subarray(i, Math.min(u8.length, i + 8192))));
    return out.join('');
  }
  var HEX = (function () { var t = []; for (var i = 0; i < 256; i++) t.push((i < 16 ? '0' : '') + i.toString(16)); return t; })();
  function normEnc(e) {
    e = String(e || 'utf8').toLowerCase();
    if (e === 'utf-8') return 'utf8';
    if (e === 'binary') return 'latin1';
    if (e === 'ucs2' || e === 'ucs-2' || e === 'utf-16le') return 'utf16le';
    return e;
  }
  function strToBytes(s, enc) {
    var i, o;
    switch (normEnc(enc)) {
      case 'utf8': return utf8enc(s);
      case 'hex':
        o = new Uint8Array(s.length >> 1);
        for (i = 0; i < o.length; i++) {
          var b = parseInt(s.substr(i * 2, 2), 16);
          if (b !== b) return o.subarray(0, i);
          o[i] = b;
        }
        return o;
      case 'base64': case 'base64url': return b64dec(s);
      case 'latin1': case 'ascii':
        o = new Uint8Array(s.length);
        for (i = 0; i < s.length; i++) o[i] = s.charCodeAt(i) & 255;
        return o;
      case 'utf16le':
        o = new Uint8Array(s.length * 2);
        for (i = 0; i < s.length; i++) { var c = s.charCodeAt(i); o[i * 2] = c & 255; o[i * 2 + 1] = c >> 8; }
        return o;
    }
    throw new TypeError('Unknown encoding: ' + enc);
  }
  function bytesToStr(u8, enc) {
    var i, s;
    switch (normEnc(enc)) {
      case 'utf8': return utf8dec(u8);
      case 'hex': s = ''; for (i = 0; i < u8.length; i++) s += HEX[u8[i]]; return s;
      case 'base64': return b64enc(u8);
      case 'base64url': return b64enc(u8).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
      case 'latin1': return latin1dec(u8);
      case 'ascii': s = ''; for (i = 0; i < u8.length; i++) s += String.fromCharCode(u8[i] & 127); return s;
      case 'utf16le': s = ''; for (i = 0; i + 1 < u8.length; i += 2) s += String.fromCharCode(u8[i] | (u8[i + 1] << 8)); return s;
    }
    throw new TypeError('Unknown encoding: ' + enc);
  }
  RR.b64enc = b64enc; RR.b64dec = b64dec; RR.utf8enc = utf8enc; RR.utf8dec = utf8dec;
  RR.strToBytes = strToBytes; RR.bytesToStr = bytesToStr;

  // ------------------------------------------------------------------ Buffer (Uint8Array subclass)
  var Buffer = (function () {
    class Buffer extends Uint8Array {
      static from(v, a, b) {
        var o, i;
        if (typeof v === 'string') { var bytes = strToBytes(v, a); o = new Buffer(bytes.length); o.set(bytes); return o; }
        if (v instanceof ArrayBuffer) return new Buffer(v, a === undefined ? 0 : a, b === undefined ? v.byteLength - (a || 0) : b);
        if (v && v.type === 'Buffer' && Array.isArray(v.data)) v = v.data;
        if (ArrayBuffer.isView(v) && !(v instanceof Uint8Array)) return new Buffer(v.buffer, v.byteOffset, v.byteLength);
        if (v && typeof v.length === 'number') {
          o = new Buffer(v.length);
          for (i = 0; i < v.length; i++) o[i] = v[i] & 255;
          return o;
        }
        throw new TypeError('The first argument must be of type string or an instance of Buffer, ArrayBuffer, or Array or an Array-like Object.');
      }
      static alloc(n, fill, enc) { var o = new Buffer(n); if (fill !== undefined && fill !== 0) o.fill(fill, 0, n, enc); return o; }
      static allocUnsafe(n) { return new Buffer(n); }
      static allocUnsafeSlow(n) { return new Buffer(n); }
      static isBuffer(b) { return b instanceof Buffer; }
      static isEncoding(e) { try { normEnc(e); strToBytes('', e); return true; } catch (x) { return false; } }
      static byteLength(s, enc) { return typeof s === 'string' ? strToBytes(s, enc).length : s.byteLength; }
      static concat(list, total) {
        var n = 0, i;
        for (i = 0; i < list.length; i++) n += list[i].length;
        if (total === undefined) total = n;
        var o = new Buffer(total), pos = 0;
        for (i = 0; i < list.length && pos < total; i++) {
          var part = list[i].length > total - pos ? list[i].subarray(0, total - pos) : list[i];
          o.set(part, pos); pos += part.length;
        }
        return o;
      }
      static compare(a, b) {
        var n = Math.min(a.length, b.length);
        for (var i = 0; i < n; i++) if (a[i] !== b[i]) return a[i] < b[i] ? -1 : 1;
        return a.length < b.length ? -1 : (a.length > b.length ? 1 : 0);
      }
      toString(enc, start, end) {
        start = start === undefined ? 0 : Math.max(0, start | 0);
        end = end === undefined ? this.length : Math.min(this.length, end | 0);
        return bytesToStr(start === 0 && end === this.length ? this : this.subarray(start, end), enc);
      }
      toJSON() { return { type: 'Buffer', data: Array.prototype.slice.call(this) }; }
      equals(o) { return Buffer.compare(this, o) === 0; }
      compare(o) { return Buffer.compare(this, o); }
      slice(s, e) { return this.subarray(s, e); }
      copy(target, ts, ss, se) {
        ts = ts || 0; ss = ss || 0; se = se === undefined ? this.length : se;
        var part = this.subarray(ss, se);
        if (part.length > target.length - ts) part = part.subarray(0, target.length - ts);
        target.set(part, ts);
        return part.length;
      }
      fill(v, s, e, enc) {
        if (typeof s === 'string') { enc = s; s = 0; e = this.length; }
        s = s === undefined ? 0 : s; e = e === undefined ? this.length : e;
        if (typeof v === 'string') {
          var pat = strToBytes(v, enc);
          if (pat.length === 0) return super.fill(0, s, e);
          for (var i = s, k = 0; i < e; i++, k++) this[i] = pat[k % pat.length];
          return this;
        }
        return super.fill(v & 255, s, e);
      }
      write(str, off, len, enc) {
        if (typeof off === 'string') { enc = off; off = 0; len = undefined; } else if (typeof len === 'string') { enc = len; len = undefined; }
        off = off || 0;
        var bytes = strToBytes(str, enc);
        var n = Math.min(bytes.length, this.length - off, len === undefined ? Infinity : len);
        this.set(bytes.subarray(0, n), off);
        return n;
      }
      indexOf(v, from, enc) {
        if (typeof v === 'number') return super.indexOf(v & 255, from);
        var pat = typeof v === 'string' ? strToBytes(v, enc) : v;
        for (var i = from || 0; i + pat.length <= this.length; i++) {
          var k = 0;
          while (k < pat.length && this[i + k] === pat[k]) k++;
          if (k === pat.length) return i;
        }
        return -1;
      }
      includes(v, from, enc) { return this.indexOf(v, from, enc) !== -1; }
      readUInt8(o) { return this[o || 0]; }
      readInt8(o) { var v = this[o || 0]; return v > 127 ? v - 256 : v; }
      readUInt16LE(o) { o = o || 0; return this[o] | (this[o + 1] << 8); }
      readUInt16BE(o) { o = o || 0; return (this[o] << 8) | this[o + 1]; }
      readInt16LE(o) { var v = this.readUInt16LE(o); return v > 32767 ? v - 65536 : v; }
      readInt16BE(o) { var v = this.readUInt16BE(o); return v > 32767 ? v - 65536 : v; }
      readUInt32LE(o) { o = o || 0; return (this[o] | (this[o + 1] << 8) | (this[o + 2] << 16)) + this[o + 3] * 16777216; }
      readUInt32BE(o) { o = o || 0; return this[o] * 16777216 + ((this[o + 1] << 16) | (this[o + 2] << 8) | this[o + 3]); }
      readInt32LE(o) { o = o || 0; return this[o] | (this[o + 1] << 8) | (this[o + 2] << 16) | (this[o + 3] << 24); }
      readInt32BE(o) { o = o || 0; return (this[o] << 24) | (this[o + 1] << 16) | (this[o + 2] << 8) | this[o + 3]; }
      writeUInt8(v, o) { o = o || 0; this[o] = v; return o + 1; }
      writeUInt16LE(v, o) { o = o || 0; this[o] = v; this[o + 1] = v >>> 8; return o + 2; }
      writeUInt16BE(v, o) { o = o || 0; this[o] = v >>> 8; this[o + 1] = v; return o + 2; }
      writeUInt32LE(v, o) { o = o || 0; this[o] = v; this[o + 1] = v >>> 8; this[o + 2] = v >>> 16; this[o + 3] = v >>> 24; return o + 4; }
      writeUInt32BE(v, o) { o = o || 0; this[o] = v >>> 24; this[o + 1] = v >>> 16; this[o + 2] = v >>> 8; this[o + 3] = v; return o + 4; }
      writeInt32LE(v, o) { return this.writeUInt32LE(v >>> 0, o); }
      writeInt32BE(v, o) { return this.writeUInt32BE(v >>> 0, o); }
    }
    return Buffer;
  })();
  RR.Buffer = Buffer;
  if (typeof global.Buffer === 'undefined') global.Buffer = Buffer;

  RR.toBytes = function (data, enc) {
    if (typeof data === 'string') return strToBytes(data, enc);
    if (data instanceof Uint8Array) return data;
    if (data instanceof ArrayBuffer) return new Uint8Array(data);
    if (ArrayBuffer.isView(data)) return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    if (data === null || data === undefined) throw new TypeError('data must not be null or undefined');
    return strToBytes(String(data), enc);
  };
