  // ------------------------------------------------------------------ fs: file descriptors
  // openSync / readSync / writeSync / fstatSync / ftruncateSync / fsyncSync / closeSync on top of the path based bridge. A file is
  // loaded into memory when it is first read or modified and written back as a whole on close / fsync / after a short idle time;
  // every path based call flushes pending data first (see nativeCall), so other code always sees what was written.
  (function (c) { for (var k in c) fs.constants[k] = c[k]; })({ O_RDONLY: 0, O_WRONLY: 1, O_RDWR: 2, O_CREAT: 64, O_EXCL: 128, O_TRUNC: 512,
    O_APPEND: 1024, O_SYNC: 1052672, O_DIRECTORY: 65536, S_IFMT: 61440, S_IFREG: 32768, S_IFDIR: 16384, UV_FS_COPYFILE_EXCL: 1 });

  var fdTable = {}, nextFd = 24, flushTimer = 0;

  function flushEntry(e) {
    if (!e.dirty) return;
    if (e.gone) { e.dirty = false; dirtyFds--; return; } // its file was deleted meanwhile: nothing to write back
    var was = flushing;
    flushing = true;
    e.dirty = false; dirtyFds--;
    try {
      nativeCall('writeBase64', 'write', e.p, b64enc(e.data.subarray(0, e.size)), false);
    } catch (err) {
      e.err = err;
      nlog('W', 'fs write-back failed: ' + e.p + ' ' + err.message);
    } finally { flushing = was; }
  }
  flushAll = function () {
    var k;
    if (flushing) return;
    flushing = true;
    try { for (k in fdTable) flushEntry(fdTable[k]); } finally { flushing = false; }
  };
  // a file that is deleted or moved while a descriptor is open: the descriptor keeps following the file, like on a real file system
  fdPathHook = function (name, p, to) {
    var k, e, pre = p + '/';
    for (k in fdTable) {
      e = fdTable[k];
      if (name === 'rename') { if (e.p === p) e.p = to; else if (e.p.indexOf(pre) === 0) e.p = to + e.p.slice(p.length); }
      else if (name === 'unlink' ? e.p === p : e.p.indexOf(pre) === 0) e.gone = true;
    }
  };
  function raiseFlushError(e) { if (e.err) { var er = e.err; e.err = null; throw er; } }
  function markDirty(e) {
    e.mtime = Date.now();
    if (!e.dirty) { e.dirty = true; dirtyFds++; }
    if (!flushTimer) flushTimer = setTimeout(function () { flushTimer = 0; flushAll(); }, 300);
  }
  if (global.addEventListener) {
    global.addEventListener('pagehide', function () { flushAll(); });
    global.addEventListener('visibilitychange', function () { if (global.document && global.document.visibilityState === 'hidden') flushAll(); });
  }
  RR.flushFiles = function () { flushAll(); };

  function argTypeErr(name, what, v) {
    return sErr(TypeError, 'ERR_INVALID_ARG_TYPE', 'The "' + name + '" argument must be ' + what + '. Received ' + describeVal(v));
  }
  function rangeErr(name, range, v) {
    return sErr(RangeError, 'ERR_OUT_OF_RANGE', 'The value of "' + name + '" is out of range. It must be ' + range + '. Received ' + v);
  }
  function getFd(fd, syscall) {
    if (typeof fd !== 'number') throw argTypeErr('fd', 'of type number', fd);
    var e = fdTable[fd];
    if (!e) throw fsError('EBADF', syscall);
    return e;
  }
  function parseFlags(f) {
    var r = { read: true, write: false, append: false, create: false, excl: false, trunc: false }, s, plus, kind;
    if (f === undefined || f === null) return r;
    if (typeof f === 'number') {
      kind = f & 3;
      r.read = kind !== 1; r.write = kind !== 0; r.append = !!(f & 1024); r.create = !!(f & 64); r.excl = !!(f & 128); r.trunc = !!(f & 512);
      return r;
    }
    s = String(f);
    if (!/^(?:rs?\+?|sr\+?|wx?\+?|xw\+?|a[sx]?\+?|[sx]a\+?)$/.test(s)) {
      throw sErr(TypeError, 'ERR_INVALID_ARG_VALUE', "The argument 'flags' is invalid. Received '" + s + "'");
    }
    plus = s.indexOf('+') >= 0;
    kind = s.replace(/[sx+]/g, '');
    r.excl = s.indexOf('x') >= 0;
    if (kind === 'r') { r.write = plus; } else if (kind === 'w') { r.write = true; r.read = plus; r.create = true; r.trunc = true; } else { r.write = true; r.append = true; r.read = plus; r.create = true; }
    return r;
  }
  function quietStat(p, syscall) { // like statSync but a missing file is a normal answer (null), not a logged failure
    var r;
    if (!N || typeof N.stat !== 'function') throw fsError('ENOSYS', syscall, p);
    if (dirtyFds && !flushing) flushAll();
    r = N.stat(p);
    if (typeof r === 'string' && r.charAt(0) === '!') {
      if (r === '!ENOENT') return null;
      throw fsError(r.slice(1), syscall, p);
    }
    return JSON.parse(r);
  }
  function openFd(p, flags) {
    var q = pstr(p), fl = parseFlags(flags), st = quietStat(q, 'open'), e, fresh = false, fd;
    if (st && st.d) throw fsError('EISDIR', 'open', q);
    if (st && fl.create && fl.excl) throw fsError('EEXIST', 'open', q);
    if (!st) {
      if (!fl.create) { logMiss('fail', 'open', q, 'ENOENT'); throw fsError('ENOENT', 'open', q); }
      nativeCall('writeBase64', 'open', q, '', false); // creates the empty file (ENOENT when its folder is missing)
      fresh = true;
    } else if (fl.trunc) {
      nativeCall('writeBase64', 'open', q, '', false);
      fresh = true;
    }
    e = { p: q, fl: fl, pos: 0, data: fresh ? new Uint8Array(0) : null, size: fresh ? 0 : st.s, mtime: st ? st.m : Date.now(), loaded: fresh, dirty: false, err: null };
    fd = nextFd++;
    fdTable[fd] = e;
    return fd;
  }
  function ensureLoaded(e) {
    if (e.loaded) return;
    var raw = xhrRead(e.p, false), n = raw.length, u8 = new Uint8Array(n), i;
    for (i = 0; i < n; i++) u8[i] = raw.charCodeAt(i) & 255;
    e.data = u8; e.size = n; e.loaded = true;
  }
  function growTo(e, n) {
    var bigger;
    if (n <= e.data.length) return;
    bigger = new Uint8Array(Math.max(n, e.data.length * 2, 1024));
    bigger.set(e.data.subarray(0, e.size));
    e.data = bigger;
  }
  function isPos(position) { return (typeof position === 'number' && position >= 0) || (typeof position === 'bigint' && position >= 0); }
  function byteView(buf) {
    if (buf instanceof Uint8Array) return buf;
    if (ArrayBuffer.isView(buf)) return new Uint8Array(buf.buffer, buf.byteOffset, buf.byteLength);
    return null;
  }

  function readFd(fd, view, off, len, position) {
    var e = getFd(fd, 'read'), at, n;
    if (!e.fl.read) throw fsError('EBADF', 'read');
    if (len === 0) return 0;
    ensureLoaded(e);
    at = isPos(position) ? Number(position) : e.pos;
    n = Math.max(0, Math.min(len, e.size - at));
    if (n > 0) view.set(e.data.subarray(at, at + n), off);
    if (!isPos(position)) e.pos = at + n;
    return n;
  }
  function writeFd(fd, bytes, position) {
    var e = getFd(fd, 'write'), at, end;
    if (!e.fl.write) throw fsError('EBADF', 'write');
    ensureLoaded(e);
    at = e.fl.append ? e.size : isPos(position) ? Number(position) : e.pos;
    end = at + bytes.length;
    growTo(e, end);
    e.data.set(bytes, at);
    if (end > e.size) e.size = end;
    if (e.fl.append || !isPos(position)) e.pos = end;
    markDirty(e);
    return bytes.length;
  }
  function truncFd(fd, len) {
    var e = getFd(fd, 'ftruncate');
    if (len === undefined || len === null) len = 0;
    if (typeof len !== 'number') throw argTypeErr('len', 'of type number', len);
    if (len !== Math.floor(len)) throw rangeErr('len', 'an integer', len);
    len = Math.max(0, len); // like Node, a negative length means 0
    if (!e.fl.write) throw fsError('EINVAL', 'ftruncate');
    if (len === 0 && !e.loaded) { e.data = new Uint8Array(0); e.size = 0; e.loaded = true; } else ensureLoaded(e);
    if (len < e.size) e.data.fill(0, len, e.size); else growTo(e, len);
    e.size = len;
    markDirty(e);
  }
  function syncFd(fd) {
    var e = getFd(fd, 'fsync');
    flushEntry(e);
    raiseFlushError(e);
  }
  function closeFd(fd) {
    var e = getFd(fd, 'close');
    flushEntry(e);
    delete fdTable[fd];
    raiseFlushError(e);
  }

  // (buffer, offset | options, length, position) -> { view, off, len, pos }
  function readArgs(buffer, a, b, c, nargs) {
    var view = byteView(buffer), off = 0, len, pos = null;
    if (!view) throw argTypeErr('buffer', 'an instance of Buffer, TypedArray, or DataView', buffer);
    if (nargs <= 3 && a !== undefined && a !== null && typeof a !== 'object') throw argTypeErr('options', 'of type object', a);
    if (a !== null && a !== undefined && typeof a === 'object') { off = a.offset || 0; len = a.length; pos = a.position === undefined ? null : a.position; }
    else { off = a === undefined ? 0 : a; len = b; pos = c === undefined ? null : c; }
    if (typeof off !== 'number') throw argTypeErr('offset', 'of type number', off);
    if (off < 0 || off > view.length) throw rangeErr('offset', '>= 0 && <= ' + view.length, off);
    if (len === undefined) len = view.length - off;
    if (typeof len !== 'number') throw argTypeErr('length', 'of type number', len);
    if (len < 0 || off + len > view.length) throw rangeErr('length', '>= 0 && <= ' + (view.length - off), len);
    return { view: view, off: off, len: len, pos: pos };
  }
  // (buffer, offset | options, length, position) or (string, position, encoding) -> { bytes, pos }
  function writeArgs(data, a, b, c) {
    var view, off, len, pos = null;
    if (typeof data === 'string') {
      if (a !== null && a !== undefined && typeof a === 'object') { pos = a.position === undefined ? null : a.position; b = a.encoding; } else { pos = a === undefined ? null : a; }
      return { bytes: strToBytes(data, typeof b === 'string' ? b : 'utf8'), pos: pos };
    }
    view = byteView(data);
    if (!view) throw argTypeErr('buffer', 'of type string or an instance of Buffer, TypedArray, or DataView', data);
    if (a !== null && a !== undefined && typeof a === 'object') { off = a.offset || 0; len = a.length; pos = a.position === undefined ? null : a.position; }
    else { off = a === undefined ? 0 : a; len = b; pos = c === undefined ? null : c; }
    if (len === undefined) len = view.length - off;
    if (off < 0 || off > view.length) throw rangeErr('offset', '>= 0 && <= ' + view.length, off);
    if (len < 0 || off + len > view.length) throw rangeErr('length', '>= 0 && <= ' + (view.length - off), len);
    return { bytes: view.subarray(off, off + len), pos: pos };
  }

  fs.openSync = function (p, flags) { return openFd(p, flags); };
  fs.closeSync = function (fd) { closeFd(fd); };
  fs.readSync = function (fd, buffer, a, b, c) { var r = readArgs(buffer, a, b, c, arguments.length); return readFd(fd, r.view, r.off, r.len, r.pos); };
  fs.writeSync = function (fd, data, a, b, c) { var r = writeArgs(data, a, b, c); return writeFd(fd, r.bytes, r.pos); };
  fs.fstatSync = function (fd) { var e = getFd(fd, 'fstat'); return new Stats({ s: e.size, m: e.mtime, d: 0, f: 1 }); };
  fs.ftruncateSync = function (fd, len) { truncFd(fd, len); };
  fs.fsyncSync = fs.fdatasyncSync = function (fd) { syncFd(fd); };
  fs.fchmodSync = fs.fchownSync = fs.futimesSync = function (fd) { getFd(fd, 'fchmod'); };
  fs.truncateSync = function (p, len) {
    var fd = openFd(p, 'r+');
    try { truncFd(fd, len); } finally { closeFd(fd); }
  };
  fs.mkdtempSync = function (prefix) {
    var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', tries, i, s;
    for (tries = 0; tries < 20; tries++) {
      s = String(prefix);
      for (i = 0; i < 6; i++) s += chars.charAt(Math.floor(Math.random() * chars.length));
      try { fs.mkdirSync(s); return s; } catch (e) { if (e.code !== 'EEXIST') throw e; }
    }
    throw fsError('EEXIST', 'mkdtemp', prefix + 'XXXXXX');
  };

  // readFileSync / writeFileSync / appendFileSync also accept a file descriptor
  ['readFileSync', 'writeFileSync', 'appendFileSync'].forEach(function (name) {
    var orig = fs[name];
    fs[name] = function (p, data, o) {
      if (typeof p !== 'number') return orig.apply(fs, arguments);
      var e, enc, bytes, b;
      if (name === 'readFileSync') {
        e = getFd(p, 'read');
        if (!e.fl.read) throw fsError('EBADF', 'read');
        ensureLoaded(e);
        bytes = e.data.slice(e.pos, e.size);
        e.pos = e.size;
        enc = optEnc(data);
        if (enc) return bytesToStr(bytes, normEnc(enc));
        b = new Buffer(bytes.length); b.set(bytes);
        return b;
      }
      writeFd(p, RR.toBytes(data, optEnc(o)), null);
    };
  });
