  // ------------------------------------------------------------------ fs: callback / promise flavours of the descriptor functions, FileHandle, streams
  function later(fn) { setTimeout(fn, 0); }
  function takeCb(args) {
    var cb = args.pop();
    if (typeof cb !== 'function') throw argTypeErr('cb', 'of type function', cb);
    return cb;
  }
  function checkFd(fd) { if (typeof fd !== 'number') throw argTypeErr('fd', 'of type number', fd); }

  fs.open = function (p) {
    var args = Array.prototype.slice.call(arguments), cb = takeCb(args), pp = pstr(args[0]), fl = args[1];
    parseFlags(fl);
    later(function () { var fd; try { fd = openFd(pp, fl); } catch (e) { cb(e); return; } cb(null, fd); });
  };
  fs.close = function (fd, cb) {
    checkFd(fd);
    later(function () { try { closeFd(fd); } catch (e) { if (cb) cb(e); return; } if (cb) cb(null); });
  };
  fs.read = function (fd) {
    var args = Array.prototype.slice.call(arguments, 1), cb = takeCb(args), o, buffer, r;
    checkFd(fd);
    if (!byteView(args[0])) { // read(fd, [options,] cb)
      o = args[0] || {};
      buffer = o.buffer || new Buffer(16384);
      args = [buffer, { offset: o.offset, length: o.length, position: o.position }];
    }
    r = readArgs(args[0], args[1], args[2], args[3], 5);
    later(function () { var n; try { n = readFd(fd, r.view, r.off, r.len, r.pos); } catch (e) { cb(e); return; } cb(null, n, args[0]); });
  };
  fs.write = function (fd, data) {
    var args = Array.prototype.slice.call(arguments, 2), cb = takeCb(args), r;
    checkFd(fd);
    r = writeArgs(data, args[0], args[1], args[2]);
    later(function () { var n; try { n = writeFd(fd, r.bytes, r.pos); } catch (e) { cb(e); return; } cb(null, n, data); });
  };
  fs.fstat = function (fd, cb) {
    checkFd(fd);
    later(function () { var s; try { s = fs.fstatSync(fd); } catch (e) { cb(e); return; } cb(null, s); });
  };
  fs.fsync = fs.fdatasync = function (fd, cb) {
    checkFd(fd);
    later(function () { try { syncFd(fd); } catch (e) { cb(e); return; } cb(null); });
  };
  fs.ftruncate = function (fd, len, cb) {
    if (typeof len === 'function') { cb = len; len = 0; }
    checkFd(fd);
    later(function () { try { truncFd(fd, len); } catch (e) { cb(e); return; } cb(null); });
  };
  fs.truncate = function (p, len, cb) {
    if (typeof len === 'function') { cb = len; len = 0; }
    later(function () { try { fs.truncateSync(p, len); } catch (e) { cb(e); return; } cb(null); });
  };
  fs.mkdtemp = function (prefix, o, cb) {
    if (typeof o === 'function') cb = o;
    later(function () { var d; try { d = fs.mkdtempSync(prefix); } catch (e) { cb(e); return; } cb(null, d); });
  };

  function promised(fn) { return new Promise(function (res, rej) { try { res(fn()); } catch (e) { rej(e); } }); }
  function FileHandle(fd) { this.fd = fd; }
  FileHandle.prototype.read = function (buffer, a, b, c) {
    var self = this;
    return promised(function () {
      var o, r;
      if (!byteView(buffer)) { o = buffer || {}; buffer = o.buffer || new Buffer(16384); a = { offset: o.offset, length: o.length, position: o.position }; }
      r = readArgs(buffer, a, b, c, 5);
      return { bytesRead: readFd(self.fd, r.view, r.off, r.len, r.pos), buffer: buffer };
    });
  };
  FileHandle.prototype.write = function (data, a, b, c) {
    var self = this;
    return promised(function () { var r = writeArgs(data, a, b, c); return { bytesWritten: writeFd(self.fd, r.bytes, r.pos), buffer: data }; });
  };
  FileHandle.prototype.readFile = function (o) { var self = this; return promised(function () { return fs.readFileSync(self.fd, o); }); };
  FileHandle.prototype.writeFile = FileHandle.prototype.appendFile = function (data, o) { var self = this; return promised(function () { fs.writeFileSync(self.fd, data, o); }); };
  FileHandle.prototype.stat = function () { var self = this; return promised(function () { return fs.fstatSync(self.fd); }); };
  FileHandle.prototype.truncate = function (len) { var self = this; return promised(function () { truncFd(self.fd, len); }); };
  FileHandle.prototype.sync = FileHandle.prototype.datasync = function () { var self = this; return promised(function () { syncFd(self.fd); }); };
  FileHandle.prototype.chmod = FileHandle.prototype.chown = FileHandle.prototype.utimes = function () { var self = this; return promised(function () { getFd(self.fd, 'fchmod'); }); };
  FileHandle.prototype.close = function () {
    var self = this;
    return promised(function () { var fd = self.fd; if (fd === -1) return; self.fd = -1; closeFd(fd); });
  };
  FileHandle.prototype.createReadStream = function (o) { return new ReadStream(null, Object.assign({}, o, { fd: this.fd })); };
  FileHandle.prototype.createWriteStream = function (o) { return new WriteStream(null, Object.assign({}, o, { fd: this.fd })); };
  fs.promises.open = function (p, flags) { return promised(function () { return new FileHandle(openFd(p, flags)); }); };
  fs.promises.truncate = function (p, len) { return promised(function () { fs.truncateSync(p, len); }); };
  fs.promises.mkdtemp = function (prefix) { return promised(function () { return fs.mkdtempSync(prefix); }); };
  fs.promises.constants = fs.constants;

  // ReadStream: the descriptor is opened on the next tick ('open', 'ready'), then the file is delivered in highWaterMark sized chunks
  function closeOwned(s, err) {
    if (s.fd !== null && s.autoClose) {
      try { if (fdTable[s.fd]) closeFd(s.fd); } catch (e) { err = err || e; }
      s.fd = null;
    }
    return err;
  }
  function checkRange(name, v) {
    if (typeof v !== 'number') throw argTypeErr(name, 'of type number', v);
    if (v < 0 || v !== Math.floor(v)) throw rangeErr(name, '>= 0 && <= 9007199254740991', v);
  }
  function ReadStream(p, opts) {
    if (!(this instanceof ReadStream)) return new ReadStream(p, opts);
    var self = this;
    opts = typeof opts === 'string' ? { encoding: opts } : Object.assign({}, opts);
    if (opts.highWaterMark === undefined) opts.highWaterMark = 65536;
    Readable.call(this, opts);
    this.fd = typeof opts.fd === 'number' ? opts.fd : null;
    this.path = this.fd === null ? p : undefined;
    this._q = this.fd === null ? pstr(p) : null; // a bad path type throws right away, like in Node
    this.flags = opts.flags === undefined ? 'r' : opts.flags;
    this.mode = opts.mode === undefined ? 438 : opts.mode;
    this.start = opts.start;
    this.end = opts.end === undefined ? Infinity : opts.end;
    this.pos = undefined;
    this.bytesRead = 0;
    this.autoClose = opts.autoClose !== false;
    if (this.start !== undefined) { checkRange('start', this.start); this.pos = this.start; }
    if (this.end !== Infinity) {
      checkRange('end', this.end);
      if (this.start !== undefined && this.start > this.end) {
        throw rangeErr('start', '<= "end" (here: ' + this.end + ')', this.start);
      }
    }
    this._opened = this.fd !== null;
    this._wantRead = false;
    if (!this._opened) streamTick(function () { self._open(); });
  }
  util.inherits(ReadStream, Readable);
  ReadStream.prototype._open = function () {
    if (this.destroyed) return;
    try { this.fd = openFd(this._q, this.flags); } catch (e) { this.destroy(e); return; }
    this._opened = true;
    this.emit('open', this.fd);
    this.emit('ready');
    if (this._wantRead) { this._wantRead = false; this._read(this._r.hwm); }
  };
  ReadStream.prototype._read = function (n) {
    var want, buf, got;
    if (!this._opened) { this._wantRead = true; return; }
    if (this.destroyed || this.fd === null) return;
    want = this.pos !== undefined ? Math.min(this.end - this.pos + 1, n) : Math.min(this.end - this.bytesRead + 1, n);
    if (want <= 0) { this.push(null); return; }
    try {
      buf = new Buffer(want);
      got = readFd(this.fd, buf, 0, want, this.pos === undefined ? null : this.pos);
    } catch (e) { this.destroy(e); return; }
    if (got === 0) { this.push(null); return; }
    if (this.pos !== undefined) this.pos += got;
    this.bytesRead += got;
    this.push(got === want ? buf : buf.subarray(0, got));
  };
  ReadStream.prototype._destroy = function (err, cb) { cb(closeOwned(this, err)); };
  ReadStream.prototype.close = function (cb) { if (typeof cb === 'function') finished(this, cb); this.destroy(); };
  Object.defineProperty(ReadStream.prototype, 'pending', { get: function () { return this.fd === null; } });

  function WriteStream(p, opts) {
    if (!(this instanceof WriteStream)) return new WriteStream(p, opts);
    var self = this;
    opts = typeof opts === 'string' ? { encoding: opts } : Object.assign({}, opts);
    opts.decodeStrings = true;
    Writable.call(this, opts);
    if (opts.encoding) this.setDefaultEncoding(opts.encoding);
    this.fd = typeof opts.fd === 'number' ? opts.fd : null;
    this.path = this.fd === null ? p : undefined;
    this.flags = opts.flags === undefined ? 'w' : opts.flags;
    this.mode = opts.mode === undefined ? 438 : opts.mode;
    this.start = opts.start;
    this.pos = undefined;
    this.bytesWritten = 0;
    this.autoClose = opts.autoClose !== false;
    this._openErr = null;
    this._ready = this.fd !== null; // 'pending' stays true until the open has been announced, as in Node
    if (this.start !== undefined) { checkRange('start', this.start); this.pos = this.start; }
    if (this.fd === null) {
      this._q = pstr(p);
      try { this.fd = openFd(this._q, this.flags); } catch (e) { this._openErr = e; }
      streamTick(function () {
        if (self.destroyed) return;
        if (self._openErr) { self.destroy(self._openErr); return; }
        self._ready = true;
        self.emit('open', self.fd);
        self.emit('ready');
      });
    }
  }
  util.inherits(WriteStream, Writable);
  WriteStream.prototype._write = function (chunk, enc, cb) {
    var n;
    if (this._openErr) { cb(this._openErr); return; }
    try { n = writeFd(this.fd, chunk, this.pos === undefined ? null : this.pos); } catch (e) { cb(e); return; }
    this.bytesWritten += n;
    if (this.pos !== undefined) this.pos += n;
    cb();
  };
  WriteStream.prototype._final = function (cb) {
    try { if (this.fd !== null && fdTable[this.fd]) syncFd(this.fd); } catch (e) { cb(e); return; }
    cb();
  };
  WriteStream.prototype._destroy = function (err, cb) { cb(closeOwned(this, err)); };
  WriteStream.prototype.close = function (cb) {
    if (typeof cb === 'function') { if (this._closeEmitted) streamTick(cb); else this.once('close', cb); }
    if (!this.autoClose) this.once('finish', this.destroy);
    this.end();
  };
  WriteStream.prototype.destroySoon = WriteStream.prototype.end;
  Object.defineProperty(WriteStream.prototype, 'pending', { get: function () { return !this._ready; } });

  fs.ReadStream = ReadStream;
  fs.WriteStream = WriteStream;
  fs.createReadStream = function (p, o) { return new ReadStream(p, o); };
  fs.createWriteStream = function (p, o) { return new WriteStream(p, o); };
