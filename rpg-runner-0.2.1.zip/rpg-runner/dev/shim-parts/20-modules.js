
  // ------------------------------------------------------------------ EventEmitter
  function EventEmitter() { this._events = {}; this._max = 10; }
  EventEmitter.defaultMaxListeners = 10;
  EventEmitter.prototype._list = function (n) { return this._events[n] || (this._events[n] = []); };
  EventEmitter.prototype.on = EventEmitter.prototype.addListener = function (n, fn) {
    if (typeof fn !== 'function') throw new TypeError('The "listener" argument must be of type function');
    this._list(n).push({ fn: fn, once: false }); return this;
  };
  EventEmitter.prototype.prependListener = function (n, fn) { this._list(n).unshift({ fn: fn, once: false }); return this; };
  EventEmitter.prototype.once = function (n, fn) { this._list(n).push({ fn: fn, once: true }); return this; };
  EventEmitter.prototype.off = EventEmitter.prototype.removeListener = function (n, fn) {
    var l = this._events[n];
    if (!l) return this;
    for (var i = l.length - 1; i >= 0; i--) if (l[i].fn === fn || l[i].fn.listener === fn) { l.splice(i, 1); break; }
    return this;
  };
  EventEmitter.prototype.removeAllListeners = function (n) { if (n === undefined) this._events = {}; else delete this._events[n]; return this; };
  EventEmitter.prototype.emit = function (n) {
    var l = this._events[n];
    if (!l || !l.length) {
      if (n === 'error') { var er = arguments[1]; throw er instanceof Error ? er : new Error('Unhandled error. (' + er + ')'); }
      return false;
    }
    var args = Array.prototype.slice.call(arguments, 1), copy = l.slice();
    for (var i = 0; i < copy.length; i++) {
      if (copy[i].once) this.removeListener(n, copy[i].fn);
      try { copy[i].fn.apply(this, args); } catch (e) { nlog('E', 'event "' + n + '" listener threw: ' + (e && e.stack || e)); }
    }
    return true;
  };
  EventEmitter.prototype.listeners = function (n) { return (this._events[n] || []).map(function (x) { return x.fn; }); };
  EventEmitter.prototype.listenerCount = function (n) { return (this._events[n] || []).length; };
  EventEmitter.prototype.eventNames = function () { return Object.keys(this._events); };
  EventEmitter.prototype.setMaxListeners = function (n) { this._max = n; return this; };
  EventEmitter.prototype.getMaxListeners = function () { return this._max; };
  EventEmitter.EventEmitter = EventEmitter;

  // ------------------------------------------------------------------ path (POSIX)
  function normalizeParts(parts, abs) {
    var out = [];
    for (var i = 0; i < parts.length; i++) {
      var p = parts[i];
      if (!p || p === '.') continue;
      if (p === '..') { if (out.length && out[out.length - 1] !== '..') out.pop(); else if (!abs) out.push('..'); }
      else out.push(p);
    }
    return out;
  }
  var path = {
    sep: '/', delimiter: ':',
    isAbsolute: function (p) { return String(p).charAt(0) === '/'; },
    normalize: function (p) {
      p = String(p);
      if (!p) return '.';
      var abs = p.charAt(0) === '/', trail = p.charAt(p.length - 1) === '/';
      var s = normalizeParts(p.split('/'), abs).join('/');
      if (!s && !abs) s = '.';
      if (s && trail) s += '/';
      return (abs ? '/' : '') + s;
    },
    join: function () {
      var parts = [];
      for (var i = 0; i < arguments.length; i++) {
        if (typeof arguments[i] !== 'string') throw new TypeError('The "path" argument must be of type string. Received ' + typeof arguments[i]);
        if (arguments[i]) parts.push(arguments[i]);
      }
      return parts.length ? path.normalize(parts.join('/')) : '.';
    },
    resolve: function () {
      var resolved = '', abs = false;
      for (var i = arguments.length - 1; i >= -1 && !abs; i--) {
        var p = i >= 0 ? arguments[i] : (global.process && global.process.cwd ? global.process.cwd() : '/');
        if (typeof p !== 'string') throw new TypeError('The "path" argument must be of type string');
        if (!p) continue;
        resolved = p + '/' + resolved;
        abs = p.charAt(0) === '/';
      }
      var s = normalizeParts(resolved.split('/'), abs).join('/');
      return ((abs ? '/' : '') + s) || '.';
    },
    dirname: function (p) {
      p = String(p);
      if (!p) return '.';
      var end = p.length;
      while (end > 1 && p.charAt(end - 1) === '/') end--;
      var i = p.lastIndexOf('/', end - 1);
      if (i < 0) return '.';
      if (i === 0) return '/';
      while (i > 1 && p.charAt(i - 1) === '/') i--;
      return p.slice(0, i);
    },
    basename: function (p, ext) {
      p = String(p);
      var end = p.length;
      while (end > 1 && p.charAt(end - 1) === '/') end--;
      p = p.slice(0, end);
      var b = p.slice(p.lastIndexOf('/') + 1);
      if (ext && b.length > ext.length && b.slice(-ext.length) === ext) b = b.slice(0, -ext.length);
      return b;
    },
    extname: function (p) {
      var b = path.basename(p), i = b.lastIndexOf('.');
      return (i <= 0) ? '' : b.slice(i);
    },
    relative: function (from, to) {
      from = path.resolve(from).split('/').filter(Boolean);
      to = path.resolve(to).split('/').filter(Boolean);
      var i = 0;
      while (i < from.length && i < to.length && from[i] === to[i]) i++;
      var up = [];
      for (var k = i; k < from.length; k++) up.push('..');
      return up.concat(to.slice(i)).join('/');
    },
    parse: function (p) {
      p = String(p);
      var root = p.charAt(0) === '/' ? '/' : '', base = path.basename(p), ext = path.extname(p);
      var dir = path.dirname(p);
      return { root: root, dir: dir === '.' && p.indexOf('/') < 0 ? '' : dir, base: base, ext: ext, name: ext ? base.slice(0, -ext.length) : base };
    },
    format: function (o) {
      var dir = o.dir || o.root || '', base = o.base || ((o.name || '') + (o.ext || ''));
      if (!dir) return base;
      return dir === o.root ? dir + base : dir + '/' + base;
    },
    toNamespacedPath: function (p) { return p; }
  };
  path.posix = path;
  path.win32 = path;

  // ------------------------------------------------------------------ process
  var stdTty = function (name) {
    return { isTTY: false, columns: 80, rows: 24, fd: name === 'stdout' ? 1 : 2,
      write: function (s) { nlog(name === 'stderr' ? 'W' : 'I', String(s).replace(/\n$/, '')); return true; },
      on: function () { return this; }, once: function () { return this; }, end: function () {}, removeListener: function () { return this; } };
  };
  var ROOT = String(CFG.root || '/');
  var DATA = String(CFG.dataDir || (ROOT + '/.rr-data'));
  var TMP = String(CFG.tmpDir || '/tmp');
  var MAIN = String(CFG.mainHtml || (ROOT + '/index.html'));
  var NWV = String(CFG.nwVersion || '0.78.1');
  var startedAt = Date.now();
  var proc = new EventEmitter();
  var chromeVer = (/Chrome\/([\d.]+)/.exec(global.navigator ? global.navigator.userAgent : '') || [0, '108.0.0.0'])[1];
  var env = { HOME: DATA, USER: 'player', USERNAME: 'player', LOGNAME: 'player', SHELL: '/bin/sh', LANG: 'en_US.UTF-8', PATH: '/usr/bin:/bin',
    TMPDIR: TMP, TEMP: TMP, TMP: TMP, APPDATA: DATA, LOCALAPPDATA: DATA, XDG_CONFIG_HOME: DATA, XDG_DATA_HOME: DATA, PWD: ROOT };
  var mainModule = { id: '.', filename: MAIN, path: path.dirname(MAIN), exports: {}, loaded: true, parent: null, children: [], paths: [], require: null };
  var processProps = {
    platform: String(CFG.platform || 'linux'), arch: 'x64', pid: 4242, ppid: 1, title: 'nw', version: 'v16.14.2',
    versions: { node: '16.14.2', nw: NWV, 'node-webkit': NWV, 'nw-flavor': 'normal', chromium: chromeVer, v8: '10.8.168.21', modules: '93' },
    release: { name: 'node' }, env: env, argv: ['nw', ROOT], execArgv: [], execPath: ROOT + '/nw', exitCode: undefined,
    mainModule: mainModule, config: { variables: {} }, features: {}, stdout: stdTty('stdout'), stderr: stdTty('stderr'), stdin: stdTty('stdin'),
    cwd: function () { return ROOT; }, chdir: function () {}, umask: function () { return 18; },
    uptime: function () { return (Date.now() - startedAt) / 1000; },
    hrtime: function (prev) {
      var t = global.performance && global.performance.now ? global.performance.now() : Date.now() - startedAt;
      var s = Math.floor(t / 1000), ns = Math.floor((t % 1000) * 1e6);
      if (prev) { s -= prev[0]; ns -= prev[1]; if (ns < 0) { s--; ns += 1e9; } }
      return [s, ns];
    },
    memoryUsage: function () {
      var m = global.performance && global.performance.memory;
      return { rss: m ? m.totalJSHeapSize : 0, heapTotal: m ? m.totalJSHeapSize : 0, heapUsed: m ? m.usedJSHeapSize : 0, external: 0, arrayBuffers: 0 };
    },
    cpuUsage: function () { return { user: 0, system: 0 }; },
    nextTick: function (fn) { var a = Array.prototype.slice.call(arguments, 1); Promise.resolve().then(function () { fn.apply(null, a); }); },
    emitWarning: function (w) { nlog('W', 'process warning: ' + (w && w.message || w)); },
    binding: function (n) { throw new Error('No such module: ' + n); },
    kill: function () { return true; }, abort: function () { RR.exit(); },
    exit: function (code) { proc.exitCode = code; try { proc.emit('exit', code || 0); } catch (e) { /* ignore */ } RR.exit(); },
    reallyExit: function () { RR.exit(); }
  };
  processProps.hrtime.bigint = function () {
    var t = processProps.hrtime();
    return typeof BigInt === 'function' ? BigInt(t[0]) * BigInt(1000000000) + BigInt(t[1]) : t[0] * 1e9 + t[1];
  };
  Object.keys(processProps).forEach(function (k) { proc[k] = processProps[k]; });
  mainModule.require = function (n) { return global.require(n); };
  RR.exit = function () {
    try { if (N && typeof N.exit === 'function') { N.exit(); return; } } catch (e) { /* ignore */ }
    try { global.close(); } catch (e2) { /* ignore */ }
  };

  // ------------------------------------------------------------------ fs
  // The Android JS bridge matches Java methods by name AND argument count, so never pass extra/undefined arguments.
  // The first distinct failures go to the log: when a game cannot find a file it expects (a language pack, a plugin resource, ...)
  // the log then names the path. existsSync() probes are counted separately because they are routine.
  var missSeen = {}, missCount = { probe: 0, fail: 0 }, MISS_CAP = { probe: 40, fail: 80 };
  function logMiss(kind, syscall, p, code) {
    var key = kind + ':' + syscall + ':' + p;
    if (missSeen[key] || missCount[kind] >= MISS_CAP[kind]) return;
    missSeen[key] = true;
    missCount[kind]++;
    nlog(kind === 'probe' ? 'I' : 'W', 'fs ' + syscall + (code ? ' ' + code : '') + ': ' + p +
      (missCount[kind] === MISS_CAP[kind] ? '  (further ' + (kind === 'probe' ? 'missing-path probes' : 'fs failures') + ' are not logged)' : ''));
  }
  // Data written through file descriptors (part 23) is kept in memory until close / fsync / a short idle time; every path based call
  // flushes it first so that readFileSync, statSync, rename ... always see what was written.
  var dirtyFds = 0, flushing = false, flushAll = function () {}, fdPathHook = null;
  function nativeCall(name, syscall, p, a, b) {
    var r, n = arguments.length - 3;
    if (dirtyFds && !flushing) flushAll();
    if (!N || typeof N[name] !== 'function') throw fsError('ENOSYS', syscall, p);
    r = n === 0 ? N[name](p) : n === 1 ? N[name](p, a) : N[name](p, a, b);
    if (typeof r === 'string' && r.charAt(0) === '!') { logMiss('fail', syscall, p, r.slice(1)); throw fsError(r.slice(1), syscall, p); }
    if (fdPathHook && (name === 'unlink' || name === 'rmdir' || name === 'rename')) fdPathHook(name, p, a);
    return r;
  }
  function pstr(p, fn) {
    if (p && typeof p === 'object' && typeof p.pathname === 'string') p = decodeURIComponent(p.pathname); // file: URL objects
    if (p instanceof Uint8Array) p = utf8dec(p);
    if (typeof p !== 'string') { var e = new TypeError('The "path" argument must be of type string or an instance of Buffer or URL. Received ' + (p === null ? 'null' : typeof p)); e.code = 'ERR_INVALID_ARG_TYPE'; throw e; }
    if (p.indexOf('file://') === 0) p = decodeURIComponent(p.replace(/^file:\/\/(localhost)?/, ''));
    if (p.charAt(0) !== '/') p = path.resolve(p); // relative to process.cwd(), like Node
    return p;
  }
  function Stats(o) {
    this.size = o.s; this.mtimeMs = o.m; this.mtime = new Date(o.m); this.ctimeMs = o.m; this.ctime = this.mtime;
    this.atimeMs = o.m; this.atime = this.mtime; this.birthtimeMs = o.m; this.birthtime = this.mtime;
    this.mode = o.d ? 16877 : 33188; this.uid = 0; this.gid = 0; this.nlink = 1; this.dev = 0; this.ino = 0; this.blksize = 4096; this.blocks = Math.ceil(o.s / 512);
    this._d = !!o.d; this._f = !!o.f;
  }
  Stats.prototype.isFile = function () { return this._f; };
  Stats.prototype.isDirectory = function () { return this._d; };
  Stats.prototype.isSymbolicLink = Stats.prototype.isFIFO = Stats.prototype.isSocket = Stats.prototype.isBlockDevice = Stats.prototype.isCharacterDevice = function () { return false; };
  function Dirent(name, st) { this.name = name; this._st = st; }
  Dirent.prototype.isFile = function () { return this._st.isFile(); };
  Dirent.prototype.isDirectory = function () { return this._st.isDirectory(); };
  Dirent.prototype.isSymbolicLink = function () { return false; };

  function optEnc(o) { return typeof o === 'string' ? o : (o && o.encoding) || null; }

  function xhrRead(p, asText) {
    if (dirtyFds && !flushing) flushAll();
    var url = global.location.origin + encodeURI(p).replace(/#/g, '%23').replace(/\?/g, '%3F');
    var x = new XMLHttpRequest();
    x.open('GET', url, false);
    x.overrideMimeType(asText ? 'text/plain; charset=utf-8' : 'text/plain; charset=x-user-defined');
    try { x.send(null); } catch (e) { throw fsError('EIO', 'read', p); }
    if (x.status === 404 || x.status === 403) { logMiss('fail', 'open', p, 'ENOENT'); throw fsError('ENOENT', 'open', p); }
    if (x.status !== 200 && x.status !== 0) throw fsError('EIO', 'read', p);
    return x.responseText;
  }

  var fs = {
    constants: { F_OK: 0, R_OK: 4, W_OK: 2, X_OK: 1, COPYFILE_EXCL: 1 }, F_OK: 0, R_OK: 4, W_OK: 2, X_OK: 1,
    Stats: Stats, Dirent: Dirent,
    existsSync: function (p) {
      try {
        var q = pstr(p), yes = nativeCall('exists', 'access', q) === '1';
        if (!yes) logMiss('probe', 'exists', q, 'false');
        return yes;
      } catch (e) { return false; }
    },
    accessSync: function (p) { if (nativeCall('exists', 'access', pstr(p)) !== '1') throw fsError('ENOENT', 'access', p); },
    statSync: function (p, o) {
      p = pstr(p);
      var r;
      try { r = nativeCall('stat', 'stat', p); } catch (e) { if (o && o.throwIfNoEntry === false && e.code === 'ENOENT') return undefined; throw e; }
      return new Stats(JSON.parse(r));
    },
    readdirSync: function (p, o) {
      p = pstr(p);
      var names = JSON.parse(nativeCall('readdir', 'scandir', p));
      if (o && typeof o === 'object' && o.withFileTypes) {
        return names.map(function (n) { return new Dirent(n, fs.statSync(p + '/' + n)); });
      }
      return names;
    },
    readFileSync: function (p, o) {
      p = pstr(p);
      var enc = optEnc(o), e = enc ? normEnc(enc) : null;
      if (e === 'utf8') return xhrRead(p, true);
      var raw = xhrRead(p, false), n = raw.length, u8 = new Uint8Array(n);
      for (var i = 0; i < n; i++) u8[i] = raw.charCodeAt(i) & 255;
      if (e) return bytesToStr(u8, e);
      var b = new Buffer(n); b.set(u8); return b;
    },
    writeFileSync: function (p, data, o) {
      p = pstr(p);
      var enc = optEnc(o), flag = o && typeof o === 'object' ? o.flag : undefined;
      var bytes = RR.toBytes(data, enc);
      nativeCall('writeBase64', 'open', p, b64enc(bytes), flag === 'a' || flag === 'a+');
    },
    appendFileSync: function (p, data, o) {
      p = pstr(p);
      nativeCall('writeBase64', 'open', p, b64enc(RR.toBytes(data, optEnc(o))), true);
    },
    mkdirSync: function (p, o) {
      var rec = !!(o && typeof o === 'object' && o.recursive);
      p = pstr(p);
      nativeCall('mkdir', 'mkdir', p, rec);
      return rec ? p : undefined;
    },
    unlinkSync: function (p) { nativeCall('unlink', 'unlink', pstr(p)); },
    rmdirSync: function (p, o) { nativeCall('rmdir', 'rmdir', pstr(p), !!(o && o.recursive)); },
    rmSync: function (p, o) {
      p = pstr(p);
      var st;
      try { st = fs.statSync(p); } catch (e) { if (o && o.force) return; throw e; }
      if (st.isDirectory()) nativeCall('rmdir', 'rm', p, !!(o && o.recursive)); else nativeCall('unlink', 'rm', p);
    },
    renameSync: function (a, b) { nativeCall('rename', 'rename', pstr(a), pstr(b)); },
    copyFileSync: function (a, b) { nativeCall('copy', 'copyfile', pstr(a), pstr(b)); },
    realpathSync: function (p) { p = pstr(p); fs.accessSync(p); return path.normalize(p); },
    utimesSync: function () {}, chmodSync: function () {}, chownSync: function () {}, symlinkSync: function (a, b) { throw fsError('ENOSYS', 'symlink', b); },
    watch: function () { var w = new EventEmitter(); w.close = function () {}; return w; }, watchFile: function () {}, unwatchFile: function () {},
    openSync: function (p) { throw fsError('ENOSYS', 'open', p); }, closeSync: function () {}
  };
  fs.lstatSync = fs.statSync;
  // callback + promise flavours are generated from the synchronous ones
  ['exists', 'access', 'stat', 'lstat', 'readdir', 'readFile', 'writeFile', 'appendFile', 'mkdir', 'unlink', 'rmdir', 'rm', 'rename', 'copyFile', 'realpath', 'utimes', 'chmod', 'chown'].forEach(function (name) {
    var sync = fs[name + 'Sync'];
    fs[name] = function () {
      var args = Array.prototype.slice.call(arguments), cb = args.pop();
      if (typeof cb !== 'function') throw new TypeError('The "cb" argument must be of type function');
      setTimeout(function () {
        var res, err = null;
        try { res = sync.apply(fs, args); } catch (e) { err = e; }
        if (name === 'exists') cb(!err && res); else if (err) cb(err); else cb(null, res);
      }, 0);
    };
  });
  fs.promises = {};
  ['access', 'stat', 'lstat', 'readdir', 'readFile', 'writeFile', 'appendFile', 'mkdir', 'unlink', 'rmdir', 'rm', 'rename', 'copyFile', 'realpath'].forEach(function (name) {
    var sync = fs[name + 'Sync'];
    fs.promises[name] = function () {
      var args = arguments;
      return new Promise(function (res, rej) { try { res(sync.apply(fs, args)); } catch (e) { rej(e); } });
    };
  });

  // ------------------------------------------------------------------ os, util, misc modules
  var os = {
    EOL: '\n', platform: function () { return proc.platform; }, type: function () { return 'Linux'; }, arch: function () { return 'x64'; },
    release: function () { return '5.10.0'; }, hostname: function () { return 'localhost'; }, homedir: function () { return DATA; },
    tmpdir: function () { return TMP; }, endianness: function () { return 'LE'; }, uptime: function () { return proc.uptime(); },
    totalmem: function () { return (global.navigator && global.navigator.deviceMemory || 4) * 1073741824; },
    freemem: function () { return 536870912; }, loadavg: function () { return [0, 0, 0]; }, networkInterfaces: function () { return {}; },
    cpus: function () {
      var n = global.navigator && global.navigator.hardwareConcurrency || 4, a = [];
      for (var i = 0; i < n; i++) a.push({ model: 'cpu', speed: 2000, times: { user: 0, nice: 0, sys: 0, idle: 0, irq: 0 } });
      return a;
    },
    userInfo: function () { return { username: 'player', uid: 1000, gid: 1000, shell: '/bin/sh', homedir: DATA }; },
    constants: { signals: {}, errno: {} }
  };
  var util = {
    inherits: function (c, s) { c.super_ = s; c.prototype = Object.create(s.prototype, { constructor: { value: c, writable: true, configurable: true } }); },
    format: function (f) {
      var a = Array.prototype.slice.call(arguments, 1), i = 0;
      if (typeof f !== 'string') return [f].concat(a).map(function (x) { return util.inspect(x); }).join(' ');
      var s = f.replace(/%[sdifjoO%]/g, function (m) {
        if (m === '%%') return '%';
        if (i >= a.length) return m;
        var v = a[i++];
        return m === '%s' ? String(v) : (m === '%d' || m === '%i') ? String(parseInt(v, 10)) : m === '%f' ? String(parseFloat(v)) : util.inspect(v);
      });
      for (; i < a.length; i++) s += ' ' + (typeof a[i] === 'string' ? a[i] : util.inspect(a[i]));
      return s;
    },
    inspect: function (v) { if (typeof v === 'string') return "'" + v + "'"; try { return JSON.stringify(v, function (k, x) { return typeof x === 'function' ? '[Function]' : x; }); } catch (e) { return String(v); } },
    promisify: function (fn) { return function () { var a = Array.prototype.slice.call(arguments), self = this; return new Promise(function (res, rej) { a.push(function (err, v) { err ? rej(err) : res(v); }); fn.apply(self, a); }); }; },
    deprecate: function (fn) { return fn; }, isArray: Array.isArray, isDeepStrictEqual: function (a, b) { return JSON.stringify(a) === JSON.stringify(b); },
    TextEncoder: global.TextEncoder, TextDecoder: global.TextDecoder, types: {}
  };
  var urlMod = {
    URL: global.URL, URLSearchParams: global.URLSearchParams,
    parse: function (s) {
      try { var u = new URL(s, 'http://localhost'); return { href: s, protocol: /^[a-z]+:/i.test(s) ? u.protocol : null, host: u.host, hostname: u.hostname, port: u.port || null, pathname: u.pathname, search: u.search, query: u.search.slice(1), hash: u.hash, path: u.pathname + u.search }; }
      catch (e) { return { href: s, pathname: s }; }
    },
    fileURLToPath: function (u) { return decodeURIComponent(String(u && u.pathname || u).replace(/^file:\/\//, '')); },
    pathToFileURL: function (p) { return new URL('file://' + encodeURI(p)); }
  };
  var stubFn = function () { throw new Error('This feature is not available on Android'); };
  var childProcess = {
    exec: function (cmd, o, cb) { cb = typeof o === 'function' ? o : cb; RR.warnOnce('child_process.exec', 'child_process.exec ignored: ' + cmd); if (cb) setTimeout(function () { cb(new Error('child_process is not available on Android'), '', ''); }, 0); return new EventEmitter(); },
    spawn: function (cmd) { RR.warnOnce('child_process.spawn', 'child_process.spawn ignored: ' + cmd); var e = new EventEmitter(); e.stdout = new EventEmitter(); e.stderr = new EventEmitter(); e.kill = function () {}; setTimeout(function () { e.emit('error', new Error('spawn ' + cmd + ' ENOENT')); }, 0); return e; },
    execSync: stubFn, spawnSync: stubFn, execFile: function () { return childProcess.exec.apply(null, arguments); }, fork: stubFn
  };
  // hashes, HMAC, PBKDF2 and the random helpers are added by 26-crypto.js
  var cryptoMod = {
    randomUUID: function () { return global.crypto && global.crypto.randomUUID ? global.crypto.randomUUID() : 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) { var r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 3 | 8)).toString(16); }); }
  };
  var stringDecoder = { StringDecoder: function (enc) { this.write = function (b) { return bytesToStr(b, enc || 'utf8'); }; this.end = function () { return ''; }; } };
  var timersMod = { setTimeout: global.setTimeout.bind(global), setInterval: global.setInterval.bind(global), clearTimeout: global.clearTimeout.bind(global), clearInterval: global.clearInterval.bind(global), setImmediate: function (f) { var a = Array.prototype.slice.call(arguments, 1); return setTimeout(function () { f.apply(null, a); }, 0); }, clearImmediate: global.clearTimeout.bind(global) };
  if (typeof global.setImmediate === 'undefined') global.setImmediate = timersMod.setImmediate;
  var assertMod = function (v, m) { if (!v) throw new Error(m || 'Assertion failed'); };
  assertMod.ok = assertMod; assertMod.equal = function (a, b, m) { if (a != b) throw new Error(m || (a + ' != ' + b)); };
  assertMod.strictEqual = function (a, b, m) { if (a !== b) throw new Error(m || (a + ' !== ' + b)); };
  assertMod.deepStrictEqual = assertMod.deepEqual = function (a, b, m) { if (!util.isDeepStrictEqual(a, b)) throw new Error(m || 'not deep equal'); };
  assertMod.throws = function (fn) { try { fn(); } catch (e) { return; } throw new Error('Missing expected exception'); };
