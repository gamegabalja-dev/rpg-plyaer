package android.content;

public class ContentResolver  { public final java.io.InputStream openInputStream(android.net.Uri uri) throws java.io.FileNotFoundException { return null; } }
