package android.content.pm;

public class PackageInfo  { public String packageName; public String versionName; }
