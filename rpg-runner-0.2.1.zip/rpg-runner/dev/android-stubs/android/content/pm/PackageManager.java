package android.content.pm;
import android.content.pm.PackageInfo;
public class PackageManager  { public static final int PERMISSION_GRANTED = 0; public android.content.Intent getLaunchIntentForPackage(String p) { return null; } public PackageInfo getPackageInfo(String p, int flags) throws NameNotFoundException { return null; } public static class NameNotFoundException extends Exception {} }
