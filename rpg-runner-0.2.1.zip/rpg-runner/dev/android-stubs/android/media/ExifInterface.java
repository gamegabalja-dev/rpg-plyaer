package android.media;

public class ExifInterface  { public static final String TAG_ORIENTATION = "Orientation"; public static final int ORIENTATION_NORMAL = 1; public ExifInterface(java.io.InputStream inputStream) throws java.io.IOException {} public int getAttributeInt(String tag, int defaultValue) { return defaultValue; } }
