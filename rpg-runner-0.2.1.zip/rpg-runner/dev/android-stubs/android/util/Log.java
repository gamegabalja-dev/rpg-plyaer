package android.util;

public class Log  { public static String getStackTraceString(Throwable t) { return ""; } }
