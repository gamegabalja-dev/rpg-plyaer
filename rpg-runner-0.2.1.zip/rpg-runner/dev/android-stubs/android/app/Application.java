package android.app;

public class Application extends android.content.ContextWrapper { public static String getProcessName() { return null; } public void onCreate() {} }
