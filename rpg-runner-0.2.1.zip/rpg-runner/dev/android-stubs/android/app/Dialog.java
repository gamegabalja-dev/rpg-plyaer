package android.app;

public class Dialog  { public void setOnDismissListener(android.content.DialogInterface.OnDismissListener l) {} public void show() {} }
