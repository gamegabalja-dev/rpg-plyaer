package android.app;

public class ActivityManager  { public static class MemoryInfo { public long totalMem; public long availMem; } public void getMemoryInfo(MemoryInfo i) {} public int getMemoryClass() { return 0; } public int getLargeMemoryClass() { return 0; } }
