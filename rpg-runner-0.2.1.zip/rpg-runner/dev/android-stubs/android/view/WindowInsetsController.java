package android.view;

public interface WindowInsetsController  { public static final int BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE = 2; void hide(int types); void setSystemBarsBehavior(int b); }
