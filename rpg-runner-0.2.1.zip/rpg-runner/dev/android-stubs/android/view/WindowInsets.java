package android.view;

public class WindowInsets  { public static final class Type { public static int statusBars() { return 1; } public static int navigationBars() { return 2; } } }
