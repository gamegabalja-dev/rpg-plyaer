package android.view;
import android.view.WindowManager;
public class Window  { public void addFlags(int f) {} public WindowManager.LayoutParams getAttributes() { return null; } public void setAttributes(WindowManager.LayoutParams a) {} public View getDecorView() { return null; } public void setDecorFitsSystemWindows(boolean b) {} public WindowInsetsController getInsetsController() { return null; } }
