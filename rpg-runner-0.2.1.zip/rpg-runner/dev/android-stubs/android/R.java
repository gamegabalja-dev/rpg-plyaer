package android;

public class R  { public static final class string { public static final int ok = 1; public static final int cancel = 2; } }
