package android.webkit;

public class PermissionRequest  { public String[] getResources() { return null; } public void deny() {} }
