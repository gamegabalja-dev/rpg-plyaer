package android.webkit;

public class ConsoleMessage  { public enum MessageLevel { TIP, LOG, WARNING, ERROR, DEBUG } public MessageLevel messageLevel() { return null; } public String message() { return null; } public String sourceId() { return null; } public int lineNumber() { return 0; } }
