package android.webkit;

public class WebChromeClient  { public boolean onConsoleMessage(ConsoleMessage m) { return false; } public boolean onJsAlert(WebView v, String url, String message, JsResult r) { return false; } public boolean onJsConfirm(WebView v, String url, String message, JsResult r) { return false; } public void onPermissionRequest(PermissionRequest r) {} }
