package android.webkit;

public class WebViewClient  { public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; } public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) { return null; } public void onPageFinished(WebView v, String url) {} public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {} public void onReceivedHttpError(WebView v, WebResourceRequest r, WebResourceResponse e) {} public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) { return false; } }
