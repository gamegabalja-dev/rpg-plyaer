package android.os;

public class Bundle  { public String getString(String key, String defaultValue) { return defaultValue; } public void putString(String key, String value) {} }
