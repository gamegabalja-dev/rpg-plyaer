package android.os;

public class Build  { public static final String MANUFACTURER = ""; public static final String MODEL = ""; public static final String[] SUPPORTED_ABIS = {}; public static class VERSION { public static final int SDK_INT = 34; public static final String RELEASE = ""; } }
