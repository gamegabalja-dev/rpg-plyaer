package android.graphics;

public class Bitmap  { public enum CompressFormat { JPEG, PNG, WEBP } public static Bitmap createScaledBitmap(Bitmap src, int dstWidth, int dstHeight, boolean filter) { return null; } public static Bitmap createBitmap(Bitmap source, int x, int y, int width, int height, Matrix m, boolean filter) { return null; } public int getWidth() { return 0; } public int getHeight() { return 0; } public boolean hasAlpha() { return false; } public boolean compress(CompressFormat format, int quality, java.io.OutputStream stream) { return false; } public void recycle() {} }
