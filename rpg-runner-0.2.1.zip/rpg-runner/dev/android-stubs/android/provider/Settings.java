package android.provider;

public class Settings  { public static final String ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION = "a"; public static final String ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION = "b"; }
