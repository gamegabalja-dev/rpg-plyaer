package android.net;

public class Uri  { public static Uri parse(String s) { return null; } public String getHost() { return null; } public String getScheme() { return null; } public String getAuthority() { return null; } public String getPath() { return null; } public java.util.List<String> getPathSegments() { return null; } }
