#!/bin/sh
# Every check that needs neither an Android device nor the Android SDK:
#   1. compiles the whole app source against hand-written Android stubs (type check of the Android classes)
#      together with the desktop test code
#   2. CoreTest: the pure-Java core (JSON, game detection, sandboxed file system, HTTP server, ...)
#   3. bridge-contract: Java @JavascriptInterface methods <-> JavaScript call sites <-> manifest
#      zlib-crypto: the pure-JS zlib / crypto of the shim compared with Node's own implementations
#      aes: the pure-JS AES ciphers (cbc, ecb, ctr) of the shim compared with Node's OpenSSL
#      streams: the shim's streams, file descriptors and file streams compared with real Node, scenario by scenario
#      workflow-zip: the GitHub workflow step that builds from one uploaded project zip (needs bash, zip, unzip)
#   4. launcher + shim/overlay + lag diagnostics (perf.js) tests in a real Chromium (they need the "playwright" npm package and its Chromium;
#      skipped with a note when it is not installed)
#
# Needs: JDK 17+, Node 18+.   Usage: sh dev/run-tests.sh
set -u
cd "$(dirname "$0")/.." || exit 1
OUT=dev/.build/classes
FAILED=0

step() { printf '\n== %s\n' "$1"; }
run() { "$@" || FAILED=$((FAILED + 1)); }

step "compile (Android stubs + app + tests)"
rm -rf "$OUT" && mkdir -p "$OUT"
FILES="$(find dev/android-stubs app/src/main/java dev/test/app -name '*.java')"
# shellcheck disable=SC2086
if javac -encoding UTF-8 -Xlint:all,-serial -proc:none -d "$OUT" $FILES; then
    echo "compiled"
else
    echo "COMPILE FAILED"
    exit 1
fi

step "CoreTest"
LC_ALL=C.UTF-8 LANG=C.UTF-8 run java -Dfile.encoding=UTF-8 -Dsun.jnu.encoding=UTF-8 -cp "$OUT" app.rpgrunner.CoreTest

step "shim.js is in sync with dev/shim-parts + bridge contract"
run node dev/test/bridge-contract.test.js

step "zlib + crypto of the NW.js layer vs Node's own (pure JS, no browser needed)"
run node dev/test/zlib-crypto.test.js

step "AES ciphers of the NW.js layer vs Node's OpenSSL (pure JS, no browser needed)"
run node dev/test/aes.test.js

step "streams, file descriptors and file streams of the NW.js layer vs real Node"
run node dev/test/streams.test.js

step "GitHub workflow: build from one uploaded project zip"
if command -v bash >/dev/null 2>&1; then
    run bash dev/test/workflow-zip.test.sh
else
    echo "skipped: bash is not installed"
fi

if node -e "require('playwright')" >/dev/null 2>&1; then
    step "launcher page (Chromium)"
    run node dev/test/launcher.test.js
    step "NW.js layer + touch overlay + server (Chromium)"
    run node dev/test/shim.test.js
    step "lag diagnostics perf.js (Chromium)"
    run node dev/test/perf.test.js
else
    step "Chromium tests skipped"
    echo "the 'playwright' npm package is not installed: npm i playwright && npx playwright install chromium"
fi

echo
if [ "$FAILED" -eq 0 ]; then
    echo "ALL CHECKS PASSED"
else
    echo "$FAILED check group(s) FAILED"
    exit 1
fi
